package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.no_slot_highlight;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.Slot;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractContainerScreen.class)
public class AbstractContainerScreenMixin {

  @Shadow
  @Nullable
  protected Slot hoveredSlot;

  @Shadow
  @Final
  private static Identifier SLOT_HIGHLIGHT_BACK_SPRITE;

  @Shadow
  @Final
  private static Identifier SLOT_HIGHLIGHT_FRONT_SPRITE;

  @Inject(method = "extractSlotHighlightBack", at = @At("HEAD"), cancellable = true)
  private void cancelSlotHighlightBack(GuiGraphicsExtractor graphics, CallbackInfo ci) {
    if (Config.NO_SLOT_HIGHLIGHT.get()) ci.cancel();
    else if (Config.OFFSET_SLOT_HIGHLIGHT.get()) {
      if (this.hoveredSlot != null && this.hoveredSlot.isHighlightable()) {
        graphics.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT_HIGHLIGHT_BACK_SPRITE, this.hoveredSlot.x - 26 - 4, this.hoveredSlot.y - 4, 24, 24);
      }
      ci.cancel();
    }
  }

  @Inject(method = "extractSlotHighlightFront", at = @At("HEAD"), cancellable = true)
  private void cancelSlotHighlightFront(GuiGraphicsExtractor graphics, CallbackInfo ci) {
    if (Config.NO_SLOT_HIGHLIGHT.get()) ci.cancel();
    else if (Config.OFFSET_SLOT_HIGHLIGHT.get()) {
      if (this.hoveredSlot != null && this.hoveredSlot.isHighlightable()) {
        graphics.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT_HIGHLIGHT_FRONT_SPRITE, this.hoveredSlot.x - 26 - 4, this.hoveredSlot.y - 4, 24, 24);
      }
      ci.cancel();
    }
  }

}
