package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.disable_pause;

import com.mojang.logging.LogUtils;
import net.minecraft.client.server.IntegratedServer;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.io.IOException;
import java.util.function.BooleanSupplier;


@Mixin(IntegratedServer.class)
public abstract class IntegratedServerMixin {

  @Shadow
  private boolean paused;

  @Inject(method = "tickServer", at = @At(value = "FIELD", target = "Lnet/minecraft/client/server/IntegratedServer;paused:Z", ordinal = 0, shift = At.Shift.AFTER, opcode = Opcodes.PUTFIELD))
  private void unpause(BooleanSupplier haveTime, CallbackInfo ci) {
//    LOGGER.info("no you don't lol");
    if (Config.DISABLE_PAUSE.get())
      this.paused = false;
  }

  @Inject(method = "initServer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/server/IntegratedServer;initializeKeyPair()V", shift = At.Shift.AFTER))
  private void preInitServer(CallbackInfoReturnable<Boolean> cir) {
    try {
      Config.loadConfig();
    } catch (IOException e) {
      LogUtils.getLogger().error("I/O error while loading AMTJMTGMA config.", e);
    }
  }

}
