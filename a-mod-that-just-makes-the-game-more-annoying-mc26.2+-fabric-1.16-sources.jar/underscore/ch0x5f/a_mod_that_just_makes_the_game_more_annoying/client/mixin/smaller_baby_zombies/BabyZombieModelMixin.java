package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.smaller_baby_zombies;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshTransformer;
import net.minecraft.client.model.monster.zombie.BabyZombieModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Environment(EnvType.CLIENT)
@Mixin(BabyZombieModel.class)
public abstract class BabyZombieModelMixin {

  @ModifyReturnValue(method = "createBodyLayer", at = @At("RETURN"))
  private static LayerDefinition scaleBody(LayerDefinition original) {
    if (Config.SMALLER_BABY_ZOMBIES.get()) return original.apply(MeshTransformer.scaling(0.5f));
    return original;
  }

}
