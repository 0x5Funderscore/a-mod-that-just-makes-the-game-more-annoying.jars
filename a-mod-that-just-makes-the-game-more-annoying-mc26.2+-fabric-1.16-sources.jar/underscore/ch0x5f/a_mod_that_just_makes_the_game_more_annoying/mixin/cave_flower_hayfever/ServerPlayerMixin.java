package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.cave_flower_hayfever;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("HEAD"))
  private void preTick(CallbackInfo ci) {
    if (Config.CAVE_FLOWER_HAYFEVER.get() && !this.isSpectator()) {
      BlockPos checkPos = BlockPos.containing(this.getEyePosition());
      for (int i = 0; i < 8; i++) {
        if (i > 0) checkPos = checkPos.above();
        BlockState blockState = this.level().getBlockState(checkPos);
        if (blockState.is(Blocks.FLOWERING_AZALEA_LEAVES) || blockState.is(Blocks.SPORE_BLOSSOM)) {
          this.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 160, 0));
          this.addEffect(new MobEffectInstance(MobEffects.POISON, 40, 0));
        } else if (!blockState.propagatesSkylightDown()) break;
      }
    }
  }

}
