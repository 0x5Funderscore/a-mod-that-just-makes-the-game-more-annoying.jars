package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.piglins_blow_up;

import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinAi;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(PiglinAi.class)
public abstract class PiglinAiMixin {
  @ModifyArgs(
      method = "stopHoldingOffHandItem",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/entity/monster/piglin/PiglinAi;throwItems(Lnet/minecraft/world/entity/monster/piglin/Piglin;Ljava/util/List;)V",
          ordinal = 0
      )
  )
  private static void checkIfPiglinShouldBlowUp(Args args) {
    if (!Config.PIGLINS_BLOW_UP.get()) return;
    Piglin body = args.get(0);
    List<ItemStack> itemStacks = args.get(1);
    if (itemStacks.stream().noneMatch(stack -> stack.is(Items.ENDER_PEARL))) {
      body.level().explode(null, body.getX(), body.getY(), body.getZ(), 9f, Level.ExplosionInteraction.MOB);
    }
  }
}
