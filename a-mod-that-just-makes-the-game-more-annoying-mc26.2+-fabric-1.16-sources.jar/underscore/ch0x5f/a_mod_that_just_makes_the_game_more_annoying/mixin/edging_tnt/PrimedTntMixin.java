package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.edging_tnt;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(PrimedTnt.class)
public abstract class PrimedTntMixin extends Entity {

  public PrimedTntMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Inject(method = "setFuse", at = @At("HEAD"), cancellable = true)
  private void cancelSetFuse(int time, CallbackInfo ci) {
    if (Config.EDGING_TNT.get()) {
      if (time <= 1) {
        Level level = this.level();
        if (!level.isClientSide()) {
          if (level.getNearestPlayer(this, 4d) == null && level.getNearestPlayer(this, 32d) != null) ci.cancel();
        }
      }
    }
  }

}
