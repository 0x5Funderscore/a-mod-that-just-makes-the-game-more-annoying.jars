package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.iron_golem_extended_reach;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.golem.AbstractGolem;
import net.minecraft.world.entity.animal.golem.IronGolem;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(IronGolem.class)
public abstract class IronGolemMixin extends AbstractGolem {

  protected IronGolemMixin(EntityType<? extends AbstractGolem> type, Level level) {
    super(type, level);
  }

  @Override
  public boolean isWithinMeleeAttackRange(@NonNull LivingEntity target) {
    if (Config.IRON_GOLEM_EXTENDED_REACH.get()) {
      double maxRange = 2.1d;
      AABB hitbox = target.getHitbox();
      return this.getAttackBoundingBox(maxRange).expandTowards(0d, 1.5d, 0d).intersects(hitbox);
    } else {
      return super.isWithinMeleeAttackRange(target);
    }
  }
}
