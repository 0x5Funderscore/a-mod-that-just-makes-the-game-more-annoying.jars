package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.shulker_machine_guns;

import net.minecraft.world.entity.monster.Shulker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Shulker.ShulkerAttackGoal.class)
public class Shulker$ShulkerAttackGoalMixin {

  @Shadow
  private int attackTime;

  @Inject(method = "tick", at = @At("HEAD"))
  private void tickStart(CallbackInfo ci) {
    if (Config.SHULKER_MACHINE_GUNS.get()) this.attackTime = 0;
  }

}
