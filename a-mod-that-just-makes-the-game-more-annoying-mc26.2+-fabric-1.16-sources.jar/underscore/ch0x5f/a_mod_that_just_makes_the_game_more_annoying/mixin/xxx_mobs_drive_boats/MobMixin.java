package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_mobs_drive_boats;

import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(Mob.class)
public class MobMixin {

  /*
  @Definition(id = "getVehicle", method = "Lnet/minecraft/world/entity/Mob;getVehicle()Lnet/minecraft/world/entity/Entity;")
  @Expression("this.getVehicle()")
  @ModifyExpressionValue(method = "updateControlFlags", at = @At("MIXINEXTRAS:EXPRESSION"))
  private Entity modifyGetVehicleBoatCheck(Entity original) {
    if (Config.MOBS_DRIVE_BOATS.get()) return null;
    return original;
  }
   */

}
