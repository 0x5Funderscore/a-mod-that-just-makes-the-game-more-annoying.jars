package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.furnace_cooking_time_x5;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  /**
   * @author _andthereitgoes
   * @reason furnace too fast
   */
  @Inject(method = "getTotalCookTime", at = @At("TAIL"), cancellable = true)
  private static void getTotalCookTimeTAIL(ServerLevel level, AbstractFurnaceBlockEntity entity, CallbackInfoReturnable<Integer> cir) {
    if (Config.FURNACE_COOKING_TIME_X5.get() && cir.getReturnValue() == 200) cir.setReturnValue(200 * 5);
  }

}
