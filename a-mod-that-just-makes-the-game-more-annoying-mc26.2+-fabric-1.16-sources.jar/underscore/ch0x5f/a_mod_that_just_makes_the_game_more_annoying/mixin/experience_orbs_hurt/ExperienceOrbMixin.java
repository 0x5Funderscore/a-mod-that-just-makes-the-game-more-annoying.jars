package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.experience_orbs_hurt;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ExperienceOrb.class)
public abstract class ExperienceOrbMixin extends Entity {

  @Shadow
  private int count;

  @Shadow
  public abstract int getValue();

  public ExperienceOrbMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Inject(method = "playerTouch", at = @At("HEAD"), cancellable = true)
  private void replacePlayerTouch(Player player, CallbackInfo ci) {
    if (Config.EXPERIENCE_ORBS_HURT.get()) {
      if (player instanceof ServerPlayer serverPlayer) {
        if (player.takeXpDelay == 0) {
          player.takeXpDelay = 2;
          ServerLevel level = serverPlayer.level();
          serverPlayer.hurtServer(level, level.damageSources().indirectMagic(this, this), Mth.ceil(this.getValue() / 2f));

          --this.count;
          if (this.count == 0) {
            this.discard();
          }
        }

      }
      ci.cancel();
    }
  }

}
