package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.smaller_baby_zombies;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.monster.zombie.Zombie;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Zombie.class)
public abstract class ZombieMixin {

  @ModifyReturnValue(method = "getDefaultDimensions", at = @At("RETURN"))
  private EntityDimensions modifyDefaultDimensions(EntityDimensions original) {
    if (Config.SMALLER_BABY_ZOMBIES.get()) {
      return original.scale(0.5f);
    }
    return original;
  }

}
