package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.every_zombie_is_a_leader;

import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.monster.zombie.Zombie;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Zombie.class)
public abstract class ZombieMixin {

  @Redirect(
      method = "handleAttributes",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/util/RandomSource;nextFloat()F"
      )
  )
  private float nextFloatForLeaderChance(RandomSource instance) {
    if (!Config.EVERY_ZOMBIE_IS_A_LEADER.get()) return instance.nextFloat();
    else instance.nextFloat();
    return -1f;
  }

}
