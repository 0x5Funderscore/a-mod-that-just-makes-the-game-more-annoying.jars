package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.no_string_wool;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;
import java.util.Optional;


@Mixin(ShapedRecipe.class)
public abstract class ShapedRecipeMixin {

  @Shadow
  @Final
  private ItemStackTemplate result;

  @Shadow
  public abstract List<Optional<Ingredient>> getIngredients();

  @Shadow
  public abstract int getWidth();

  @Shadow
  public abstract int getHeight();

  @Unique
  private boolean rb$isWool = false;
  @Unique
  private boolean rb$checkedWool = false;

  @Unique
  private boolean rb$checkIsWool() {
    return this.result.is(Blocks.WOOL.white().asItem()) && this.getIngredients().stream().filter(op -> op.map(item -> item.test(new ItemStack(Items.STRING, 1))).orElse(false)).count() == 4 && this.getWidth() == 2 && this.getHeight() == 2;
  }

  @Inject(method = "matches(Lnet/minecraft/world/item/crafting/CraftingInput;Lnet/minecraft/world/level/Level;)Z", at = @At("HEAD"), cancellable = true)
  private void matches(CraftingInput input, Level level, CallbackInfoReturnable<Boolean> cir) {
    if (!this.rb$checkedWool) {
      this.rb$checkedWool = true;
      this.rb$isWool = this.rb$checkIsWool();
    }
    if (Config.NO_STRING_WOOL.get() && this.rb$isWool) {
      cir.setReturnValue(false);
      cir.cancel();
    }
  }

}
