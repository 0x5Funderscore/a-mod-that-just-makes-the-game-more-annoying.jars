package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin._global;

import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.particles.ExplosionParticleInfo;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.random.WeightedList;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.level.entity.PersistentEntitySectionManager;
import net.minecraft.world.level.storage.WritableLevelData;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;


@Mixin(ServerLevel.class)
public abstract class ServerLevelMixin extends Level {

  @Shadow
  @Final
  private PersistentEntitySectionManager<Entity> entityManager;

  protected ServerLevelMixin(WritableLevelData levelData, ResourceKey<Level> dimension, RegistryAccess registryAccess, Holder<DimensionType> dimensionTypeRegistration, boolean isClientSide, boolean isDebug, long biomeZoomSeed, int maxChainedNeighborUpdates) {
    super(levelData, dimension, registryAccess, dimensionTypeRegistration, isClientSide, isDebug, biomeZoomSeed, maxChainedNeighborUpdates);
  }

  @Shadow
  public abstract <T extends Entity> List<? extends T> getEntities(EntityTypeTest<Entity,T> type, Predicate<? super T> selector);

  @Shadow
  public abstract void explode(@Nullable Entity source, @Nullable DamageSource damageSource, @Nullable ExplosionDamageCalculator damageCalculator, double x, double y, double z, float r, boolean fire, Level.ExplosionInteraction interactionType, ParticleOptions smallExplosionParticles, ParticleOptions largeExplosionParticles, WeightedList<ExplosionParticleInfo> blockParticles, Holder<SoundEvent> explosionSound);

  @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/entity/PersistentEntitySectionManager;tick()V"))
  private void tickEntitiesExtra(BooleanSupplier haveTime, CallbackInfo ci) {
    this.getEntities(EntityTypeTest.forClass(Entity.class), entity -> {
      Set<String> entityTags = entity.entityTags();
      if (entityTags.contains("rabbit_bomb")) {
        if (!entity.isPassenger()) {
          entity.remove(Entity.RemovalReason.DISCARDED);
        } else if (entity.getVehicle() instanceof LivingEntity livingEntity && livingEntity.isDeadOrDying() && livingEntity.deathTime > 1) {
          this.explode(null, entity.getX(), entity.getY(), entity.getZ(), 4.0f, ExplosionInteraction.MOB);
          entity.remove(Entity.RemovalReason.DISCARDED);
        }
      } else if (entityTags.contains("kill_when_no_passenger")) {
        if (!entity.isPassenger()) entity.remove(Entity.RemovalReason.DISCARDED);
      }
      if (entityTags.contains("strike_lightning")) {
        if (entity instanceof ItemEntity itemEntity) {
          if (itemEntity.getAge() >= 15) {
            LightningBolt lb = new LightningBolt(EntityTypes.LIGHTNING_BOLT, this);
            lb.setPos(itemEntity.position());
            this.addFreshEntity(lb);
            entity.remove(Entity.RemovalReason.DISCARDED);
          }
        }
      }
      return false;
    });
  }

}
