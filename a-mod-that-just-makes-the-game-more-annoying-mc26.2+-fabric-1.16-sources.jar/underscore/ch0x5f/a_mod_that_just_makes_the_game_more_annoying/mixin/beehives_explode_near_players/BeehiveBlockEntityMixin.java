package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.beehives_explode_near_players;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BeehiveBlock;
import net.minecraft.world.level.block.entity.BeehiveBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.apache.commons.compress.utils.Lists;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(BeehiveBlockEntity.class)
public abstract class BeehiveBlockEntityMixin {

  @Shadow
  @Final
  public List<BeehiveBlockEntity.BeeData> stored;

  @Shadow
  private static boolean releaseOccupant(Level level, BlockPos blockPos, BlockState state, BeehiveBlockEntity.Occupant beeData, @org.jspecify.annotations.Nullable List<Entity> spawned, BeehiveBlockEntity.BeeReleaseStatus releaseStatus, @org.jspecify.annotations.Nullable BlockPos savedFlowerPos) {
    throw new UnsupportedOperationException("Implemented via mixin");
  }

  @Inject(method = "serverTick", at = @At("HEAD"))
  private static void serverTickHEAD(Level level, BlockPos blockPos, BlockState state, BeehiveBlockEntity entity, CallbackInfo ci) {
    if (!Config.BEEHIVES_EXPLODE_NEAR_PLAYERS.get()) return;
    if (!(level instanceof ServerLevel)) return;
    @Nullable Player nearestPlayer = level.getNearestPlayer(blockPos.getX() + 0.5d, blockPos.getY(), blockPos.getZ() + 0.5d, 8.0d, player -> !player.isSpectator());
    if (nearestPlayer != null) {
      int releaseCount = level.getRandom().nextInt(100);
      for (int i = 0; i < releaseCount; i++)
        entity.stored.forEach(occupantEntry -> releaseOccupant(
            level,
            blockPos,
            state,
            occupantEntry.toOccupant(),
            Lists.newArrayList(),
            BeehiveBlockEntity.BeeReleaseStatus.EMERGENCY,
            null
        ));
      entity.emptyAllLivingFromHive(nearestPlayer, state, BeehiveBlockEntity.BeeReleaseStatus.EMERGENCY);
      level.destroyBlock(blockPos, false);
      level.explode(null, blockPos.getX() + 0.5d, blockPos.getY() + 0.5d, blockPos.getZ() + 0.5d, 0.5f, Level.ExplosionInteraction.NONE);
      Containers.updateNeighboursAfterDestroy(state, level, blockPos);
      ((BeehiveBlock)state.getBlock()).angerNearbyBees(level, blockPos);
    }
  }

}
