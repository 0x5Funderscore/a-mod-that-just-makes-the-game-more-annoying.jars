package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.lava_spreads_lava;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.LavaFluid;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LavaFluid.class)
public abstract class LavaFluidMixin {

  @ModifyArgs(
      method = "randomTick",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/server/level/ServerLevel;setBlockAndUpdate(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Z"
      )
  )
  private void modifyFire(Args args) {
    if (Config.LAVA_SPREADS_LAVA.get()) {
      args.set(1, Blocks.LAVA.defaultBlockState());
    }
  }

}
