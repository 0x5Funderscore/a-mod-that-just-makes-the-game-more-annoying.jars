package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.end_portal_needs_frame;

import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EndPortalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EndPortalBlock.class)
public abstract class EndPortalBlockMixin extends BaseEntityBlock {
  protected EndPortalBlockMixin(Properties properties) {
    super(properties);
  }

  @Override
  public @Nullable <T extends BlockEntity> BlockEntityTicker<T> getTicker(@NonNull Level level, @NonNull BlockState blockState, @NonNull BlockEntityType<T> type) {
    if (!Config.END_PORTAL_NEEDS_FRAME.get()) return null;
    return (tickLevel, pos, state, entity) -> {
      if (tickLevel instanceof ServerLevel serverLevel) {
        if (state.is(Blocks.END_PORTAL)) {
          for (Direction direction: Direction.Plane.HORIZONTAL) {
            BlockState neighborState = serverLevel.getBlockState(pos.relative(direction));
            if (neighborState.is(Blocks.END_PORTAL)) continue;
            if (neighborState.is(Blocks.BEDROCK)) continue;
            if (neighborState.is(Blocks.END_PORTAL_FRAME)) {
              if (neighborState.getValue(BlockStateProperties.EYE)) {
                if (neighborState.getValue(BlockStateProperties.HORIZONTAL_FACING) == direction.getOpposite()) {
                  continue;
                }
              }
            }
            serverLevel.destroyBlock(pos, false);
          }
        }
      }
    };
  }

//  @Override
//  protected void tick(@NonNull BlockState state, @NonNull ServerLevel level, @NonNull BlockPos pos, @NonNull RandomSource random) {
//    super.tick(state, level, pos, random);
//  }

}
