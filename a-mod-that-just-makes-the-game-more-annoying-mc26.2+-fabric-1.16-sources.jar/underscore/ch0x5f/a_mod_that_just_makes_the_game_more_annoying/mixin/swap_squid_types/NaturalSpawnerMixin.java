package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.swap_squid_types;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.squid.Squid;
import net.minecraft.world.level.NaturalSpawner;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(NaturalSpawner.class)
public abstract class NaturalSpawnerMixin {

  @ModifyReturnValue(method = "getMobForSpawn", at = @At("RETURN"))
  private static @Nullable Mob modifyMobForSpawn(@Nullable Mob original) {
    if (Config.MOSTLY_REMOVE_SQUIDS.get()) {
      if (original != null) {
        if (original instanceof Squid && Math.random() < 0.999d) {
          return null;
        }
      }
    }
    return original;
  }

}
