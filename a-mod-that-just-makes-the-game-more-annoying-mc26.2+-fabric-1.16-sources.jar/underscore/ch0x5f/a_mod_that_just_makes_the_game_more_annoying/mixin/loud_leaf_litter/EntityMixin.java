package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.loud_leaf_litter;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Entity.class)
public abstract class EntityMixin {

  @Shadow
  public abstract BlockState getInBlockState();

  @Shadow
  public abstract Level level();

  @Shadow
  public abstract void playSound(SoundEvent sound, float volume, float pitch);

  @Inject(method = "playStepSound", at = @At("TAIL"))
  private void postStepSound(BlockPos pos, BlockState blockState, CallbackInfo ci) {
    if (Config.LOUD_LEAF_LITTER.get()) {
      if (this.getInBlockState().is(Blocks.LEAF_LITTER)) {
        for (int i = 0; i < 5; i++) {
          this.playSound(SoundEvents.LEAF_LITTER_STEP, 2.0f, 1.0f);
          this.playSound(SoundEvents.LEAF_LITTER_STEP, 2.0f, 0.9f);
          this.playSound(SoundEvents.LEAF_LITTER_STEP, 2.0f, 1.3f);
        }
      }
    }
  }

}
