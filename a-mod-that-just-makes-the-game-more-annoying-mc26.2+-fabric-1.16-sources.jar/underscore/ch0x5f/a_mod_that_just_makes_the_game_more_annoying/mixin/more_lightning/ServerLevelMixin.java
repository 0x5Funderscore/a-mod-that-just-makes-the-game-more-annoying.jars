package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.more_lightning;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.storage.WritableLevelData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Optional;


@Mixin(ServerLevel.class)
public abstract class ServerLevelMixin extends Level {

  protected ServerLevelMixin(WritableLevelData levelData, ResourceKey<Level> dimension, RegistryAccess registryAccess, Holder<DimensionType> dimensionTypeRegistration, boolean isClientSide, boolean isDebug, long biomeZoomSeed, int maxChainedNeighborUpdates) {
    super(levelData, dimension, registryAccess, dimensionTypeRegistration, isClientSide, isDebug, biomeZoomSeed, maxChainedNeighborUpdates);
  }

  @ModifyArg(method = "tickThunder", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/RandomSource;nextInt(I)I", ordinal = 0), index = 0)
  private int modifyThunderChance(int bound) {
    if (Config.MORE_LIGHTNING.get()) return bound / 10;
    return bound;
  }

  @ModifyReturnValue(method = "findLightningTargetAround", at = @At(value = "RETURN", ordinal = 2))
  private BlockPos checkForEntityLightningTargetAgain(BlockPos original) {
    if (!Config.MORE_LIGHTNING.get()) return original;
    Player nearestCopperPlayer = this.getNearestPlayer(
        original.getX() + 0.5d, original.getY(), original.getZ() + 0.5d,
        64d,
        e -> {
          if (e instanceof ServerPlayer player && !player.isSpectator()) {
            Inventory inventory = player.getInventory();
            return (
                inventory.contains(stack -> stack.is(Items.COPPER_INGOT)) ||
                inventory.contains(stack -> stack.is(Items.COPPER_NUGGET)) ||
                inventory.contains(stack -> stack.is(Items.COPPER_TORCH)) ||
                inventory.contains(stack -> stack.is(Items.RAW_COPPER)) ||
                inventory.contains(stack -> stack.is(Items.RAW_COPPER_BLOCK)) ||
                inventory.contains(stack -> Items.LIGHTNING_ROD.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_BLOCK.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.CUT_COPPER.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_LANTERN.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_BULB.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.CUT_COPPER_SLAB.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.CUT_COPPER_STAIRS.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_BARS.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_CHAIN.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_CHEST.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_DOOR.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_GRATE.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_TRAPDOOR.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Items.COPPER_GOLEM_STATUE.asList().contains(stack.getItem())) ||
                inventory.contains(stack -> Optional.ofNullable(stack.get(DataComponents.REPAIRABLE)).map(repairable -> repairable.isValidRepairItem(new ItemStack(Items.COPPER_INGOT))).orElse(false))
            );
          }
          return false;
        }
    );
    return nearestCopperPlayer == null ? original : nearestCopperPlayer.blockPosition();
  }

}
