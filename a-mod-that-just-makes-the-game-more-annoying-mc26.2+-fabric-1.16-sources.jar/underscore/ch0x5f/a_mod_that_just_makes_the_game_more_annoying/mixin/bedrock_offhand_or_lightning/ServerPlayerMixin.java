package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.bedrock_offhand_or_lightning;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Unique
  private boolean verifyOffhand(ItemStack itemStack) {
    return (
        itemStack.isEmpty() ||
        itemStack.is(Items.TOTEM_OF_UNDYING) ||
        itemStack.is(Items.SHIELD) ||
        itemStack.is(Items.MAP) ||
        itemStack.is(Items.FILLED_MAP) ||
        itemStack.is(Items.NAUTILUS_SHELL) ||
        itemStack.is(Items.FIREWORK_ROCKET) ||
        itemStack.is(ItemTags.ARROWS)
    );
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.BEDROCK_OFFHAND_OR_LIGHTNING.get()) {
      ItemStack offhand = this.getOffhandItem();
      if (!verifyOffhand(offhand)) {
        ItemEntity itemEntity = this.drop(offhand.copy(), false);
        if (itemEntity != null) {
          itemEntity.setNeverPickUp();
          itemEntity.setDeltaMovement(itemEntity.getDeltaMovement().scale(3d));
          itemEntity.addTag("strike_lightning");
        }
        offhand.shrink(offhand.count());
      }
    }
  }

}
