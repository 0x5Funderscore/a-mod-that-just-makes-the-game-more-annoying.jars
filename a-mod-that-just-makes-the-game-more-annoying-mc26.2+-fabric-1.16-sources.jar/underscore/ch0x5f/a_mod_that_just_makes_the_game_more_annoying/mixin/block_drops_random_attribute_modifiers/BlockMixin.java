package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.block_drops_random_attribute_modifiers;

import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.UUID;
import java.util.function.Supplier;


@Mixin(Block.class)
public abstract class BlockMixin {

  @Inject(
      method = "popResource(Lnet/minecraft/world/level/Level;Ljava/util/function/Supplier;Lnet/minecraft/world/item/ItemStack;)V",
      at = @At(
          value = "INVOKE",
          target = "Ljava/util/function/Supplier;get()Ljava/lang/Object;",
          ordinal = 0,
          shift = At.Shift.AFTER
      )
  )
  private static void modifyItemStack(Level level, Supplier<ItemEntity> entityFactory, ItemStack itemStack, CallbackInfo ci) {
    if (!Config.BLOCK_DROPS_RANDOM_ATTRIBUTE_MODIFIERS.get()) return;
    if (Math.random() < 0.015625) {
      String modifierPath = "random_block_drop_attribute_modifier_" + UUID.randomUUID().toString().replace("-", "");
      switch (Mth.floor(Math.random() * 13)) {
        case 0 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.STEP_HEIGHT,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -0.5,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 1 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.ATTACK_SPEED,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -0.5,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 2 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.ATTACK_DAMAGE,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -0.5,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 3 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.ARMOR,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -0.5,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 4 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.ARMOR_TOUGHNESS,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -0.5,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 5 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.GRAVITY,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                0.5,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 6 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.BLOCK_BREAK_SPEED,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -0.5,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 7 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.BLOCK_INTERACTION_RANGE,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -1.0,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 8 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.JUMP_STRENGTH,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -0.5,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                ).build());
        case 9 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.SNEAKING_SPEED,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -0.5,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 10 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.SAFE_FALL_DISTANCE,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -2.0,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 11 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.BURNING_TIME,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                2.0,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
        case 12 -> itemStack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ATTRIBUTE_MODIFIERS,
                    ItemAttributeModifiers.builder()
                        .add(
                            Attributes.MOVEMENT_SPEED,
                            new AttributeModifier(
                                Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath),
                                -0.1,
                                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                            ),
                            EquipmentSlotGroup.ANY
                        ).build()
                )
//                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(false, new LinkedHashSet<>(List.of(DataComponents.ATTRIBUTE_MODIFIERS))))
                .build());
      }
    }
  }

}
