package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.hissbines;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.hissbines.Hissbine;


@Mixin(BlockBehaviour.class)
public abstract class BlockBehaviourMixin {

  @Mutable
  @Shadow
  @Final
  protected boolean isRandomlyTicking;

  @Inject(method = "isRandomlyTicking", at = @At("HEAD"))
  private void enableRandomlyTickingRails(BlockState state, CallbackInfoReturnable<Boolean> cir) {
    if (Config.HISSBINES.get() && state.is(Blocks.GLOW_LICHEN)) {
      this.isRandomlyTicking = true;
    }
  }

  @Inject(method = "randomTick", at = @At("TAIL"))
  private void postRandomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random, CallbackInfo ci) {
    if (Config.HISSBINES.get() && state.is(Blocks.GLOW_LICHEN) && random.nextDouble() < 0.01d) {
      Hissbine.addHissbineBaseAutoDirection(pos, level);
    }
  }

}
