package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.no_enchanting_tables;

import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.function.Predicate;


@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

  @Shadow
  public abstract boolean is(Predicate<Holder<Item>> item);

  @Shadow
  public abstract Item getItem();

  @Shadow
  public abstract void shrink(int amount);

  @Shadow
  public abstract int getCount();

  @Inject(method = "inventoryTick", at = @At("TAIL"))
  private void extraInventoryTick(Level level, Entity owner, EquipmentSlot slot, CallbackInfo ci) {
    if (Config.NO_ENCHANTING_TABLES.get()) {
      if (this.getItem() == Items.ENCHANTING_TABLE) {
        this.shrink(this.getCount());
      }
    }
  }

}
