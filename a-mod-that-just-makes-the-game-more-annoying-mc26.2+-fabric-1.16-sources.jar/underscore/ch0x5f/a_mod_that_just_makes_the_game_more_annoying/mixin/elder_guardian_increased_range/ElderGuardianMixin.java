package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.elder_guardian_increased_range;

import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectUtil;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.ElderGuardian;
import net.minecraft.world.entity.monster.Guardian;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(ElderGuardian.class)
public abstract class ElderGuardianMixin extends Guardian {
  public ElderGuardianMixin(EntityType<? extends Guardian> type, Level level) {
    super(type, level);
  }

  @Inject(method = "customServerAiStep", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/monster/Guardian;customServerAiStep(Lnet/minecraft/server/level/ServerLevel;)V", shift = At.Shift.AFTER), cancellable = true)
  private void customServerAiStep(final ServerLevel level, CallbackInfo ci) {
    if (Config.ELDER_GUARDIAN_INCREASED_RANGE.get()) {
      if ((this.tickCount + this.getId()) % 5 == 0) {
        MobEffectInstance miningFatigue = new MobEffectInstance(MobEffects.MINING_FATIGUE, 30000, 2);
        List<ServerPlayer> affectedPlayers = MobEffectUtil.addEffectToPlayersAround(level, this, this.position(), 100f, miningFatigue, 1200);
        affectedPlayers.forEach((player) -> player.connection.send(new ClientboundGameEventPacket(ClientboundGameEventPacket.GUARDIAN_ELDER_EFFECT, this.isSilent() ? 0.0F : 1.0F)));
      }

      if (!this.hasHome()) {
        this.setHomeTo(this.blockPosition(), 16);
      }

      ci.cancel();
    }
  }

}
