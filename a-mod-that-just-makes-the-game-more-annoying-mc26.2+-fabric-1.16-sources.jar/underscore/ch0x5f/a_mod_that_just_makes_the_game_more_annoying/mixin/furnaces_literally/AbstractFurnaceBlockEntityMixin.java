package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.furnaces_literally;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FurnaceBlock;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTypes;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  @Inject(method = "serverTick", at = @At("HEAD"), cancellable = true)
  private static void preTick(ServerLevel level, BlockPos pos, BlockState state, AbstractFurnaceBlockEntity entity, CallbackInfo ci) {
    if (Config.FURNACES_LITERALLY.get()) {
      if (entity.is(BlockEntityTypes.BLAST_FURNACE)) {
        if (state.getValue(FurnaceBlock.LIT)) {
          level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
          double x = pos.getX() + 0.5d;
          double y = pos.getY() + 0.25d;
          double z = pos.getZ() + 0.5d;
          level.sendParticles(ParticleTypes.LAVA, false, false, x, y, z, 64, 0.1d, 0.1d, 0.1d, 5.0d);
          level.explode(null, x, y, z, 2.0f, Level.ExplosionInteraction.BLOCK);
          ci.cancel();
        }
      } else if (entity.is(BlockEntityTypes.SMOKER)) {
        if (state.getValue(FurnaceBlock.LIT)) {
          double x = pos.getX() + 0.5d;
          double y = pos.getY() + 1.0d;
          double z = pos.getZ() + 0.5d;
          level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, false, false, x, y, z, 4, 0.1d, 0.0d, 0.1d, 0.02d);
        }
      }
    }
  }

}
