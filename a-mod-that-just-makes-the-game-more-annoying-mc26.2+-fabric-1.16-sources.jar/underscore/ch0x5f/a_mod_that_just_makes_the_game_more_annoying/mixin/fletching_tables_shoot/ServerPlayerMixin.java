package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fletching_tables_shoot;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Random;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("HEAD"))
  private void preTick(CallbackInfo ci) {
    if (Config.FLETCHING_TABLES_SHOOT.get() && !this.isSpectator()) {
      ServerLevel level = this.level();
      for (int i = 0; i < 16; i++) {
        Random rng = new Random();
        double dx = rng.nextGaussian() * 4d;
        double dy = rng.nextGaussian() * 1.5d + 1d;
        double dz = rng.nextGaussian() * 4d;
        if (Vector3d.lengthSquared(dx, dy, dz) > 1.5625) { // 1.25 * 1.25
          BlockPos blockPos = BlockPos.containing(this.position().add(dx, dy, dz));
          if (level.isLoaded(blockPos)) {
            BlockState block = level.getBlockState(blockPos);
            if (block.is(Blocks.FLETCHING_TABLE)) {
              Arrow arrow = new Arrow(EntityTypes.ARROW, level);
              Vec3 pos = Vec3.atCenterOf(blockPos);
              Vec3 dir = this.getEyePosition().subtract(pos).normalize();
              arrow.setPos(pos.add(dir.scale(1.25d)));
              arrow.shoot(dir.x, dir.y, dir.z, 10f, 0f);
              Projectile.spawnProjectile(arrow, level, ItemStack.EMPTY);
              arrow.setOwner(arrow);
              arrow.setCustomName(Component.translatable("block.minecraft.fletching_table"));
            }
          }
        }
      }
    }
  }

}
