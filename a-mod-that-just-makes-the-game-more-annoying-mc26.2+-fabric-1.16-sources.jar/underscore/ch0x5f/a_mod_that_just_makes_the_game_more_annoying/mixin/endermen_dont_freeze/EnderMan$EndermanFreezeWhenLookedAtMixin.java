package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.endermen_dont_freeze;

import net.minecraft.world.entity.monster.EnderMan;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.EndermanFreezeWhenLookedAt.class)
public class EnderMan$EndermanFreezeWhenLookedAtMixin {

  @Inject(method = "canUse", at = @At("HEAD"), cancellable = true)
  private void replaceCanUse(CallbackInfoReturnable<Boolean> cir) {
    if (Config.ENDERMEN_DONT_FREEZE.get()) {
      cir.setReturnValue(false);
      cir.cancel();
    }
  }

}
