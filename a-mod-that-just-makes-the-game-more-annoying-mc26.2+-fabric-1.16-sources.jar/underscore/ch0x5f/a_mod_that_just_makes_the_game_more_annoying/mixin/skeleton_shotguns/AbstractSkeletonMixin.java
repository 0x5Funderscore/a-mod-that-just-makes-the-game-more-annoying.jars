package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.skeleton_shotguns;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.skeleton.AbstractSkeleton;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractSkeleton.class)
public abstract class AbstractSkeletonMixin extends Monster {

  @Shadow
  protected abstract AbstractArrow getArrow(ItemStack projectile, float power, @Nullable ItemStack firingWeapon);

  protected AbstractSkeletonMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @Inject(method = "performRangedAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/Projectile;spawnProjectileUsingShoot(Lnet/minecraft/world/entity/projectile/Projectile;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/item/ItemStack;DDDFF)Lnet/minecraft/world/entity/projectile/Projectile;"))
  private void afterProjectileSpawn(
      LivingEntity target, float power, CallbackInfo ci
  ) {
    if (Config.SKELETON_SHOTGUNS.get()) {
      ItemStack bowItem = this.getItemInHand(ProjectileUtil.getWeaponHoldingHand(this, Items.BOW));
      ItemStack projectile = this.getProjectile(bowItem);
      double xd = target.getX() - this.getX();
      double zd = target.getZ() - this.getZ();
      double distanceToTarget = Math.sqrt(xd * xd + zd * zd);
      Level level = this.level();
      if (level instanceof ServerLevel serverLevel) {
        for (int i = 0; i < Mth.floor(Math.random() * 16d + 15d); i++) {
          AbstractArrow arrow = this.getArrow(projectile, power, bowItem);
          double yd = target.getY(0.3333333333333333) - arrow.getY();
          Projectile.spawnProjectileUsingShoot(arrow, serverLevel, projectile, xd, yd + distanceToTarget * (double)0.2F, zd, 1.6F, 22f);
        }
      }
    }
  }

}
