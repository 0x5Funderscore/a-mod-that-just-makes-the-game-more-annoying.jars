package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.endermen_randomly_get_boom;

import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.class)
public abstract class EnderManMixin {

  @Shadow
  public abstract @Nullable BlockState getCarriedBlock();

  @Shadow
  public abstract void setCarriedBlock(@Nullable BlockState carryingBlock);

  @Inject(method = "aiStep", at = @At("HEAD"))
  private void aiStepHEAD(CallbackInfo ci) {
    if (!Config.ENDERMEN_RANDOMLY_GET_BOOM.get()) return;
    if (this.getCarriedBlock() == null && Math.random() < 0.005) {
      double n = Math.random();
      if (n < 0.01) this.setCarriedBlock(Blocks.REDSTONE_BLOCK.defaultBlockState());
      else if (n < 0.02) this.setCarriedBlock(Blocks.FIRE.defaultBlockState());
      else this.setCarriedBlock(Blocks.TNT.defaultBlockState());
    }
  }

}
