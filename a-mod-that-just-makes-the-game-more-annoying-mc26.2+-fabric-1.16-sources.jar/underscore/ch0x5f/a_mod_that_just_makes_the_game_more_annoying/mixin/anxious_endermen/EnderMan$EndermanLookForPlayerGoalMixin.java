package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.anxious_endermen;

import net.minecraft.world.entity.monster.EnderMan;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.EndermanLookForPlayerGoal.class)
public abstract class EnderMan$EndermanLookForPlayerGoalMixin {

  @Shadow
  private int teleportTime;

  @Inject(method = "tick", at = @At("HEAD"))
  private void tickHEAD(CallbackInfo ci) {
    if (!Config.ANXIOUS_ENDERMEN.get()) return;
    this.teleportTime = Integer.MAX_VALUE >> 1;
  }

}
