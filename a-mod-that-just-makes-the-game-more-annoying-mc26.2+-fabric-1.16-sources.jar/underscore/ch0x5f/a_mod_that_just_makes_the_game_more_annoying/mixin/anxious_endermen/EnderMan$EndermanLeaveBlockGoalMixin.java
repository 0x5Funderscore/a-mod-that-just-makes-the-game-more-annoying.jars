package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.anxious_endermen;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.level.gamerules.GameRules;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.EndermanLeaveBlockGoal.class)
public abstract class EnderMan$EndermanLeaveBlockGoalMixin extends Goal {

  @Shadow
  @Final
  private EnderMan enderman;

  @Inject(method = "canUse", at = @At("HEAD"), cancellable = true)
  public void canUse(CallbackInfoReturnable<Boolean> cir) {
    if (!Config.ANXIOUS_ENDERMEN.get()) return;
    if (this.enderman.getCarriedBlock() == null) {
      cir.setReturnValue(false);
    } else if (!(Boolean)getServerLevel(this.enderman).getGameRules().get(GameRules.MOB_GRIEFING)) {
      cir.setReturnValue(false);
    } else {
      cir.setReturnValue(this.enderman.getRandom().nextInt(reducedTickDelay(80)) == 0);
    }
  }

}
