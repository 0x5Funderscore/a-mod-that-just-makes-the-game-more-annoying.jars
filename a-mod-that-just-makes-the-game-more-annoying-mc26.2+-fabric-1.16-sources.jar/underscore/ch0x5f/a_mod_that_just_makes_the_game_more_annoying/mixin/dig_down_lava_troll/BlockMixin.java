package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.dig_down_lava_troll;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Block.class)
public abstract class BlockMixin {

  @Inject(method = "playerDestroy", at = @At("TAIL"))
  private void playerDestroyTAIL_lavaTroll(Level level, Player player, BlockPos pos, BlockState state, BlockEntity blockEntity, ItemStack destroyedWith, CallbackInfo ci) {
    if (!Config.DIG_DOWN_LAVA_TROLL.get()) return;
    if (
        level instanceof ServerLevel serverLevel
        && (
            (level.dimension() == Level.OVERWORLD && pos.getY() < 54)
            || level.dimension() == Level.NETHER
        )
        && player.blockPosition().equals(pos.above())
        && Math.random() < 0.1
    ) {
      BlockPos lavaSpawnPos = pos.offset(0, -1, 0);
      boolean canSpawnLava = true;
      for (Direction direction: Direction.values()) {
        BlockPos checkPos = lavaSpawnPos.relative(direction);
        if (direction == Direction.UP) checkPos = lavaSpawnPos;
        if (!serverLevel.getBlockState(checkPos).canOcclude()) {
          canSpawnLava = false;
          break;
        }
      }
      if (canSpawnLava) {
        level.setBlockAndUpdate(lavaSpawnPos, Blocks.LAVA.defaultBlockState());
      }
    }
  }

}
