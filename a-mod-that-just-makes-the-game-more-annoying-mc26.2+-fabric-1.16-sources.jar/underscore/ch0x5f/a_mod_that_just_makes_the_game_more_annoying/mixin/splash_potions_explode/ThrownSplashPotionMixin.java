package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.splash_potions_explode;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.throwableitemprojectile.AbstractThrownPotion;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownSplashPotion;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ThrownSplashPotion.class)
public abstract class ThrownSplashPotionMixin extends AbstractThrownPotion {
  public ThrownSplashPotionMixin(EntityType<? extends AbstractThrownPotion> type, Level level) {
    super(type, level);
  }

  @Inject(method = "onHitAsPotion", at = @At("TAIL"))
  private void onHitAsPotionTAIL(ServerLevel level, ItemStack potionItem, HitResult hitResult, CallbackInfo ci) {
    if (!Config.SPLASH_POTIONS_EXPLODE.get()) return;
    if (this.random.nextDouble() < 0.2d) {
      level.explode(this, this.getX(), this.getY(), this.getZ(), 4f, Level.ExplosionInteraction.TNT);
    }
  }

}
