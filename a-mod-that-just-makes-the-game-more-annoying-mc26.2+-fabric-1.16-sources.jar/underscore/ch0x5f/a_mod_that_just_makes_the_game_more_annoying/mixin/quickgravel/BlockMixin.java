package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.quickgravel;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Block.class)
public abstract class BlockMixin {

  @Inject(method = "stepOn", at = @At("HEAD"))
  private void stepOnHEAD(Level level, BlockPos pos, BlockState onState, Entity entity, CallbackInfo ci) {
    if (level.isClientSide()) return;
    if (!Config.QUICKGRAVEL.get()) return;
    if (level instanceof ServerLevel serverLevel) {
      if (onState.is(Blocks.GRAVEL)) {
        if (serverLevel.getServer().getTickCount() % 2 != 0) return;
        RandomSource rs = serverLevel.getRandom().forkPositional().at(pos);
        rs.setSeed(rs.nextLong() ^ serverLevel.getServer().getTickCount());
        if (rs.nextDouble() < 0.5d) {
          FallingBlockEntity fallingBlock = FallingBlockEntity.fall(level, pos, onState);
          fallingBlock.setDeltaMovement(0.0d, 0.2d, 0.0d);
        }
      }
    }
  }

}
