package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.origin_desert;

import com.mojang.datafixers.util.Either;
import com.mojang.logging.LogUtils;
import net.minecraft.core.Holder;
import net.minecraft.world.level.biome.*;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(MultiNoiseBiomeSource.class)
public abstract class MultiNoiseBiomeSourceMixin extends BiomeSource {

  @Shadow
  @Final
  private Either<Climate.ParameterList<Holder<Biome>>,Holder<MultiNoiseBiomeSourceParameterList>> parameters;

  @Shadow
  protected abstract Climate.ParameterList<Holder<Biome>> parameters();

  @Shadow
  public abstract Holder<Biome> getNoiseBiome(Climate.TargetPoint target);

  @Unique
  private static final Logger LOGGER = LogUtils.getLogger();

  @Inject(method = "getNoiseBiome(IIILnet/minecraft/world/level/biome/Climate$Sampler;)Lnet/minecraft/core/Holder;", at = @At("HEAD"), cancellable = true)
  private void replaceNoiseBiome(int quartX, int quartY, int quartZ, Climate.Sampler sampler, CallbackInfoReturnable<Holder<Biome>> cir) {
    if (Config.ORIGIN_DESERT.get()) {
      if ((long)quartX * (long)quartX + (long)quartZ * (long)quartZ < 15625L) {
        cir.setReturnValue(this.getNoiseBiome(new Climate.TargetPoint(5660L, 1130L, 2222L, 750L, 3137L, 1970L)));
        cir.cancel();
      }
    }
  }

}
