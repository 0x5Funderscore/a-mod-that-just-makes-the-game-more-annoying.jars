package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.vaults_dispense_mobs;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Position;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.util.random.WeightedList;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.VaultBlock;
import net.minecraft.world.level.block.entity.vault.VaultState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(VaultState.class)
public abstract class VaultStateMixin {

  @WrapOperation(method = "ejectResultItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/core/dispenser/DefaultDispenseItemBehavior;spawnItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;ILnet/minecraft/core/Direction;Lnet/minecraft/core/Position;)V"))
  private static void redirectSpawnItem(
      Level level, ItemStack itemStack, int accuracy, Direction direction, Position position,
      Operation<Void> original,
      @Local(name = "pos", argsOnly = true) BlockPos pos
      ) {
    if (!Config.VAULTS_DISPENSE_MOBS.get()) {
      original.call(level, itemStack, accuracy, direction, position);
      return;
    }

    if (level.isClientSide()) return;

    // direction is always UP

    boolean ominous = level.getBlockState(pos).getValueOrElse(VaultBlock.OMINOUS, false);

    RandomSource random = level.getRandom();

    EntityType<? extends Mob> entityType = (
        ominous
            ? new WeightedList.Builder<EntityType<? extends Mob>>()
                .add(EntityTypes.ZOMBIE, 100)
                .add(EntityTypes.HUSK, 100)
                .add(EntityTypes.DROWNED, 100)
                .add(EntityTypes.SKELETON, 100)
                .add(EntityTypes.WITHER_SKELETON, 80)
                .add(EntityTypes.STRAY, 100)
                .add(EntityTypes.BOGGED, 100)
                .add(EntityTypes.PARCHED, 100)
                .add(EntityTypes.SPIDER, 100)
                .add(EntityTypes.CAVE_SPIDER, 100)
                .add(EntityTypes.CREEPER, 100)
                .add(EntityTypes.ENDERMAN, 80)
                .add(EntityTypes.PILLAGER, 30)
                .add(EntityTypes.WITCH, 50)
                .add(EntityTypes.EVOKER, 20)
                .add(EntityTypes.VINDICATOR, 20)
                .add(EntityTypes.RAVAGER, 10)
                .add(EntityTypes.SILVERFISH, 50)
                .add(EntityTypes.SLIME, 50)
                .add(EntityTypes.MAGMA_CUBE, 20)
                .add(EntityTypes.WARDEN, 1)
                .add(EntityTypes.WITHER, 1)
                .add(EntityTypes.BLAZE, 80)
                .add(EntityTypes.BREEZE, 100)
                .add(EntityTypes.ELDER_GUARDIAN, 10)
                .add(EntityTypes.GUARDIAN, 10)
                .add(EntityTypes.ZOMBIE_NAUTILUS, 20)
                .add(EntityTypes.ZOMBIFIED_PIGLIN, 20)
                .add(EntityTypes.ZOGLIN, 20)
                .build()
            : new WeightedList.Builder<EntityType<? extends Mob>>()
                .add(EntityTypes.ZOMBIE, 100)
                .add(EntityTypes.HUSK, 90)
                .add(EntityTypes.DROWNED, 90)
                .add(EntityTypes.SKELETON, 100)
                .add(EntityTypes.STRAY, 70)
                .add(EntityTypes.BOGGED, 70)
                .add(EntityTypes.PARCHED, 70)
                .add(EntityTypes.SPIDER, 100)
                .add(EntityTypes.CAVE_SPIDER, 60)
                .add(EntityTypes.CREEPER, 100)
                .add(EntityTypes.BREEZE, 50)
                .build()
    ).getRandomOrThrow(random);
    Mob entity = entityType.create(level, EntitySpawnReason.DISPENSER);
    if (entity == null) return;

    EquipmentSlot slot = EquipmentSlot.OFFHAND;
    entity.setItemSlot(slot, itemStack);
    entity.setDropChance(slot, 2f);
    entity.setGuaranteedDrop(slot);

    entity.setPos(position.x(), position.y() - 0.125d, position.z());

    entity.setDeltaMovement(
        random.triangle(0d, 0.0172275 * (double)accuracy * 4d),
        random.triangle(0.2d, 0.0172275 * (double)accuracy),
        random.triangle(0d, 0.0172275 * (double)accuracy * 4d)
    );

    BlockPos.betweenClosed(entity.getBoundingBox().inflate(0.25d, 0d, 0.25d).expandTowards(0d, 0.25d, 0d)).forEach(blockPos -> {
      if (level.getBlockState(blockPos).isAir()) return;
      if (level.getBlockState(blockPos).is(BlockTags.DRAGON_IMMUNE)) return;
      if (level.getBlockState(blockPos).is(BlockTags.WITHER_IMMUNE)) return;
      level.destroyBlock(blockPos, false);
    });

    level.addFreshEntity(entity);
  }

}
