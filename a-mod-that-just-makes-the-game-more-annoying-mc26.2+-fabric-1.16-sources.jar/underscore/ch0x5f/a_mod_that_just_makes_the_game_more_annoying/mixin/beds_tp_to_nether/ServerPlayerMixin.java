package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.beds_tp_to_nether;

import com.mojang.authlib.GameProfile;
import com.mojang.datafixers.util.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {
  @Shadow
  @Final
  private MinecraftServer server;

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "stopSleepInBed", at = @At("TAIL"))
  private void stopSleepInBedTAIL_netherTeleport(CallbackInfo ci) {
    if (!Config.BEDS_TP_TO_NETHER.get()) return;
    if (!this.isSpectator() && this.random.nextDouble() < 0.2d) {
      ServerLevel dim = this.server.getLevel(Level.NETHER);
      BlockPos where = this.blockPosition();
      if (dim == null) {
        dim = this.server.getLevel(Level.END);
        if (dim == null) return;
      } else {
        Pair<BlockPos,Holder<Biome>> close = dim.findClosestBiome3d(biomeHolder -> biomeHolder.value().getBaseTemperature() < -0.25, where, 2048, 32, 32);
        if (close != null) {
          where = close.getFirst();
        }
      }
      dim.getPortalForcer().findClosestPortalPosition(where, false, dim.getWorldBorder());
      this.teleport(new TeleportTransition(dim, Vec3.atBottomCenterOf(where), Vec3.ZERO, this.getYRot(), this.getXRot(), _ -> {}));
    }
  }

}
