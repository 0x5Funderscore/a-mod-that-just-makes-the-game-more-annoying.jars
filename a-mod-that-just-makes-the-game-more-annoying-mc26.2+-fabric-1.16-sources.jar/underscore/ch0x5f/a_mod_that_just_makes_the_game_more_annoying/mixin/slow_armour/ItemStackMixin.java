package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.slow_armour;

import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.component.PatchedDataComponentMap;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.equipment.Equippable;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Objects;
import java.util.Optional;


@Mixin(ItemStack.class)
public class ItemStackMixin {

  @Shadow
  @Final
  private PatchedDataComponentMap components;

  @Inject(method = "inventoryTick", at = @At("TAIL"))
  private void postInventoryTick(Level level, Entity owner, EquipmentSlot slot, CallbackInfo ci) {
    if (Config.SLOW_ARMOUR.get()) {
      if (this.components.has(DataComponents.EQUIPPABLE) && !Optional.ofNullable(this.components.get(DataComponents.REPAIRABLE)).map(r -> r.isValidRepairItem(new ItemStack(Items.LEATHER))).orElse(false)) {
        Equippable equippable = Objects.requireNonNull(this.components.get(DataComponents.EQUIPPABLE));
        EquipmentSlot equipSlot = equippable.slot();
        EquipmentSlotGroup slotGroup = switch (equipSlot) {
          case HEAD -> EquipmentSlotGroup.HEAD;
          case CHEST -> EquipmentSlotGroup.CHEST;
          case LEGS -> EquipmentSlotGroup.LEGS;
          case FEET -> EquipmentSlotGroup.FEET;
          case BODY -> EquipmentSlotGroup.BODY;
          default -> null;
        };
        if (slotGroup != null) {
          String modifierPath = "armor_slow_" + slotGroup.getSerializedName();
          Identifier id = Identifier.fromNamespaceAndPath("a_mod_that_just_makes_the_game_more_annoying", modifierPath);
          ItemAttributeModifiers itemAttributeModifiers = this.components.get(DataComponents.ATTRIBUTE_MODIFIERS);
          boolean applied = itemAttributeModifiers != null && itemAttributeModifiers.modifiers().stream().anyMatch(entry -> entry.matches(Attributes.MOVEMENT_SPEED, id) && entry.modifier().amount() != 0d);
          if (owner instanceof Player) {
            if (!applied) {
              this.components.applyPatch(
                  DataComponentPatch.builder()
                      .set(DataComponents.ATTRIBUTE_MODIFIERS,
                          ItemAttributeModifiers.builder()
                              .add(
                                  Attributes.MOVEMENT_SPEED,
                                  new AttributeModifier(
                                      id,
                                      -0.2,
                                      AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                                  ),
                                  slotGroup
                              ).build()
                      )
                      .build()
              );
            }
          } else {
            if (applied) {
              this.components.applyPatch(
                  DataComponentPatch.builder()
                      .set(DataComponents.ATTRIBUTE_MODIFIERS,
                          ItemAttributeModifiers.builder()
                              .add(
                                  Attributes.MOVEMENT_SPEED,
                                  new AttributeModifier(
                                      id,
                                      0.0,
                                      AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                                  ),
                                  slotGroup
                              ).build()
                      )
                      .build()
              );
            }
          }
        }
      }
    }
  }

}
