package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.lower_step_height;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Player.class)
public abstract class PlayerMixin {

  @ModifyReturnValue(method = "createAttributes", at = @At("TAIL"))
  private static AttributeSupplier.Builder modifyCreatedAttributes(AttributeSupplier.Builder original) {
    if (Config.LOWER_STEP_HEIGHT.get()) original.add(Attributes.STEP_HEIGHT, 0.4f);
    return original;
  }

}
