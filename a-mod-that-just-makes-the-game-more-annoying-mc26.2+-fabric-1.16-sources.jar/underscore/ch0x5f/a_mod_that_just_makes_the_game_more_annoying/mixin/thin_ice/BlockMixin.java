package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.thin_ice;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Block.class)
public abstract class BlockMixin {

  @Inject(method = "stepOn", at = @At("HEAD"))
  private void stepOnHEAD_thinIce(Level level, BlockPos pos, BlockState onState, Entity entity, CallbackInfo ci) {
    if (!Config.THIN_ICE.get()) return;
    if (level instanceof ServerLevel serverLevel && entity instanceof ServerPlayer serverPlayer) {
      if (onState.is(Blocks.ICE)) {
        if (serverLevel.getBiome(pos).value().getBaseTemperature() < 0.1f) {
          serverLevel.setBlockAndUpdate(pos, Blocks.WATER.defaultBlockState());
        }
      }
    }
  }

}
