package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.environmental_temperature_damage;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract @NonNull ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void tickTAIL_environmentalDamage(CallbackInfo ci) {
    if (!Config.ENVIRONMENTAL_TEMPERATURE_DAMAGE.get()) return;
    if (!this.isSpectator() && this.tickCount % 50 == 0) {
      ServerLevel level = this.level();
      Biome biome = level.getBiome(this.blockPosition()).value();
      float temperature = biome.getBaseTemperature();
      if (this.isInWaterOrRain()) temperature -= 0.2f;
      if (this.tickCount % 100 == 0 || temperature > 1.98f || temperature < 0.02f) {
        if (temperature > 1.9f) {
          this.hurtServer(level, level.damageSources().onFire(), 1.0f);
        } else if (temperature < 0.1f) {
          this.hurtServer(level, level.damageSources().freeze(), 1.0f);
        }
      }
    }
  }

}
