package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.phantoms_pick_up_players;

import net.minecraft.world.entity.monster.Phantom;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Phantom.PhantomCircleAroundAnchorGoal.class)
public abstract class PhantomCircleAroundAnchorGoalMixin {
  @Shadow
  @Final
  Phantom this$0;

  @Inject(method="tick", at=@At(value="INVOKE", target="Lnet/minecraft/world/entity/monster/Phantom$PhantomCircleAroundAnchorGoal;selectNext()V"))
  private void tickInject(CallbackInfo ci) {
    if (!Config.PHANTOMS_PICK_UP_PLAYERS.get()) return;
    this$0.ejectPassengers();
  }
}
