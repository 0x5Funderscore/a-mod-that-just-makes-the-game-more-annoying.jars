package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.phantoms_pick_up_players;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Phantom;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Phantom.PhantomSweepAttackGoal.class)
public abstract class PhantomSweepAttackGoalMixin {
  @Shadow
  @Final
  private Phantom this$0;

  @Inject(
      method="tick",
      at=@At(
          value="INVOKE",
          target="Lnet/minecraft/world/entity/monster/Phantom;doHurtTarget(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/Entity;)Z",
          shift=At.Shift.AFTER
      ),
      locals = LocalCapture.CAPTURE_FAILSOFT
  )
  private void didHurtedTarget(CallbackInfo ci, LivingEntity target) {
    if (!Config.PHANTOMS_PICK_UP_PLAYERS.get()) return;
    target.startRiding(this$0, true, true);
  }
}
