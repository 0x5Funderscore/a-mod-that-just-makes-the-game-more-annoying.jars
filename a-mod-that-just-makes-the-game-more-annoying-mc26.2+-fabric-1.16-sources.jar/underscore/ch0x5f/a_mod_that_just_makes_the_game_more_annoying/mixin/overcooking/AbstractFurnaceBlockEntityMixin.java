package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.overcooking;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  @Shadow
  @Final
  protected static int SLOT_RESULT;

  @Unique
  private static final int MAX_RESULT_ITEMS = 4;

  @Inject(method = "serverTick", at = @At("TAIL"))
  private static void postServerTick(ServerLevel level, BlockPos pos, BlockState state, AbstractFurnaceBlockEntity entity, CallbackInfo ci) {
    if (!Config.OVERCOOKING.get()) return;
    SlotAccess resultSlot = entity.getSlot(SLOT_RESULT);
    if (resultSlot == null) return;
    ItemStack stack = resultSlot.get();
    if (stack.count() > MAX_RESULT_ITEMS) {
      resultSlot.set(new ItemStack(Items.CHARCOAL, MAX_RESULT_ITEMS));
    }
  }

}
