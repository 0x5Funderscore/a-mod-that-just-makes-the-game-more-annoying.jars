package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.super_surge_conductor;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {
  @Shadow
  public abstract ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Unique
  private boolean isSurgeConductor(ItemStack itemStack) {
    return Items.LIGHTNING_ROD.asList().contains(itemStack.getItem()) || itemStack.getEnchantments().getLevel(this.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.CHANNELING)) > 0;
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.SUPER_SURGE_CONDUCTOR.get()) {
      ServerLevel level = this.level();
      if (level.isThundering() && level.isRainingAt(this.blockPosition()) && this.random.nextInt(4) == 0) {
        if (isSurgeConductor(this.getItemBySlot(EquipmentSlot.MAINHAND)) || isSurgeConductor(this.getItemBySlot(EquipmentSlot.OFFHAND))) {
          LightningBolt lb = new LightningBolt(EntityTypes.LIGHTNING_BOLT, level);
          lb.setPos(this.position());
          level.addFreshEntity(lb);
        }
      }
    }
  }
}
