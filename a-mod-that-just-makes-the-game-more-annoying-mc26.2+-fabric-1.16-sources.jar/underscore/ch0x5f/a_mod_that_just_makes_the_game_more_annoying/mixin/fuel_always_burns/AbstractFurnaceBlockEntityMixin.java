package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fuel_always_burns;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.NonNullList;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  @Shadow
  private static void consumeFuel(NonNullList<ItemStack> items, ItemStack fuel) {
    throw new UnsupportedOperationException("Implemented via mixin");
  }

  @ModifyVariable(method = "serverTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/core/NonNullList;get(I)Ljava/lang/Object;", ordinal = 0), name = "isLit")
  private static boolean modifyIsLit(boolean isLit, @Local(name = "entity", argsOnly = true) AbstractFurnaceBlockEntity entity, @Local(name = "level", argsOnly = true) ServerLevel level) {
    if (!Config.FUEL_ALWAYS_BURNS.get()) return isLit;
    if (!isLit) {
      ItemStack fuel = entity.items.get(1);
      int newLitTime = entity.getBurnDuration(level.fuelValues(), fuel);
      entity.litTimeRemaining = newLitTime;
      entity.litTotalTime = newLitTime;
      if (newLitTime > 0) {
        consumeFuel(entity.items, fuel);
        return true;
      }
      return false;
    }
    return true;
  }
}
