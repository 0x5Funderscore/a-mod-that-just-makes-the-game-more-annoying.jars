package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.gravel_and_stones_fall_on_your_head;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {
  @Shadow
  public abstract ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void tickTAIL_gravelFall(CallbackInfo ci) {
    if (!Config.GRAVEL_AND_STONES_FALL_ON_YOUR_HEAD.get()) return;
    if (this.tickCount % 4 != 0) return;
    if (!this.isSpectator() && Math.random() < 0.2d) {
      for (int i = 2; i < 18; i++) {
        BlockPos blockPos = this.blockPosition().above(i);
        BlockState blockState = this.level().getBlockState(blockPos);
        if (
            blockState.is(Blocks.GRAVEL)
                || (Math.random() < 0.5d && blockState.is(Blocks.POINTED_DRIPSTONE) || blockState.is(Blocks.DRIPSTONE_BLOCK))
                || (Math.random() < 0.05d && (blockState.is(BlockTags.BASE_STONE_OVERWORLD) || blockState.is(BlockTags.BASE_STONE_NETHER)))
        ) {
          FallingBlockEntity.fall(this.level(), blockPos, blockState);
          break;
        } else if (!blockState.isAir()) break;
      }
    }
  }

}
