package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.neutral_levitation;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

  @Redirect(method = "travelInAir", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/effect/MobEffectInstance;getAmplifier()I", ordinal = 0))
  private int changeLevitationAmplifier(MobEffectInstance instance) {
    int original = instance.getAmplifier();
    if (Config.NEUTRAL_LEVITATION.get()) {
      return -1;
    }
    return original;
  }

}
