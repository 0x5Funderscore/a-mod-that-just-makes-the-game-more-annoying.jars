package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.inverse_absorption;

import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Player.class)
public abstract class PlayerMixin {

  @Redirect(method = "actuallyHurt", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getAbsorptionAmount()F"))
  private float redirectAbsorptionAmount(Player instance) {
    if (!Config.INVERSE_ABSORPTION.get()) return instance.getAbsorptionAmount();
    return 0.0f;
  }

  @Redirect(method = "actuallyHurt", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;setAbsorptionAmount(F)V"))
  private void redirectSetAbsorptionAmount(Player instance, float v) {
    if (!Config.INVERSE_ABSORPTION.get()) instance.setAbsorptionAmount(v);
  }

}
