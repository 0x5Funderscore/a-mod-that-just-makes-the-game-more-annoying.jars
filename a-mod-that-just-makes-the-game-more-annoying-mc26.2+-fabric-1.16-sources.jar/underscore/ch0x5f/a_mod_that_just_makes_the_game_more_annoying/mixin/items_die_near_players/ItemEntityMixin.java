package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.items_die_near_players;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin extends Entity {

  @Shadow
  private int age;

  public ItemEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Shadow
  public abstract boolean hasPickUpDelay();

  @Definition(id = "age", field = "Lnet/minecraft/world/entity/item/ItemEntity;age:I")
  @Expression("this.age != ?")
  @WrapOperation(method = "tick", at = @At("MIXINEXTRAS:EXPRESSION"))
  private boolean extraAge(int left, int right, Operation<Boolean> original) {
    if (original.call(left, right)) {
      if (Config.ITEMS_DIE_NEAR_PLAYERS.get()) {
        if (!this.hasPickUpDelay()) {
          Level level = this.level();
          Player nearestPlayer = level.getNearestPlayer(this, 16d);
          if (nearestPlayer != null) {
            double distanceFraction = 1.0d - nearestPlayer.position().distanceTo(this.position()) / 16d;
            double itemAgeSpeed = Math.pow(3.0d, distanceFraction * 4.0d);
            this.age += (int)itemAgeSpeed - 1;
          }
        }
      }
      return true;
    } else return false;
  }

}
