package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.furnace_exponential_progress;

import net.minecraft.world.inventory.AbstractFurnaceMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceMenu.class)
public abstract class AbstractFurnaceMenuMixin {
  @Inject(method = "getBurnProgress", at = @At("TAIL"), cancellable = true)
  private void getBurnProgress(CallbackInfoReturnable<Float> cir) {
    if (!Config.FURNACE_EXPONENTIAL_PROGRESS.get()) return;
    cir.setReturnValue(Math.clamp(1f - (float)Math.pow(5f, -cir.getReturnValue()), 0f, 1f));
  }
}
