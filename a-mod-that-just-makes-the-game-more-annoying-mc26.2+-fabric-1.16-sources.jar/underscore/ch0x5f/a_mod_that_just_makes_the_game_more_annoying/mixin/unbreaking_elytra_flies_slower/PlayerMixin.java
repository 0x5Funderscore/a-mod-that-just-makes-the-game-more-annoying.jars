package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.unbreaking_elytra_flies_slower;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Avatar;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Player.class)
public abstract class PlayerMixin extends Avatar {

  protected PlayerMixin(EntityType<? extends LivingEntity> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void elytraSpeedReduction(CallbackInfo ci) {
    if (Config.UNBREAKING_ELYTRA_FLIES_SLOWER.get()) {
      if (this.isFallFlying()) {
        ItemStack chestItem = this.getItemBySlot(EquipmentSlot.CHEST);
        if (chestItem.is(Items.ELYTRA)) {
          int unbreakingLevel = 0;
          boolean mending = false;
          for (Object2IntMap.Entry<Holder<Enchantment>> enchantmentEntry: chestItem.getEnchantments().entrySet()) {
            Holder<Enchantment> key = enchantmentEntry.getKey();
            if (key.is(Enchantments.UNBREAKING)) {
              unbreakingLevel = enchantmentEntry.getIntValue();
            } else if (key.is(Enchantments.MENDING)) {
              mending = true;
            }
            if (unbreakingLevel > 0 && mending) break;
          }
          if (unbreakingLevel > 0 || mending) {
            double speedMultiplier = Math.pow(0.95, unbreakingLevel);
            if (mending) speedMultiplier *= 0.5d;
            this.addDeltaMovement(this.getDeltaMovement().scale(-1d + speedMultiplier));
          }
        }
      }
    }
  }

}
