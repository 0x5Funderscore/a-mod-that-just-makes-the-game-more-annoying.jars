package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.iron_golem_space_program;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.golem.AbstractGolem;
import net.minecraft.world.entity.animal.golem.IronGolem;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(IronGolem.class)
public abstract class IronGolemMixin extends AbstractGolem {

  protected IronGolemMixin(EntityType<? extends AbstractGolem> type, Level level) {
    super(type, level);
  }

  @Inject(method = "doHurtTarget", at = @At("TAIL"))
  private void afterHurtTarget(ServerLevel level, Entity target, CallbackInfoReturnable<Boolean> cir) {
    if (Config.IRON_GOLEM_SPACE_PROGRAM.get()) {
      target.addDeltaMovement(new Vec3(0d, 100d, 0d));
    }
  }
}
