package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.llama_spit_launch;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.LlamaSpit;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LlamaSpit.class)
public abstract class LlamaSpitMixin extends Projectile {

  public LlamaSpitMixin(EntityType<? extends Projectile> type, Level level) {
    super(type, level);
  }

  @Inject(method = "onHitEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/enchantment/EnchantmentHelper;doPostAttackEffects(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;)V"))
  private void afterHitEntity(
      EntityHitResult hitResult, CallbackInfo ci,
      @Local(name = "target") Entity target
  ) {
    if (Config.LLAMA_SPIT_LAUNCH.get()) target.addDeltaMovement(this.getDeltaMovement().scale(10d).horizontal().add(0d, 2d, 0d));
  }
}
