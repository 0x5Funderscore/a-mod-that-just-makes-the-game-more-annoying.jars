package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_portal;

import net.minecraft.advancements.*;
import net.minecraft.advancements.triggers.Criterion;
import net.minecraft.advancements.triggers.ImpossibleTrigger;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.ServerAdvancementManager;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.component.BlockItemStateProperties;
import net.minecraft.world.level.block.Blocks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;
import java.util.Map;
import java.util.Optional;


@Mixin(ServerAdvancementManager.class)
public abstract class ServerAdvancementManagerMixin {

  @ModifyVariable(
      method = "apply(Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/util/profiling/ProfilerFiller;)V",
      at = @At("HEAD"),
      argsOnly = true,
      name = "preparations"
  )
  private Map<Identifier,Advancement> addPreparations(Map<Identifier, Advancement> preparations) {
    if (!Config.REPLACE_END_PORTAL.get()) return preparations;
    preparations.put(AMTJMTGMA.FOUND_PORTAL_ROOM_ADVANCEMENT, new Advancement(
        Optional.of(Identifier.withDefaultNamespace("story/follow_ender_eye")),
        Optional.of(new DisplayInfo(
            new ItemStackTemplate(
                Blocks.TEST_BLOCK.asItem(),
                DataComponentPatch.builder()
                    .set(DataComponents.BLOCK_STATE, new BlockItemStateProperties(Map.of("mode", "fail")))
                .build()
            ),
            Component.literal("What Portal?"),
            Component.literal("First you have to find The Pickaxe That Can Mine End Portal Frames, in one specific chest in one specific room in a mansion somewhere, and then you have to find 12 portal frames, which spawn occasionally at the bottom of the world under trees"),
            Optional.empty(),
            AdvancementType.TASK,
            true, false, true
        )),
        AdvancementRewards.EMPTY,
        Map.of("complete", new Criterion<>(new ImpossibleTrigger(), new ImpossibleTrigger.TriggerInstance())),
        new AdvancementRequirements(List.of(List.of("complete"))),
        false
    ));
    return preparations;
  }
}
