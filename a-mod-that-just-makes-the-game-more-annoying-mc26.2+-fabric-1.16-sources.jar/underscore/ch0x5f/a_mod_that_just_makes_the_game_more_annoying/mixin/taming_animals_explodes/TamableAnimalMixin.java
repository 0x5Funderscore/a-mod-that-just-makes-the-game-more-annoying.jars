package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.taming_animals_explodes;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(TamableAnimal.class)
public abstract class TamableAnimalMixin extends Animal {
  protected TamableAnimalMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tame", at = @At("HEAD"), cancellable = true)
  private void tameStop(Player player, CallbackInfo ci) {
    if (Config.TAMING_ANIMALS_EXPLODES.get()) {
      if (this.level() instanceof ServerLevel serverLevel) {
        serverLevel.explode(this, this.getX(), this.getY(), this.getZ(), 2f, Level.ExplosionInteraction.MOB);
        this.remove(RemovalReason.DISCARDED);
      }
      ci.cancel();
    }
  }

}
