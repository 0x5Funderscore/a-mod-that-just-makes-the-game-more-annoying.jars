package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.do_not_swim;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Player.class)
public abstract class PlayerMixin {

  @ModifyArgs(
      method = "travel",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/entity/player/Player;setDeltaMovement(Lnet/minecraft/world/phys/Vec3;)V",
          ordinal = 0
      )
  )
  private void modifySwimDeltaMovement(Args args) {
    if (!Config.DO_NOT_SWIM.get()) return;
    args.set(0, ((Vec3)args.get(0)).scale(-1.0d - Math.random()));
  }

}
