package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.wild_tamed_animals;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(TamableAnimal.class)
public abstract class TamableAnimalMixin extends Animal {
  @Shadow
  public abstract void setOwner(@Nullable LivingEntity owner);

  @Shadow
  public abstract void setTame(boolean isTame, boolean includeSideEffects);

  protected TamableAnimalMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Override
  protected void actuallyHurt(@NonNull ServerLevel level, @NonNull DamageSource source, float dmg) {
    super.actuallyHurt(level, source, dmg);
    if (Config.WILD_TAMED_ANIMALS.get()) {
      this.setOwner(null);
      this.setTame(false, true);
    }
  }
}
