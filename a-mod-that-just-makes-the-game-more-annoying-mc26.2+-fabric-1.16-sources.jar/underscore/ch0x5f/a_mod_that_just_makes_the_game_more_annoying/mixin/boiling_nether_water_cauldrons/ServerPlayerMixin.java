package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.boiling_nether_water_cauldrons;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {
  @Shadow
  public abstract ServerLevel level();

  @Shadow
  public abstract boolean hurtServer(ServerLevel level, DamageSource source, float damage);

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.BOILING_NETHER_WATER_CAULDRONS.get()) {
      ServerLevel level = this.level();
      BlockPos pos = this.blockPosition();
      if (level.getBlockState(pos).is(Blocks.WATER_CAULDRON)) {
        if (level.environmentAttributes().getValue(EnvironmentAttributes.WATER_EVAPORATES, pos)) {
          Vec3 particlePos = Vec3.atCenterOf(pos);
          level.sendParticles(ParticleTypes.BUBBLE, false, false, particlePos.x, particlePos.y, particlePos.z, 3, 0.2d, 0.25d, 0.2d, 0.1d);
          this.hurtServer(level, this.damageSources().onFire(), 1f);
        }
      }
    }
  }
}
