package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.lava_blows_up_furnaces;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public class AbstractFurnaceBlockEntityMixin {

  @Shadow
  public NonNullList<ItemStack> items;

  @Shadow
  @Final
  protected static int SLOT_FUEL;

  @Inject(method = "serverTick", at = @At("HEAD"), cancellable = true)
  private static void serverTickPre(ServerLevel level, BlockPos pos, BlockState state, AbstractFurnaceBlockEntity entity, CallbackInfo ci) {
    if (!Config.LAVA_BLOWS_UP_FURNACES.get()) return;
    if (entity.items.get(SLOT_FUEL).is(Items.LAVA_BUCKET)) {
      level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
      double x = pos.getX() + 0.5d;
      double y = pos.getY() + 0.25d;
      double z = pos.getZ() + 0.5d;
      level.sendParticles(ParticleTypes.LAVA, false, false, x, y, z, 64, 0.1d, 0.1d, 0.1d, 5.0d);
      level.explode(null, x, y, z, 2.0f, Level.ExplosionInteraction.BLOCK);
      ci.cancel();
    }
  }

}
