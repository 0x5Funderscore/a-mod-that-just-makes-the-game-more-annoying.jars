package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.broken_recipes;

import net.minecraft.core.Holder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.ShapedRecipePattern;
import org.joml.Vector2i;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;


@Mixin(ShapedRecipePattern.class)
public abstract class ShapedRecipePatternMixin {
  @Shadow
  @Final
  private int height;

  @Shadow
  @Final
  private int width;

  @Shadow
  @Final
  private List<Optional<Ingredient>> ingredients;

  @Inject(method = "matches(Lnet/minecraft/world/item/crafting/CraftingInput;Z)Z", at = @At("HEAD"), cancellable = true)
  private void matches(CraftingInput input, boolean xFlip, CallbackInfoReturnable<Boolean> cir) {
    if (!Config.BROKEN_RECIPES.get()) return;

    List<Vector2i> cellMapping = new ArrayList<>();
    for (int y = 0; y < this.height; y++) {
      for (int x = 0; x < this.width; x++) {
        Optional<Ingredient> expected;
        if (xFlip) {
          expected = this.ingredients.get(this.width - x - 1 + y * this.width);
        } else {
          expected = this.ingredients.get(x + y * this.width);
        }
        if (expected.isPresent() && !expected.get().acceptsItem(Holder.direct(Items.AIR))) {
          cellMapping.add(new Vector2i(x, y));
        }
      }
    }
    Random random = new Random();
    List<Vector2i> remappedCells = new ArrayList<>();
    while (!cellMapping.isEmpty()) {
      remappedCells.add(cellMapping.remove(random.nextInt(cellMapping.size())));
    }
    int i = 0;
    for(int yo = 0; yo < this.height; ++yo) {
      for(int xo = 0; xo < this.width; ++xo) {
        Optional<Ingredient> expected;
        if (xFlip) {
          expected = this.ingredients.get(this.width - xo - 1 + yo * this.width);
        } else {
          expected = this.ingredients.get(xo + yo * this.width);
        }

        int x = xo;
        int y = yo;
        if (expected.isPresent() && !expected.get().acceptsItem(Holder.direct(Items.AIR))) {
          Vector2i v = remappedCells.get(i);
          i++;
          x = v.x;
          y = v.y;
        }

        ItemStack actual = input.getItem(x, y);
        if (!Ingredient.testOptionalIngredient(expected, actual)) {
          cir.setReturnValue(false);
          return;
        }
      }
    }

    cir.setReturnValue(true);
  }

}
