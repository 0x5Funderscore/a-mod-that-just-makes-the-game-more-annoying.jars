package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.creepers_ignore_cats;

import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.monster.Creeper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Creeper.class)
public abstract class CreeperMixin {

  @Redirect(method = "registerGoals", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V"))
  private void redirectAddGoal(GoalSelector instance, int prio, Goal goal) {
    if (!Config.CREEPERS_IGNORE_CATS.get() || !(goal instanceof AvoidEntityGoal<?>)) instance.addGoal(prio, goal);
  }

}
