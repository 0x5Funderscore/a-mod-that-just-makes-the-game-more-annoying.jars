package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.end_crystals_require_player_punch;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EndCrystal.class)
public abstract class EndCrystalMixin extends Entity {
  public EndCrystalMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Dynamic
  @Unique
  private boolean isInvulnerableTo2(DamageSource source) {
    return this.isInvulnerableToBase(source) || !source.is(DamageTypes.PLAYER_ATTACK);
  }

  @Redirect(method = "hurtServer", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/boss/enderdragon/EndCrystal;isInvulnerableToBase(Lnet/minecraft/world/damagesource/DamageSource;)Z"))
  private boolean redirectInvulnerableServer(EndCrystal instance, DamageSource source) {
    if (!Config.END_CRYSTALS_REQUIRE_PLAYER_PUNCH.get()) return this.isInvulnerableToBase(source);
    return this.isInvulnerableTo2(source);
  }

  @Redirect(method = "hurtClient", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/boss/enderdragon/EndCrystal;isInvulnerableToBase(Lnet/minecraft/world/damagesource/DamageSource;)Z"))
  private boolean redirectInvulnerableClient(EndCrystal instance, DamageSource source) {
    if (!Config.END_CRYSTALS_REQUIRE_PLAYER_PUNCH.get()) return this.isInvulnerableToBase(source);
    return this.isInvulnerableTo2(source);
  }
}
