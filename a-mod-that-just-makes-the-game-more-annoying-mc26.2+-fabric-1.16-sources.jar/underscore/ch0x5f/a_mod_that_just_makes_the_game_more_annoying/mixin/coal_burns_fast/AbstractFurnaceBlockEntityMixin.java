package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.coal_burns_fast;

import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.FuelValues;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  @Inject(method = "getBurnDuration", at = @At("TAIL"), cancellable = true)
  private void getBurnDurationTAIL(FuelValues fuelValues, ItemStack itemStack, CallbackInfoReturnable<Integer> cir) {
    if (Config.COAL_BURNS_FAST.get())
      if (itemStack.is(ItemTags.COALS) || itemStack.is(Items.COAL_BLOCK)) {
        cir.setReturnValue(cir.getReturnValue() / 16);
      }
  }

}
