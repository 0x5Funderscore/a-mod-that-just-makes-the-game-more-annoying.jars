package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fifty_skeleton_horses;

import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.world.entity.animal.equine.SkeletonTrapGoal;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(SkeletonTrapGoal.class)
public abstract class SkeletonTrapGoalMixin {

  @Expression("3")
  @ModifyExpressionValue(method = "tick", at = @At("MIXINEXTRAS:EXPRESSION"))
  private int modify3(int original) {
    if (Config.FIFTY_SKELETON_HORSES.get()) return 49;
    return original;
  }

}
