package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.endermen_teleport_a_lot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.class)
public abstract class EnderManMixin extends Monster {
  protected EnderManMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @Shadow
  protected abstract boolean teleport();

  @Inject(
      method = "customServerAiStep",
      at = @At("HEAD")
  )
  private void extraTeleport(ServerLevel level, CallbackInfo ci) {
    if (!Config.ENDERMEN_TELEPORT_A_LOT.get()) return;
    if (this.random.nextFloat() < 0.5 && this.getTarget() == null) this.teleport();
  }

}
