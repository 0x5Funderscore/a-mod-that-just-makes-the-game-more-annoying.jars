package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.annoying_trapped_chests;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.TrappedChestBlock;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.ITrappedChestSelfClosingExtension;

import java.util.function.Supplier;


@Mixin(TrappedChestBlock.class)
public abstract class TrappedChestBlockMixin extends ChestBlock {
  protected TrappedChestBlockMixin(Supplier<BlockEntityType<? extends ChestBlockEntity>> blockEntityType, SoundEvent openSound, SoundEvent closeSound, Properties properties) {
    super(blockEntityType, openSound, closeSound, properties);
  }

  @Override
  public @Nullable <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState blockState, BlockEntityType<T> type) {
    BlockEntityTicker<T> ticker = super.getTicker(level, blockState, type);
    if (Config.ANNOYING_TRAPPED_CHESTS.get()) {
      BlockEntityTicker<T> postTicker = (level1, pos, state, entity) -> {
        if (entity instanceof TrappedChestBlockEntity trappedChest && level1 instanceof ServerLevel serverLevel) {
          ITrappedChestSelfClosingExtension extended = (ITrappedChestSelfClosingExtension)trappedChest;
          if (extended.willSelfClose()) {
            if (extended.tickSelfClosing()) {
              trappedChest.getEntitiesWithContainerOpen().forEach(cu -> {
                if (cu instanceof ServerPlayer player) player.closeContainer();
              });
            }
          }
        }
      };
      return ticker == null ? postTicker : ticker.andThen(postTicker);
    }
    return ticker;
  }
}
