package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.copper_golem_lightning;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.animal.golem.AbstractGolem;
import net.minecraft.world.entity.animal.golem.CopperGolem;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(CopperGolem.class)
public abstract class CopperGolemMixin extends AbstractGolem {

  protected CopperGolemMixin(EntityType<? extends AbstractGolem> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tick", at = @At("HEAD"))
  private void preTick(CallbackInfo ci) {
    if (!this.level().isClientSide() && Config.COPPER_GOLEM_LIGHTNING.get() && this.level().isRainingAt(this.blockPosition()) && this.level().isThundering() && this.onGround() && this.level().canSeeSky(this.blockPosition()) && this.level().getRandom().nextInt(10) == 0) {
      LightningBolt lb = new LightningBolt(EntityTypes.LIGHTNING_BOLT, this.level());
      lb.setPos(this.position());
      this.level().addFreshEntity(lb);
    }
  }

}
