package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.loud_cave_sounds;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(SimpleSoundInstance.class)
@Environment(EnvType.CLIENT)
public class SimpleSoundInstanceMixin {

  @Definition(id = "AMBIENT", field = "Lnet/minecraft/sounds/SoundSource;AMBIENT:Lnet/minecraft/sounds/SoundSource;")
  @Expression("AMBIENT")
  @ModifyExpressionValue(method = "forAmbientMood", at = @At("MIXINEXTRAS:EXPRESSION"))
  private static SoundSource replaceAmbientSoundSource(SoundSource original) {
    if (Config.LOUD_CAVE_SOUNDS.get()) return SoundSource.MASTER;
    return original;
  }

}
