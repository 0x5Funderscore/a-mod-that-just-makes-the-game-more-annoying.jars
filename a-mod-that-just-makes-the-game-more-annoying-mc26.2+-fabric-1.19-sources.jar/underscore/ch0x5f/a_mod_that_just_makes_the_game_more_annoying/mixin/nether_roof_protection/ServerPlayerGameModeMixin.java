package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.nether_roof_protection;

import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.BuiltinDimensionTypes;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayerGameMode.class)
public class ServerPlayerGameModeMixin {

  @Shadow
  protected ServerLevel level;

  @Shadow
  @Final
  protected ServerPlayer player;

  @Inject(method = "destroyBlock", at = @At("HEAD"), cancellable = true)
  private void beforeDestroyBlock(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
    if (this.level.dimension() == Level.NETHER && pos.getY() >= 128) {
      rb$sendDenial(this.player);
      cir.setReturnValue(false);
      cir.cancel();
    }
  }

  @Inject(method = "useItemOn", at = @At("HEAD"), cancellable = true)
  private void beforeUseItemOn(ServerPlayer player, Level level, ItemStack itemStack, InteractionHand hand, BlockHitResult hitResult, CallbackInfoReturnable<InteractionResult> cir) {
    if (Config.NETHER_ROOF_PROTECTION.get()) {
      if (level.dimension() == Level.NETHER && hitResult.getType() == HitResult.Type.BLOCK && hitResult.getBlockPos().getY() >= 128 - hitResult.getDirection().getStepY()) {
        rb$sendDenial(player);
        cir.setReturnValue(InteractionResult.FAIL);
        cir.cancel();
      }
    }
  }

  @Unique
  private static void rb$sendDenial(ServerPlayer player) {
    player.sendSystemMessage(Component.empty().append(Component.literal("Hey!").withStyle(Style.EMPTY.withBold(true).withColor(TextColor.RED))).append(Component.literal(" You can't do that here.").withStyle(Style.EMPTY.withBold(false).withColor(TextColor.GRAY))));
  }

}
