package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fighting_fish;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.fish.AbstractFish;
import net.minecraft.world.entity.animal.fish.AbstractSchoolingFish;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractSchoolingFish.class)
public abstract class AbstractSchoolingFishMixin extends AbstractFish {

  public AbstractSchoolingFishMixin(EntityType<? extends AbstractFish> type, Level level) {
    super(type, level);
  }

  @Inject(method = "registerGoals", at = @At("HEAD"))
  private void preRegisterGoals(CallbackInfo ci) {
    if (Config.FIGHTING_FISH.get()) {
      this.targetSelector.addGoal(-1, new HurtByTargetGoal(this));
      this.goalSelector.addGoal(-1, new MeleeAttackGoal(this, 1.0d, true));
    }
  }
}
