package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.sweet_berry_bushes_apply_effects;

import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InsideBlockEffectApplier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.SweetBerryBushBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(SweetBerryBushBlock.class)
public abstract class SweetBerryBushBlockMixin {
  @Inject(
      method = "entityInside",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/entity/Entity;hurtServer(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;F)Z"
      )
  )
  private void entityInsideHurt(BlockState state, Level level, BlockPos pos, Entity entity, InsideBlockEffectApplier effectApplier, boolean isPrecise, CallbackInfo ci) {
    if (!Config.SWEET_BERRY_BUSHES_APPLY_EFFECTS.get()) return;
    if (entity instanceof LivingEntity livingEntity) {
      livingEntity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 240, 0));
      livingEntity.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 240, 0));
      livingEntity.addEffect(new MobEffectInstance(MobEffects.POISON, 240, 0));
    }
  }
}
