package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.wither_skeletons_combine;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.skeleton.AbstractSkeleton;
import net.minecraft.world.entity.monster.skeleton.WitherSkeleton;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(WitherSkeleton.class)
public abstract class WitherSkeletonMixin extends AbstractSkeleton {
  protected WitherSkeletonMixin(EntityType<? extends AbstractSkeleton> type, Level level) {
    super(type, level);
  }

  @Override
  public void tick() {
    if (Config.WITHER_SKELETONS_COMBINE.get() && !this.isRemoved()) {
      if (this.level() instanceof ServerLevel serverLevel) {
        List<WitherSkeleton> nearbyEntities = serverLevel
            .getEntities(
                EntityTypeTest.forExactClass(WitherSkeleton.class),
                AABB.ofSize(this.position(), 1.0, 1.0, 1.0),
                witherSkeleton -> witherSkeleton.getUUID() != this.getUUID()
            )
            .stream()
            .filter(witherSkeleton -> this.distanceToSqr(witherSkeleton) <= 1.0d)
            .limit(2)
            .toList();
        if (nearbyEntities.size() >= 2) {
          Vec3 averagePosition = this.position().add(nearbyEntities.getFirst().position()).add(nearbyEntities.getLast().position()).scale(0.3333333333333333);
          nearbyEntities.forEach(witherSkeleton -> witherSkeleton.remove(RemovalReason.DISCARDED));
          this.remove(RemovalReason.DISCARDED);
          WitherBoss wither = new WitherBoss(EntityTypes.WITHER, serverLevel);
          wither.setPos(averagePosition);
          serverLevel.addFreshEntity(wither);
        }
      }
    }
    super.tick();
  }
}
