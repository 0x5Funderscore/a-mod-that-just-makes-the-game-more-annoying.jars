package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_more_witch_spawns;

import com.google.common.collect.ImmutableMap;
import net.minecraft.util.random.Weighted;
import net.minecraft.util.random.WeightedList;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.MobSpawnSettings;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.HashMap;
import java.util.Map;


@Mixin(MobSpawnSettings.class)
public class MobSpawnSettingsMixin {

  /*
  @Mutable
  @Shadow
  @Final
  private Map<MobCategory,WeightedList<MobSpawnSettings.SpawnerData>> spawners;

  @Shadow
  @Final
  private static Logger LOGGER;

  @Inject(method = "getMobs", at = @At("HEAD"))
  private void preGetMobs(MobCategory category, CallbackInfoReturnable<WeightedList<MobSpawnSettings.SpawnerData>> cir) {
    if (this.spawners instanceof ImmutableMap<MobCategory,WeightedList<MobSpawnSettings.SpawnerData>>) {
      if (Config.MORE_WITCH_SPAWNS.get()) {
        LOGGER.info("change mob spawn settings");
        this.spawners = new HashMap<>(this.spawners);
        this.spawners.computeIfPresent(MobCategory.MONSTER, (mobCategory, spawnerDataWeightedList) -> {
          for (Weighted<MobSpawnSettings.SpawnerData> item: spawnerDataWeightedList.unwrap()) {
            if (item.value().type() == EntityTypes.WITCH) {
              item.weight *= 40;
            }
          }
          return spawnerDataWeightedList;
        });
      }
    }
  }
   */

}
