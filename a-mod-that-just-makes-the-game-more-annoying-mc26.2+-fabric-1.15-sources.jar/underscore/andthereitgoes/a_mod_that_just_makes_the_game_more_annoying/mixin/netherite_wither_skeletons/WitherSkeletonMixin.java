package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.netherite_wither_skeletons;

import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.skeleton.WitherSkeleton;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(WitherSkeleton.class)
public abstract class WitherSkeletonMixin extends Mob {

  protected WitherSkeletonMixin(EntityType<? extends Mob> type, Level level) {
    super(type, level);
  }

  @Inject(method = "populateDefaultEquipmentSlots", at = @At("HEAD"))
  private void replaceEquipmentSlots(RandomSource random, DifficultyInstance difficulty, CallbackInfo ci) {
    //noinspection ConstantValue
    if (Config.NETHERITE_WITHER_SKELETONS.get() && (LivingEntity)this instanceof WitherSkeleton) {
      this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET, 1));
      this.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE, 1));
      this.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS, 1));
      this.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS, 1));
      this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD, 1));
      this.setDropChance(EquipmentSlot.HEAD, 0f);
      this.setDropChance(EquipmentSlot.CHEST, 0f);
      this.setDropChance(EquipmentSlot.LEGS, 0f);
      this.setDropChance(EquipmentSlot.FEET, 0f);
      this.setDropChance(EquipmentSlot.MAINHAND, 0f);
    }
  }
}
