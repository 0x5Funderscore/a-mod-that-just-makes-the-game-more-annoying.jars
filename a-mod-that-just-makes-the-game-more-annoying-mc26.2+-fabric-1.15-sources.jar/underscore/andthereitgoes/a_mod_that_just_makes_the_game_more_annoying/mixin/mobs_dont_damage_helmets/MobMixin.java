package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.mobs_dont_damage_helmets;

import com.llamalad7.mixinextras.expression.Definition;import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Mob.class)
public abstract class MobMixin {
  @Definition(id = "isDamageableItem", method = "Lnet/minecraft/world/item/ItemStack;isDamageableItem()Z")
  @Definition(id = "sunBlocker", local = @Local(type = ItemStack.class, name = "sunBlocker"))
  @Expression("sunBlocker.isDamageableItem()")
  @ModifyExpressionValue(method = "burnUndead", at = @At("MIXINEXTRAS:EXPRESSION"))
  private boolean modifyIsDamageableItem(boolean original) {
    if (Config.MOBS_DONT_DAMAGE_HELMETS.get()) return false;
    return original;
  }
}
