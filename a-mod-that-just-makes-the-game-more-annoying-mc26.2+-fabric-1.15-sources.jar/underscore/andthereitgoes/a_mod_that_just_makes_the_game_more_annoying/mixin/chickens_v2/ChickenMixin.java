package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.chickens_v2;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Chicken.class)
public abstract class ChickenMixin extends Animal {

  protected ChickenMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Redirect(method = "registerGoals", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V"))
  private void redirectAddGoal(GoalSelector instance, int prio, Goal goal) {
    if (Config.CHICKENS_V2.get()) {
      if (prio == 0) {
        TargetingConditions.Selector selector = (target, level) -> !target.isSpectator() && !target.hasInfiniteMaterials() && target.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true, selector));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 2.0d, true));
      } else {
        prio++;
      }
    }
    instance.addGoal(prio, goal);
  }

  @Inject(method = "createAttributes", at = @At("TAIL"))
  private static void addExtraAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (!Config.CHICKENS_V2.get()) return;
    cir.getReturnValue()
        .add(Attributes.FLYING_SPEED, 4.0d)
        .add(Attributes.ATTACK_DAMAGE, 8.0f)
        .add(Attributes.ATTACK_KNOCKBACK, 2.0f)
        .add(Attributes.MAX_HEALTH, 20.0f)
    ;
  }

  @Override
  protected @NonNull PathNavigation createNavigation(@NonNull Level level) {
    if (!Config.CHICKENS_V2.get()) return super.createNavigation(level);
    FlyingPathNavigation flyingPathNavigation = new FlyingPathNavigation(this, level);
    flyingPathNavigation.setCanOpenDoors(false);
    flyingPathNavigation.setCanFloat(true);
    return flyingPathNavigation;
  }
}
