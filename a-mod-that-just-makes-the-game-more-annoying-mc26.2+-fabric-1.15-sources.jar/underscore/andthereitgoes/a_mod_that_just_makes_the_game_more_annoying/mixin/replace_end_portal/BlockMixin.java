package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_portal;

import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.PlayerAdvancements;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.TestBlockMode;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.function.Supplier;


@Mixin(Block.class)
public abstract class BlockMixin extends BlockBehaviour {

  public BlockMixin(Properties properties) {
    super(properties);
  }

  @Inject(method = "stepOn", at = @At("HEAD"))
  private void stepOnHEAD(Level level, BlockPos pos, BlockState onState, Entity entity, CallbackInfo ci) {
    if (level.isClientSide()) return;
    if (onState.isAir()) return;
    if (level instanceof ServerLevel serverLevel) {
      if (!Config.REPLACE_END_PORTAL.get()) return;
      if (entity instanceof ServerPlayer serverPlayer) {
        MinecraftServer server = serverLevel.getServer();
        if (server.getTickCount() % 10 == 0) {
          if (onState.is(Blocks.TEST_BLOCK) && onState.getValue(BlockStateProperties.TEST_BLOCK_MODE).equals(TestBlockMode.FAIL)) {
            AdvancementHolder foundPortalRoomAdvancementHolder = server.getAdvancements().get(AMTJMTGMA.FOUND_PORTAL_ROOM_ADVANCEMENT);
            if (foundPortalRoomAdvancementHolder != null) {
              PlayerAdvancements playerAdvancements = serverPlayer.getAdvancements();
              if (!playerAdvancements.getOrStartProgress(foundPortalRoomAdvancementHolder).isDone()) {
                playerAdvancements.award(foundPortalRoomAdvancementHolder, "complete");
              }
            }
          }
        }
      }
    }
  }

  @Inject(method = "playerDestroy", at = @At("HEAD"))
  private void playerDestroyHEAD_dropEndPortalFrame(Level level, Player player, BlockPos pos, BlockState state, BlockEntity blockEntity, ItemStack destroyedWith, CallbackInfo ci) {
    if (!Config.REPLACE_END_PORTAL.get()) return;
    if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer serverPlayer) {
      if (state.is(Blocks.END_PORTAL_FRAME)) {
        if (!destroyedWith.isEmpty()) {
          CustomData customData = destroyedWith.getComponents().getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY);
          if (customData.copyTag().getBooleanOr("breaks_end_portal_frames", false)) {
            @Nullable AdvancementHolder advancementHolder = serverLevel.getServer().getAdvancements().get(AMTJMTGMA.FOUND_PORTAL_ROOM_ADVANCEMENT);
            boolean hasAdvancement = true;
            if (advancementHolder != null) {
              hasAdvancement = serverPlayer.getAdvancements().getOrStartProgress(advancementHolder).isDone();
            }// else LOGGER.info("Could not find can mine end portal frame advancement.");
            if (hasAdvancement) {
              Block.popResource(serverLevel, pos, new ItemStack(Items.END_PORTAL_FRAME, 1));
            }
          }
        }
      }
    }
  }

}
