package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.solidifying_lava;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.LavaFluid;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LavaFluid.class)
public class LavaFluidMixin {

  @Inject(method = "randomTick", at = @At("TAIL"))
  private void postRandomTick(ServerLevel level, BlockPos pos, FluidState fluidState, RandomSource random, CallbackInfo ci) {
    if (Config.SOLIDIFYING_LAVA.get() && fluidState.isSource() && !level.environmentAttributes().getDimensionValue(EnvironmentAttributes.FAST_LAVA) && Math.random() < 0.05d) {
      level.setBlockAndUpdate(pos, Blocks.OBSIDIAN.defaultBlockState());
    }
  }

}
