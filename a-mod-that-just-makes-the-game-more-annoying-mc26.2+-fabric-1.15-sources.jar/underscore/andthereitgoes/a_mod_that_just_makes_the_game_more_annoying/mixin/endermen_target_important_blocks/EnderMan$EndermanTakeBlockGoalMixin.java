package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.endermen_target_important_blocks;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.EndermanTakeBlockGoal.class)
public class EnderMan$EndermanTakeBlockGoalMixin {

  @Unique private static final TagKey<Block> TAG_SAPLINGS = TagKey.create(Registries.BLOCK, Identifier.withDefaultNamespace("saplings"));
  @Unique private static final TagKey<Block> TAG_ORES = TagKey.create(Registries.BLOCK, Identifier.withDefaultNamespace("ores"));

  @Unique
  private static boolean isImportant(BlockState blockState) {
    return (
        blockState.hasBlockEntity() ||
        blockState.is(BlockTags.ALL_HANGING_SIGNS) ||
        (blockState.is(BlockTags.ANCIENT_CITY_REPLACEABLE) && !blockState.is(Blocks.DEEPSLATE)) ||
        blockState.is(BlockTags.ANVIL) ||
        blockState.is(BlockTags.SIGNS) ||
        blockState.is(BlockTags.BANNERS) ||
        blockState.is(BlockTags.BARS) ||
        blockState.is(BlockTags.BEACON_BASE_BLOCKS) ||
        blockState.is(BlockTags.BEEHIVES) ||
        blockState.is(BlockTags.BUTTONS) ||
        blockState.is(BlockTags.CAMPFIRES) ||
        blockState.is(BlockTags.CANDLES) ||
        blockState.is(BlockTags.CANDLE_CAKES) ||
        blockState.is(BlockTags.CAULDRONS) ||
        blockState.is(BlockTags.CHAINS) ||
        blockState.is(BlockTags.CONCRETE) ||
        blockState.is(BlockTags.CONCRETE_POWDERS) ||
        blockState.is(BlockTags.COPPER) ||
        blockState.is(BlockTags.COPPER_GOLEM_STATUES) ||
        blockState.is(BlockTags.CORAL_BLOCKS) ||
        blockState.is(BlockTags.CROPS) ||
        blockState.is(BlockTags.ENCHANTMENT_POWER_PROVIDER) ||
        blockState.is(BlockTags.FEATURES_CANNOT_REPLACE) ||
        blockState.is(BlockTags.FENCE_GATES) ||
        blockState.is(BlockTags.FENCES) ||
        blockState.is(BlockTags.FIRE) ||
        blockState.is(BlockTags.FLOWERS) ||
        blockState.is(BlockTags.FLOWER_POTS) ||
        blockState.is(BlockTags.GLAZED_TERRACOTTA) ||
        blockState.is(BlockTags.GROWS_CROPS) ||
        blockState.is(BlockTags.GUARDED_BY_PIGLINS) ||
        blockState.is(BlockTags.HOGLIN_REPELLENTS) ||
        blockState.is(BlockTags.IMPERMEABLE) ||
        blockState.is(BlockTags.LANTERNS) ||
        blockState.is(BlockTags.LIGHTNING_RODS) ||
        blockState.is(TAG_ORES) ||
        blockState.is(BlockTags.PIGLIN_REPELLENTS) ||
        blockState.is(BlockTags.PLANKS) ||
        blockState.is(BlockTags.PORTALS) ||
        blockState.is(BlockTags.PRESSURE_PLATES) ||
        blockState.is(BlockTags.RAILS) ||
        blockState.is(BlockTags.WOODEN_SHELVES) ||
        blockState.is(TAG_SAPLINGS) ||
        blockState.is(BlockTags.SHULKER_BOXES) ||
        blockState.is(BlockTags.SPELEOTHEMS) ||
        blockState.is(BlockTags.STAIRS) ||
        blockState.is(BlockTags.STONE_BRICKS) ||
        blockState.is(BlockTags.SLABS) ||
        blockState.is(BlockTags.TRAPDOORS) ||
        blockState.is(BlockTags.WALLS) ||
        blockState.is(BlockTags.WOOL) ||
        blockState.is(BlockTags.WOOL_CARPETS) ||
        blockState.is(Blocks.END_PORTAL_FRAME) ||
        blockState.is(Blocks.VAULT) ||
        blockState.is(Blocks.SCULK_SENSOR) ||
        blockState.is(Blocks.SCULK_SHRIEKER) ||
        blockState.is(Blocks.CALIBRATED_SCULK_SENSOR) ||
        blockState.is(Blocks.REDSTONE_WIRE) ||
        blockState.is(Blocks.REDSTONE_WALL_TORCH) ||
        blockState.is(Blocks.REDSTONE_TORCH) ||
        blockState.is(Blocks.REDSTONE_LAMP) ||
        blockState.is(Blocks.REDSTONE_BLOCK) ||
        blockState.is(Blocks.TORCH) ||
        blockState.is(Blocks.SOUL_TORCH) ||
        blockState.is(Blocks.WALL_TORCH) ||
        blockState.is(Blocks.SOUL_WALL_TORCH) ||
        blockState.is(Blocks.JACK_O_LANTERN) ||
        blockState.is(Blocks.BAMBOO_BLOCK) ||
        blockState.is(Blocks.BAMBOO_MOSAIC) ||
        blockState.is(Blocks.STRIPPED_BAMBOO_BLOCK) ||
        blockState.is(Blocks.ACACIA_WOOD) ||
        blockState.is(Blocks.BIRCH_WOOD) ||
        blockState.is(Blocks.CHERRY_WOOD) ||
        blockState.is(Blocks.JUNGLE_WOOD) ||
        blockState.is(Blocks.DARK_OAK_WOOD) ||
        blockState.is(Blocks.MANGROVE_WOOD) ||
        blockState.is(Blocks.OAK_WOOD) ||
        blockState.is(Blocks.PALE_OAK_WOOD) ||
        blockState.is(Blocks.SPRUCE_WOOD) ||
        blockState.is(Blocks.STRIPPED_ACACIA_WOOD) ||
        blockState.is(Blocks.STRIPPED_BIRCH_WOOD) ||
        blockState.is(Blocks.STRIPPED_CHERRY_WOOD) ||
        blockState.is(Blocks.STRIPPED_JUNGLE_WOOD) ||
        blockState.is(Blocks.STRIPPED_DARK_OAK_WOOD) ||
        blockState.is(Blocks.STRIPPED_MANGROVE_WOOD) ||
        blockState.is(Blocks.STRIPPED_OAK_WOOD) ||
        blockState.is(Blocks.STRIPPED_PALE_OAK_WOOD) ||
        blockState.is(Blocks.STRIPPED_SPRUCE_WOOD) ||
        blockState.is(Blocks.STRIPPED_ACACIA_LOG) ||
        blockState.is(Blocks.STRIPPED_BIRCH_LOG) ||
        blockState.is(Blocks.STRIPPED_CHERRY_LOG) ||
        blockState.is(Blocks.STRIPPED_JUNGLE_LOG) ||
        blockState.is(Blocks.STRIPPED_DARK_OAK_LOG) ||
        blockState.is(Blocks.STRIPPED_MANGROVE_LOG) ||
        blockState.is(Blocks.STRIPPED_OAK_LOG) ||
        blockState.is(Blocks.STRIPPED_PALE_OAK_LOG) ||
        blockState.is(Blocks.STRIPPED_SPRUCE_LOG) ||
        blockState.is(Blocks.DRAGON_EGG) ||
        blockState.is(Blocks.DRAGON_HEAD) ||
        blockState.is(Blocks.DRAGON_WALL_HEAD) ||
        blockState.is(Blocks.NOTE_BLOCK) ||
        blockState.is(Blocks.JUKEBOX) ||
        blockState.is(Blocks.PISTON) ||
        blockState.is(Blocks.STICKY_PISTON) ||
        blockState.is(Blocks.SLIME_BLOCK) ||
        blockState.is(Blocks.HONEY_BLOCK) ||
        blockState.is(Blocks.CAKE) ||
        blockState.is(Blocks.COBBLESTONE) ||
        blockState.is(Blocks.COBBLED_DEEPSLATE) ||
        blockState.is(Blocks.SMOOTH_STONE) ||
        blockState.is(Blocks.STONE_BRICKS) ||
        blockState.is(Blocks.SMOOTH_BASALT) ||
        blockState.is(Blocks.TUFF_BRICKS) ||
        blockState.is(Blocks.DEEPSLATE_BRICKS) ||
        blockState.is(Blocks.DEEPSLATE_TILES) ||
        blockState.is(Blocks.POLISHED_BLACKSTONE_BRICKS) ||
        blockState.is(Blocks.POLISHED_BLACKSTONE)
    );
  }

  @Shadow
  @Final
  private EnderMan enderman;

  @Definition(id = "BlockPos", type = BlockPos.class)
  @Expression("new BlockPos(?, ?, ?)")
  @ModifyExpressionValue(method = "tick", at = @At("MIXINEXTRAS:EXPRESSION"))
  private BlockPos modifyPos(
      BlockPos original,
      @Local(name = "level") Level level
  ) {
    if (Config.ENDERMEN_TARGET_IMPORTANT_BLOCKS.get()) {
      BlockPos closestImportantBlockPos = original;
      BlockPos pos = this.enderman.blockPosition().offset(0,1,0);
      int closestImportantBlockDistanceSquared = Math.min((int)original.distSqr(pos), 5*5*2+1);
      for (int x = -5; x <= 5; ++x) {
        for (int z = -5; z <= 5; ++z) {
          for (int y = -1; y <= 2; ++y) {
            int distanceSquared = x*x + y*y + z*z;
            if (distanceSquared < closestImportantBlockDistanceSquared) {
              BlockPos worldBlockPos = pos.offset(x,y,z);
              if (level.isLoaded(worldBlockPos)) {
                BlockState state = level.getBlockState(worldBlockPos);
                if (isImportant(state)) {
                  closestImportantBlockPos = worldBlockPos;
                  closestImportantBlockDistanceSquared = distanceSquared;
                }
              }
            }
          }
        }
      }
      return closestImportantBlockPos;
    }
    return original;
  }

}
