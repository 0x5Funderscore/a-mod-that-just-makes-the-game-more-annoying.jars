package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.mob_armor_binding_curse;

import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Mob.class)
public abstract class MobMixin extends LivingEntity {

  protected MobMixin(EntityType<? extends LivingEntity> type, Level level) {
    super(type, level);
  }

  @ModifyArgs(method = "dropCustomDeathLoot", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Mob;spawnAtLocation(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/entity/item/ItemEntity;"))
  private void modifyItemStackBeforeSpawn(Args args) {
    if (Config.MOB_ARMOR_BINDING_CURSE.get()) {
      Level level = this.level();
      if (!level.isClientSide()) {
        ((ItemStack)args.get(1)).enchant(level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.BINDING_CURSE), 1);
      }
    }
  }

}
