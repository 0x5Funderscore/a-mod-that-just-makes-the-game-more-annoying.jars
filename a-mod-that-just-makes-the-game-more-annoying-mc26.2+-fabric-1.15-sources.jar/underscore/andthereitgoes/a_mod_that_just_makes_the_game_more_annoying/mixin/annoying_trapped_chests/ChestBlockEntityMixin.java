package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.annoying_trapped_chests;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ContainerUser;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.ITrappedChestSelfClosingExtension;


@Mixin(ChestBlockEntity.class)
@Implements(@Interface(iface = ITrappedChestSelfClosingExtension.class, prefix = "i$"))
public abstract class ChestBlockEntityMixin extends RandomizableContainerBlockEntity implements ITrappedChestSelfClosingExtension {

  @Unique
  private boolean willClose = false;

  @Unique
  private int selfClosingTicks = 0;

  public boolean i$willSelfClose() {
    return this.willClose;
  }

  public boolean i$tickSelfClosing() {
    return (this.selfClosingTicks--) <= 0;
  }

  protected ChestBlockEntityMixin(BlockEntityType<?> type, BlockPos worldPosition, BlockState blockState) {
    super(type, worldPosition, blockState);
  }

  @Inject(method = "startOpen", at = @At("TAIL"))
  private void startOpenExtra(ContainerUser containerUser, CallbackInfo ci) {
    if (Config.ANNOYING_TRAPPED_CHESTS.get()) {
      if (this.level instanceof ServerLevel serverLevel) {
        if ((ChestBlockEntity)(Object)this instanceof TrappedChestBlockEntity && Math.random() < 0.8d) {
          serverLevel.playSound(null, this.getBlockPos(), SoundEvents.SHULKER_AMBIENT, SoundSource.BLOCKS, 1.0F, 1.0F);
          this.willClose = true;
          this.selfClosingTicks = 2;
        }
      }
    }
  }

}
