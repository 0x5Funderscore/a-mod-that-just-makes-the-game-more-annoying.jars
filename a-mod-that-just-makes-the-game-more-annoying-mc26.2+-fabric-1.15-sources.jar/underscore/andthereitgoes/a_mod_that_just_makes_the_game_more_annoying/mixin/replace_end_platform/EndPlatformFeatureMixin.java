package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_platform;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.feature.EndPlatformFeature;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EndPlatformFeature.class)
public abstract class EndPlatformFeatureMixin {

  @Inject(method = "createEndPlatform", at = @At("HEAD"), cancellable = true)
  private static void createEndPlatform(ServerLevelAccessor newLevel, BlockPos origin, boolean dropResources, CallbackInfo ci) {
    if (!Config.REPLACE_END_PLATFORM.get()) return;

    BlockPos.MutableBlockPos pos = origin.mutable();

    for(int dz = -2; dz <= 2; ++dz) {
      for(int dx = -2; dx <= 2; ++dx) {
        for(int dy = -1; dy < 3; ++dy) {
          BlockPos blockPos = pos.set(origin).move(dx, dy, dz);
          if (dy == -1) {
            if (newLevel.getBlockState(blockPos).isAir()) {
              newLevel.setBlock(blockPos, Blocks.BARRIER.defaultBlockState(), 2);
            }
          } else {
            if (dropResources) {
              newLevel.destroyBlock(blockPos, true, null);
            }
            newLevel.setBlock(blockPos, Blocks.AIR.defaultBlockState(), 2);
          }
        }
      }
    }

    ci.cancel();
  }
}
