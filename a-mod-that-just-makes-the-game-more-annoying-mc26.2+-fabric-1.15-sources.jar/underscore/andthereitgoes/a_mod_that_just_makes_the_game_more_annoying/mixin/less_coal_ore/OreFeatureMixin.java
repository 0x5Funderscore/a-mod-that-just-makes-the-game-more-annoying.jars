package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.less_coal_ore;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.OreFeature;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(OreFeature.class)
public abstract class OreFeatureMixin {

  @Unique
  private static final TagKey<Block> COAL_ORES = TagKey.create(Registries.BLOCK, Identifier.withDefaultNamespace("coal_ores"));

  @ModifyVariable(method = "place", at = @At("HEAD"), argsOnly = true, name = "context")
  private FeaturePlaceContext<OreConfiguration> modifyContext(FeaturePlaceContext<OreConfiguration> context) {
    if (!Config.LESS_COAL_ORE.get()) return context;
    if (context.config().targetStates.getFirst().state.is(COAL_ORES)) {
      return new FeaturePlaceContext<>(
          context.topFeature(),
          context.level(),
          context.chunkGenerator(),
          context.random(),
          context.origin(),
          new OreConfiguration(
              context.config().targetStates,
              context.config().size / 2,
              context.config().discardChanceOnAirExposure
          )
      );
    }
    return context;
  }

}
