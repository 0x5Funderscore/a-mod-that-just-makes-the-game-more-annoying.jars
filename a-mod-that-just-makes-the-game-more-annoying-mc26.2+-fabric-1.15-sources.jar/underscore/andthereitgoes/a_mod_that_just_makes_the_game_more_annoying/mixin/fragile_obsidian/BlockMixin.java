package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.fragile_obsidian;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Block.class)
public abstract class BlockMixin {

  @Inject(method = "stepOn", at = @At("HEAD"))
  private void stepOnHEAD(Level level, BlockPos pos, BlockState onState, Entity entity, CallbackInfo ci) {
    if (level.isClientSide()) return;
    if (!Config.FRAGILE_OBSIDIAN.get()) return;
    if (level instanceof ServerLevel serverLevel) {
      if (onState.is(Blocks.OBSIDIAN)) {
        serverLevel.destroyBlock(pos, false);
        serverLevel.updateNeighborsAt(pos, Blocks.AIR);
      }
    }
  }

}
