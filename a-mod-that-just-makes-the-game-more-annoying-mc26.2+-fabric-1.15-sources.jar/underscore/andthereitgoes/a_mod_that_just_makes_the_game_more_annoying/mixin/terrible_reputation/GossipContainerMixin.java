package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.terrible_reputation;

import net.minecraft.world.entity.ai.gossip.GossipContainer;
import net.minecraft.world.entity.ai.gossip.GossipType;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;


@Mixin(GossipContainer.class)
public abstract class GossipContainerMixin {
  @Shadow
  @Final
  private Map<UUID,GossipContainer.EntityGossips> gossips;

  @Inject(method = "getReputation", at = @At("HEAD"), cancellable = true)
  public void getReputation(UUID entity, Predicate<GossipType> types, CallbackInfoReturnable<Integer> cir) {
    if (!Config.TERRIBLE_REPUTATION.get()) return;
    GossipContainer.EntityGossips entry = this.gossips.get(entity);
    cir.setReturnValue((entry != null ? entry.weightedValue(types) : 0) - 98);
  }
}
