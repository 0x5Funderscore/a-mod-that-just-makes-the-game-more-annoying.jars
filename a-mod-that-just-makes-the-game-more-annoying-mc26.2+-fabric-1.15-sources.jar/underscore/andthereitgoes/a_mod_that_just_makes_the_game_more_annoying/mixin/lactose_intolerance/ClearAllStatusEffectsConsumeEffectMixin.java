package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.lactose_intolerance;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.consume_effects.ClearAllStatusEffectsConsumeEffect;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ClearAllStatusEffectsConsumeEffect.class)
public abstract class ClearAllStatusEffectsConsumeEffectMixin {

  @Inject(method = "apply", at = @At("HEAD"), cancellable = true)
  private void preApply(Level level, ItemStack stack, LivingEntity user, CallbackInfoReturnable<Boolean> cir) {
    if (Config.LACTOSE_INTOLERANCE.get()) {
      user.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 500));
      cir.setReturnValue(true);
      cir.cancel();
    }
  }

}
