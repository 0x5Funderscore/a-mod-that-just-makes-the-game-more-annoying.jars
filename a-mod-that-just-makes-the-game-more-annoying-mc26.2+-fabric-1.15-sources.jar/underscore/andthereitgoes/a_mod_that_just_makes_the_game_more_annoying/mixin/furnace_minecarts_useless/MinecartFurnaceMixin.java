package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.furnace_minecarts_useless;

import net.minecraft.world.entity.vehicle.minecart.MinecartFurnace;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(MinecartFurnace.class)
public abstract class MinecartFurnaceMixin {

  @Inject(method = "addFuel", at = @At("HEAD"), cancellable = true)
  private void cancelFuel(Vec3 interactingPos, ItemStack itemStack, CallbackInfoReturnable<Boolean> cir) {
    if (Config.FURNACE_MINECARTS_USELESS.get()) {
      cir.setReturnValue(true);
      cir.cancel();
    }
  }

}
