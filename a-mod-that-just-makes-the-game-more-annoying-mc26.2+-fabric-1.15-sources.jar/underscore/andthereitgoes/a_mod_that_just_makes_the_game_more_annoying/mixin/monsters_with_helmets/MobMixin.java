package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.monsters_with_helmets;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Mob.class)
public abstract class MobMixin extends LivingEntity {
  protected MobMixin(EntityType<? extends LivingEntity> type, Level level) {
    super(type, level);
  }

  @Definition(id = "random", local = @Local(type = RandomSource.class, name = "random", argsOnly = true))
  @Definition(id = "nextFloat", method = "Lnet/minecraft/util/RandomSource;nextFloat()F")
//  @Definition(id = "partialChance", local = @Local(type = float.class, name = "partialChance"))
//  @Definition(id = "difficulty", local = @Local(type = DifficultyInstance.class, name = "difficulty", argsOnly = true))
//  @Definition(id = "getSpecialMultiplier", method = "Lnet/minecraft/world/DifficultyInstance;getSpecialMultiplier()F")
  @Expression("random.nextFloat() < ?")
  @WrapOperation(method = "populateDefaultEquipmentSlots", at = @At(value = "MIXINEXTRAS:EXPRESSION", ordinal = 0))
  private boolean modifyRNG(float left, float right, Operation<Boolean> original) {
    if (Config.MONSTERS_WITH_HELMETS.get()) return true;
    return original.call(left, right);
  }

}
