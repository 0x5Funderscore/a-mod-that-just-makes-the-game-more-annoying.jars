package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.furnace_cooking_time_x5;

import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractCookingRecipe.class)
public abstract class AbstractCookingRecipeMixin {
  @Shadow
  @Final
  private int cookingTime;

  @Inject(method = "cookingTime", at = @At("HEAD"), cancellable = true)
  public void cookingTime(CallbackInfoReturnable<Integer> cir) {
    if (Config.FURNACE_COOKING_TIME_X5.get()) cir.setReturnValue(this.cookingTime * 5);
  }
}
