package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.fast_ghasts;

import net.minecraft.world.entity.monster.Ghast;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Ghast.GhastShootFireballGoal.class)
public abstract class GhastShootFireballGoalMixin {

  @Shadow
  public int chargeTime;

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.FAST_GHASTS.get()) {
      if (this.chargeTime < 0) this.chargeTime = 9;
    }
  }

}
