package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.doors_change_randomly;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(DoorBlock.class)
public abstract class DoorBlockMixin extends Block {
  public DoorBlockMixin(Properties properties) {
    super(properties);
  }

  @Override
  protected void randomTick(@NonNull BlockState state, @NonNull ServerLevel serverLevel, @NonNull BlockPos pos, @NonNull RandomSource random) {
    if (Config.DOORS_CHANGE_RANDOMLY.get()) {
      if (state.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
        DoorHingeSide hinge = random.nextBoolean() ? DoorHingeSide.RIGHT : DoorHingeSide.LEFT;
        boolean open = random.nextBoolean();
        Direction facing = Direction.Plane.HORIZONTAL.getRandomDirection(random);
        serverLevel.setBlockAndUpdate(pos, state.setValue(DoorBlock.HINGE, hinge).setValue(DoorBlock.OPEN, open).setValue(DoorBlock.FACING, facing));
      }
    }

    super.randomTick(state, serverLevel, pos, random);
  }

  @Override
  protected boolean isRandomlyTicking(@NonNull BlockState state) {
    if (!Config.DOORS_CHANGE_RANDOMLY.get()) return super.isRandomlyTicking(state);
    return state.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER;
  }

}
