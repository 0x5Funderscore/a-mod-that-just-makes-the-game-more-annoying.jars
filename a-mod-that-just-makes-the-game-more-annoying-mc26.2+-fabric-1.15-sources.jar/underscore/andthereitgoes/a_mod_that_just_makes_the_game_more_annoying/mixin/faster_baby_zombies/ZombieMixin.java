package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.faster_baby_zombies;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.monster.zombie.Zombie;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Zombie.class)
public abstract class ZombieMixin {

  @Unique
  private static boolean modifiedBabySpeed = false;

  @Inject(method = "setBaby", at = @At("HEAD"))
  private void preSetBaby(boolean baby, CallbackInfo ci) {
    if (!modifiedBabySpeed) {
      modifiedBabySpeed = true;
      Zombie.SPEED_MODIFIER_BABY = new AttributeModifier(Zombie.SPEED_MODIFIER_BABY_ID, 3.0d, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
    }
  }
}
