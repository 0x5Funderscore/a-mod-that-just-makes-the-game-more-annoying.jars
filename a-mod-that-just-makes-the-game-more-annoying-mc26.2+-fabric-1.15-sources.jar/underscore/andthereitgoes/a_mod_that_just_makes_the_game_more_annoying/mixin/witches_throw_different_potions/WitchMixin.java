package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.witches_throw_different_potions;

import net.minecraft.core.Holder;
import net.minecraft.world.entity.monster.Witch;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.Potions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Random;


@Mixin(Witch.class)
public abstract class WitchMixin {

  @ModifyArg(method = "performRangedAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/alchemy/PotionContents;createItemStack(Lnet/minecraft/world/item/Item;Lnet/minecraft/core/Holder;)Lnet/minecraft/world/item/ItemStack;"), index = 1)
  private Holder<Potion> modifyPotionType(Holder<Potion> potion) {
    if (Config.WITCHES_THROW_DIFFERENT_POTIONS.get()) {
      if (potion == Potions.HARMING || potion == Potions.POISON) {
        potion = switch (new Random().nextInt(3)) {
          case 1 -> Potions.WEAVING;
          case 2 -> Potions.OOZING;
          default -> potion;
        };
      }
      if (Math.random() < 0.5d) {
        if (potion == Potions.POISON) {
          potion = Math.random() < 0.5d ? Potions.STRONG_POISON : Potions.LONG_POISON;
        } else if (potion == Potions.SLOWNESS) {
          potion = Math.random() < 0.5d ? Potions.STRONG_SLOWNESS : Potions.LONG_SLOWNESS;
        } else if (potion == Potions.WEAKNESS) {
          potion = Potions.LONG_WEAKNESS;
        } else if (potion == Potions.HARMING) {
          potion = Potions.STRONG_HARMING;
        } else if (potion == Potions.HEALING) {
          potion = Potions.STRONG_HEALING;
        } else if (potion == Potions.REGENERATION) {
          potion = Math.random() < 0.5d ? Potions.STRONG_REGENERATION : Potions.LONG_REGENERATION;
        }
      }
    }
    return potion;
  }

}
