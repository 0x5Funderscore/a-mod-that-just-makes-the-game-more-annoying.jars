package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.doors_are_afraid_of_water;

import com.mojang.math.Transformation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.redstone.Orientation;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Objects;


@Mixin(DoorBlock.class)
public abstract class DoorBlockMixin extends Block {

  public DoorBlockMixin(Properties properties) {
    super(properties);
  }

  @Inject(method = "neighborChanged", at = @At("TAIL"))
  private void neighborChanged(@NonNull BlockState state, @NonNull Level level, @NonNull BlockPos pos, @NonNull Block block, @Nullable Orientation orientation, boolean movedByPiston, CallbackInfo ci) {
    if (Config.DOORS_ARE_AFRAID_OF_WATER.get()) {
      if (level instanceof ServerLevel serverLevel) {
        for (Direction direction: Direction.values()) {
          if (serverLevel.getBlockState(pos.relative(direction)).getFluidState().is(FluidTags.WATER)) {
            if (state.getValue(DoorBlock.HALF) != DoubleBlockHalf.LOWER) {
              var posBelow = pos.below();
              var stateBelow = serverLevel.getBlockState(posBelow);
              if (stateBelow.is(this)) {
                this.makeAlive(stateBelow, serverLevel, posBelow);
              }
            } else {
              this.makeAlive(state, serverLevel, pos);
            }
            return;
          }
        }
      }
    }
  }

  @Unique
  private void makeAlive(@NonNull BlockState state, @NonNull ServerLevel serverLevel, @NonNull BlockPos pos) {
    var posAbove = pos.above();
    var stateAbove = serverLevel.getBlockState(posAbove);
    if (stateAbove.is(this)) {

      serverLevel.setBlock(pos, Blocks.AIR.defaultBlockState(), 2);
      serverLevel.setBlock(posAbove, Blocks.AIR.defaultBlockState(), 2);

      var bottomBlock = new Display.BlockDisplay(EntityTypes.BLOCK_DISPLAY, serverLevel);
      var topBlock = new Display.BlockDisplay(EntityTypes.BLOCK_DISPLAY, serverLevel);
      bottomBlock.addTag("kill_when_no_passenger");
      topBlock.addTag("kill_when_no_passenger");

      Bat entity = new Bat(EntityTypes.BAT, serverLevel);
      entity.setSilent(true);
      entity.setInvisible(true);
      entity.setPos(Vec3.atBottomCenterOf(pos).add(0.0d, 1.0d - entity.getBbHeight() * 0.03125d, 0.0d));
      float offsetY = entity.getBbHeight() * -0.03125f - 1.0f;
      Objects.requireNonNull(entity.getAttribute(Attributes.SCALE)).setBaseValue(0.0625d);
      entity.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, -1, 0, true, false));

      bottomBlock.setPos(Vec3.atBottomCenterOf(pos));
      topBlock.setPos(Vec3.atBottomCenterOf(pos));
      bottomBlock.setBlockState(state);
      topBlock.setBlockState(stateAbove);
      bottomBlock.setTransformation(new Transformation(new Vector3f(-0.5f, offsetY, -0.5f), null, null, null));
      topBlock.setTransformation(new Transformation(new Vector3f(-0.5f, offsetY + 1.0f, -0.5f), null, null, null));

      serverLevel.addFreshEntity(entity);
      serverLevel.addFreshEntity(bottomBlock);
      serverLevel.addFreshEntity(topBlock);

      bottomBlock.startRiding(entity);
      topBlock.startRiding(bottomBlock);

    }
  }

}
