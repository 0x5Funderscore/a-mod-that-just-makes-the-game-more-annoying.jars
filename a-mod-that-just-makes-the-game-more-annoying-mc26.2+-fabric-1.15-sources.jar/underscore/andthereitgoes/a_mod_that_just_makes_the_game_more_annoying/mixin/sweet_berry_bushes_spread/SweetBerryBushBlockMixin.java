package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.sweet_berry_bushes_spread;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SweetBerryBushBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(SweetBerryBushBlock.class)
public abstract class SweetBerryBushBlockMixin {

  @Inject(method = "isRandomlyTicking", at = @At("HEAD"), cancellable = true)
  protected void isRandomlyTickingV2(BlockState state, CallbackInfoReturnable<Boolean> cir) {
    if (Config.SWEET_BERRY_BUSHES_SPREAD.get()) cir.setReturnValue(true);
  }

  @Inject(method = "randomTick", at = @At("HEAD"))
  private void randomTickHEAD(BlockState state, ServerLevel level, BlockPos pos, RandomSource random, CallbackInfo ci) {
    if (!Config.SWEET_BERRY_BUSHES_SPREAD.get()) return;
    int spreadCount = Math.clamp(state.getValue(SweetBerryBushBlock.AGE), 0, 4);
    if (spreadCount > 0) {
      Direction.Plane.HORIZONTAL.shuffledCopy(random).subList(0, spreadCount).forEach(direction -> {
        BlockPos growPos = pos.relative(direction).below();
        for (int i = 0; i < 3; ++i) {
          if (level.getBlockState(growPos).isAir() && level.getBlockState(growPos.below()).is(BlockTags.SUPPORTS_VEGETATION)) {
            level.setBlockAndUpdate(growPos, Blocks.SWEET_BERRY_BUSH.defaultBlockState());
          }
          growPos = growPos.above();
        }
      });
    }
  }
}
