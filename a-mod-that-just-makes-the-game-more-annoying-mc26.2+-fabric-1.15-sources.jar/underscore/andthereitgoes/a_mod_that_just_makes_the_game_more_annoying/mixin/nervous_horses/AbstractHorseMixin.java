package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.nervous_horses;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractHorse.class)
public abstract class AbstractHorseMixin extends Animal {

  protected AbstractHorseMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "causeFallDamage", at = @At("HEAD"))
  private void beforeFallDamage(double fallDistance, float damageModifier, DamageSource damageSource, CallbackInfoReturnable<Boolean> cir) {
    if (!this.level().isClientSide() && Config.NERVOUS_HORSES.get()) this.getPassengers().forEach(Entity::stopRiding);
  }

  @Inject(method = "hurtServer", at = @At("HEAD"))
  private void beforeHurtServer(ServerLevel level, DamageSource source, float damage, CallbackInfoReturnable<Boolean> cir) {
    if (!this.level().isClientSide() && Config.NERVOUS_HORSES.get()) this.getPassengers().forEach(Entity::stopRiding);
  }
}
