package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.shuffle_chests_on_open;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.world.entity.ContainerUser;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Random;


@Mixin(ChestBlockEntity.class)
public abstract class ChestBlockEntityMixin extends RandomizableContainerBlockEntity {
  @Shadow
  private NonNullList<ItemStack> items;

  protected ChestBlockEntityMixin(BlockEntityType<?> type, BlockPos worldPosition, BlockState blockState) {
    super(type, worldPosition, blockState);
  }

  @Inject(method = "startOpen", at = @At("HEAD"))
  private void startStartOpen(ContainerUser containerUser, CallbackInfo ci) {
    if (!Config.SHUFFLE_CHESTS_ON_OPEN.get()) return;
    if (!this.remove && !containerUser.getLivingEntity().isSpectator()) {
      Random random = new Random();
      // Fisher-Yates shuffle
      for (int i = this.items.size() - 1; i >= 1; i--) {
        int j = random.nextInt(i + 1);
        ItemStack itemStack = this.items.get(j);
        this.items.set(j, this.items.get(i));
        this.items.set(i, itemStack);
      }
    }
  }

}
