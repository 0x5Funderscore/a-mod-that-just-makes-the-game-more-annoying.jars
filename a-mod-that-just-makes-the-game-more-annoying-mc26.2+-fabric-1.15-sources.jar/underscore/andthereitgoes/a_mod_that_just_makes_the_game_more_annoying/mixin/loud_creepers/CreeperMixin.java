package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.loud_creepers;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Creeper.class)
public abstract class CreeperMixin extends Monster {
  protected CreeperMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @Inject(
      method = "explodeCreeper",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/server/level/ServerLevel;explode(Lnet/minecraft/world/entity/Entity;DDDFLnet/minecraft/world/level/Level$ExplosionInteraction;)V",
          shift = At.Shift.AFTER
      )
  )
  private void explodeCreeperExplode(CallbackInfo ci) {
    if (!Config.LOUD_CREEPER_EXPLOSIONS.get()) return;
    this.level().playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.MASTER, 10000.0f, 1.0f);
  }
}
