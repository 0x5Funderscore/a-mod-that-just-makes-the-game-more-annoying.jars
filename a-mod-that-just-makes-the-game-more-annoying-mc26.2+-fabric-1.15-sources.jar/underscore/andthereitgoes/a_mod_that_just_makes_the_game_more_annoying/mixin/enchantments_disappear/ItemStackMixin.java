package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.enchantments_disappear;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.component.TypedDataComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;
import java.util.function.Consumer;


@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

  @Shadow
  public abstract ItemEnchantments getEnchantments();

  @Shadow
  public abstract <T> T set(DataComponentType<T> type, @Nullable T value);

  @Inject(method = "applyDamage", at = @At("HEAD"))
  private void preApplyDamage(int newDamage, @Nullable ServerPlayer player, Consumer<Item> onBreak, CallbackInfo ci) {
    if (!Config.ENCHANTMENTS_DISAPPEAR.get()) return;
    ItemEnchantments enchantments = this.getEnchantments();
    if (Math.random() < 0.1 && !enchantments.isEmpty()) {
      List<Holder<Enchantment>> enchantmentsList = enchantments.entrySet().stream().map(Object2IntMap.Entry::getKey).toList();
      Holder<Enchantment> enchantmentToRemove = enchantmentsList.get(Mth.floor(Math.random() * enchantmentsList.size()));
      ItemEnchantments.Mutable mutableEnchantments = new ItemEnchantments.Mutable(enchantments);
      mutableEnchantments.removeIf(enchantmentToRemove::equals);
      this.set(DataComponents.ENCHANTMENTS, mutableEnchantments.toImmutable());
    }
  }
}
