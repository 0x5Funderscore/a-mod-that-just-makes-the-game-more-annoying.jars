package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.skeleton_homing_arrows;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.skeleton.AbstractSkeleton;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.IArrowHomingExtension;


@Mixin(ProjectileUtil.class)
public abstract class ProjectileUtilMixin {

  @Inject(method = "getMobArrow", at = @At("TAIL"))
  private static void addHomingDataToMobArrow(LivingEntity mob, ItemStack projectile, float power, ItemStack firedFromWeapon, CallbackInfoReturnable<AbstractArrow> cir) {
    if (Config.SKELETON_HOMING_ARROWS.get()) {
      AbstractArrow arrow = cir.getReturnValue();
      if (mob instanceof AbstractSkeleton skeleton) {
        ((IArrowHomingExtension)arrow).setHomingTarget(skeleton.getTarget());
      }
    }
  }

}
