package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.require_balanced_diet;

import com.mojang.authlib.GameProfile;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.NonNull;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.*;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {
  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Shadow
  public abstract @NonNull ServerLevel level();

  @Shadow
  @Final
  private static Logger LOGGER;

  @Shadow
  public abstract boolean hurtServer(@NonNull ServerLevel level, @NonNull DamageSource source, float damage);

  @Shadow
  public abstract GameType gameMode();

  @Shadow
  public abstract void sendSystemMessage(@NonNull Component message);

  @Unique
  public HashMap<ResourceKey<Item>,Integer> foodsEatenToday = new HashMap<>();

  @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
  private void readAdditionalAdditionalSaveData(ValueInput input, CallbackInfo ci) {
    if (!Config.REQUIRE_BALANCED_DIET.get()) return;
    Optional<ValueInput.ValueInputList> foodsEatenTodayListOptional = input.childrenList("foods_eaten_today");
    foodsEatenToday.clear();
    foodsEatenTodayListOptional.ifPresent(foodsEatenTodayList ->
        foodsEatenTodayList.stream().forEach(element -> {
          String itemString = element.getStringOr("id", "");
          int itemAmount = element.getIntOr("amount", 0);
          if (!itemString.isEmpty() && itemAmount > 0) {
            ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, Identifier.parse(itemString));
            Optional<Holder.Reference<Item>> itemOptional = BuiltInRegistries.ITEM.get(itemKey);
            if (itemOptional.isPresent()) {
              foodsEatenToday.put(itemKey, itemAmount);
            }
          }
        })
    );
  }

  @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
  private void addAdditionalAdditionalSaveData(ValueOutput output, CallbackInfo ci) {
    if (!Config.REQUIRE_BALANCED_DIET.get()) return;
    ValueOutput.ValueOutputList foodsEatenTodayList = output.childrenList("foods_eaten_today");
    for (Map.Entry<ResourceKey<Item>,Integer> entry: foodsEatenToday.entrySet()) {
      ValueOutput element = foodsEatenTodayList.addChild();
      element.putString("id", entry.getKey().identifier().toString());
      element.putInt("amount", entry.getValue());
    }
  }

  @Inject(method = "completeUsingItem", at = @At("HEAD"))
  private void completeUsingItemHEAD(CallbackInfo ci) {
    if (!Config.REQUIRE_BALANCED_DIET.get()) return;
    if (!this.useItem.isEmpty() && this.isUsingItem() && !this.isSpectator()) {
      Optional<ResourceKey<Item>> itemKeyOptional = BuiltInRegistries.ITEM.getResourceKey(this.useItem.getItem());
      itemKeyOptional.ifPresent(itemResourceKey ->
          countFood(itemResourceKey, foodsEatenToday.getOrDefault(itemResourceKey, 0) + 1)
      );
//      LOGGER.info("food {} is now {}", itemKeyOptional.orElse(null), foodsEatenToday.getOrDefault(itemKeyOptional.orElse(null), -1));
    }
  }

  @Unique
  private void countFood(ResourceKey<Item> foodItem, int count) {
    if (!Config.REQUIRE_BALANCED_DIET.get()) return;
    if (count >= 3) {
      this.foodsEatenToday.clear();
      this.hurtServer(this.level(), this.level().damageSources().starve(), Float.MAX_VALUE);
      this.sendSystemMessage(Component.literal("You need to eat a balanced diet!").withStyle(ChatFormatting.RED));
    } else {
      this.foodsEatenToday.put(foodItem, count);
    }
  }

  @Inject(method = "tick", at = @At("HEAD"))
  private void tickHEAD_manageFoodsEatenToday(CallbackInfo ci) {
    if (!Config.REQUIRE_BALANCED_DIET.get()) return;
    if (this.level().getOverworldClockTime() == 0L || this.isSleepingLongEnough()) {
      this.foodsEatenToday.clear();
    }
  }

}
