package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.rails_spawn_furnace_minecarts;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.vehicle.minecart.MinecartFurnace;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BlockBehaviour.class)
public abstract class BlockBehaviourMixin {

  @Mutable
  @Shadow
  @Final
  protected boolean isRandomlyTicking;

  @Inject(method = "isRandomlyTicking", at = @At("HEAD"))
  private void enableRandomlyTickingRails(BlockState state, CallbackInfoReturnable<Boolean> cir) {
    if (Config.RAILS_SPAWN_FURNACE_MINECARTS.get() && (
        state.is(Blocks.RAIL) ||
        state.is(Blocks.POWERED_RAIL) ||
        state.is(Blocks.ACTIVATOR_RAIL) ||
        state.is(Blocks.DETECTOR_RAIL)
    )) {
      this.isRandomlyTicking = true;
    }
  }

  @Inject(method = "randomTick", at = @At("TAIL"))
  private void postRandomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random, CallbackInfo ci) {
    if (Config.RAILS_SPAWN_FURNACE_MINECARTS.get() && state.is(BlockTags.RAILS) && random.nextDouble() < 0.01d) {
      Vec3 xyz = Vec3.atBottomCenterOf(pos);
      MinecartFurnace fmc = MinecartFurnace.createMinecart(
          level,
          xyz.x, xyz.y + 0.125d, xyz.z,
          EntityTypes.FURNACE_MINECART,
          EntitySpawnReason.NATURAL,
          new ItemStack(Items.FURNACE_MINECART, 1),
          null
      );
      if (fmc != null) level.addFreshEntity(fmc);
    }
  }

}
