package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.animals_stop_sleep;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;
import java.util.function.Predicate;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin {

  @Redirect(
      method = "startSleepInBed",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/server/level/ServerLevel;getEntitiesOfClass(Ljava/lang/Class;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;)Ljava/util/List;"
      )
  )
  private <T extends Entity> List<? extends Entity> getMonstersV2(ServerLevel instance, Class<T> aClass, AABB aabb, Predicate<? super T> predicate) {
    if (Config.ANIMALS_STOP_SLEEP.get())
      return instance.getEntitiesOfClass(LivingEntity.class, aabb, livingEntity -> !(livingEntity instanceof Player));
    else
      return instance.getEntitiesOfClass(aClass, aabb, predicate);
  }

}
