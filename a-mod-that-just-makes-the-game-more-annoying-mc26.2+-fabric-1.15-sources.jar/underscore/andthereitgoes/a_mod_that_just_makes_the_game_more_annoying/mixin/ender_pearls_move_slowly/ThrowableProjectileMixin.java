package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.ender_pearls_move_slowly;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEnderpearl;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ThrowableProjectile.class)
public abstract class ThrowableProjectileMixin extends Projectile {

  public ThrowableProjectileMixin(EntityType<? extends Projectile> type, Level level) {
    super(type, level);
  }

  @Inject(method = "getDefaultGravity", at = @At("TAIL"), cancellable = true)
  private void replaceDefaultGravity(CallbackInfoReturnable<Double> cir) {
    //noinspection ConstantValue
    if (Config.ENDER_PEARLS_MOVE_SLOWLY.get() && (ThrowableProjectile)(Object)this instanceof ThrownEnderpearl) {
      cir.setReturnValue(cir.getReturnValueD() * 0.05d);
    }
  }

  @ModifyArg(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/phys/Vec3;add(Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3;", ordinal = 0))
  private Vec3 replaceAddVelocity(Vec3 vec) {
    //noinspection ConstantValue
    if (Config.ENDER_PEARLS_MOVE_SLOWLY.get() && (ThrowableProjectile)(Object)this instanceof ThrownEnderpearl) {
      return vec.scale(0.05d);
    }
    return vec;
  }
}
