package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.lava_flows_fast;

import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.material.LavaFluid;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LavaFluid.class)
public abstract class LavaFluidMixin {

  @Inject(method = "getDropOff", at = @At("HEAD"), cancellable = true)
  private void reGetDropOff(LevelReader level, CallbackInfoReturnable<Integer> cir) {
    if (Config.LAVA_FLOWS_FAST.get()) {
      cir.setReturnValue(1);
      cir.cancel();
    }
  }

  @Inject(method = "getTickDelay", at = @At("HEAD"), cancellable = true)
  private void reGetTickDelay(LevelReader level, CallbackInfoReturnable<Integer> cir) {
    if (Config.LAVA_FLOWS_FAST.get()) {
      cir.setReturnValue(1);
      cir.cancel();
    }
  }

}
