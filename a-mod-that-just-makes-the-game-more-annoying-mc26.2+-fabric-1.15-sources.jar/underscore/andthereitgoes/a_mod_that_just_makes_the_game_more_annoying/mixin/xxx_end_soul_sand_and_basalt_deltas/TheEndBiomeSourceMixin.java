package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_end_soul_sand_and_basalt_deltas;

import net.minecraft.world.level.biome.TheEndBiomeSource;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(TheEndBiomeSource.class)
public abstract class TheEndBiomeSourceMixin {
  /*

  @Unique
  private static Holder<Biome> basaltDeltas;

  @Unique
  private static Holder<Biome> soulSandValley;

  @Inject(method = "create", at = @At("TAIL"))
  private static void registerExtraBiomes(HolderGetter<Biome> biomes, CallbackInfoReturnable<TheEndBiomeSource> cir) {
    basaltDeltas = biomes.getOrThrow(Biomes.BASALT_DELTAS);
    soulSandValley = biomes.getOrThrow(Biomes.SOUL_SAND_VALLEY);
  }

  @Inject(method = "collectPossibleBiomes", at = @At("TAIL"), cancellable = true)
  private void addExtraBiomes(CallbackInfoReturnable<Stream<Holder<Biome>>> cir) {
    if (Config.END_SOUL_SAND_AND_BASALT_DELTAS.get()) {
      Stream<Holder<Biome>> biomes = cir.getReturnValue();
      List<Holder<Biome>> newBiomes = new ArrayList<>(biomes.toList());
      newBiomes.add(basaltDeltas);
      newBiomes.add(soulSandValley);
      cir.setReturnValue(newBiomes.stream());
    }
  }

   */
}
