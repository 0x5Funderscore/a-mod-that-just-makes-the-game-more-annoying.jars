package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.endermen_hold_anything;

import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.EndermanTakeBlockGoal.class)
public abstract class EnderMan$EndermanTakeBlockGoalMixin extends Goal {

  @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/tags/TagKey;)Z"))
  private boolean redirectBlockStateIs(BlockState instance, TagKey<Block> tagKey) {
    if (Config.ENDERMEN_HOLD_ANYTHING.get()) {
      if (Config.ENDERMEN_CANNOT_HOLD_WITHER_IMMUNE.get()) {
        return !instance.is(BlockTags.WITHER_IMMUNE);
      }
      return !instance.isAir();
    }
    return instance.is(tagKey);
  }

}
