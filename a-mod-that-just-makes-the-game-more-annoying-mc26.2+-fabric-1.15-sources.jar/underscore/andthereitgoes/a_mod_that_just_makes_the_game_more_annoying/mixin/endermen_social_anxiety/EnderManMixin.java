package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.endermen_social_anxiety;

import net.minecraft.world.entity.monster.EnderMan;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.class)
public abstract class EnderManMixin {

  @ModifyArgs(method = "isBeingStaredBy", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/monster/EnderMan;isLookingAtMe(Lnet/minecraft/world/entity/LivingEntity;DZZ[D)Z"))
  private void modifyIsLookingAtMe(Args args) {
    if (Config.ENDERMEN_SOCIAL_ANXIETY.get()) args.set(1, 0.25d);
  }

}
