package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.all_zombies_are_babies;

import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.monster.zombie.Zombie;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Zombie.class)
public abstract class ZombieMixin {

  @Inject(method = "getSpawnAsBabyOdds", at = @At("HEAD"), cancellable = true)
  private static void getSpawnAsBabyOdds(RandomSource random, CallbackInfoReturnable<Boolean> cir) {
    if (Config.ALL_ZOMBIES_ARE_BABIES.get()) cir.setReturnValue(true);
  }

}
