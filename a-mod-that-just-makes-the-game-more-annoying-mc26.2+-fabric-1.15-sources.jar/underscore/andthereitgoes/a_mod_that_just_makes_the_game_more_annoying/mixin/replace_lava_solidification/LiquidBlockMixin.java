package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_lava_solidification;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(LiquidBlock.class)
public abstract class LiquidBlockMixin {

  @Redirect(
      method = "shouldSpreadLiquid",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/level/Level;setBlockAndUpdate(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Z"
      )
  )
  private boolean modifySetBlockState(Level instance, BlockPos pos, BlockState blockState) {
    if (Config.REPLACE_LAVA_SOLIDIFICATION.get()) {
      if (blockState.is(Blocks.OBSIDIAN)) {
        for (Direction direction: Direction.values()) {
          if (instance.getBlockState(pos.relative(direction)).is(Blocks.OBSIDIAN)) {
            final List<Block> OBSIDIAN_REPLACEMENTS = List.of(
                Blocks.ANDESITE,
                Blocks.DIORITE,
                Blocks.GRANITE,
                Blocks.BASALT,
                Blocks.SMOOTH_BASALT,
                Blocks.TUFF,
                Blocks.COBBLESTONE,
                Blocks.STONE
            );
            Block block = OBSIDIAN_REPLACEMENTS.get(instance.getRandom().nextInt(OBSIDIAN_REPLACEMENTS.size()));
            return instance.setBlockAndUpdate(pos, block.defaultBlockState());
          }
        }
        final List<Block> OBSIDIAN_REPLACEMENTS = List.of(
            Blocks.ANDESITE,
            Blocks.DIORITE,
            Blocks.GRANITE,
            Blocks.BASALT,
            Blocks.SMOOTH_BASALT,
            Blocks.TUFF,
            Blocks.COBBLESTONE,
            Blocks.STONE,
            Blocks.OBSIDIAN,
            Blocks.CRYING_OBSIDIAN
        );
        Block block = OBSIDIAN_REPLACEMENTS.get(instance.getRandom().nextInt(OBSIDIAN_REPLACEMENTS.size()));
        return instance.setBlockAndUpdate(pos, block.defaultBlockState());
      } else if (blockState.is(Blocks.STONE) || blockState.is(Blocks.COBBLESTONE)) {
        final List<Block> NON_OBSIDIAN_REPLACEMENTS = List.of(
            Blocks.ANDESITE,
            Blocks.DIORITE,
            Blocks.GRANITE,
            Blocks.BASALT,
            Blocks.SMOOTH_BASALT,
            Blocks.TUFF,
            Blocks.COBBLESTONE,
            Blocks.STONE
        );
        Block block = NON_OBSIDIAN_REPLACEMENTS.get(instance.getRandom().nextInt(NON_OBSIDIAN_REPLACEMENTS.size()));
        return instance.setBlockAndUpdate(pos, block.defaultBlockState());
      }
    }
    return instance.setBlockAndUpdate(pos, blockState);
  }

}
