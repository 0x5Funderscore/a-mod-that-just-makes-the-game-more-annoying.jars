package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.witches_throw_lingering;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Witch;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownLingeringPotion;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Witch.class)
public abstract class WitchMixin {

  @Redirect(method = "performRangedAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/Projectile;spawnProjectileUsingShoot(Lnet/minecraft/world/entity/projectile/Projectile$ProjectileFactory;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;DDDFF)Lnet/minecraft/world/entity/projectile/Projectile;"))
  private <T extends Projectile> T redirectSpawnProjectile(Projectile.ProjectileFactory<T> creator, ServerLevel serverLevel, ItemStack itemStack, LivingEntity source, double targetX, double targetY, double targetZ, float pow, float uncertainty) {
    if (Config.WITCHES_THROW_LINGERING.get()) {
      Projectile.spawnProjectileUsingShoot(ThrownLingeringPotion::new, serverLevel, itemStack,  source, targetX, targetY, targetZ, pow, uncertainty);
      return null;
    }
    return Projectile.spawnProjectileUsingShoot(creator, serverLevel, itemStack,  source, targetX, targetY, targetZ, pow, uncertainty);
  }

}
