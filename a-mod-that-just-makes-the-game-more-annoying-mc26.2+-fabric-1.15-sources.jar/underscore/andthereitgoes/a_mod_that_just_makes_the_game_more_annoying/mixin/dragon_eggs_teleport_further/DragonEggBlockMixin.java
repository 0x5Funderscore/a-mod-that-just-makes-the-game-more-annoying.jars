package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.dragon_eggs_teleport_further;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DragonEggBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.levelgen.Heightmap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(DragonEggBlock.class)
public abstract class DragonEggBlockMixin {

  @Inject(method = "teleport", at = @At("HEAD"), cancellable = true)
  private void teleport(BlockState state, Level level, BlockPos pos, CallbackInfo ci) {
    if (!Config.DRAGON_EGGS_TELEPORT_FURTHER.get()) return;

    WorldBorder worldBorder = level.getWorldBorder();
    RandomSource random = level.getRandom();

    for(int i = 0; i < 1000; ++i) {
      BlockPos testPos = pos.offset(random.nextInt(256) - random.nextInt(256), random.nextInt(64) - random.nextInt(64), random.nextInt(256) - random.nextInt(256));
      testPos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, testPos);
      if (level.getBlockState(testPos).isAir() && !level.getBlockState(testPos.below()).isAir() && worldBorder.isWithinBounds(testPos) && level.isInsideBuildHeight(testPos)) {
        if (level.isClientSide()) {
          for(int j = 0; j < 128; ++j) {
            double d = random.nextDouble();
            float xa = (random.nextFloat() - 0.5F) * 0.2F;
            float ya = (random.nextFloat() - 0.5F) * 0.2F;
            float za = (random.nextFloat() - 0.5F) * 0.2F;
            double x = Mth.lerp(d, testPos.getX(), pos.getX()) + (random.nextDouble() - (double)0.5F) + (double)0.5F;
            double y = Mth.lerp(d, testPos.getY(), pos.getY()) + random.nextDouble() - (double)0.5F;
            double z = Mth.lerp(d, testPos.getZ(), pos.getZ()) + (random.nextDouble() - (double)0.5F) + (double)0.5F;
            level.addParticle(ParticleTypes.PORTAL, x, y, z, xa, ya, za);
          }
        } else {
          level.setBlock(testPos, state, 2);
          level.removeBlock(pos, false);
        }

        return;
      }
    }

    ci.cancel();
  }

}
