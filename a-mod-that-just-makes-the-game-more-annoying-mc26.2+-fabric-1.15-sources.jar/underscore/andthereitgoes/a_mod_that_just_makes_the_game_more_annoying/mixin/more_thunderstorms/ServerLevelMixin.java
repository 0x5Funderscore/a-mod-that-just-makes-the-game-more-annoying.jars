package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.more_thunderstorms;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerLevel.class)
public class ServerLevelMixin {

  @Definition(id = "RAIN_DELAY", field = "Lnet/minecraft/server/level/ServerLevel;RAIN_DELAY:Lnet/minecraft/util/valueproviders/IntProvider;")
  @Definition(id = "THUNDER_DELAY", field = "Lnet/minecraft/server/level/ServerLevel;THUNDER_DELAY:Lnet/minecraft/util/valueproviders/IntProvider;")
  @Definition(id = "sample", method = "Lnet/minecraft/util/valueproviders/IntProvider;sample(Lnet/minecraft/util/RandomSource;)I")
  @Expression("RAIN_DELAY.sample(?)")
  @Expression("THUNDER_DELAY.sample(?)")
  @ModifyExpressionValue(method = "advanceWeatherCycle", at = @At("MIXINEXTRAS:EXPRESSION"))
  private int changeRainDelaySample(int original) {
    if (Config.MORE_THUNDERSTORMS.get()) return original / 5;
    return original;
  }

}
