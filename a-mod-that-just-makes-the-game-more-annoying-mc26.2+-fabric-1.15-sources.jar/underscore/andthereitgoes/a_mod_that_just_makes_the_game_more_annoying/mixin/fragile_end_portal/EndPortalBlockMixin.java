package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.fragile_end_portal;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InsideBlockEffectApplier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EndPortalBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(EndPortalBlock.class)
public class EndPortalBlockMixin {

  @Unique
  private static final Vec3i[] POSITION_OFFSET = new Vec3i[]{
      new Vec3i(-1, 0, 0),
      new Vec3i(1, 0, 0),
      new Vec3i(0, 0, -1),
      new Vec3i(0, 0, 1),
      new Vec3i(-2, 0, 0),
      new Vec3i(2, 0, 0),
      new Vec3i(0, 0, -2),
      new Vec3i(0, 0, 2),
  };

  @Inject(method = "entityInside", at = @At("HEAD"), cancellable = true)
  private void preEntityInside(BlockState state, Level level, BlockPos pos, Entity entity, InsideBlockEffectApplier effectApplier, boolean isPrecise, CallbackInfo ci) {
    if (!level.isClientSide()) {
      if (Math.random() < 0.3d) {
        boolean canDelete = false;
        for (Vec3i offset: POSITION_OFFSET) {
          BlockState blockState = level.getBlockState(pos.offset(offset));
          if (blockState.is(Blocks.END_PORTAL_FRAME)) {
            canDelete = true;
          } else if (blockState.is(Blocks.BEDROCK)) {
            canDelete = false;
            break;
          }
        }
        if (canDelete) level.destroyBlock(pos, false);
      }
    }
  }

}
