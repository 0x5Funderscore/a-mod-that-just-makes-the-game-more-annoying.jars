package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin.uncapped_volume;

import it.unimi.dsi.fastutil.objects.Object2FloatMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Options;
import net.minecraft.client.sounds.SoundEngine;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(SoundEngine.class)
@Environment(EnvType.CLIENT)
public abstract class SoundEngineMixin {
  @Shadow
  @Final
  private Options options;

  @Shadow
  @Final
  private Object2FloatMap<SoundSource> gainBySource;

  @Inject(method = "calculateVolume(FLnet/minecraft/sounds/SoundSource;)F", at = @At("HEAD"), cancellable = true)
  private void calculateVolume(float volume, SoundSource source, CallbackInfoReturnable<Float> cir) {
    if (!Config.UNCAPPED_VOLUME.get()) return;
    cir.setReturnValue(volume * Mth.clamp(this.options.getFinalSoundSourceVolume(source), 0.0F, 1.0F) * this.gainBySource.getFloat(source));
    cir.cancel();
  }
}
