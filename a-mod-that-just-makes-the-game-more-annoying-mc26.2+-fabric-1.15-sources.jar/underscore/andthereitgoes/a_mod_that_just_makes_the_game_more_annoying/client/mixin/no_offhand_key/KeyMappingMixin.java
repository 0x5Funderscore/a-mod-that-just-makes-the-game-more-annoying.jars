package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin.no_offhand_key;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.KeyMapping;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Objects;


@Environment(EnvType.CLIENT)
@Mixin(KeyMapping.class)
public abstract class KeyMappingMixin {

  @Shadow
  public abstract boolean same(KeyMapping that);

  @ModifyReturnValue(method = "isDown", at = @At("RETURN"))
  private boolean cancelIsDown(boolean original) {
    if (Config.NO_OFFHAND_KEY.get()) {
      if (this.same(Objects.requireNonNull(KeyMapping.get("key.swapOffhand")))) return false;
    }
    return original;
  }

  @ModifyReturnValue(method = "consumeClick", at = @At("RETURN"))
  private boolean cancelConsumeClick(boolean original) {
    if (Config.NO_OFFHAND_KEY.get()) {
      if (this.same(Objects.requireNonNull(KeyMapping.get("key.swapOffhand")))) return false;
    }
    return original;
  }

  @Inject(method = "setDown", at = @At("HEAD"), cancellable = true)
  private void cancelSetDown(boolean down, CallbackInfo ci) {
    if (Config.NO_OFFHAND_KEY.get()) {
      if (this.same(Objects.requireNonNull(KeyMapping.get("key.swapOffhand")))) ci.cancel();
    }
  }

}
