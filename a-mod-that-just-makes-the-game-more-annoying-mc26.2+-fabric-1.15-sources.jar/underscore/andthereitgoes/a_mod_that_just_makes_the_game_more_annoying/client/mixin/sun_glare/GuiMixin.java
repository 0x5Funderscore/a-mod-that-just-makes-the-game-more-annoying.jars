package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin.sun_glare;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.logging.LogUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.EndFlashState;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Environment(EnvType.CLIENT)
@Mixin(Gui.class)
public class GuiMixin {

  @Unique
  private float rb$calculateSunDotProduct(float partialTicks) {
    Minecraft minecraft = Minecraft.getInstance();

    ClientLevel cameraLevel = minecraft.level;
    if (cameraLevel == null) return 0f;

    Entity cameraEntity = minecraft.getCameraEntity();
    if (cameraEntity == null) return 0f;

    Camera camera = minecraft.gameRenderer.mainCamera();

    DimensionType dimensionType = cameraLevel.dimensionType();

    float dot = 0f;

    if (dimensionType.hasSkyLight() && !dimensionType.hasCeiling()) {
      if (dimensionType.skybox() == DimensionType.Skybox.OVERWORLD) {

        float sunAngle = Mth.positiveModulo(camera.attributeProbe().getValue(EnvironmentAttributes.SUN_ANGLE, partialTicks) * (Mth.PI / 180f), Mth.TWO_PI);
        if (sunAngle < Mth.HALF_PI || sunAngle > Mth.PI + Mth.HALF_PI) {
          float sunBrightness = (float)Math.pow(Math.max(0f, Mth.cos(sunAngle)), 0.2d) * (1f - cameraLevel.getRainLevel(partialTicks));
          Vector3f sunDir = new Vector3f(0f, 1f, 0f).rotateZ(sunAngle).normalize(sunBrightness);
          BlockHitResult clipped = cameraLevel.clip(new ClipContext(camera.position(), cameraEntity.getEyePosition().add(new Vec3(sunDir).normalize().scale(600d)), ClipContext.Block.VISUAL, ClipContext.Fluid.ANY, CollisionContext.empty()));
          if (clipped.getType() == HitResult.Type.MISS) {
            dot = sunDir.dot(cameraEntity.getLookAngle().toVector3f());
          }
        }

      }

      if (dimensionType.hasEndFlashes()) {

        EndFlashState endFlashState = cameraLevel.endFlashState();
        if (endFlashState == null) return 0f;
        float intensity = endFlashState.getIntensity(partialTicks);
        if (intensity > 1e-4f) {
          float yAngle = 180f - endFlashState.getYAngle();
          float xAngle = -90f - endFlashState.getXAngle();
          Vector3f endFlashDir = new Vector3f(0f, 1f, 0f).rotateX(xAngle * (Mth.PI / 180f)).rotateY(yAngle * (Mth.PI / 180f)).normalize(intensity);
          BlockHitResult clipped = cameraLevel.clip(new ClipContext(camera.position(), cameraEntity.getEyePosition().add(new Vec3(endFlashDir).normalize().scale(600d)), ClipContext.Block.VISUAL, ClipContext.Fluid.ANY, CollisionContext.empty()));
          if (clipped.getType() == HitResult.Type.MISS) {
            float endFlashDot = endFlashDir.dot(cameraEntity.getLookAngle().toVector3f());
            dot = Math.max(dot, endFlashDot);
          }
        }

      }
    }

    return dot;
  }

  @Definition(id = "graphics", local = @Local(type = GuiGraphicsExtractor.class, name = "graphics"))
  @Definition(id = "GuiGraphicsExtractor", type = GuiGraphicsExtractor.class)
  @Expression("graphics = new GuiGraphicsExtractor(?, ?, ?, ?)")
  @Inject(method = "extractRenderState", at = @At(value = "MIXINEXTRAS:EXPRESSION", shift = At.Shift.AFTER))
  private void renderWhiteOverlay(
      DeltaTracker deltaTracker, boolean shouldRenderLevel, boolean resourcesLoaded, CallbackInfo ci,
      @Local(name = "graphics") GuiGraphicsExtractor graphics
  ) {
    if (Config.SUN_GLARE.get()) {
      float dot = this.rb$calculateSunDotProduct(deltaTracker.getGameTimeDeltaTicks());
      if (dot > 0f) {
        float opacity = dot * dot * dot * 0.75f;
        graphics.fill(0, 0, graphics.guiWidth(), graphics.guiHeight(), ARGB.white(opacity));
      }
    }
  }

}
