package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin._global;

import com.mojang.logging.LogUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.resources.ReloadInstance;
import net.minecraft.server.packs.resources.ReloadableResourceManager;
import net.minecraft.util.Unit;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;


@Mixin(ReloadableResourceManager.class)
@Environment(EnvType.CLIENT)
public abstract class ReloadableResourceManagerMixin {

  @Inject(method = "createReload", at = @At("TAIL"))
  private void extraReloadResources(Executor backgroundExecutor, Executor mainThreadExecutor, CompletableFuture<Unit> initialTask, List<PackResources> resourcePacks, CallbackInfoReturnable<ReloadInstance> cir) {
    try {
      Config.loadConfig();
    } catch (IOException e) {
      LogUtils.getLogger().error("I/O error while loading AMTJMTGMA config.", e);
    }
  }

}
