package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin._global;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.LogoRenderer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.screens.AMTJMTGMAScreenConstants;

import java.util.List;


@Mixin(LogoRenderer.class)
@Environment(EnvType.CLIENT)
public abstract class LogoRendererMixin {

  @Redirect(
      method = "extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IFI)V",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blit(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIFFIIIII)V",
          ordinal = 1
      )
  )
  private void redirectRenderEdition(GuiGraphicsExtractor instance, RenderPipeline renderPipeline, Identifier texture, int x, int y, float u, float v, int width, int height, int textureWidth, int textureHeight, int color) {
    AMTJMTGMAScreenConstants.EDITION_BOXES_CALCULATED.clear();
    x -= width / 2;
    width *= 2;
    y -= height / 2;
    height *= 2;
    float alpha = ARGB.vector4fFromARGB32(color).w;
    for (int idx = 0; idx < AMTJMTGMAScreenConstants.EDITION_BOXES.length; idx += 5) {
      int x0 = (int)((AMTJMTGMAScreenConstants.EDITION_BOXES[idx] / 512f) * (float)width) + x;
      int y0 = (int)((AMTJMTGMAScreenConstants.EDITION_BOXES[idx+1] / 64f) * (float)height) + y;
      int x1 = (int)((AMTJMTGMAScreenConstants.EDITION_BOXES[idx+2] / 512f) * (float)width) + x;
      int y1 = (int)((AMTJMTGMAScreenConstants.EDITION_BOXES[idx+3] / 64f) * (float)height) + y;
      AMTJMTGMAScreenConstants.EDITION_BOXES_CALCULATED.addAll(List.of(x0, y0, x1 - x0, y1 - y0, AMTJMTGMAScreenConstants.EDITION_COLORS[AMTJMTGMAScreenConstants.EDITION_BOXES[idx+4]]));
      instance.fill(RenderPipelines.GUI, x0, y0, x1, y1, ARGB.color(alpha, AMTJMTGMAScreenConstants.EDITION_COLORS[AMTJMTGMAScreenConstants.EDITION_BOXES[idx+4]]));
    }
  }

}
