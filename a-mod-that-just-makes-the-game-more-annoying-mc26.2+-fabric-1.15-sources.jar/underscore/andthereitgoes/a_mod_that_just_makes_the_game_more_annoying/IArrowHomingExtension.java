package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying;

import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.Nullable;


public interface IArrowHomingExtension {
  @Nullable Entity getHomingTarget();
  void setHomingTarget(@Nullable Entity homingTarget);
}
