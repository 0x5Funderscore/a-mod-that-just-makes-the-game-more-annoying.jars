package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.stronger_nausea_effect;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(GameRenderer.class)
@Environment(EnvType.CLIENT)
public abstract class GameRendererMixin {

  @Definition(id = "playerState", local = @Local(type = PlayerRenderState.class, name = "playerState"))
  @Definition(id = "nauseaEffectIntensity", field = "Lnet/minecraft/client/renderer/state/level/PlayerRenderState;nauseaEffectIntensity:F")
  @Expression("playerState.nauseaEffectIntensity")
  @ModifyExpressionValue(method = "renderLevel", at = @At("MIXINEXTRAS:EXPRESSION"))
  private float modifyNauseaIntensity(float original) {
    if (Config.STRONGER_NAUSEA_EFFECT.get()) {
      return original + (original * original) * 9.0f;
    }
    return original;
  }

}
