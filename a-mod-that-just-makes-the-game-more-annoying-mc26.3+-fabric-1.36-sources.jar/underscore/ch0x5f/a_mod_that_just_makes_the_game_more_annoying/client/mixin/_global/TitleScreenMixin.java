package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin._global;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.platform.cursor.CursorTypes;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CommonButtons;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.options_screen.ConfigOptionsScreen;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.screens.AMTJMTGMAScreenConstants;


@Mixin(TitleScreen.class)
@Environment(EnvType.CLIENT)
public abstract class TitleScreenMixin extends Screen {
  protected TitleScreenMixin(Component title) {
    super(title);
  }

  @Inject(method = "init", at = @At("TAIL"))
  private void initExtraButtons(
      CallbackInfo ci,
      @Local(name = "topPos") int topPos
  ) {
    SpriteIconButton explicitButton = SpriteIconButton.builder(
        Component.literal("Ragebait Options..."),
        button -> this.minecraft.setScreenAndShow(new ConfigOptionsScreen()),
        true
    )
        .size(20, 20)
        .sprite(Identifier.withDefaultNamespace("toast/tree"), 20, 20)
        .build();
    explicitButton.setTooltip(Tooltip.create(Component.literal("Ragebait Options")));
    this.addRenderableWidget(explicitButton).setPosition(this.width / 2 + 104, topPos);
  }

}
