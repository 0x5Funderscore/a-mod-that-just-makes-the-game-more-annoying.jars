package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.bitrate_reducer;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.mojang.blaze3d.platform.FramerateLimitTracker;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.bitrate_reducer.BitrateReducer;


@Mixin(FramerateLimitTracker.class)
@Environment(EnvType.CLIENT)
public abstract class FramerateLimitTrackerMixin {

  @ModifyReturnValue(method = "getFramerateLimit", at = @At("TAIL"))
  private int modifyFramerateLimit(int original) {
    if (Config.BITRATE_REDUCER.get()) {
      if (Minecraft.getInstance().player != null) {
        if (BitrateReducer.bitrateReduced) {
          return Math.min(original, Math.min((int)(Math.random() * 40) + 4, 20));
        }
      } else {
        BitrateReducer.bitrateReduced = false;
        BitrateReducer.setTimer();
      }
    }
    return original;
  }

}
