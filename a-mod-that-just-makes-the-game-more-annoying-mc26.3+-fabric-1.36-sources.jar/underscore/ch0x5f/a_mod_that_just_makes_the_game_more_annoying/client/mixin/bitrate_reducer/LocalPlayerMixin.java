package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.bitrate_reducer;

import com.google.common.collect.ImmutableList;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.mojang.authlib.GameProfile;
import com.mojang.logging.LogUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.bitrate_reducer.BitrateReducer;

import java.util.List;


@Mixin(LocalPlayer.class)
@Environment(EnvType.CLIENT)
public abstract class LocalPlayerMixin extends AbstractClientPlayer {

  public LocalPlayerMixin(ClientLevel level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("HEAD"))
  private void tickHEAD(CallbackInfo ci) {
    if (Config.BITRATE_REDUCER.get()) {
      if (this.tickCount < 3) {
        BitrateReducer.bitrateReduced = false;
        BitrateReducer.bitrateReducedTimer = Math.max(BitrateReducer.bitrateReducedTimer, BitrateReducer.getRecentlyDeadTimer());
      } else {
        BitrateReducer.bitrateReducedTimer--;
        BitrateReducer.checkTimer((LocalPlayer)(AbstractClientPlayer)this);
      }
    } else {
      BitrateReducer.bitrateReduced = false;
    }
  }

  @Unique
  private List<Identifier> rb$sourceActivePostEffectsList;
  @Unique
  private List<Identifier> rb$modifiedActivePostEffectsList;

  @ModifyReturnValue(method = "getActivePostEffects", at = @At("TAIL"))
  private List<Identifier> modifyActivePostEffects(List<Identifier> original) {
    if (Config.BITRATE_REDUCER.get()) {

      if (BitrateReducer.bitrateReduced) {

        if (rb$sourceActivePostEffectsList != original) {
          rb$sourceActivePostEffectsList = original;
          rb$modifiedActivePostEffectsList = ImmutableList.<Identifier>builder()
              .addAll(original)
              .add(Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "low_quality"))
              .build();
        }
        return rb$modifiedActivePostEffectsList;

      } else {
        rb$sourceActivePostEffectsList = null;
        rb$modifiedActivePostEffectsList = null;
      }

    }
    return original;
  }

}
