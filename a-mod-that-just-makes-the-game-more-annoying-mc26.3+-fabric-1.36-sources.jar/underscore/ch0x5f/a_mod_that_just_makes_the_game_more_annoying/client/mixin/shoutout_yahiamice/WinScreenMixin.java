package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.shoutout_yahiamice;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.WinScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.Music;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(WinScreen.class)
@Environment(EnvType.CLIENT)
public abstract class WinScreenMixin extends Screen {

  protected WinScreenMixin(Component title) {
    super(title);
  }

  @Unique
  private static final Identifier rb$CANTALOUPE = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/cantaloupe.png");
  @Unique
  private float rb$cantaloupeTimer = 0.0f;
  @Unique
  private boolean rb$playedMusic = false;

  @Inject(method = "extractRenderState", at = @At("TAIL"))
  private void postRender(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a, CallbackInfo ci) {
    if (Config.SHOUTOUT_YAHIAMICE.get()) {
      this.rb$cantaloupeTimer += a;
      if (this.rb$cantaloupeTimer >= 234.0f) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, rb$CANTALOUPE, 0, 0, 0, 0, this.width, this.height, this.width, this.height, -1);
      }
    }
  }

  @ModifyReturnValue(method = "getBackgroundMusic", at = @At("TAIL"))
  private Music modifyBackgroundMusic(Music original) {

    if (Config.SHOUTOUT_YAHIAMICE.get()) {

      if (!this.rb$playedMusic) {
        this.rb$playedMusic = true;
        Identifier soundId = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "invincible");
        Minecraft.getInstance().getSoundManager().play(
            new SimpleSoundInstance(
                soundId,
                SoundSource.MASTER,
                1.0f,
                1.0f,
                RandomSource.create(),
                false,
                0,
                SoundInstance.Attenuation.NONE,
                0.0d, 0.0d, 0.0d,
                true
            )
        );
      }
      return null;
    }
    return original;
  }

}
