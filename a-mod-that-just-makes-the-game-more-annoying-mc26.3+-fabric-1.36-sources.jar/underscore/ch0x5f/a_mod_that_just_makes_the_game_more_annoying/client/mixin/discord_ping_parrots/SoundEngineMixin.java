package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.discord_ping_parrots;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.Sound;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundEngine;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(SoundEngine.class)
@Environment(EnvType.CLIENT)
public abstract class SoundEngineMixin {

  @ModifyVariable(method = "play", at = @At("HEAD"), name = "instance", argsOnly = true)
  private SoundInstance modifySound(SoundInstance instance) {
    if (Config.DISCORD_PING_PARROT.get() && instance instanceof AbstractSoundInstance abstractSoundInstance && instance.getIdentifier().equals(Identifier.withDefaultNamespace("entity.parrot.ambient"))) {
      return new SimpleSoundInstance(
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "discord_ping"),
          abstractSoundInstance.getSource(),
          abstractSoundInstance.volume,
          1.0f,
          abstractSoundInstance.random,
          abstractSoundInstance.isLooping(),
          abstractSoundInstance.getDelay(),
          abstractSoundInstance.getAttenuation(),
          abstractSoundInstance.getX(),
          abstractSoundInstance.getY(),
          abstractSoundInstance.getZ(),
          abstractSoundInstance.isRelative()
      );
    }
    return instance;
  }

}
