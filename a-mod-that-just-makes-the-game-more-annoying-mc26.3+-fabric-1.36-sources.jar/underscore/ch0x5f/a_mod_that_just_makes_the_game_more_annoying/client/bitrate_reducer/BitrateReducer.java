package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.bitrate_reducer;

import net.minecraft.ChatFormatting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;


public final class BitrateReducer {

  public static boolean bitrateReduced = false;

  public static int bitrateReducedTimer = 0;

  public static void checkTimer(LocalPlayer localPlayer) {
    if (bitrateReducedTimer <= 0) {
      bitrateReduced = !bitrateReduced;
      if (bitrateReduced) {
        localPlayer.sendSystemMessage(Component.literal("Low bitrate detected. Please hold on...").withStyle(ChatFormatting.GRAY));
      }
      setTimer();
    }
  }

  public static int getRecentlyDeadTimer() {
    return Mth.lerpDiscrete((float)Math.random(), 60*20, 120*20);
  }

  public static void setTimer() {
    if (bitrateReduced) {
      // 2 sec to 20 sec
      bitrateReducedTimer = Mth.lerpDiscrete((float)Math.random(), 2*20, 20*20);
    } else {
      // 10 min to 30 min
      bitrateReducedTimer = Mth.lerpDiscrete((float)Math.random(), 10*60*20, 30*60*20);
    }
  }

}
