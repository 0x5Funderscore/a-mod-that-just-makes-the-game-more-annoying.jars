package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.StructureTags;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.phys.Vec3;

import java.util.Collections;
import java.util.List;


public final class VillageFinder {

  public static void findAndSendVillage(ServerPlayer player, ServerLevel level, Position position) {

    Pair<BlockPos,Holder<Structure>> village = level.getChunkSource()
        .getGenerator()
        .findNearestMapStructure(
            level,
            level.registryAccess()
                .lookupOrThrow(Registries.STRUCTURE)
                .getOrThrow(StructureTags.VILLAGE),
            BlockPos.containing(position),
            32,
            false
        );

    Component foundVillage = Component.literal("none nearby").withColor(TextColor.RED);

    if (village != null) {

      Vec3 where = Vec3.atBottomCenterOf(village.getFirst());
      Vec3 from = new Vec3(position.x(), position.y(), position.z()).with(Direction.Axis.Y, where.y);
      double distance = where.distanceTo(from);
      double angle = Math.atan2(where.x - from.x, from.z - where.z);

      if (distance <= 64.0d) {
        foundVillage = Component.literal("nearby").withColor(TextColor.GREEN);
      } else {
        int directionIndex = Math.floorMod((int)Math.round(angle / Math.PI * 4), 8);
        String direction = new String[]{"north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"}[directionIndex];
        foundVillage = Component.literal(Math.round(distance) + " blocks ").withColor(TextColor.YELLOW).append(Component.literal(direction).withColor(TextColor.YELLOW));
      }
    }

    player.sendSystemMessage(Component.literal("Village: ").withColor(TextColor.GOLD).append(foundVillage));
  }

}
