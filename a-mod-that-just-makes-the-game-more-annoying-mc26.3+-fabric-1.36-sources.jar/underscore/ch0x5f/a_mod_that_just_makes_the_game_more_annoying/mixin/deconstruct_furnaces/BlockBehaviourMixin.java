package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.deconstruct_furnaces;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(BlockBehaviour.class)
public abstract class BlockBehaviourMixin {

  @ModifyReturnValue(method = "getDrops", at = @At("TAIL"))
  private List<ItemStack> modifyDrops(
      List<ItemStack> original,
      @Local(name = "state", argsOnly = true) BlockState state
  ) {
    if (Config.DECONSTRUCT_FURNACES.get()) {
      if (state.is(Blocks.FURNACE)) {
        return List.of(new ItemStack(Items.COBBLESTONE, 4));
      } else if (state.is(Blocks.BLAST_FURNACE)) {
        return List.of(new ItemStack(Items.COBBLESTONE, 4), new ItemStack(Items.IRON_INGOT, 2), new ItemStack(Items.STONE, 2));
      } else if (state.is(Blocks.SMOKER)) {
        return List.of(new ItemStack(Items.COBBLESTONE, 4), new ItemStack(Items.CHARCOAL, 2));
      }
    }
    return original;
  }
}
