package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.endermen_social_anxiety;

import net.minecraft.world.entity.monster.Enderman;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Enderman.class)
public abstract class EndermanMixin {

  @ModifyArg(method = "isBeingStaredBy", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/monster/Enderman;isLookingAtMe(Lnet/minecraft/world/entity/LivingEntity;DZZ[D)Z"), index = 1)
  private double modifyIsLookingAtMeConeSize(double par2) {
    if (Config.ENDERMEN_SOCIAL_ANXIETY.get()) return par2 * 10d;
    return par2;
  }

}
