package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.origin_desert;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(StructureManager.class)
public abstract class StructureManagerMixin {

  @Definition(id = "getStartForStructure", method = "Lnet/minecraft/world/level/StructureManager;getStartForStructure(Lnet/minecraft/world/level/levelgen/structure/Structure;Lnet/minecraft/world/level/chunk/StructureAccess;)Lnet/minecraft/world/level/levelgen/structure/StructureStart;")
  @Expression("this.getStartForStructure(?, ?)")
  @ModifyExpressionValue(method = "fillStartsForStructure", at = @At("MIXINEXTRAS:EXPRESSION"))
  private StructureStart editStartForStructure(
      StructureStart original,
      @Local(name = "chunkPos") ChunkPos chunkPos
  ) {
    if (Config.ORIGIN_DESERT.get() && original != StructureStart.INVALID_START) {
      BlockPos center = chunkPos.getMiddleBlockPosition(0);
      long x = center.getX();
      long z = center.getZ();
      if (x * x + z * z < 250000L) {
        return StructureStart.INVALID_START;
      }
    }
    return original;
  }

}
