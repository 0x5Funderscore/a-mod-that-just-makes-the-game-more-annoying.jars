package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.origin_desert;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.core.Holder;
import net.minecraft.world.level.biome.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(MultiNoiseBiomeSource.class)
public abstract class MultiNoiseBiomeSourceMixin extends BiomeSource {

  @Shadow
  public abstract Holder<Biome> getNoiseBiome(Climate.TargetPoint target);

  @ModifyReturnValue(method = "createResolverForChunk", at = @At("RETURN"))
  private BiomeResolver modifyBiomeResolver(BiomeResolver original) {
    if (Config.ORIGIN_DESERT.get()) {
      return (quartX, quartY, quartZ) -> {
        if ((long)quartX * (long)quartX + (long)quartZ * (long)quartZ < 15625L) {
          return this.getNoiseBiome(new Climate.TargetPoint(5660L, 1130L, 2222L, 750L, 3137L, 1970L));
        } else {
          return original.getNoiseBiome(quartX, quartY, quartZ);
        }
      };
    }
    return original;
  }

}
