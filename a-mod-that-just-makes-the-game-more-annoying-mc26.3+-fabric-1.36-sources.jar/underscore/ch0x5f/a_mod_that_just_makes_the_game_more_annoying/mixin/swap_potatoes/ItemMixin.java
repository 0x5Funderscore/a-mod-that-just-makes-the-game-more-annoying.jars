package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.swap_potatoes;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.Consumables;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;


@Mixin(Item.class)
public abstract class ItemMixin {

  @Definition(id = "get", method = "Lnet/minecraft/world/item/ItemStack;get(Lnet/minecraft/core/component/DataComponentType;)Ljava/lang/Object;")
  @Definition(id = "CONSUMABLE", field = "Lnet/minecraft/core/component/DataComponents;CONSUMABLE:Lnet/minecraft/core/component/DataComponentType;")
  @Definition(id = "itemStack", local = @Local(type = ItemStack.class, name = "itemStack", argsOnly = true))
  @Expression("itemStack.get(CONSUMABLE)")
  @ModifyExpressionValue(method = "finishUsingItem", at = @At("MIXINEXTRAS:EXPRESSION"))
  private Object replaceConsumable(Object original) {
    if ((Object)this == Items.POTATO) return Consumables.POISONOUS_POTATO;
    if ((Object)this == Items.POISONOUS_POTATO) return Consumables.DEFAULT_FOOD;
    return original;
  }

}
