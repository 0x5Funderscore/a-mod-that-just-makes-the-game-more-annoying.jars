package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.falling_blocks_drop_loot;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootTable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(FallingBlockEntity.class)
public abstract class FallingBlockEntityMixin extends Entity {

  @Shadow
  private BlockState blockState;

  public FallingBlockEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/item/FallingBlockEntity;spawnAtLocation(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/level/ItemLike;)Lnet/minecraft/world/entity/item/ItemEntity;"))
  private ItemEntity wrapSpawnAtLocation(FallingBlockEntity instance, ServerLevel serverLevel, ItemLike itemLike, Operation<ItemEntity> original) {
    if (Config.FALLING_BLOCKS_DROP_LOOT.get()) {
      List<ItemStack> drops = Block.getDrops(this.blockState, serverLevel, this.blockPosition(), null);
      drops.forEach(stack -> this.spawnAtLocation(serverLevel, stack));
      return null;
    }
    return original.call(instance, serverLevel, itemLike);
  }

}
