package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.rabbits_love_players;

import net.minecraft.world.entity.animal.rabbit.Rabbit;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.function.Predicate;


@Mixin(Rabbit.class)
public abstract class RabbitMixin {

  @ModifyArg(method = "registerGoals", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/goal/TemptGoal;<init>(Lnet/minecraft/world/entity/PathfinderMob;DLjava/util/function/Predicate;Z)V"), index = 2)
  private Predicate<ItemStack> modifyTemptCondition(Predicate<ItemStack> items) {
    if (Config.RABBITS_LOVE_PLAYERS.get()) {
      return _ -> true;
    }
    return items;
  }

}
