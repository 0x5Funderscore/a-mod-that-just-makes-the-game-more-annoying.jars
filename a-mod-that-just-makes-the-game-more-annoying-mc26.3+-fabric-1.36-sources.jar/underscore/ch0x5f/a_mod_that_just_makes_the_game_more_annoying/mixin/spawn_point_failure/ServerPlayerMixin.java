package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.spawn_point_failure;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.server.level.ServerPlayer;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Optional;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin {

  @Shadow
  public abstract void setRespawnPosition(ServerPlayer.@Nullable RespawnConfig respawnConfig, boolean showMessage);

  @Shadow
  public abstract void sendSystemMessage(Component message);

  @ModifyExpressionValue(method = "findRespawnPositionAndUseSpawnBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;findRespawnAndUseSpawnBlock(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/server/level/ServerPlayer$RespawnConfig;Z)Ljava/util/Optional;"))
  private Optional<ServerPlayer.RespawnPosAngle> modifyRespawn(
      Optional<ServerPlayer.RespawnPosAngle> original,
      @Local(name = "respawnConfig") ServerPlayer.RespawnConfig respawnConfig,
      @Local(name = "consumeSpawnBlock", argsOnly = true) boolean consumeSpawnBlock
  ) {
    if (original.isPresent() && !consumeSpawnBlock && Config.SPAWN_POINT_FAILURE.get() && Math.random() < 0.05d && !respawnConfig.forced()) {
      this.setRespawnPosition(null, false);
      return Optional.empty();
    }
    return original;
  }

}
