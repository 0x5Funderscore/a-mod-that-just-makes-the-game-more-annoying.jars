package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.experience_orbs_hurt;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ExperienceOrb.class)
public abstract class ExperienceOrbMixin extends Entity {

  @Shadow
  private int count;

  @Shadow
  public abstract int getValue();

  public ExperienceOrbMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @WrapOperation(method = "playerTouch", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;giveExperiencePoints(I)V"))
  private void wrapGiveExperiencePoints(Player instance, int i, Operation<Void> original) {
    if (Config.EXPERIENCE_ORBS_HURT.get()) {
      if (instance instanceof ServerPlayer serverPlayer) {
        ServerLevel level = serverPlayer.level();
        serverPlayer.hurtServer(level, level.damageSources().indirectMagic(this, this), Mth.ceil(i / 2f));
        return;
      }
    }
    original.call(instance, i);
  }

}
