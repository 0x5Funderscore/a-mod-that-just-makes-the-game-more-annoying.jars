package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.anvils_fall_up;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(FallingBlockEntity.class)
public abstract class FallingBlockEntityMixin extends Entity {
  @Shadow
  private BlockState blockState;

  @Shadow
  public int time;

  @Shadow
  public abstract BlockPos getStartPos();

  public FallingBlockEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @ModifyReturnValue(method = "getDefaultGravity", at = @At("TAIL"))
  private double modifyDefaultGravity(double original) {
    if (this.blockState.is(BlockTags.ANVIL) && Config.ANVILS_FALL_UP.get()) return -original;
    return original;
  }

  @ModifyExpressionValue(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/item/FallingBlockEntity;onGround()Z"))
  private boolean modifyOnGround(boolean original) {
    if (this.blockState.is(BlockTags.ANVIL) && Config.ANVILS_FALL_UP.get()) return this.verticalCollision && this.time > 1;
    return original;
  }

}
