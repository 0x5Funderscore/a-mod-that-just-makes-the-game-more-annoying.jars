package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.anvils_fall_up;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FallingBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(FallingBlock.class)
public abstract class FallingBlockMixin extends Block {
  public FallingBlockMixin(Properties properties) {
    super(properties);
  }

  @ModifyExpressionValue(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/core/BlockPos;below()Lnet/minecraft/core/BlockPos;"))
  private BlockPos modifyBelow(BlockPos original) {
    if (this.defaultBlockState().is(BlockTags.ANVIL) && Config.ANVILS_FALL_UP.get()) original = original.above(2);
    return original;
  }

  @Definition(id = "pos", local = @Local(type = BlockPos.class, name = "pos", argsOnly = true))
  @Definition(id = "getY", method = "Lnet/minecraft/core/BlockPos;getY()I")
  @Definition(id = "level", local = @Local(type = ServerLevel.class, name = "level", argsOnly = true))
  @Definition(id = "getMinY", method = "Lnet/minecraft/server/level/ServerLevel;getMinY()I")
  @Expression("pos.getY() >= level.getMinY()")
  @ModifyExpressionValue(method = "tick", at = @At(value = "MIXINEXTRAS:EXPRESSION"))
  private boolean wrapYCheck(
      boolean original,
      @Local(name = "pos", argsOnly = true) BlockPos pos,
      @Local(name = "level", argsOnly = true) ServerLevel level
  ) {
    if (this.defaultBlockState().is(BlockTags.ANVIL) && Config.ANVILS_FALL_UP.get()) return pos.getY() <= level.getMaxY();
    return original;
  }

}
