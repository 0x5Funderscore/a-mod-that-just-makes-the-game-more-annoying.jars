package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.thieving_piglins;

import com.google.common.collect.ImmutableList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Prediction;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinAi;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(Piglin.class)
public abstract class PiglinMixin extends AbstractPiglin {

  @Shadow
  public abstract Brain<Piglin> getBrain();

  @Unique
  private boolean rb$isThief = false;

  public PiglinMixin(EntityType<? extends AbstractPiglin> type, Level level) {
    super(type, level);
  }

  @Inject(method = "finalizeSpawn", at = @At("TAIL"))
  private void postFinalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, EntitySpawnReason spawnReason, SpawnGroupData groupData, CallbackInfoReturnable<SpawnGroupData> cir) {
    this.rb$isThief = Math.random() < 0.05d;
  }

  @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
  private void addExtraAdditionalSaveData(ValueOutput output, CallbackInfo ci) {
    output.putBoolean("IsThief", this.rb$isThief);
  }

  @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
  private void readExtraAdditionalSaveData(ValueInput input, CallbackInfo ci) {
    this.rb$isThief = input.getBooleanOr("IsThief", this.rb$isThief);
  }

  @Unique
  private static final List<EquipmentSlot> rb$armorSlots = ImmutableList.of(
      EquipmentSlot.HEAD,
      EquipmentSlot.CHEST,
      EquipmentSlot.LEGS,
      EquipmentSlot.FEET
  );

  @Inject(method = "customServerAiStep", at = @At("TAIL"))
  private void postAiStep(ServerLevel level, CallbackInfo ci) {
    if (Config.THIEVING_PIGLINS.get() && this.rb$isThief && this.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty()) {
      level.getEntities(EntityTypeTest.forClass(Player.class), this.getBoundingBox().inflate(0.5d), player -> !player.hasInfiniteMaterials() && !player.isSpectator())
          .forEach(player -> {
            List<EquipmentSlot> stealSlots = rb$armorSlots.stream()
                .filter(slot -> player.getItemBySlot(slot).is(ItemTags.PIGLIN_LOVED) && this.getItemBySlot(slot).isEmpty())
                .toList();
            if (!stealSlots.isEmpty()) {
              EquipmentSlot stealSlot = stealSlots.get((int)(Math.random() * stealSlots.size()));
              ItemStack stolenItem = player.getItemBySlot(stealSlot).copyWithCount(1);
              player.getItemBySlot(stealSlot).shrink(1);
              ItemEntity itemEntity = new ItemEntity(level, player.getX(), player.getY(), player.getZ(), stolenItem);
              level.addFreshEntity(itemEntity);
              this.pickUpItem(level, itemEntity);
            }
          });
    }
  }

}
