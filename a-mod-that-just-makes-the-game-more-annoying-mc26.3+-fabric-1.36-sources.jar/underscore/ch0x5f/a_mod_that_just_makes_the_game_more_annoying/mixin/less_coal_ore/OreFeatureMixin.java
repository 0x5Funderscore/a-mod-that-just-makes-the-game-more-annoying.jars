package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.less_coal_ore;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.AbstractOreFeature;
import net.minecraft.world.level.levelgen.feature.BlockReplacement;
import net.minecraft.world.level.levelgen.feature.OreFeature;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CTags;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(OreFeature.class)
public abstract class OreFeatureMixin extends AbstractOreFeature {
  public OreFeatureMixin(List<BlockReplacement> targetStates, int size, float discardChanceOnAirExposure) {
    super(targetStates, size, discardChanceOnAirExposure);
  }

  @Unique
  private boolean rb$modifiedCoalSize = false;

  @Inject(method = "place", at = @At("HEAD"))
  private void prePlace(WorldGenLevel level, ChunkGenerator chunkGenerator, RandomSource random, BlockPos origin, CallbackInfoReturnable<Boolean> cir) {
    if (!Config.LESS_COAL_ORE.get()) return;
    if (this.targetStates.stream().anyMatch(blockReplacement -> blockReplacement.state().is(CTags.Blocks.Ores.coal))) {
      if (!rb$modifiedCoalSize) {
        this.size /= 3;
        this.rb$modifiedCoalSize = true;
      }
    }
  }

}
