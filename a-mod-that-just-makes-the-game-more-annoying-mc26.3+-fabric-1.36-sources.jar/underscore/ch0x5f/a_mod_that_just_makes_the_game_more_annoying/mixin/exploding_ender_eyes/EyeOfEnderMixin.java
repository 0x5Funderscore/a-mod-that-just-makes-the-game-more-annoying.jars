package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.exploding_ender_eyes;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.EyeOfEnder;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EyeOfEnder.class)
public abstract class EyeOfEnderMixin extends Entity {

  public EyeOfEnderMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;levelEvent(ILnet/minecraft/core/BlockPos;I)V"))
  private void onEyePop(CallbackInfo ci) {
    if (Config.EXPLODING_ENDER_EYES.get()) {
      this.level().explode(this, this.getX(), this.getY(), this.getZ(), 8.0f, false, Level.ExplosionInteraction.MOB);
    }
  }

}
