package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fighting_fish;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.fish.AbstractFish;
import net.minecraft.world.entity.animal.fish.WaterAnimal;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFish.class)
public abstract class AbstractFishMixin extends WaterAnimal {

  protected AbstractFishMixin(EntityType<? extends WaterAnimal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "createAttributes", at = @At("TAIL"))
  private static void modifyAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (Config.FIGHTING_FISH.get()) {
      cir.getReturnValue().add(Attributes.ATTACK_DAMAGE, 2.0d);
    }
  }

}
