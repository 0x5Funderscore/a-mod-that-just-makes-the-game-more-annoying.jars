package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_mob_ai_natural_selection;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(MeleeAttackGoal.class)
public abstract class MeleeAttackGoalMixin {

  /*
  @Shadow
  @Final
  protected PathfinderMob mob;

  @Definition(id = "ticksUntilNextPathRecalculation", field = "Lnet/minecraft/world/entity/ai/goal/MeleeAttackGoal;ticksUntilNextPathRecalculation:I")
  @Expression("this.ticksUntilNextPathRecalculation <= 0")
  @ModifyExpressionValue(method = "tick", at = @At(value = "MIXINEXTRAS:EXPRESSION", ordinal = 0))
  private boolean modifyPathUpdateCondition(
      boolean original,
      @Local(name = "target") LivingEntity target
  ) {
    if (Config.MOB_AI_NATURAL_SELECTION.get()) {
    }
    return original;
  }
  */

}
