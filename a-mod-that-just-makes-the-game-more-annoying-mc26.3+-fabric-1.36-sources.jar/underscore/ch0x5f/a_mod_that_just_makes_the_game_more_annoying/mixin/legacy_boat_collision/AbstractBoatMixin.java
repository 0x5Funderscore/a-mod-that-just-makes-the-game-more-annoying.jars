package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.legacy_boat_collision;

import com.mojang.logging.LogUtils;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.VehicleEntity;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gamerules.GameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractBoat.class)
public abstract class AbstractBoatMixin extends VehicleEntity {

  public AbstractBoatMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tick", at = @At("HEAD"))
  private void preTick(CallbackInfo ci) {
    if (Config.LEGACY_BOAT_COLLISION.get() && this.level() instanceof ServerLevel) {
      if (!this.level().noBlockCollision(this, this.getBoundingBox().inflate(0.1d, -0.1d, 0.1d))) {
        this.rb$collideAndBreak();
      }
    }
  }

  @Unique
  private void rb$collideAndBreak() {
    ServerLevel level = (ServerLevel)this.level();
    if (level.getGameRules().get(GameRules.ENTITY_DROPS)) {
      this.spawnAtLocation(level, new ItemStack(Items.OAK_PLANKS, 3));
      this.spawnAtLocation(level, new ItemStack(Items.STICK, 2));
      this.kill(level);
    }
  }

}
