package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.villager_vengeance;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ConversionParams;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.function.Consumer;


@Mixin(Villager.class)
public abstract class VillagerMixin {

  @WrapOperation(method = "tellWitnessesThatIWasMurdered", at = @At(value = "INVOKE", target = "Ljava/lang/Iterable;forEach(Ljava/util/function/Consumer;)V"))
  private void wrapReputationEvent(Iterable<LivingEntity> instance, Consumer<? super LivingEntity> action, Operation<Void> original) {
    original.call(instance, action);
    if (Config.VILLAGER_VENGEANCE.get()) {
      instance.forEach(entity -> {
        if (entity instanceof Villager villager) {
          villager.convertTo(EntityTypes.VINDICATOR, ConversionParams.single(villager, false, false), mob -> mob.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.DIAMOND_AXE)));
        }
      });
    }
  }

}
