package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.explode_on_place;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BlockItem.class)
public abstract class BlockItemMixin {

  @Inject(method = "place", at = @At("TAIL"))
  private void afterPlace(BlockPlaceContext placeContext, CallbackInfoReturnable<InteractionResult> cir) {
    if (Config.EXPLODE_ON_PLACE.get()) {
      Level level = placeContext.getLevel();
      if (level instanceof ServerLevel serverLevel) {
        BlockPos pos = placeContext.getClickedPos();
        if (level.getRandom().forkPositional().at(pos).nextDouble() < 0.00025d) {
          serverLevel.explode(null, pos.getX() + 0.5d, pos.getY() + 0.5d, pos.getZ() + 0.5d, 2.0f, false, Level.ExplosionInteraction.BLOCK);
        }
      }
    }
  }

}
