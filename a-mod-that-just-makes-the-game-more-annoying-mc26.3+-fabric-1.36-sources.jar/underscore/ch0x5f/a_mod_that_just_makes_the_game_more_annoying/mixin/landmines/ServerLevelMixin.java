package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.landmines;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.entity.EntityTypeTest;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.landmines.Landmine;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;
import java.util.stream.Collectors;


@Mixin(ServerLevel.class)
public abstract class ServerLevelMixin {

  @Shadow
  public abstract <T extends Entity> List<? extends T> getEntities(EntityTypeTest<Entity,T> type, Predicate<? super T> selector);

  @Unique
  private final List<Landmine> rb$landmines = new ArrayList<>();

  @Inject(method = "addEntity", at = @At("TAIL"))
  private void postAddEntity(Entity entity, CallbackInfoReturnable<Boolean> cir) {
    Landmine potentialLandmine = Landmine.maybeAttachEntity(entity);
    if (potentialLandmine != null) {
      this.rb$landmines.add(potentialLandmine);
    }
  }

  @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;runBlockEvents()V"))
  private void tickLandmines(BooleanSupplier haveTime, CallbackInfo ci) {
    Set<Display.BlockDisplay> countedBlockDisplays = this.rb$landmines.stream().map(landmine -> landmine.blockDisplay).collect(Collectors.toSet());
    this.getEntities(
        EntityTypeTest.forExactClass(Display.BlockDisplay.class),
        d -> d.entityTags().contains("landmine") && !countedBlockDisplays.contains(d)
    ).forEach(d -> this.rb$landmines.add(new Landmine(d, (ServerLevel)(Object)this)));
    this.rb$landmines.forEach(Landmine::tick);
    this.rb$landmines.removeIf(Landmine::isRemoved);
  }

}
