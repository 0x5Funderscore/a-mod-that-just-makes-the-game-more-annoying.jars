package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.upper_void;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Entity.class)
public abstract class EntityMixin {

  @Shadow
  public abstract double getY();

  @Shadow
  public abstract Level level();

  @Shadow
  protected abstract void onBelowWorld();

  @Inject(method = "checkBelowWorld", at = @At("TAIL"))
  private void afterCheckBelowWorld(CallbackInfo ci) {
    if (Config.UPPER_VOID.get()) {
      if (this.getY() > this.level().getMaxY() + 64) {
        this.onBelowWorld();
      }
    }
  }

}
