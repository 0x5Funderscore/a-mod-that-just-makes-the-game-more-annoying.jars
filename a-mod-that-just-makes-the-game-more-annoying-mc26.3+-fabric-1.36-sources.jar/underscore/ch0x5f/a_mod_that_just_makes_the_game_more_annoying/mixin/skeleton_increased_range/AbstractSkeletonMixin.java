package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.skeleton_increased_range;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.skeleton.AbstractSkeleton;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractSkeleton.class)
public abstract class AbstractSkeletonMixin extends Monster {
  protected AbstractSkeletonMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @Inject(method = "createAttributes", at = @At("TAIL"))
  private static void modifyAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (Config.SKELETON_INCREASED_RANGE.get()) cir.getReturnValue().add(Attributes.FOLLOW_RANGE, 50d);
  }

}
