package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.magma_breaks_falling_blocks;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(FallingBlockEntity.class)
public abstract class FallingBlockEntityMixin extends Entity {

  @Shadow
  public int time;

  public FallingBlockEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @ModifyExpressionValue(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/item/FallingBlockEntity;onGround()Z"))
  private boolean modifyOnGround(boolean original) {
    if (Config.MAGMA_BREAKS_FALLING_BLOCKS.get() && this.level() instanceof ServerLevel && this.level().getBlockState(BlockPos.containing(this.position().add(this.getDeltaMovement().scale(1.5d)))).is(Blocks.MAGMA_BLOCK)) {
      if (this.time < 10000) this.time = 10000;
      return false;
    }
    return original;
  }

}
