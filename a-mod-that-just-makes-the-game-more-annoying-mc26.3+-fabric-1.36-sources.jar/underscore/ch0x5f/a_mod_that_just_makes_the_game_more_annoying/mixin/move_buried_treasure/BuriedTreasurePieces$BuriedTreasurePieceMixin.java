package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.move_buried_treasure;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntityTypes;
import net.minecraft.world.level.block.entity.DropperBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.structures.BuriedTreasurePieces;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Optional;


@Mixin(BuriedTreasurePieces.BuriedTreasurePiece.class)
public abstract class BuriedTreasurePieces$BuriedTreasurePieceMixin {

  @Inject(method = "postProcess", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/levelgen/structure/structures/BuriedTreasurePieces$BuriedTreasurePiece;createChest(Lnet/minecraft/world/level/ServerLevelAccessor;Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/util/RandomSource;Lnet/minecraft/core/BlockPos;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/world/level/block/state/BlockState;)Z"), order = 900)
  private void afterCreateChest(WorldGenLevel level, StructureManager structureManager, ChunkGenerator generator, RandomSource random, BoundingBox chunkBB, ChunkPos chunkPos, BlockPos referencePos, CallbackInfo ci) {
    if (Config.MOVE_BURIED_TREASURE.get()) {

      BlockPos pos = referencePos.offset(5, 0, 5);

      boolean move;
      do {
        BlockState state = level.getBlockState(pos);
        move = state.isAir() || state.canBeReplaced();
        pos = pos.below();
      } while (move);

      level.setBlock(pos, Blocks.DROPPER.defaultBlockState().setValue(DirectionalBlock.FACING, Direction.DOWN), 2);
      Optional<DropperBlockEntity> blockEntityOptional = level.getBlockEntity(pos, BlockEntityTypes.DROPPER);
      if (blockEntityOptional.isPresent()) {
        DropperBlockEntity blockEntity = blockEntityOptional.get();
        ItemStack itemstack = new ItemStack(Items.PAPER, 1);
        itemstack.applyComponents(DataComponentPatch.builder().set(DataComponents.CUSTOM_NAME, Component.literal("The buried treasure you are looking for has moved to 4/4 (in chunk). Sorry for the inconvenience.")).build());
        blockEntity.setItem(4, itemstack);
      }

    }
  }

}
