package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.end_portal_frame_misclick;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.item.EnderEyeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderEyeItem.class)
public abstract class EnderEyeItemMixin extends Item {
  public EnderEyeItemMixin(Properties properties) {
    super(properties);
  }

  @ModifyExpressionValue(method = "useOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Ljava/lang/Object;)Z"))
  private boolean modifyBlockStateCheck(
      boolean original,
      @Local(name = "level") Level level
  ) {
    if (Config.END_PORTAL_FRAME_MISCLICK.get() && !level.isClientSide() && Math.random() < 0.75d) return false;
    return original;
  }

}
