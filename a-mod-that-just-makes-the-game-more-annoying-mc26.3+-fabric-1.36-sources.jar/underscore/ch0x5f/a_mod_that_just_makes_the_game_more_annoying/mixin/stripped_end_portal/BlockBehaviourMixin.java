package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.stripped_end_portal;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.component.BlockTransformer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.BlockTransformers;
import net.minecraft.world.item.component.SwingAnimation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.TheEndPortalBlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.ITheEndPortalBlockEntityStripExtension;


@Mixin(BlockBehaviour.class)
public abstract class BlockBehaviourMixin {

  @Inject(method = "useItemOn", at = @At("HEAD"))
  private void preUseItemOn(ItemStack itemStack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult, CallbackInfoReturnable<InteractionResult> cir) {
    if (!level.isClientSide() && Config.STRIPPED_END_PORTAL.get() && state.is(Blocks.END_PORTAL)) {
      if (level.getBlockEntity(pos) instanceof TheEndPortalBlockEntity endPortalBlockEntity) {

        Holder<BlockTransformer> blockTransformer = itemStack.getItem().components().get(DataComponents.BLOCK_TRANSFORMER);
        if (blockTransformer != null) {
          if (blockTransformer.is(BlockTransformers.SHOVEL)) {
            if (level.getBlockState(pos.above()).isAir()) {
              if (((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).flatten()) {
                level.playSound(null, pos, SoundEvents.SHOVEL_FLATTEN.value(), SoundSource.BLOCKS, 1f, 1f);
                player.swing(hand, SwingAnimation.DEFAULT, true);
                level.sendBlockUpdated(pos, state, state, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
                level.blockEntityChanged(pos);
              }
            }
          } else if (blockTransformer.is(BlockTransformers.AXE)) {
            if (((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).strip()) {
              level.playSound(null, pos, SoundEvents.AXE_STRIP.value(), SoundSource.BLOCKS, 1f, 1f);
              player.swing(hand, SwingAnimation.DEFAULT, true);
              level.sendBlockUpdated(pos, state, state, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
              level.blockEntityChanged(pos);
            }
          }
        }

      }
    }
  }

}
