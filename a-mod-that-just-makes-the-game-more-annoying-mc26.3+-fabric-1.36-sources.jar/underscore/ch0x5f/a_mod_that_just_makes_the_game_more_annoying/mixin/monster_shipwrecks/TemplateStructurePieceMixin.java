package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.monster_shipwrecks;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.ByteTag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntityTypes;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.TemplateStructurePiece;
import net.minecraft.world.level.levelgen.structure.structures.ShipwreckPieces;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;
import java.util.Optional;
import java.util.stream.LongStream;
import java.util.stream.Stream;


@Mixin(TemplateStructurePiece.class)
public abstract class TemplateStructurePieceMixin {

  @Shadow
  @Final
  protected StructureTemplate template;

  @Shadow
  protected BlockPos templatePosition;

  @Shadow
  @Final
  protected StructurePlaceSettings placeSettings;

  @Inject(method = "postProcess", at = @At("TAIL"))
  private void postPostProcess(WorldGenLevel level, StructureManager structureManager, ChunkGenerator generator, RandomSource random, BoundingBox chunkBB, ChunkPos chunkPos, BlockPos referencePos, CallbackInfo ci) {
    if (Config.MONSTER_SHIPWRECKS.get()) {
      if ((TemplateStructurePiece)(Object)this instanceof ShipwreckPieces.ShipwreckPiece) {
        if (level.getBiome(referencePos).is(BiomeTags.IS_DEEP_OCEAN)) {

          BoundingBox boundingBox = this.template.getBoundingBox(this.placeSettings, this.templatePosition);
          BlockPos centerBottom = boundingBox.getCenter().atY(boundingBox.minY());
          float xDiameter = boundingBox.getXSpan();
          float zDiameter = boundingBox.getZSpan();
          float diameter = (float)Math.hypot(xDiameter, zDiameter);
          xDiameter = Math.min(Mth.lerp(0.1f, xDiameter, diameter), 24.5f);
          zDiameter = Math.min(Mth.lerp(0.1f, zDiameter, diameter), 24.5f);

          double a0 = Math.random();
          int count = (int)(diameter * Math.PI / 4d);

          int lowestY = centerBottom.getY();

          BoundingBox safetyBounds = chunkBB.inflatedBy(16);

          for (int i = 0; i < count; i++) {
            double a = ((double)i + Math.random() * 0.25 + a0) / count * 2d * Math.PI;
            double dr = Math.random();

            int dx = (int)(Math.cos(a) * (xDiameter / 2.2d + dr));
            int dz = (int)(Math.sin(a) * (zDiameter / 2.2d + dr));
            int x = centerBottom.getX() + dx;
            int z = centerBottom.getZ() + dz;

            BlockPos toothPos = new BlockPos(
                Math.clamp(x, safetyBounds.minX(), safetyBounds.maxX()),
                centerBottom.getY(),
                Math.clamp(z, safetyBounds.minZ(), safetyBounds.maxZ())
            );

            int j = 0;
            while (level.getBlockState(toothPos).canBeReplaced() && j++ < 6) toothPos = toothPos.below();
            level.setBlock(toothPos.above(), Blocks.BONE_BLOCK.defaultBlockState(), 2);
            level.setBlock(toothPos, Blocks.BONE_BLOCK.defaultBlockState(), 2);
            if (j >= 7) {
              while (level.getBlockState(toothPos).canBeReplaced()) {
                toothPos = toothPos.below();
                level.setBlock(toothPos, Blocks.BONE_BLOCK.defaultBlockState(), 2);
              }
            }
            if (toothPos.getY() < lowestY) lowestY = toothPos.getY();
          }

          double xr = xDiameter / 2.2d;
          double zr = zDiameter / 2.2d;
          BlockPos c = centerBottom.atY(lowestY - 5);
          long cl = c.asLong();

          List<StructureTemplate.StructureBlockInfo> chestInfo = this.template.filterBlocks(this.templatePosition, this.placeSettings, Blocks.CHEST);

          long[] chestNodes = chestInfo.stream().map(StructureTemplate.StructureBlockInfo::pos).mapToLong(BlockPos::asLong).toArray();

          chestInfo.stream()
              .map(info -> level.getBlockEntity(info.pos(), BlockEntityTypes.CHEST))
              .filter(Optional::isPresent)
              .map(Optional::get)
              .forEach(chest -> {

                CompoundTag customTag = new CompoundTag();
                customTag.putBoolean("sea_monster_bait", true);
                customTag.putLongArray("sea_monster_chests", chestNodes);
                customTag.putLong("sea_monster_position", cl);
                customTag.putDouble("sea_monster_rx", xr);
                customTag.putDouble("sea_monster_rz", zr);

                ItemStack itemstack = new ItemStack(Items.PRISMARINE_CRYSTALS, 1);
                itemstack.applyComponents(DataComponentPatch.builder().set(DataComponents.CUSTOM_DATA, CustomData.of(customTag)).build());

                int slot = (int)(Math.random() * chest.getContainerSize());
                chest.setItem(slot, itemstack);
              });

        }
      }
    }
  }

}
