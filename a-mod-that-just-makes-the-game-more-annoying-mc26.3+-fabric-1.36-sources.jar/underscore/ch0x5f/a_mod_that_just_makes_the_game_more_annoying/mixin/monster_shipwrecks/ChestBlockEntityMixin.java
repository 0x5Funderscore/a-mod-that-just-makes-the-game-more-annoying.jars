package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.monster_shipwrecks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ContainerUser;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Optional;


@Mixin(ChestBlockEntity.class)
public abstract class ChestBlockEntityMixin extends RandomizableContainerBlockEntity {

  @Shadow
  private NonNullList<ItemStack> items;

  protected ChestBlockEntityMixin(BlockEntityType<?> type, BlockPos worldPosition, BlockState blockState) {
    super(type, worldPosition, blockState);
  }

  @Inject(method = "startOpen", at = @At("TAIL"))
  private void afterStartOpen(ContainerUser containerUser, CallbackInfo ci) {
    if (Config.MONSTER_SHIPWRECKS.get() && this.level != null) {
      this.items.forEach(stack -> {
        CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
        if (customData != null) {
          CompoundTag dataTag = customData.copyTag();
          if (dataTag.getBooleanOr("sea_monster_bait", false)) {

            Optional<Long> centerNode = dataTag.getLong("sea_monster_position");
            long[] otherChests = dataTag.getLongArray("sea_monster_chests").orElseGet(() -> new long[0]);
            double rx = dataTag.getDoubleOr("sea_monster_rx", 0.0d);
            double rz = dataTag.getDoubleOr("sea_monster_rz", 0.0d);

            stack.remove(DataComponents.CUSTOM_DATA);
//            customData.update(compoundTag -> {
//              compoundTag.remove("sea_monster_bait");
//              compoundTag.remove("sea_monster_chests");
//              compoundTag.remove("sea_monster_position");
//              compoundTag.remove("sea_monster_rx");
//              compoundTag.remove("sea_monster_rz");
//            });

            if (centerNode.isPresent()) {
              BlockPos center = BlockPos.of(centerNode.get());

              for (long otherChestNode: otherChests) {
                BlockPos pos = BlockPos.of(otherChestNode);
                if (!pos.equals(this.worldPosition)) {
                  this.level.setBlockAndUpdate(pos, this.level.getBlockState(pos).getFluidState().createLegacyBlock());
                }
              }

              this.level.playSound(null, center, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 2.0f, 0.3f);

              for (int dx = -Mth.ceil(rx); dx <= Mth.floor(rx); dx++) {
                for (int dz = -Mth.ceil(rz); dz <= Mth.floor(rz); dz++) {
                  if (Math.hypot(dx / rx, dz / rz) <= 1.0d) {

                    BlockPos p = center.offset(dx, 0, dz);
                    boolean magma = true;
                    BlockState blockState;

                    while (p.getY() <= 62) {
                      blockState = this.level.getBlockState(p);
                      if (!p.equals(this.worldPosition)) {
                        if (!blockState.canBeReplaced() && !blockState.is(Blocks.BONE_BLOCK) || magma) {
                          if (!(blockState.is(Blocks.WATER) && magma) && blockState.getBlock().getExplosionResistance() > 6.0f) break;
                          if (magma) {
                            this.level.setBlockAndUpdate(p, Blocks.MAGMA_BLOCK.defaultBlockState());
                          } else {
                            if (blockState.is(BlockTags.BASE_STONE_OVERWORLD)) {
                              this.level.setBlockAndUpdate(p, Blocks.WATER.defaultBlockState());
                            } else {
                              FallingBlockEntity.fall(this.level, p, blockState);
                              if (this.level.getBlockState(p).isAir()) this.level.setBlockAndUpdate(p, Blocks.WATER.defaultBlockState());
                            }
                          }
                        }
                      }
                      p = p.above();
                      magma = false;
                    }

                  }
                }
              }

            }
          }
        }
      });
    }
  }

}
