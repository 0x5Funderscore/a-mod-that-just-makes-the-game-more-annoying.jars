package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.elytra_generates_broken;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.structure.structures.EndCityPieces;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EndCityPieces.EndCityPiece.class)
public abstract class EndCityPieces$EndCityPieceMixin {

  @Definition(id = "ELYTRA", field = "Lnet/minecraft/world/item/Items;ELYTRA:Lnet/minecraft/world/item/Item;")
  @Definition(id = "ItemStack", type = ItemStack.class)
  @Expression("new ItemStack(ELYTRA)")
  @ModifyExpressionValue(method = "handleDataMarker", at = @At("MIXINEXTRAS:EXPRESSION"))
  private ItemStack modifyElytraItemStack(ItemStack original) {
    if (Config.ELYTRA_GENERATES_BROKEN.get()) {
      original.set(DataComponents.DAMAGE, original.getMaxDamage());
    }
    return original;
  }

}
