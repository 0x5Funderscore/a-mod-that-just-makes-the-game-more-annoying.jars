package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.poisonous_spruce_smoke;

import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {
}
