package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.where_is_village;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.players.NameAndId;
import net.minecraft.server.players.PlayerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.VillageFinder;

import java.util.Optional;


@Mixin(PlayerList.class)
public abstract class PlayerListMixin {

  @Shadow
  public abstract Optional<CompoundTag> loadPlayerData(NameAndId nameAndId);

  @Unique
  private boolean rb$sendVillage = false;

  @Inject(method = "placeNewPlayer", at = @At("HEAD"))
  private void beforePlaceNewPlayer(Connection connection, ServerPlayer player, CommonListenerCookie cookie, CallbackInfo ci) {
    this.rb$sendVillage = Config.WHERE_IS_VILLAGE.get() && this.loadPlayerData(player.nameAndId()).isEmpty();
  }

  @Inject(method = "placeNewPlayer", at = @At("TAIL"))
  private void afterPlaceNewPlayer(Connection connection, ServerPlayer player, CommonListenerCookie cookie, CallbackInfo ci) {
    if (Config.WHERE_IS_VILLAGE.get() && this.rb$sendVillage) {
      VillageFinder.findAndSendVillage(player, player.level(), player.position());
    }
  }

}
