package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.where_is_village;

import net.minecraft.core.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.portal.TeleportTransition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.VillageFinder;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin {

  @Inject(method = "findRespawnPositionAndUseSpawnBlock", at = @At("TAIL"))
  private void respawnDefault(boolean consumeSpawnBlock, TeleportTransition.PostTeleportTransition postTeleportTransition, CallbackInfoReturnable<TeleportTransition> cir) {
    TeleportTransition teleportTransition = cir.getReturnValue();
    if (Config.WHERE_IS_VILLAGE.get()) {
      VillageFinder.findAndSendVillage((ServerPlayer)(Object)this, teleportTransition.newLevel(), teleportTransition.position());
    }
  }

  @Inject(method = "findRespawnPositionAndUseSpawnBlock", at = @At("RETURN"))
  private void respawnMissing(boolean consumeSpawnBlock, TeleportTransition.PostTeleportTransition postTeleportTransition, CallbackInfoReturnable<TeleportTransition> cir) {
    TeleportTransition teleportTransition = cir.getReturnValue();
    if (Config.WHERE_IS_VILLAGE.get() && teleportTransition.missingRespawnBlock()) {
      VillageFinder.findAndSendVillage((ServerPlayer)(Object)this, teleportTransition.newLevel(), teleportTransition.position());
    }
  }

}
