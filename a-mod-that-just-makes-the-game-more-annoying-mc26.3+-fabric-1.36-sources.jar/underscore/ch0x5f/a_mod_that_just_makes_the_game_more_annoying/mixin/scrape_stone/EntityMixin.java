package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.scrape_stone;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Entity.class)
public abstract class EntityMixin {

  @Shadow
  public abstract Level level();

  @Shadow
  public abstract void playSound(SoundEvent sound, float volume, float pitch);

  @Inject(method = "playStepSound", at = @At(value = "TAIL"))
  private void afterPlaySound(
      BlockPos pos,
      BlockState blockState,
      CallbackInfo ci,
      @Local(name = "soundType") SoundType soundType
  ) {
    if (Config.SCRAPE_STONE.get()) {
      if ((Entity)(Object)this instanceof Player player) {
        if (!player.getItemBySlot(EquipmentSlot.FEET).is(Items.LEATHER_BOOTS)) {
          if (soundType == SoundType.STONE) {
            this.playSound(SoundEvents.GRINDSTONE_USE, 1.0f, soundType.getPitch());
          }
        }
      }
    }
  }

}

