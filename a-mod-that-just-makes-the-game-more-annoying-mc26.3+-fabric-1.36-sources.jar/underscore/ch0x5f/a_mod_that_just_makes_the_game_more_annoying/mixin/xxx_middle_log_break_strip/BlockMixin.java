package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_middle_log_break_strip;

import net.minecraft.world.level.block.Block;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(Block.class)
public abstract class BlockMixin {

  /*

  @Shadow
  @Final
  private static Logger LOGGER;

  @WrapOperation(method = "playerDestroy", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;dropResources(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)V"))
  private void wrapDropResources(BlockState state, Level level, BlockPos pos, BlockEntity blockEntity, Entity breaker, ItemStack tool, Operation<Void> original) {
    if (Config.MIDDLE_LOG_BREAK_STRIP.get() && !level.isClientSide() && level.isLoaded(pos.above()) && breaker instanceof ServerPlayer serverPlayer) {

      BlockTransformer.BlockTransformData strippables = BlockTransformers.axeStrippables();

      if (state.getValueOrElse(RotatedPillarBlock.AXIS, Direction.Axis.X) == Direction.Axis.Y) {
        LOGGER.info("strip: 1");
        BlockState stripsInto = strippables.blockStateProvider().value().getOptionalState(level, level.getRandom(), pos);
        if (stripsInto != null) {
          LOGGER.info("strip: 2 {}", stripsInto);

          BlockState aboveState = level.getBlockState(pos.above());
          if (aboveState.getValueOrElse(RotatedPillarBlock.AXIS, Direction.Axis.X) == Direction.Axis.Y) {
            LOGGER.info("strip: 3");
            @Nullable BlockState aboveStripsInto = strippables.blockStateProvider().value().getOptionalState(level, level.getRandom(), pos.above());

            if (aboveStripsInto != null && stripsInto.is(aboveStripsInto.getBlock())) {
              LOGGER.info("strip: 4 {}", aboveStripsInto);
              level.registryAccess()
                  .lookupOrThrow(Registries.BLOCK_TRANSFORMER)
                  .getValueOrThrow(BlockTransformers.AXE)
                  .transformBlock(new UseOnContext(
                      serverPlayer,
                      InteractionHand.MAIN_HAND,
                      new BlockHitResult(Vec3.atCenterOf(pos), serverPlayer.getDirection(), pos, true, false)
                  ));
              return;
            }
          }

        }
      }

    }
    original.call(state, level, pos, blockEntity, breaker, tool);
  }

  */

}
