package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.insufficient_bubble_columns;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity {
  public LivingEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Definition(id = "is", method = "Lnet/minecraft/world/level/block/state/BlockState;is(Ljava/lang/Object;)Z")
  @Definition(id = "BUBBLE_COLUMN", field = "Lnet/minecraft/world/level/block/Blocks;BUBBLE_COLUMN:Lnet/minecraft/world/level/block/Block;")
  @Expression("?.is(BUBBLE_COLUMN)")
  @ModifyExpressionValue(method = "baseTick", at = @At("MIXINEXTRAS:EXPRESSION"))
  private boolean modifyIsBubbleColumn(boolean original) {
    if (original && Config.INSUFFICIENT_BUBBLE_COLUMNS.get()) {
      if ((Entity)this instanceof ServerPlayer) {
        return this.tickCount % 5 == 0 || this.getAirSupply() < 4;
      }
    }
    return original;
  }

}
