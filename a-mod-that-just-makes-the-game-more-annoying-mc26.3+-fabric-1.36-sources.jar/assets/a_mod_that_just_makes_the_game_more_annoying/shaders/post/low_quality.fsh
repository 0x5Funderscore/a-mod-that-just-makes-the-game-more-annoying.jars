#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

void main() {
    int height = 240;
    int width = int(InSize.x / InSize.y * height);

    vec2 size = vec2(width, height);

    vec2 videoPixel = floor(texCoord * size);
    vec2 tile = videoPixel / 16.0;
    vec2 fTile = fract(tile);

    vec2 uvFloor = (floor(tile) + 0.25) * 16.0 / size;
    vec2 uvCeil = (ceil(tile) - 0.25) * 16.0 / size;

    vec4 c00 = round(texture(InSampler, vec2(uvFloor.x, uvFloor.y)) * 8.0) / 8.0;
    vec4 c01 = round(texture(InSampler, vec2(uvFloor.x, uvCeil.y)) * 8.0) / 8.0;
    vec4 c10 = round(texture(InSampler, vec2(uvCeil.x, uvFloor.y)) * 8.0) / 8.0;
    vec4 c11 = round(texture(InSampler, vec2(uvCeil.x, uvCeil.y)) * 8.0) / 8.0;
    fragColor = mix(mix(c00, c01, fTile.y), mix(c10, c11, fTile.y), fTile.x);
}
