package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.popup_ads;

import it.unimi.dsi.fastutil.ints.IntList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Blocks;
import org.apache.commons.lang3.RandomUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.popup_ads.PopupAd;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


@Mixin(Hud.class)
@Environment(EnvType.CLIENT)
public abstract class HudMixin {

  @Shadow
  @Final
  private Minecraft minecraft;

  @Unique
  private List<PopupAd> rb$ads;

  @Unique
  private static final List<PopupAd> rb$adPool = List.of(
      PopupAd.template(
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/sleep_bottom.png"),
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/sleep_top.png"),
          160, 120
      ),
      PopupAd.template(
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/mine_bottom.png"),
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/mine_top.png"),
          150, 100
      ),
      PopupAd.template(
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/moviesfree_bottom.png"),
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/moviesfree_top.png"),
          200, 64
      ),
      PopupAd.template(
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/horse_bottom.png"),
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/horse_top.png"),
          166, 141
      ),
      PopupAd.template(
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/call_bottom.png"),
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/call_top.png"),
          128, 128
      )
  );

  @Unique
  private float rb$timer = 0.0f;

  @Unique
  private long rb$randomSeed = 0L;

  @Inject(method = "extractRenderState", at = @At("TAIL"))
  private void postExtractRenderState(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker, CallbackInfo ci) {
    if (this.rb$ads == null) this.rb$ads = new ArrayList<>();

    if (Config.POPUP_ADS.get() && this.minecraft.gameMode != null && this.minecraft.gameMode.canHurtPlayer()) {

      float dt = deltaTracker.getRealtimeDeltaTicks();

      if (this.minecraft.getSingleplayerServer() instanceof IntegratedServer integratedServer) {
        float tickrate = integratedServer.tickRateManager().tickrate();
        if (tickrate > 20f) dt *= tickrate / 20f;
      }

      if (!this.minecraft.isPaused()) {
        this.rb$timer += dt;
        if (this.rb$timer > 5f) {
          this.rb$timer %= 5f;
          this.rb$randomSeed += 5L;
          if (Math.random() < (this.rb$ads.isEmpty() ? 0.0005 : 0.125)) {
            this.rb$ads.add(rb$adPool.get((int)(Math.random() * rb$adPool.size())).randomize());
            if (this.rb$ads.size() >= 5) {
              this.rb$timer -= 120f;
              this.rb$randomSeed += 120L;
            }
          }
        }
      }

      long seed = this.rb$randomSeed + (long)Math.floor(this.rb$timer);

      MultiPlayerGameMode gameMode = this.minecraft.gameMode;
      boolean destroying = gameMode == null || gameMode.isDestroying();
      float destroySpeed = minecraft.player == null ? 1.0f : minecraft.player.getDestroySpeed(Blocks.AIR.defaultBlockState());

      for (int i = 0; i < this.rb$ads.size(); i++) {
        PopupAd ad = this.rb$ads.get(i);
        if (destroying) ad.destroyProgress += dt / 100f * destroySpeed;
        if (ad.shouldRemove()) {
          this.rb$ads.remove(i--);
        } else {
          ad.render(graphics, dt, seed);
        }
      }
    } else {
      this.rb$randomSeed++;
      this.rb$ads.clear();
    }
  }

}
