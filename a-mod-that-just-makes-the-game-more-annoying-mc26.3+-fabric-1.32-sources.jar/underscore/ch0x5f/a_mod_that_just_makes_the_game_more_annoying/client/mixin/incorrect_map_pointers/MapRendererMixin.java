package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.incorrect_map_pointers;

import net.fabricmc.api.EnvType;import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.MapRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(MapRenderer.class)
@Environment(EnvType.CLIENT)
public class MapRendererMixin {

  @ModifyArg(method = "render", index = 1, at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;rotateDegrees(Lcom/mojang/math/Axis;F)V"))
  private float modifyRotateAngle(float angle) {
    if (Config.ROTATED_MAP_ICONS.get()) {
      return -angle;
    }
    return angle;
  }

}
