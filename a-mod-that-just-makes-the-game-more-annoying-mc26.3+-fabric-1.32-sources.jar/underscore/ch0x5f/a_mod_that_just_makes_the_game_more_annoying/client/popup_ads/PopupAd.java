package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.popup_ads;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;


public final class PopupAd {
  public final Identifier textureBottom;
  public final Identifier textureTop;
  public final float cx;
  public final float cy;
  public final int width;
  public final int height;
  public float destroyProgress;
  private float removeTime = 0.0f;

  public PopupAd(
      Identifier textureBottom,
      Identifier textureTop,
      float cx,
      float cy,
      int width,
      int height
  ) {
    this.textureBottom = textureBottom;
    this.textureTop = textureTop;
    this.cx = cx;
    this.cy = cy;
    this.width = width;
    this.height = height;
  }

  public static PopupAd template(Identifier bottom, Identifier top, int width, int height) {
    return new PopupAd(bottom, top, 0f, 0f, width, height);
  }

  public PopupAd randomize() {
    return new PopupAd(
        this.textureBottom,
        this.textureTop,
        (float)Math.random(),
        (float)Math.random(),
        this.width,
        this.height
    );
  }

  public boolean shouldRemove() {
    return this.removeTime >= 1.0f;
  }

  private int intStuff(double a) {
    if (a < -1.0) return -1;
    else if (a > 1.0) return 1;
    else return 0;
  }

  public void render(GuiGraphicsExtractor graphics, float deltaTime, long seed) {
    float scale = 1.0f;
    if (this.destroyProgress >= 1.0f) {
      this.removeTime += deltaTime / 10.0f;
      scale = Math.clamp((float)Math.pow(1.0f - this.removeTime, 3.0), 0.0f, 1.0f);
    }

    int w = (int)(this.width * scale);
    int h = (int)(this.height * scale);

    if (w > 0 && h > 0) {

      int scx = (int)(graphics.guiWidth() * this.cx);
      int scy = (int)(graphics.guiHeight() * this.cy);
      int x0 = scx - w / 2;
      int y0 = scy - h / 2;
      graphics.blit(RenderPipelines.GUI_TEXTURED, this.textureBottom, x0, y0, 0, 0, w, h, w, h);

      RandomSource randomSource = RandomSource.create(seed);
      int tx = intStuff(randomSource.nextGaussian());
      int ty = intStuff(randomSource.nextGaussian());
      graphics.blit(RenderPipelines.GUI_TEXTURED, this.textureTop, x0 + tx, y0 + ty, 0, 0, w, h, w, h);

      int destroyTexture = Math.min((int)(this.destroyProgress * 11f) - 1, 9);
      if (destroyTexture >= 0) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, Identifier.withDefaultNamespace("textures/block/destroy_stage_" + destroyTexture + ".png"), x0, y0, -x0, -y0, w, h, 16, 16);
      }
    }
  }

}
