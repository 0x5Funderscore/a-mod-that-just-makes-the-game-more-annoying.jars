package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.disable_item_grouping;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.item.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ItemEntity.class)
public class ItemEntityMixin {

  @ModifyReturnValue(method = "isMergable", at = @At("TAIL"))
  private boolean modifyMergable(boolean original) {
    if (Config.DISABLE_ITEM_GROUPING.get()) {
      return false;
    }
    return original;
  }

}
