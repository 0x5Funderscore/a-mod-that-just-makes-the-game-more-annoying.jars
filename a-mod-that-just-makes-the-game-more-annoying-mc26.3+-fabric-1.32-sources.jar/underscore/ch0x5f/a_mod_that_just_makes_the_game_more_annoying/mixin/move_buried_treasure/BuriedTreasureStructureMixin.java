package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.move_buried_treasure;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.levelgen.structure.structures.BuriedTreasureStructure;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BuriedTreasureStructure.class)
public class BuriedTreasureStructureMixin {

  @Definition(id = "BlockPos", type = BlockPos.class)
  @Expression("new BlockPos(?, ?, ?)")
  @ModifyExpressionValue(method = "generatePieces", at = @At("MIXINEXTRAS:EXPRESSION"))
  private static BlockPos modifyBlockPos(BlockPos original) {
    if (Config.MOVE_BURIED_TREASURE.get()) {
      return original.offset(-5, 0, -5);
    }
    return original;
  }

}
