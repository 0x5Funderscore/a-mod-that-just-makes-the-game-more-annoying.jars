package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.trapped_buried_treasure;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.structures.BuriedTreasurePieces;
import net.minecraft.world.level.storage.loot.LootTable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import static net.minecraft.world.level.levelgen.structure.StructurePiece.reorient;


@Mixin(BuriedTreasurePieces.BuriedTreasurePiece.class)
public class BuriedTreasurePieces$BuriedTreasurePieceMixin {

  @WrapOperation(method = "postProcess", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/levelgen/structure/structures/BuriedTreasurePieces$BuriedTreasurePiece;createChest(Lnet/minecraft/world/level/ServerLevelAccessor;Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/util/RandomSource;Lnet/minecraft/core/BlockPos;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/world/level/block/state/BlockState;)Z"))
  private boolean wrapCreateChest(BuriedTreasurePieces.BuriedTreasurePiece instance, ServerLevelAccessor level, BoundingBox chunkBB, RandomSource random, BlockPos pos, ResourceKey<LootTable> lootTable, BlockState blockState, Operation<Boolean> original) {
    if (Config.TRAPPED_BURIED_TREASURE.get()) {
      if (chunkBB.isInside(pos) && !level.getBlockState(pos).is(Blocks.CHEST)) {
        if (blockState == null) {
          blockState = reorient(level, pos, Blocks.TRAPPED_CHEST.defaultBlockState());
        }

        level.setBlock(pos, blockState, 2);
        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (blockEntity instanceof ChestBlockEntity chestBlockEntity) {
          chestBlockEntity.setLootTable(lootTable, random.nextLong());
        }

        BlockPos c = pos.below(2);
        level.setBlock(c, Blocks.TNT.defaultBlockState(), 2);
        level.setBlock(c.offset(-1, 0, 0), Blocks.TNT.defaultBlockState(), 2);
        level.setBlock(c.offset(+1, 0, 0), Blocks.TNT.defaultBlockState(), 2);
        level.setBlock(c.offset(0, 0, -1), Blocks.TNT.defaultBlockState(), 2);
        level.setBlock(c.offset(0, 0, +1), Blocks.TNT.defaultBlockState(), 2);

        return true;
      } else {
        return false;
      }
    }
    return original.call(instance, level, chunkBB, random, pos, lootTable, blockState);
  }

}
