package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.zzz_mob_ai_natural_selection;

import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(MeleeAttackGoal.class)
public abstract class MeleeAttackGoalMixin {

  /*
  @Shadow
  @Final
  protected PathfinderMob mob;

  @Definition(id = "ticksUntilNextPathRecalculation", field = "Lnet/minecraft/world/entity/ai/goal/MeleeAttackGoal;ticksUntilNextPathRecalculation:I")
  @Expression("this.ticksUntilNextPathRecalculation <= 0")
  @ModifyExpressionValue(method = "tick", at = @At(value = "MIXINEXTRAS:EXPRESSION", ordinal = 0))
  private boolean modifyPathUpdateCondition(
      boolean original,
      @Local(name = "target") LivingEntity target
  ) {
    if (Config.MOB_AI_NATURAL_SELECTION.get()) {
    }
    return original;
  }
  */

}
