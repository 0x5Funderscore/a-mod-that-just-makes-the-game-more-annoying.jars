package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.kicking_cows;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.cow.AbstractCow;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractCow.class)
public abstract class AbstractCowMixin extends Animal {

  protected AbstractCowMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "createAttributes", at = @At("TAIL"))
  private static void modifyCreatedAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (Config.KICKING_COWS.get())
      cir.getReturnValue()
          .add(Attributes.ATTACK_DAMAGE, 4.0)
          .add(Attributes.ATTACK_KNOCKBACK, 6.0);
  }

  @Definition(id = "goalSelector", field = "Lnet/minecraft/world/entity/animal/cow/AbstractCow;goalSelector:Lnet/minecraft/world/entity/ai/goal/GoalSelector;")
  @Definition(id = "addGoal", method = "Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V")
  @Definition(id = "PanicGoal", type = PanicGoal.class)
  @Expression("this.goalSelector.addGoal(?, new PanicGoal(?, ?))")
  @WrapOperation(method = "registerGoals", at = @At("MIXINEXTRAS:EXPRESSION"))
  private void wrapAddGoal(GoalSelector instance, int prio, Goal goal, Operation<Void> original) {
    if (Config.KICKING_COWS.get()) {

      AbstractCow mob = (AbstractCow)(Object)this;

      original.call(instance, prio, new MeleeAttackGoal(mob, 2.0d, false));

      this.targetSelector.addGoal(0, new HurtByTargetGoal(mob) {
        @Override
        public boolean canContinueToUse() {
          return this.mob.getLastHurtMobTimestamp() < this.mob.getLastHurtByMobTimestamp();
        }
      });

      return;
    }
    original.call(instance, prio, goal);
  }

}
