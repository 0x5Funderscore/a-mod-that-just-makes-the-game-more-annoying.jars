package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.you_block_origin;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.consume_effects.ConsumeEffect;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BlockBehaviour.class)
public abstract class BlockBehaviourMixin {

  @Inject(method = "useItemOn", at = @At("HEAD"), cancellable = true)
  private void preUseItemOn(ItemStack itemStack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult, CallbackInfoReturnable<InteractionResult> cir) {
    if (Config.YOU_BLOCK_ORIGIN.get()) {

      if (itemStack.is(Items.GLOWSTONE_DUST)) {

        if (!player.hasInfiniteMaterials()) {
          itemStack.shrink(1);
        }

        ItemStack adBlockerItemStack = new ItemStack(Items.GLOBE_BANNER_PATTERN);
        adBlockerItemStack.remove(DataComponents.PROVIDES_BANNER_PATTERNS);

        CompoundTag customDataTag = new CompoundTag();
        customDataTag.putBoolean("you_block_origin", true);

        adBlockerItemStack.applyComponents(DataComponentPatch.builder()
                .set(DataComponents.CUSTOM_DATA, CustomData.of(customDataTag))
                .set(DataComponents.ITEM_MODEL, Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "you_block_origin"))
                .set(DataComponents.ITEM_NAME, Component.literal("You Block Origin"))
            .build()
        );

        Block.popResource(level, pos, adBlockerItemStack);

        level.destroyBlock(pos, false);

        cir.setReturnValue(InteractionResult.SUCCESS);
        cir.cancel();
      }

    }
  }

}
