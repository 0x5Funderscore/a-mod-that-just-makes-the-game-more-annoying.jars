package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.infinite_snow_accumulation;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.storage.WritableLevelData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerLevel.class)
public abstract class ServerLevelMixin extends Level {

  protected ServerLevelMixin(WritableLevelData levelData, ResourceKey<Level> dimension, RegistryAccess registryAccess, Holder<DimensionType> dimensionTypeRegistration, boolean isClientSide, boolean isDebug, long biomeZoomSeed, int maxChainedNeighborUpdates) {
    super(levelData, dimension, registryAccess, dimensionTypeRegistration, isClientSide, isDebug, biomeZoomSeed, maxChainedNeighborUpdates);
  }

  @Definition(id = "getBlockState", method = "Lnet/minecraft/server/level/ServerLevel;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;")
  @Definition(id = "topPos", local = @Local(type = BlockPos.class, name = "topPos"))
  @Expression("this.getBlockState(topPos)")
  @ModifyExpressionValue(method = "tickPrecipitation", at = @At("MIXINEXTRAS:EXPRESSION"))
  private BlockState modifyBlockState(
      BlockState original,
      @Local(name = "topPos") LocalRef<BlockPos> topPos
  ) {
    if (Config.INFINITE_SNOW_ACCUMULATION.get()) {

      if (original.is(Blocks.SNOW) && original.getValue(SnowLayerBlock.LAYERS) == 8) {

        BlockPos newTop = topPos.get();
        BlockState state;

        boolean up;
        do {
          newTop = newTop.above();
          state = this.getBlockState(newTop);
          up = state.is(Blocks.SNOW) && state.getValue(SnowLayerBlock.LAYERS) == 8;
        } while (up);

        topPos.set(newTop);

        return state;
      }
    }
    return original;
  }

  @Definition(id = "min", method = "Ljava/lang/Math;min(II)I")
  @Definition(id = "maxHeight", local = @Local(type = int.class, name = "maxHeight"))
  @Expression("min(maxHeight, 8)")
  @ModifyExpressionValue(method = "tickPrecipitation", at = @At("MIXINEXTRAS:EXPRESSION"))
  private int modifyMin(int original) {
    if (Config.INFINITE_SNOW_ACCUMULATION.get()) {
      return 8;
    }
    return original;
  }

}
