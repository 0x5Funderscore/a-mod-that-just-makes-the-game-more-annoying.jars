package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.frogs_eat_players;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.frog.Frog;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Frog.class)
public abstract class FrogMixin {

  @ModifyReturnValue(method = "canEat", at = @At("TAIL"))
  private static boolean modifyCanEat(
      boolean original,
      @Local(name = "entity", argsOnly = true) LivingEntity entity
  ) {
    if (Config.FROGS_EAT_PLAYERS.get()) {
      if (entity instanceof Player) return true;
    }
    return original;
  }

}
