package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.trident_snipers;

import net.minecraft.world.entity.monster.zombie.Drowned;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Drowned.class)
public abstract class DrownedMixin {

  @ModifyArg(
      method = "addBehaviourGoals",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/entity/monster/zombie/Drowned$DrownedTridentAttackGoal;<init>(Lnet/minecraft/world/entity/monster/RangedAttackMob;DIF)V"
      ),
      index = 3
  )
  private float modifyAttackRadius(float attackRadius) {
    if (Config.TRIDENT_MINIGUNS.get()) return 100.0f;
    return attackRadius;
  }

}
