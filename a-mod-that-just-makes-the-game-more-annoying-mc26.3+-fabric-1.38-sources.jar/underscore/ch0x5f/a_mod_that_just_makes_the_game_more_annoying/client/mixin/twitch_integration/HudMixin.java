package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.twitch_integration;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.GuiUtils;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing.ClientFishing;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.twitch_integration.TwitchIntegrationClient;


@Mixin(Hud.class)
@Environment(EnvType.CLIENT)
public abstract class HudMixin {

  @Shadow
  public abstract Font getFont();

  @Inject(method = "extractRenderState", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Hud;extractChat(Lnet/minecraft/client/gui/GuiGraphicsExtractor;Lnet/minecraft/client/DeltaTracker;)V"))
  private void afterExtractChat(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker, CallbackInfo ci) {
    if (TwitchIntegrationClient.currentEffect != null) {
      boolean instantEffect = TwitchIntegrationClient.instantEffect;
      graphics.text(this.getFont(), Component.literal(TwitchIntegrationClient.currentEffect).withStyle(instantEffect ? ChatFormatting.GRAY : ChatFormatting.LIGHT_PURPLE), 8, 4, -1, !instantEffect);
    }

    if (TwitchIntegrationClient.maxTime > 0) {
      if (!Minecraft.getInstance().isPaused() || Minecraft.getInstance().isMultiplayerServer()) TwitchIntegrationClient.timeLeft -= deltaTracker.getGameTimeDeltaTicks();
      graphics.blit(RenderPipelines.GUI_TEXTURED, TwitchIntegrationClient.TIME_BAR_BACKGROUND, 4, 24, 0, 0, 64, 4, 64, 4);
      float progress = Math.clamp(1.0f - (TwitchIntegrationClient.timeLeft / TwitchIntegrationClient.maxTime), 0.0f, 1.0f);
      if (progress > 0.0f) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, TwitchIntegrationClient.TIME_BAR_FILL, 4, 24, 0, 0, (int)(64 * progress), 4, 64, 4);
      }
    }

    for (int i = 0; i < TwitchIntegrationClient.chaosNames.length; i++) {
      int y = 32 + i * 20;
      boolean win = TwitchIntegrationClient.highlightOption == i;

      int color = win ? TextColor.GREEN.getValue() : TextColor.WHITE.getValue();
      graphics.text(this.getFont(), Component.literal((i + 1) + ". " + TwitchIntegrationClient.chaosNames[i]), 4, y, color | 0xff000000, true);

      int progressY = y + 10;
      graphics.blit(RenderPipelines.GUI_TEXTURED, TwitchIntegrationClient.VOTE_BAR_BACKGROUND, 4, progressY, 0, 0, 64, 4, 64, 4);
      float progress = (float)TwitchIntegrationClient.chaosFractions[i];
      if (progress > 0.0f) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, win ? TwitchIntegrationClient.VOTE_BAR_FILL_WIN : TwitchIntegrationClient.VOTE_BAR_FILL, 4, progressY, 0, 0, (int)(64 * progress), 4, 64, 4);
      }
    }
  }

}
