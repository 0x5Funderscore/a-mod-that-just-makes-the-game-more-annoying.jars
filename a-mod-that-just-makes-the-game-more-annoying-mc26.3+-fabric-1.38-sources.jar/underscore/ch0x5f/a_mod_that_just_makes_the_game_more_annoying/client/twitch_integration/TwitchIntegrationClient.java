package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.twitch_integration;

import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;


public class TwitchIntegrationClient {

  public static @Nullable String currentEffect = null;
  public static boolean instantEffect = false;
  public static String[] chaosNames = new String[0];
  public static double[] chaosFractions = new double[0];
  public static int highlightOption = -1;

  public static int maxTime = 0;
  public static float timeLeft = 0.0f;

  public static final Identifier VOTE_BAR_BACKGROUND = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/gui/twitch_integration/vote_bg.png");
  public static final Identifier VOTE_BAR_FILL = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/gui/twitch_integration/vote_fg.png");
  public static final Identifier VOTE_BAR_FILL_WIN = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/gui/twitch_integration/vote_fg_win.png");

  public static final Identifier TIME_BAR_BACKGROUND = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/gui/twitch_integration/time_bg.png");
  public static final Identifier TIME_BAR_FILL = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/gui/twitch_integration/time_fg.png");

  public static void reset() {
    currentEffect = null;
    instantEffect = false;
    chaosNames = new String[0];
    chaosFractions = new double[0];
    highlightOption = -1;
    maxTime = 0;
    timeLeft = 0.0f;
  }

}
