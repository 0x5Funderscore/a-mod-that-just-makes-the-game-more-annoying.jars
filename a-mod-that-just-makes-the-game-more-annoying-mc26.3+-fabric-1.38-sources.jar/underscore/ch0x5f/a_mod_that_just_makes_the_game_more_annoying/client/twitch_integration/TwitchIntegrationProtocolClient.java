package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.twitch_integration;

import com.mojang.logging.LogUtils;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchIntegrationProtocol;


public class TwitchIntegrationProtocolClient {

  private static void handlePacketStatic(TwitchIntegrationProtocol.TwitchChaosPacket twitchChaosPacket, ClientPlayNetworking.Context context) {
    LogUtils.getLogger().info("recv packet: {}", twitchChaosPacket);

    TwitchIntegrationClient.chaosNames = twitchChaosPacket.names();
    TwitchIntegrationClient.chaosFractions = twitchChaosPacket.fractions();
    TwitchIntegrationClient.highlightOption = twitchChaosPacket.selected();
    TwitchIntegrationClient.currentEffect = twitchChaosPacket.activeEffect();
    TwitchIntegrationClient.instantEffect = twitchChaosPacket.instantEffect();

    if (twitchChaosPacket.timer() == 0) {
      TwitchIntegrationClient.maxTime = 0;
    } else {
      TwitchIntegrationClient.maxTime = Math.max(TwitchIntegrationClient.maxTime, twitchChaosPacket.timer());
    }
    TwitchIntegrationClient.timeLeft = twitchChaosPacket.timer();
  }

  public static void register() {
    ClientPlayConnectionEvents.INIT.register((listener, client) -> ClientPlayNetworking.registerReceiver(TwitchIntegrationProtocol.TYPE, TwitchIntegrationProtocolClient::handlePacketStatic));
  }

}
