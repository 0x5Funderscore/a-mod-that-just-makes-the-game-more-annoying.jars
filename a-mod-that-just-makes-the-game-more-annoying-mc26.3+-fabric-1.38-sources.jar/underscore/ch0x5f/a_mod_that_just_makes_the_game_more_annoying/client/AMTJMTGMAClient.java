package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing.ClientFishing;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.twitch_integration.TwitchIntegrationProtocolClient;


public class AMTJMTGMAClient implements ClientModInitializer {

  @Override
  public void onInitializeClient() {
    AMTJMTGMA.playerUsername = Minecraft.getInstance().getUser().getName();
    ClientFishing.register();
    TwitchIntegrationProtocolClient.register();
  }
}
