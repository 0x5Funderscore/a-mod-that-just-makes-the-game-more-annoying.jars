package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;


import com.mojang.logging.LogUtils;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing.ServerFishing;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchChaosRegistry;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchIntegrationConnector;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchIntegrationProtocol;

import java.io.IOException;


public final class AMTJMTGMA implements ModInitializer {
  public static final String MOD_ID = "a_mod_that_just_makes_the_game_more_annoying";

  public static final String KILL_WHEN_NO_PASSENGER = "kill_when_no_passenger";

  public static final Identifier FOUND_PORTAL_ROOM_ADVANCEMENT = Identifier.fromNamespaceAndPath(MOD_ID, "stronghold_portal_room");

  public static String playerUsername = "";

  @Override
  public void onInitialize() {
    try {
      Config.loadConfig();
    } catch (IOException e) {
      LogUtils.getLogger().error("I/O error while loading AMTJMTGMA config.", e);
    }
    ServerFishing.register();
    TwitchIntegrationProtocol.register();
    TwitchChaosRegistry.bootstrap();
    TwitchIntegrationConnector.INSTANCE.loadChannelName();
    if (Config.TWITCH_INTEGRATION__EXPERIMENTAL.get()) {
      TwitchIntegrationConnector.INSTANCE.attemptConnect();
    }
  }
}
