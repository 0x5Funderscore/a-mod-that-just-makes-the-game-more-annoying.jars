package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_chaos;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchChaosOption;


public class SpleefMode {

  public static final TwitchChaosOption OPTION = new TwitchChaosOption(
      "Spleef Mode",
      server -> {},
      server ->
          server.getAllLevels().forEach(level ->
              level.players().forEach(player -> {
                if (player.onGround()) {
                  BlockPos onPos = player.getOnPos();
                  BlockState state = level.getBlockState(onPos);
                  if (!state.hasBlockEntity() && !state.is(BlockTags.WITHER_IMMUNE) && state.getBlock().getExplosionResistance() <= 9f) {
                    FallingBlockEntity fallingBlockEntity = FallingBlockEntity.fall(level, onPos, state);
                    fallingBlockEntity.setDeltaMovement(0.0d, 0.2d, 0.0d);
                  }
                }
              })
          ),
      server -> {},
      0.25f
  );

}
