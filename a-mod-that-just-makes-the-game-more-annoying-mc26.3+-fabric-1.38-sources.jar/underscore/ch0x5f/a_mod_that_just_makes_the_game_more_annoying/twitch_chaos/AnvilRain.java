package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_chaos;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Util;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchChaosOption;


public class AnvilRain {

  private static final RandomSource randomSource = RandomSource.create(Util.getEpochMillis() ^ -1794269230771965952L);

  private static final Direction[] HORIZONTAL_DIRECTIONS = new Direction[]{
      Direction.NORTH,
      Direction.SOUTH,
      Direction.EAST,
      Direction.WEST,
  };

  public static final TwitchChaosOption OPTION = new TwitchChaosOption(
      "Anvil Rain",
      server -> {},
      server ->
          server.getAllLevels().forEach(level -> {
            if (!level.dimensionType().hasCeiling()) {
              ChunkMap chunkMap = level.getChunkSource().chunkMap;
              chunkMap.forEachBlockTickingChunk(levelChunk -> {
                if (chunkMap.anyPlayerCloseEnoughForSpawning(levelChunk.getPos()) && Math.random() < 0.02) {
                  BlockPos rainFrom = levelChunk.getPos().getBlockAt(randomSource.nextInt(16), level.getMaxY(), randomSource.nextInt(16));
                  BlockState rainState = Blocks.ANVIL.defaultBlockState();
                  rainState.setValue(AnvilBlock.FACING, HORIZONTAL_DIRECTIONS[randomSource.nextInt(HORIZONTAL_DIRECTIONS.length)]);
                  FallingBlockEntity fallingBlock = FallingBlockEntity.fall(level, rainFrom, rainState);
                  fallingBlock.addTag("fall_normally");
                  ((AnvilBlock)Blocks.ANVIL).falling(fallingBlock);
                  fallingBlock.disableDrop();
                }
              });
            }
          }),
      server -> {}
  );

}
