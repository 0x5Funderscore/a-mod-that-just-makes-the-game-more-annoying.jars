package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_chaos;

import com.google.common.collect.ImmutableList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Util;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.SupportType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchChaosOption;

import java.util.ArrayList;
import java.util.List;


public class RainingBlocks {

  private static final RandomSource randomSource = RandomSource.create(Util.getEpochMillis() ^ 1422622409447163398L);

  private static @Nullable BlockState getRainBlockState(ServerLevel level, BlockPos pos) {

    List<Block> blocks = new ArrayList<>(level.registryAccess().lookupOrThrow(Registries.BLOCK).stream().toList());
    Block block = blocks.get(randomSource.nextInt(blocks.size()));

    if (block.asItem() == Items.AIR) return null;
    if (block.getExplosionResistance() > 9f) return null;

    ImmutableList<BlockState> states = block.getStateDefinition().getPossibleStates();
    BlockState state = states.get(randomSource.nextInt(states.size()));
    if (!state.getFluidState().isEmpty()) state = state.trySetValue(BlockStateProperties.WATERLOGGED, false);

    if (state.isAir()) return null;
    if (!state.getFluidState().isEmpty()) return null;
    if (state.hasBlockEntity()) return null;
    if (state.canBeReplaced()) return null;
    VoxelShape collisionShape = state.getCollisionShape(level, pos);
    if (collisionShape.isEmpty()) return null;
    AABB collisionBounds = collisionShape.bounds();
    if (collisionBounds.getXsize() < 0.5d || collisionBounds.getYsize() < 0.5d || collisionBounds.getZsize() < 0.5d) return null;
    if (!state.isFaceSturdy(level, pos, Direction.DOWN, SupportType.RIGID)) return null;

    return state;
  }

  public static final TwitchChaosOption OPTION = new TwitchChaosOption(
      "Raining Blocks",
      server -> {},
      server ->
          server.getAllLevels().forEach(level -> {
            if (!level.dimensionType().hasCeiling()) {
              ChunkMap chunkMap = level.getChunkSource().chunkMap;
              chunkMap.forEachBlockTickingChunk(levelChunk -> {
                if (chunkMap.anyPlayerCloseEnoughForSpawning(levelChunk.getPos()) && Math.random() < 0.01) {
                  BlockPos rainFrom = levelChunk.getPos().getBlockAt(randomSource.nextInt(16), level.getMaxY(), randomSource.nextInt(16));
                  BlockState rainState = getRainBlockState(level, rainFrom);
                  if (rainState != null) {
                    FallingBlockEntity fallingBlock = FallingBlockEntity.fall(level, rainFrom, rainState);
                    fallingBlock.addTag("fall_normally");
                    fallingBlock.setHurtsEntities(0.2f, 5);
                    fallingBlock.disableDrop();
                  }
                }
              });
            }
          })
      ,
      server -> {}
  );

}
