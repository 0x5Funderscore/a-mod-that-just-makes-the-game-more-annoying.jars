package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_chaos;

import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchChaosOption;


public class SkipWeather {

  public static final TwitchChaosOption OPTION = new TwitchChaosOption(
      "Skip Weather",
      server -> server.getAllLevels().forEach(level -> {
        if (level.isThundering()) {
          level.getWeatherData().setThunderTime(1);
          level.getWeatherData().setThundering(false);
        } else if (level.isRaining()) {
          level.getWeatherData().setRainTime(1);
          level.getWeatherData().setRaining(false);
        } else {
          level.getWeatherData().setClearWeatherTime(1);
        }
      })
  );

}
