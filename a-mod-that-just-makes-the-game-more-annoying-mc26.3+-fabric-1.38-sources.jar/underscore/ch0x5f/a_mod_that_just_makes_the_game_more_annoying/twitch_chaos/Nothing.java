package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_chaos;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.clock.WorldClocks;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchChaosOption;


public class Nothing {

  public static final TwitchChaosOption OPTION = new TwitchChaosOption(
      "Nothing",
      _ -> {}
  );

}
