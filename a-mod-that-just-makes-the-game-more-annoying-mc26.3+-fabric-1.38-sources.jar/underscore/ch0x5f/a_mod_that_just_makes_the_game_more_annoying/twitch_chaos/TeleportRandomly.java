package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_chaos;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchChaosOption;


public class TeleportRandomly {

  public static final TwitchChaosOption OPTION = new TwitchChaosOption(
      "Teleport Randomly",
      server -> server.getAllLevels().forEach(level -> {
        RandomSource random = level.getRandom();

        level.players().forEach(player -> {

          BlockPos targetApproximate = BlockPos.containing(player.position().offsetRandomXZ(random, 256.0f))
              .atY(random.nextIntBetweenInclusive(level.getMinY(), level.getMaxY()));

          BlockPos target = level.getPortalForcer()
              .findClosestPortalPosition(targetApproximate, false, level.getWorldBorder())
              .orElseGet(() -> level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, targetApproximate));

          player.setPos(Vec3.atBottomCenterOf(target));
          player.teleport(TeleportTransition.createDefault(player, TeleportTransition.DO_NOTHING));
        });
      })
  );

}
