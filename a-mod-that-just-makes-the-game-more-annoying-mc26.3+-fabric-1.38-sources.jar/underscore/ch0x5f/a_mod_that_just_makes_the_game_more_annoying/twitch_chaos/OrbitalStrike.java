package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_chaos;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.phys.Vec3;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchChaosOption;

import java.util.HashSet;
import java.util.Set;


public class OrbitalStrike {

  public static final TwitchChaosOption OPTION = new TwitchChaosOption(
      "Orbital Strike",
      server -> {
        server.getAllLevels().forEach(level -> {
          if (!level.dimensionType().hasCeiling()) {

            Set<ServerPlayer> skip = new HashSet<>();

            for (int i = 0; i < 8; i++) {

              ServerPlayer target = level.getRandomPlayer();
              if (target == null) continue;
              if (skip.contains(target)) continue;
              if (i < 6 && level.getLightEngine().getLayerListener(LightLayer.SKY).getLightValue(target.blockPosition()) < 6) {
                continue;
              }
              skip.add(target);

              Vec3 targetPos = target.position();

              int radius = 0;
              float tnt = 1.0f;
              for (int ring = 0; ring < 5; ring++) {

                for (int n = 0; n < tnt; n++) {
                  double angle = Math.random() * Math.TAU;
                  double dx = Math.cos(angle) * radius;
                  double dz = Math.sin(angle) * radius;
                  PrimedTnt tntEntity = new PrimedTnt(level, targetPos.x + dx, targetPos.y + 50.0, targetPos.z + dz, null);
                  tntEntity.addTag("explode_normally");
                  level.addFreshEntity(tntEntity);
                }

                radius += 4;
                tnt += 20;
                tnt *= 0.8f;
              }

            }

          }
        });
      }
  );

}
