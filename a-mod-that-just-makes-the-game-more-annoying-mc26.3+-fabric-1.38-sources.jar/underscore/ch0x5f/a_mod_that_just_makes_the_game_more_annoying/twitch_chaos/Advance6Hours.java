package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_chaos;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.clock.WorldClocks;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchChaosOption;


public class Advance6Hours {

  public static final TwitchChaosOption OPTION = new TwitchChaosOption(
      "Advance 6 Hours",
      server -> server.clockManager().addTicks(server.registryAccess().lookupOrThrow(Registries.WORLD_CLOCK).getOrThrow(WorldClocks.OVERWORLD), 6000)
  );

}
