package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration;

import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;


public record TwitchChaosOption(
    @NotNull String name,
    boolean instant,
    @NotNull Consumer<MinecraftServer> start, @NotNull Consumer<MinecraftServer> tick, @NotNull Consumer<MinecraftServer> end,
    float durationMultiplier
) {

  private static final Consumer<MinecraftServer> NOOP = _ -> {
  };

  public TwitchChaosOption(@NotNull String name, @NotNull Consumer<MinecraftServer> start, @NotNull Consumer<MinecraftServer> tick, @NotNull Consumer<MinecraftServer> end) {
    this(name, false, start, tick, end, 1.0f);
  }

  public TwitchChaosOption(@NotNull String name, @NotNull Consumer<MinecraftServer> start, @NotNull Consumer<MinecraftServer> tick, @NotNull Consumer<MinecraftServer> end, float durationMultiplier) {
    this(name, false, start, tick, end, durationMultiplier);
  }

  public TwitchChaosOption(@NotNull String name, @NotNull Consumer<MinecraftServer> start) {
    this(name, true, start, NOOP, NOOP, 0f);
  }

  public TwitchChaosOption(@NotNull String name, float durationMultiplier) {
    this(name, false, NOOP, NOOP, NOOP, durationMultiplier);
  }

  public TwitchChaosOption(@NotNull String name) {
    this(name, false, NOOP, NOOP, NOOP, 1.0f);
  }

}
