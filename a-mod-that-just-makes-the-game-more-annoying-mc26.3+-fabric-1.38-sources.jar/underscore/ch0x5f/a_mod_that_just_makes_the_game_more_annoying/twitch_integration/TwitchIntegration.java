package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration;

import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.RandomSource;
import net.minecraft.util.valueproviders.ConstantInt;
import net.minecraft.util.valueproviders.IntProvider;
import org.jetbrains.annotations.Nullable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class TwitchIntegration {
  public static final TwitchIntegration INSTANCE = new TwitchIntegration();

  public static int numOptions = 4;

  public int votingTimer = 0;
  private boolean running = false;

  public static IntProvider voteDuration = ConstantInt.of(20*30);
  public static IntProvider showWinnerDuration = ConstantInt.of(20*5);
  public static IntProvider cooldownDuration = ConstantInt.of(20*55);
  private Stage votingStage = Stage.COOLDOWN;

  public static IntProvider baseEffectDuration = ConstantInt.of(20 * 30);
  public static int minEffectDuration = 20;

  private final RandomSource randomSource = RandomSource.create(System.currentTimeMillis() ^ -4272830698232029646L);

  public @Nullable TwitchChaosOption activeEffect = null;
  private int effectTicksLeft = 0;

  public TwitchChaosOption[] chaosOptions = new TwitchChaosOption[0];
  public int[] optionVotes = new int[0];
  public Object2IntOpenHashMap<String> votes = new Object2IntOpenHashMap<>();

  public int winningOption = -1;

  public boolean collectingVotes = false;

  public void notifyPlayers(MinecraftServer server) {
    TwitchIntegrationProtocol.TwitchChaosPacket packet = new TwitchIntegrationProtocol.TwitchChaosPacket(
        Arrays.stream(this.chaosOptions)
            .map(TwitchChaosOption::name)
            .toArray(String[]::new),
        this.getOptionVoteFractions(),
        votingStage == Stage.SHOW_WINNER ? winningOption : -1,
        activeEffect != null ? activeEffect.name() : null,
        activeEffect != null && activeEffect.instant(),
        votingStage == Stage.VOTE ? votingTimer : 0
    );
    server.getPlayerList().getPlayers().forEach(player -> ServerPlayNetworking.send(player, packet));
  }

  public void start(MinecraftServer server) {
    clearOptions();
    activeEffect = null;
    running = true;
    votingStage = Stage.COOLDOWN;
    votingTimer = cooldownDuration.sample(randomSource);
    collectingVotes = false;
    winningOption = -1;
    notifyPlayers(server);
  }

  public void tick(MinecraftServer server) {
    if (running) {

      if (TwitchIntegrationConnector.INSTANCE.getStatus() == ConnectionStatus.LOADING) return;
      else if (TwitchIntegrationConnector.INSTANCE.getStatus() == ConnectionStatus.DISCONNECTED) {
        running = false;
        stop(server);
        notifyPlayers(server);
        return;
      }

      votingTimer--;
      if (votingTimer <= 0) {
        votingStage = switch (votingStage) {
          case VOTE -> {
            calculateWinningOption();
            collectingVotes = false;
            votingTimer = showWinnerDuration.sample(randomSource);
            yield Stage.SHOW_WINNER;
          }
          case SHOW_WINNER -> {
            finishVoting(server);
            clearOptions();
            votingTimer = cooldownDuration.sample(randomSource);
            yield Stage.COOLDOWN;
          }
          default -> {
            pickNewOptions();
            votingTimer = voteDuration.sample(randomSource);
            yield Stage.VOTE;
          }
        };
        notifyPlayers(server);
      } else if (votingStage == Stage.VOTE) {
        if (votingTimer % 10 == 0) notifyPlayers(server);
      }

      effectTicksLeft--;
      if (effectTicksLeft <= 0) {
        if (activeEffect != null) {
          activeEffect.end().accept(server);
          activeEffect = null;
          notifyPlayers(server);
        }
      } else if (activeEffect != null) {
        activeEffect.tick().accept(server);
      }

    }
  }

  public void stop(MinecraftServer server) {
    if (activeEffect != null) activeEffect.end().accept(server);
    activeEffect = null;
    effectTicksLeft = 0;
    running = false;
    clearOptions();
  }

  public void clearOptions() {
    chaosOptions = new TwitchChaosOption[0];
    optionVotes = new int[0];
    votes.clear();
  }

  public void pickNewOptions() {
    clearOptions();
    votingStage = Stage.VOTE;
    collectingVotes = true;

    List<TwitchChaosOption> enabledOptions = new ArrayList<>(TwitchChaosRegistry.getEnabledOptions());

    chaosOptions = new TwitchChaosOption[numOptions];
    for (int i = 0; i < numOptions; i++) {
      if (enabledOptions.isEmpty()) {
        TwitchChaosOption[] options0 = chaosOptions;
        chaosOptions = new TwitchChaosOption[i];
        System.arraycopy(options0, 0, chaosOptions, 0, i);
        break;
      }
      int choice = (int)Math.floor(Math.random() * enabledOptions.size());
      chaosOptions[i] = enabledOptions.remove(choice);
    }

    optionVotes = new int[chaosOptions.length];
    LogUtils.getLogger().info("options: {}", Arrays.toString(this.chaosOptions));
  }

  private void calculateWinningOption() {
    if (this.votes.isEmpty()) {
      winningOption = -1;
      return;
    }
    winningOption = 0;
    int winningVotes = 0;
    for (int i = 0; i < chaosOptions.length; i++) {
      if (optionVotes[i] > winningVotes) {
        winningVotes = optionVotes[i];
        winningOption = i;
      }
    }
  }

  public void finishVoting(MinecraftServer server) {
    if (activeEffect != null) activeEffect.end().accept(server);
    if (winningOption >= 0) {
      activeEffect = chaosOptions[winningOption];
      activeEffect.start().accept(server);
      effectTicksLeft = Math.max((int)(baseEffectDuration.sample(randomSource) * activeEffect.durationMultiplier()), minEffectDuration);
    } else {
      activeEffect = null;
      effectTicksLeft = 0;
    }
  }

  public void handleMessage(TwitchMessage message) {
    if (Config.TWITCH_INTEGRATION__EXPERIMENTAL.get() && collectingVotes) {
      String trimmedContent = message.content().trim();
      if (!trimmedContent.matches("\\d+")) return;
      int option;
      try {
        option = Integer.parseUnsignedInt(trimmedContent, 10) - 1;
      } catch (NumberFormatException e) {
        return;
      }
      if (option >= 0 && option < chaosOptions.length) {
        String username = message.username();
        if (votes.containsKey(username)) {
          int votedOption = votes.getInt(username);
          optionVotes[votedOption]--;
        }
        votes.put(username, option);
        optionVotes[option]++;
      }
    }
  }

  public double[] getOptionVoteFractions() {
    int totalVotes = votes.size();
    double[] voteFractions = new double[chaosOptions.length];
    if (totalVotes == 0) return voteFractions;
    for (int i = 0; i < chaosOptions.length; i++) {
      voteFractions[i] = (double)optionVotes[i] / totalVotes;
    }
    return voteFractions;
  }

  public enum Stage {
    VOTE,
    SHOW_WINNER,
    COOLDOWN
  }

}
