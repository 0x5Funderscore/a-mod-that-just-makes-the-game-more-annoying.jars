package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration;

import com.azure.json.models.JsonString;
import com.mojang.logging.LogUtils;
import org.apache.commons.lang3.function.TriConsumer;
import org.slf4j.Logger;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.io.IOException;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;


class TwitchWebSocketListener implements WebSocket.Listener {

  private static final Logger LOGGER = LogUtils.getLogger();

  private final String channel;

  private final Consumer<WebSocket> onOpen;
  private final TriConsumer<WebSocket,Integer,String> onClose;
  private final BiConsumer<WebSocket,Throwable> onError;

  public TwitchWebSocketListener(String channel, Consumer<WebSocket> onOpen, TriConsumer<WebSocket,Integer,String> onClose, BiConsumer<WebSocket,Throwable> onError) {
    this.channel = channel;
    this.onOpen = onOpen;
    this.onClose = onClose;
    this.onError = onError;
  }

  private static char randomDigit() {
    return (char)((int)'0' + (int)Math.floor(Math.random() * 10.0));
  }

  private static String generateRandomDigits(int count) {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < count; i++) {
      sb.append(randomDigit());
    }
    return sb.toString();
  }

  private String bufferingMessage = "";

  @Override
  public void onOpen(WebSocket webSocket) {
    String joinChannels = Arrays.stream(channel.replace("\r\n", "").split(",")).map(s -> "#"+s.toLowerCase().trim()).collect(Collectors.joining(","));
    LOGGER.info("Twitch Integration WebSocket connected...");
    webSocket.sendText("PASS " + UUID.randomUUID(), true);
    webSocket.sendText("NICK justinfan" + generateRandomDigits(10), true);
    webSocket.sendText("JOIN " + joinChannels, true);
    this.onOpen.accept(webSocket);
    webSocket.request(1);
  }

  @Override
  public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
    if (!Config.TWITCH_INTEGRATION__EXPERIMENTAL.get()) return webSocket.sendClose(1000, "");
    bufferingMessage += data;
    try {
      LOGGER.info("text: {}", new JsonString(bufferingMessage).toJsonString());
    } catch (IOException ignored) {}
    if (last) {
      for (String line: bufferingMessage.split("\r\n")) {
        if (line.isEmpty()) continue;
        if (line.startsWith("PING ")) {
          webSocket.sendText("PONG " + line.substring(5), true);
        } else {
          TwitchMessage message = TwitchMessage.parse(line);
          if (message != null) {
            TwitchIntegration.INSTANCE.handleMessage(message);
          }
        }
      }
      bufferingMessage = "";
    }
    webSocket.request(1);
    return CompletableFuture.completedFuture(null);
  }

  @Override
  public CompletionStage<?> onBinary(WebSocket webSocket, ByteBuffer data, boolean last) {
    return webSocket.sendClose(1000, "binary not supported");
  }

  @Override
  public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
    this.onClose.accept(webSocket, statusCode, reason);
    return CompletableFuture.completedFuture(null);
  }

  @Override
  public void onError(WebSocket webSocket, Throwable error) {
    this.onError.accept(webSocket, error);
  }
}
