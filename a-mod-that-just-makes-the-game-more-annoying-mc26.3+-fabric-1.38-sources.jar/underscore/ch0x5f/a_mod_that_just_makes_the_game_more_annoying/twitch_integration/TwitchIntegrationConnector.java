package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration;

import com.mojang.logging.LogUtils;
import net.fabricmc.loader.api.FabricLoader;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.ThrowingConsumer;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;


public class TwitchIntegrationConnector {

  public static final TwitchIntegrationConnector INSTANCE = new TwitchIntegrationConnector();

  private static final String CONNECT_URL = "wss://irc-ws.chat.twitch.tv:443";
  private static final Logger LOGGER = LogUtils.getLogger();

  public @Nullable String channelName = null;
  private ConnectionStatus status = ConnectionStatus.DISCONNECTED;
  private final HttpClient client = HttpClient.newHttpClient();
  private WebSocket webSocket;

  private static void openChannelFile(ThrowingConsumer<File> callback) {
    try {
      File file = FabricLoader.getInstance().getConfigDir().resolve(AMTJMTGMA.MOD_ID + ".twitch_channel.txt").toFile();
      if (!file.exists()) file.createNewFile();
      callback.accept(file);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  public void saveChannelName() {
    openChannelFile(file -> {
      try (FileWriter fileWriter = new FileWriter(file)) {
        fileWriter.write(this.channelName == null ? "" : this.channelName);
        fileWriter.flush();
      }
    });
  }

  public void loadChannelName() {
    openChannelFile(file -> {
      try (FileReader fileReader = new FileReader(file)) {
        this.channelName = fileReader.readAllAsString();
        if (this.channelName.isEmpty()) this.channelName = null;
      }
    });
  }

  public void attemptConnect() {
    if (this.status == ConnectionStatus.LOADING) {
      return;
    }

    if (this.webSocket != null) {
      this.webSocket.sendClose(1000, "");
      this.webSocket = null;
    }

    this.status = ConnectionStatus.LOADING;

    String channel = this.channelName;
    if (channel == null || channel.isEmpty()) {
      this.status = ConnectionStatus.DISCONNECTED;
      return;
    }
    LOGGER.info("Twitch Integration attempting to connect to channel: {}", channel);

    try {
      this.client.newWebSocketBuilder()
          .buildAsync(
              URI.create(CONNECT_URL),
              new TwitchWebSocketListener(
                  channel,
                  (webSocket) -> {
                    this.webSocket = webSocket;
                    this.status = ConnectionStatus.CONNECTED;
                    LOGGER.info("Twitch Integration connected! Channel: {}", channel);
                  },
                  (webSocket, statusCode, reason) -> {
                    if (webSocket == this.webSocket) {
                      this.status = ConnectionStatus.DISCONNECTED;
                      LOGGER.error("Twitch Integration disconnected");
                    }
                  },
                  (webSocket, error) -> {
                    if (webSocket == this.webSocket) {
                      this.status = ConnectionStatus.DISCONNECTED;
                      LOGGER.error("Twitch Integration errored", error);
                    }
                  }
              )
          )
          .handleAsync((webSocket, throwable) -> {
            if (throwable != null) {
              this.status = ConnectionStatus.DISCONNECTED;
              LOGGER.error("Failed to initialize WebSocket", throwable);
              LOGGER.error("Twitch Integration failed to connect");
            }
            return null;
          });
    } catch (Exception e) {
      this.status = ConnectionStatus.DISCONNECTED;
      LOGGER.error("Twitch Integration failed to initialize", e);
    }

  }

  public ConnectionStatus getStatus() {
    return this.status;
  }
}
