package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;


public record TwitchMessage(String username, String content) {

  public static @Nullable TwitchMessage parse(@NotNull String webSocketMessage) {
    webSocketMessage = webSocketMessage.trim();
    String[] parts = webSocketMessage.split(":", 3);
    if (parts.length != 3 || !parts[1].contains(" PRIVMSG ")) return null;
    String username = parts[0].split("!")[0].trim();
    String content = parts[2].trim();
    return new TwitchMessage(username, content);
  }

}
