package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;

import java.util.Objects;


public class TwitchIntegrationProtocol {

  public static final CustomPacketPayload.Type<TwitchChaosPacket> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "twitch_chaos"));
  public static final StreamCodec<FriendlyByteBuf,TwitchChaosPacket> STREAM_CODEC = StreamCodec.of(TwitchChaosPacket::encode, TwitchChaosPacket::decode);

  public static void register() {
    PayloadTypeRegistry.clientboundPlay().register(TYPE, STREAM_CODEC);
  }

  public record TwitchChaosPacket(
      String[] names,
      double[] fractions,
      int selected,
      @Nullable String activeEffect,
      boolean instantEffect,
      int timer
  ) implements CustomPacketPayload {

    public TwitchChaosPacket {
      if (names.length != fractions.length) throw new IllegalArgumentException("Array size mismatch");
    }

    public TwitchChaosPacket() {
      this(new String[0], new double[0], -1, null, false, 0);
    }

    @Override
    public @NonNull Type<? extends CustomPacketPayload> type() {
      return TYPE;
    }

    public static void encode(FriendlyByteBuf friendlyByteBuf, TwitchChaosPacket twitchChaosPacket) {
      friendlyByteBuf.writeInt(twitchChaosPacket.names.length);
      for (int i = 0; i < twitchChaosPacket.names.length; i++) {
        friendlyByteBuf.writeUtf(twitchChaosPacket.names[i]);
        friendlyByteBuf.writeDouble(twitchChaosPacket.fractions[i]);
      }
      friendlyByteBuf.writeInt(twitchChaosPacket.selected);
      friendlyByteBuf.writeUtf(Objects.requireNonNullElse(twitchChaosPacket.activeEffect, ""));
      friendlyByteBuf.writeBoolean(twitchChaosPacket.instantEffect);
      friendlyByteBuf.writeInt(twitchChaosPacket.timer());
    }

    public static TwitchChaosPacket decode(FriendlyByteBuf friendlyByteBuf) {
      int count = friendlyByteBuf.readInt();
      String[] names = new String[count];
      double[] fractions = new double[count];
      for (int i = 0; i < count; i++) {
        names[i] = friendlyByteBuf.readUtf();
        fractions[i] = friendlyByteBuf.readDouble();
      }
      int selected = friendlyByteBuf.readInt();
      String activeEffect = friendlyByteBuf.readUtf();
      if (activeEffect.isEmpty()) activeEffect = null;
      boolean instantEffect = friendlyByteBuf.readBoolean();
      int timer = friendlyByteBuf.readInt();
      return new TwitchChaosPacket(names, fractions, selected, activeEffect, instantEffect, timer);
    }

  }

}
