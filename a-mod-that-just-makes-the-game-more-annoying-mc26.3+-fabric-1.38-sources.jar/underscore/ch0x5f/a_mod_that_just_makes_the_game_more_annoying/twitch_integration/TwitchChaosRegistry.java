package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration;

import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.ConfigProperty;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_chaos.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public final class TwitchChaosRegistry {

  private static final Map<ConfigProperty,TwitchChaosOption> options = new HashMap<>();

  public static void register(ConfigProperty enableProperty, TwitchChaosOption option) {
    options.put(enableProperty, option);
  }

  public static List<TwitchChaosOption> getEnabledOptions() {
    return options.entrySet()
        .stream()
        .filter(entry -> entry.getKey().get())
        .map(Map.Entry::getValue)
        .toList();
  }

  public static void bootstrap() {
    register(Config.TWITCH__TELEPORT_RANDOMLY, TeleportRandomly.OPTION);
    register(Config.TWITCH__SKIP_WEATHER, SkipWeather.OPTION);
    register(Config.TWITCH__ADVANCE_6_HOURS, Advance6Hours.OPTION);
    register(Config.TWITCH__NOTHING, Nothing.OPTION);
    register(Config.TWITCH__RAINING_BLOCKS, RainingBlocks.OPTION);
    register(Config.TWITCH__ORBITAL_STRIKE, OrbitalStrike.OPTION);
    register(Config.TWITCH__SPLEEF_MODE, SpleefMode.OPTION);
    register(Config.TWITCH__ANVIL_RAIN, AnvilRain.OPTION);
  }

}
