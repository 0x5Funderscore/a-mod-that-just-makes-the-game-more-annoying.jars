package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration;

public enum ConnectionStatus {
  CONNECTED,
  LOADING,
  DISCONNECTED
}
