package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import java.util.function.Consumer;


@FunctionalInterface
public interface ThrowingConsumer<T> {
  void accept(T t) throws Exception;
}
