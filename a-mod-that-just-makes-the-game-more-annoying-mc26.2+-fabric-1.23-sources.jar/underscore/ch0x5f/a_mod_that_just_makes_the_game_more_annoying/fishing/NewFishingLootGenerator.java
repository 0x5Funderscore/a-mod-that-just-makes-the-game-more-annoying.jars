package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;


public final class NewFishingLootGenerator {

  public static @NotNull ObjectArrayList<ItemStack> generateItems(boolean perfect, Entity entity, Vec3 position, ItemStack rod, float luck) {
    ServerLevel level = (ServerLevel)entity.level();
//    LootTable fish = level.getServer().reloadableRegistries().getLootTable(BuiltInLootTables.FISHING_FISH);
//    LootTable junk = level.getServer().reloadableRegistries().getLootTable(BuiltInLootTables.FISHING_JUNK);
//    LootTable treasure = level.getServer().reloadableRegistries().getLootTable(BuiltInLootTables.FISHING_TREASURE);
    LootParams params = (new LootParams.Builder(level)).withParameter(LootContextParams.ORIGIN, position).withParameter(LootContextParams.TOOL, rod).withParameter(LootContextParams.THIS_ENTITY, entity).withLuck(luck + (perfect ? 2f : -0.25f)).create(LootContextParamSets.FISHING);
    LootTable lootTable = level.getServer().reloadableRegistries().getLootTable(BuiltInLootTables.FISHING);
    return lootTable.getRandomItems(params);
  }

}
