package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing;


import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;


public interface IServerPlayerFishingExtension {
  ServerFishing getNewFishing();
  void queueNextFishingContext(@NotNull ItemStack itemStack, @NotNull InteractionHand hand);
  void startNewFishing();
  void clearNewFishing();
}
