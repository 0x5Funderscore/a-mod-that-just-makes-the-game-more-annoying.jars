package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing;

import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.gameevent.GameEvent;
import org.jetbrains.annotations.NotNull;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


public class ServerFishing {

  private final ServerPlayer player;
  private final ItemStack rod;
  private final InteractionHand interactionHand;

  private int ticksSinceUpdate = -1;
  private float[] keyframes = new float[0];
  private float barSize = 0.3f;
  private float progressDecreaseSpeed = 0.005f;
  private float progressIncreaseSpeed = 0.01f;
  private float barForce = 0.007f;
  private float barGravity = 0.007f;
  private float barBounce = 0.5f;
  private int keyframe = 0;
  private boolean firstHover = false;
  private boolean perfect = true;
  private boolean success = false;
  private float lastProgress = 1f;

  private boolean won = false;
  private int winTime = 0;

  public ServerFishing(@NotNull ServerPlayer player, @NotNull ItemStack rod, @NotNull InteractionHand interactionHand) {
    this.player = player;
    this.rod = rod;
    this.interactionHand = interactionHand;
//    this.noise = new ImprovedNoise(RandomSource.create(System.nanoTime()));
  }

  float deltaHeight = (float)Math.random() - 0.5f;
  float lastKeyframe = 0.5f;
  private float generateNextKeyframe() {
    deltaHeight = Mth.clamp(deltaHeight + (float)Math.random() * 0.2f - 0.1f, -1f, 1f);
    lastKeyframe += deltaHeight * 0.1f;
    if (lastKeyframe <= 0.05f) {
      lastKeyframe = 0.05f;
      deltaHeight = Math.max(deltaHeight, 0f);
    } else if (lastKeyframe >= 0.95f) {
      lastKeyframe = 0.95f;
      deltaHeight = Math.min(deltaHeight, 0f);
    }
    return lastKeyframe;
  }

  public void tick() {
    if (!Config.FISHING.get() || player.fishing == null || player.fishing.isRemoved() || player.fishing.getHookedIn() != null || player.fishing.nibble <= 0) {
//      LogUtils.getLogger().info("clearing fishing; bobber: {}, hooked: {}, nibble: {}", player.fishing, player.fishing == null ? null : player.fishing.getHookedIn(), player.fishing == null ? null : player.fishing.nibble);
      ServerPlayNetworking.send(this.player, NewFishing.FishingPacketPayload.clientboundClear());
      ((IServerPlayerFishingExtension)player).clearNewFishing();
      return;
    }

    if (this.winTime >= NewFishing.WIN_TICKS) {
      player.fishing.nibble = 1;
      this.finish(true);
      return;
    } else if (this.won) {
      player.fishing.nibble = NewFishing.WIN_TICKS - this.winTime + 1;
      this.winTime++;
      return;
    } else {
      this.winTime = 0;
    }

    player.fishing.nibble = 20;

    if (keyframes.length != NewFishing.NUM_KEYFRAMES) {
      keyframes = new float[NewFishing.NUM_KEYFRAMES];
      for (int i = NewFishing.RESEND_EVERY_KEYFRAMES; i < NewFishing.NUM_KEYFRAMES; i++) {
        keyframes[i] = generateNextKeyframe();
        keyframe++;
      }
    }

    ticksSinceUpdate++;
//    LogUtils.getLogger().info("ticks since update: {}", ticksSinceUpdate);
    if (ticksSinceUpdate <= 0 || ticksSinceUpdate >= NewFishing.RESEND_EVERY_KEYFRAMES * NewFishing.KEYFRAME_INTERVAL) {
      for (int i = 0; i < NewFishing.NUM_KEYFRAMES; i++) {
        int copyFrom = i + NewFishing.RESEND_EVERY_KEYFRAMES;
        if (copyFrom >= NewFishing.NUM_KEYFRAMES) {
          keyframes[i] = generateNextKeyframe();
          keyframe++;
        } else {
          keyframes[i] = keyframes[copyFrom];
        }
      }
//      LogUtils.getLogger().info("server sending update: {}", Arrays.toString(keyframes));
      ServerPlayNetworking.send(this.player, NewFishing.FishingPacketPayload.clientbound(keyframes, barSize, "minecraft:cod", progressDecreaseSpeed, progressIncreaseSpeed, barForce, barGravity, barBounce));
      ticksSinceUpdate = 0;
    }
  }

  public @NotNull ObjectArrayList<ItemStack> getItems(FishingHook entity) {
    if (this.success) {
      Player playerOwner = entity.getPlayerOwner();
      return NewFishingLootGenerator.generateItems(this.perfect, entity, entity.position(), this.rod, (float)entity.luck + (playerOwner == null ? 0f : playerOwner.getLuck()));
    }
    return new ObjectArrayList<>();
  }

  private void finish(boolean successful) {
    if (!Config.FISHING.get() || this.player.fishing == null || player.fishing.isRemoved()) return;

//    LogUtils.getLogger().info("fish finish; successful = {}, perfect = {}", successful, perfect);

    this.success = successful;
    int dmg = this.player.fishing.retrieve(this.rod);
    this.rod.hurtAndBreak(dmg, player, interactionHand.asEquipmentSlot());

    this.player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.FISHING_BOBBER_RETRIEVE, SoundSource.NEUTRAL, 1.0F, 0.4f / (this.player.getRandom().nextFloat() * 0.4f + 0.8f));
    this.rod.causeUseVibration(player, GameEvent.ITEM_INTERACT_FINISH);
    this.player.swing(this.interactionHand, true);

    ServerPlayNetworking.send(this.player, NewFishing.FishingPacketPayload.clientboundClear());
    ((IServerPlayerFishingExtension)this.player).clearNewFishing();
  }

  public void handlePacket(@NotNull NewFishing.FishingPacketPayload payload, @NotNull ServerPlayNetworking.Context context) {
    float progress = payload.progress();
    boolean newWon = progress >= 1f;
    if (newWon && !won) {
      won = true;
      if (this.perfect) ServerPlayNetworking.send(this.player, NewFishing.FishingPacketPayload.clientboundPerfect());
    }
    if (won) return;
//    LogUtils.getLogger().info("progress {} <- {}", progress, lastProgress);
    if (progress > lastProgress) {
      if (!firstHover) {
//        LogUtils.getLogger().info("hover");
        firstHover = true;
        perfect = true;
      }
    } else {
//      if (perfect) LogUtils.getLogger().info("!perfect");
      perfect = false;
    }
    lastProgress = progress;
    if (progress <= 0f) {
      this.finish(false);
    }
  }

  public static ServerPlayNetworking.PlayPayloadHandler<NewFishing.FishingPacketPayload> handlePacketStaticFactory(ServerPlayer serverPlayer) {
    return (@NotNull NewFishing.FishingPacketPayload payload, @NotNull ServerPlayNetworking.Context context) -> {
      if (Config.FISHING.get()) {
        ServerFishing serverFishing = ((IServerPlayerFishingExtension)serverPlayer).getNewFishing();
        if (serverFishing != null) {
          serverFishing.handlePacket(payload, context);
        } else {
          LogUtils.getLogger().warn("received fishing packet but player isn't fishing!");
        }
      }
    };
  }

  public static void register() {
    PayloadTypeRegistry.serverboundPlay().register(NewFishing.TYPE, NewFishing.SERVERBOUND_STREAM_CODEC);
    PayloadTypeRegistry.clientboundPlay().register(NewFishing.TYPE, NewFishing.CLIENTBOUND_STREAM_CODEC);
    ServerPlayConnectionEvents.INIT.register((listener, server) -> ServerPlayNetworking.registerReceiver(listener, NewFishing.TYPE, ServerFishing.handlePacketStaticFactory(listener.getPlayer())));
  }
}
