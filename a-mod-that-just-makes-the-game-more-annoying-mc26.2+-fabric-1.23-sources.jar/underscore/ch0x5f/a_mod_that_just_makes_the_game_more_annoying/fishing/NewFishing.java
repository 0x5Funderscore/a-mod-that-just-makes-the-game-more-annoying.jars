package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;


public final class NewFishing {

  public static final CustomPacketPayload.Type<FishingPacketPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "fishing"));
  public static final StreamCodec<FriendlyByteBuf, FishingPacketPayload> SERVERBOUND_STREAM_CODEC = StreamCodec.of(FishingPacketPayload::encodeServerbound, FishingPacketPayload::decodeServerbound);
  public static final StreamCodec<FriendlyByteBuf, FishingPacketPayload> CLIENTBOUND_STREAM_CODEC = StreamCodec.of(FishingPacketPayload::encodeClientbound, FishingPacketPayload::decodeClientbound);

  // 8 keyframes = 40 ticks = 2 seconds
  public static final int NUM_KEYFRAMES = 8;
  // 5 ticks
  public static final int KEYFRAME_INTERVAL = 5;
  // 4 keyframes = 20 ticks = 1 second
  public static final int RESEND_EVERY_KEYFRAMES = 4;

  public static final int WIN_TICKS = 20;

  public record FishingPacketPayload(
      boolean shorterVersion,
      boolean perfect,
      float @Nullable [] heights,
      float barSize,
      @Nullable String fishItemName,
      float progressDecreaseSpeed,
      float progressIncreaseSpeed,
      float barForce,
      float barGravity,
      float barBounce,
      float progress
  ) implements CustomPacketPayload {

    public static FishingPacketPayload clientboundPerfect() {
      return new FishingPacketPayload(
          true,
          true,
          null,
          0f,
          null,
          0f,
          0f,
          0f,
          0f,
          0f,
          -1f
      );
    }

    public static FishingPacketPayload clientboundClear() {
      return new FishingPacketPayload(
          true,
          false,
          null,
          0f,
          null,
          0f,
          0f,
          0f,
          0f,
          0f,
          -1f
      );
    }

    public static FishingPacketPayload clientbound(
        float @NotNull [] heights,
        float barSize,
        @Nullable String fishItemName,
        float progressDecreaseSpeed,
        float progressIncreaseSpeed,
        float barForce,
        float barGravity,
        float barBounce
    ) {
      return new FishingPacketPayload(
          false,
          false,
          heights,
          barSize,
          fishItemName,
          progressDecreaseSpeed,
          progressIncreaseSpeed,
          barForce,
          barGravity,
          barBounce,
          -1f
      );
    }

    public static FishingPacketPayload serverbound(float progress) {
      return new FishingPacketPayload(
          false,
          false,
          null,
          -1f,
          null,
          -1f,
          -1f,
          -1f,
          -1f,
          -1f,
          progress
      );
    }

    public static FishingPacketPayload serverboundExiting() {
      return serverbound(0f);
    }

    public static FishingPacketPayload serverboundCompleted() {
      return serverbound(1f);
    }

    public static void encodeServerbound(FriendlyByteBuf buf, FishingPacketPayload payload) {
      buf.writeShort(Math.clamp((int)(payload.progress * 65535f), 0, 65535));
    }

    public static FishingPacketPayload decodeServerbound(FriendlyByteBuf buf) {
      return serverbound(buf.readUnsignedShort() / 65535f);
    }

    public static void encodeClientbound(FriendlyByteBuf buf, FishingPacketPayload payload) {

      buf.writeBoolean(payload.shorterVersion);
      if (payload.shorterVersion) {
        buf.writeBoolean(payload.perfect);
        return;
      }

      if (payload.heights == null) throw new IllegalArgumentException("clientbound payload needs heights");
      if (payload.barSize < 0f) throw new IllegalArgumentException("clientbound payload needs barSize");
//      if (payload.progressDecreaseSpeed < 0f) throw new IllegalArgumentException("clientbound payload needs progressDecreaseSpeed");
//      if (payload.progressIncreaseSpeed < 0f) throw new IllegalArgumentException("clientbound payload needs progressIncreaseSpeed");
      if (payload.heights.length != NUM_KEYFRAMES) throw new ArrayIndexOutOfBoundsException("clientbound payload heights was an incorrect length: expected " + NUM_KEYFRAMES + " but got " + payload.heights.length);

      for (int i = 0; i < NUM_KEYFRAMES; i++) {
        buf.writeByte(Math.clamp((int)(payload.heights[i] * 255f), 0, 255));
      }
      buf.writeShort(Math.clamp((int)(payload.barSize * 65535f), 0, 65535));
      buf.writeFloat(Math.clamp(payload.progressDecreaseSpeed, 0f, 1f));
      buf.writeFloat(Math.clamp(payload.progressIncreaseSpeed, 0f, 1f));
      buf.writeFloat(payload.barForce);
      buf.writeFloat(payload.barGravity);
      buf.writeFloat(payload.barBounce);
      String fishItemName = payload.fishItemName == null ? "" : payload.fishItemName;
      buf.writeUtf(fishItemName, 32767);
    }

    public static FishingPacketPayload decodeClientbound(FriendlyByteBuf buf) {

      if (buf.readBoolean()) return buf.readBoolean() ? clientboundPerfect() : clientboundClear();

      float[] heights = new float[NUM_KEYFRAMES];
      for (int i = 0; i < NUM_KEYFRAMES; i++) {
        heights[i] = buf.readUnsignedByte() / 255f;
      }
      float barSize = buf.readUnsignedShort() / 65535f;
      float progressDecreaseSpeed = buf.readFloat();
      float progressIncreaseSpeed = buf.readFloat();
      float barForce = buf.readFloat();
      float barGravity = buf.readFloat();
      float barBounce = buf.readFloat();
      String fishItemName = buf.readUtf(32767);
      if (fishItemName.isEmpty()) fishItemName = null;
      return clientbound(heights, barSize, fishItemName, progressDecreaseSpeed, progressIncreaseSpeed, barForce, barGravity, barBounce);
    }

    @Override
    public @NonNull Type<FishingPacketPayload> type() {
      return TYPE;
    }
  }

}
