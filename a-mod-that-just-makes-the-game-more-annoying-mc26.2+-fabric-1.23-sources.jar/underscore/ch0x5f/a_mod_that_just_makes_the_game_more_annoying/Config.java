package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.fabricmc.loader.api.FabricLoader;
import org.jetbrains.annotations.ApiStatus;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.function.Consumer;

import static underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.ConfigTags.*;


public enum Config implements ConfigProperty {

  BEDS_TP_TO_NETHER(server, true),
  SHIELD_BLOCKING_DISABLES(server, true),
  PHANTOMS_PICK_UP_PLAYERS(server, true),
  ALWAYS_SPAWN_PHANTOMS(server, false),
  OFFSET_CROSSHAIR(client, true),
  OFFSET_HUNGER_BAR(client, true),
  PIGLINS_BLOW_UP(server, false),
  EMERALD_INFLATION(server, false),
  SHUFFLE_CHESTS_ON_OPEN(server, true),
  INVISIBLE_CREEPERS(client, true),
  LOUD_CREEPER_EXPLOSIONS(server, true),
  UNCAPPED_VOLUME(client, true),
  BROKEN_RECIPES(server, false),
  ITEMS_BREAK_RANDOMLY(server, true),
  RANDOMLY_STOP_SNEAKING_IN_NETHER(client, true),
  FRAGILE_OBSIDIAN(server, true),
  GOOFY_SPIDERS(server, true),
  VICIOUS_HORSES(server, true),
  REQUIRE_BALANCED_DIET(server, true),
  INVENTORY_GLASS_PANES_TROLL(server, true),
  BLOCK_DROPS_RANDOM_ATTRIBUTE_MODIFIERS(server, true),
  DO_NOT_SWIM(both, true),
  DISABLE_PAUSE(both, false),
  DESTROYING_BLOCKS_WITH_HAND_HURTS(server, true),
  ENVIRONMENTAL_TEMPERATURE_DAMAGE(server, true),
  SUPER_BOUNCY(both, true),
  REPLACE_END_PORTAL(both, true),
  BEEHIVES_EXPLODE_NEAR_PLAYERS(server, true),
  BEES_STING_ENDLESSLY(server, true),
  ANXIOUS_ENDERMEN(server, true),
  ENDERMEN_RANDOMLY_GET_BOOM(server, true),
  GOOFY_ENDER_DRAGON(client, true),
  REPLACE_END_PLATFORM(server, true),
  DIG_DOWN_LAVA_TROLL(server, true),
  QUICKGRAVEL(server, true),
  GRAVEL_AND_STONES_FALL_ON_YOUR_HEAD(server, true),
  HALVE_DRAGON_DAMAGE(server, true),
  DRAGON_EGGS_TELEPORT_FURTHER(both, true),
  REQUIRE_8_CRYSTALS_FOR_RESPAWN(server, true),
  END_CRYSTALS_REQUIRE_PLAYER_PUNCH(server, true),
  LESS_COAL_ORE(server, true),
  COAL_BURNS_FAST(server, true),
  FURNACE_COOKING_TIME_X5(server, true),
  FURNACE_EXPONENTIAL_PROGRESS(client, true),
  FALL_DAMAGE_AT_2_BLOCKS(both, false),
  DIFFERENT_END_BED_EXPLOSION(server, true),
  SLEEP_AFTER_MIDNIGHT(server, true),
  TERRIBLE_REPUTATION(server, true),
  SWEET_BERRY_BUSHES_SPREAD(server, true),
  SWEET_BERRY_BUSHES_APPLY_EFFECTS(server, true),
  EVERY_ZOMBIE_IS_A_LEADER(server, true),
  REALLY_HARD_MODE(server, true),
  THIN_BRIDGES_BREAK(server, true),
  THIN_ICE(server, true),
  ENDERMEN_TELEPORT_A_LOT(server, false),
  TTS_GUIDE(client, true),
  END_PORTAL_NEEDS_FRAME(server, true),
  FALL_THROUGH_LEAVES(both, false),
  WITHER_SKELETONS_COMBINE(server, true),
  SPLASH_POTIONS_EXPLODE(server, true),
  ANIMALS_STOP_SLEEP(server, true),
  DOORS_CHANGE_RANDOMLY(server, true),
  ALL_ZOMBIES_ARE_BABIES(server, false),
  MINING_FATIGUE_UNAFFECTED_BY_MILK(server, false),
  REPLACE_LAVA_SOLIDIFICATION(server, true),
  ELDER_GUARDIAN_INCREASED_RANGE(server, true),
  TAMING_ANIMALS_EXPLODES(server, false),
  BED_WETTING(server, true),
  INVERSE_ABSORPTION(both, true),
  LOWER_STEP_HEIGHT(both, true),
  DOORS_ARE_AFRAID_OF_WATER(server, true),
  RARE_ITEMS_FLY_AWAY(both, true),
  SWEEPING_DAMAGES_SELF(server, true),
  ORIGIN_DESERT(server, false),
  EXPERIENCE_ORBS_HURT(server, true),
  NO_XP(server, true),
  SKELETON_HOMING_ARROWS(server, true),
  NO_ENCHANTING_TABLES(server, true),
  EXPLODE_ON_PLACE(server, true),
  ANNOYING_TRAPPED_CHESTS(server, true),
  FAST_GHASTS(server, true),
  FURNACE_TOUCH_DAMAGE(server, true),
  LAVA_SPREADS_LAVA(server, false),
  EDGING_TNT(server, true),
  FALL_HEART_ATTACKS(server, false),
  OVERCOOKING(server, true),
  FUEL_ALWAYS_BURNS(server, true),
  HOLDING_LAVA_HURTS(server, true),
  ENCHANTMENTS_DISAPPEAR(server, true),
  LAVA_BLOWS_UP_FURNACES(server, true),
  LACTOSE_INTOLERANCE(server, true),
  SHORT_ENDERMAN_HITBOX(both, true),
  ENDERMEN_SOCIAL_ANXIETY(server, true),
  ENDERMEN_DONT_FREEZE(server, true),
  ENDERMEN_HOLD_ANYTHING(server, true),
  ENDERMEN_HOLD_WITHER_IMMUNE(server, false),
  FRAGILE_END_PORTAL(server, false),
  SLOW_ARMOUR(server, true),
  ALTITUDE_TEMPERATURE_DAMAGE(server, true),
  EXPLOSIVE_RABBITS(server, true),
  NORMAL_RAILS_ARE_POWERED_OFF(server, true),
  ENDERMEN_UNAFFECTED_BY_WATER(server, true),
  BATS_TARGET_EYES(server, true),
  BEDROCK_OFFHAND_OR_LIGHTNING(server, true),
  ITEMS_DIE_NEAR_PLAYERS(server, true),
  RAILS_SPAWN_FURNACE_MINECARTS(server, true),
  INVENTORY_WATER_BUCKET_SPILLING(server, true),
  FURNACE_MINECARTS_USELESS(server, true),
  ENDERMEN_TARGET_IMPORTANT_BLOCKS(server, true),
  LANDMINES(server, true),
  MOSTLY_REMOVE_SQUIDS(server, false),
  TALL_LANDS(server, false),
  REMOVE_TOOLTIP_BACKGROUNDS(client, true),
  NO_SLOT_HIGHLIGHT(client, false),
  OFFSET_SLOT_HIGHLIGHT(client, true),
  WILD_TAMED_ANIMALS(server, true),
  LLAMA_SPIT_LAUNCH(server, true),
  IRON_GOLEM_EXTENDED_REACH(server, true),
  IRON_GOLEM_SPACE_PROGRAM(server, true),
  NERVOUS_HORSES(server, true),
  SHULKER_MACHINE_GUNS(server, true),
  SKELETON_SHOTGUNS(server, false),
  FIFTY_SKELETON_HORSES(server, true),
  CHICKENS_V2(server, true),
  LAVA_FLOWS_FAST(server, true),
  FLYING_SQUIDS(server, true),
  NEUTRAL_LEVITATION(both, true),
  CREEPERS_IGNORE_CATS(server, true),
  FURNACES_LITERALLY(server, true),
  FLETCHING_TABLES_SHOOT(server, true),
  SHULKERS_SHOOT_CLOSED(server, true),
  UNBREAKING_ELYTRA_FLIES_SLOWER(both, true),
//  END_SOUL_SAND_AND_BASALT_DELTAS(server, true),
  ENDER_PEARLS_MOVE_SLOWLY(both, true),
  SKELETON_DODGING(server, false),
  HISSBINES(server, true),
//  INCREASED_PLAYER_HEIGHT(both, false),
  MONSTERS_WITH_HELMETS(server, true),
  SMALLER_BABY_ZOMBIES(both, false),
  BLAZE_MACHINE_GUNS(server, true),
  NETHERITE_WITHER_SKELETONS(server, false),
  SHORT_WITHER_SKELETON_HITBOX(both, true),
  MOBS_DONT_DAMAGE_HELMETS(server, true),
  MOB_ARMOR_BINDING_CURSE(server, true),
  NO_OFFHAND_KEY(client, false),
  MORE_LIGHTNING(server, true),
  MORE_THUNDERSTORMS(server, true),
  NAUSEA_INVERTED_MOVEMENT(client, true),
  WITCHES_THROW_LINGERING(server, true),
  WITCHES_THROW_DIFFERENT_POTIONS(server, true),
//  MORE_WITCH_SPAWNS(server, true),
  BOILING_NETHER_WATER_CAULDRONS(server, true),
  SUPER_SURGE_CONDUCTOR(server, true),
  SUN_GLARE(client, true),
  SOLIDIFYING_LAVA(server, true),
  COPPER_GOLEM_LIGHTNING(server, true),
  TIMID_SHEEP(server, true),
  NO_STRING_WOOL(server, true),
  LOUD_LEAF_LITTER(both, true),
  VAULTS_DISPENSE_MOBS(server, true),
  THUNDERSTORM_SCREW_YOU_IN_PARTICULAR(server, true),
  FAST_WARDEN(server, true),
  FOXES_SCAN_INVENTORIES(server, true),
  CAVE_FLOWER_HAYFEVER(server, true),
  CATS_SCAN_INVENTORIES(server, true),
  SAME_SIZE_SLIMES(server, true),
  SHY_FURNACES(server, false),
  DISAPPEARING_CATS(server, false),
  WARDEN_SIGHT(server, true),
  GLOW_SQUIDS_HATCH_SILVERFISH(server, false),
  NO_VIBRATION_OCCLUDING(server, true),
  WILDER_WOLVES(server, true),
  CHANGE_PIGLIN_BARTER_LOOT(server, true),
  SMART_BLOCK_DROPS(server, true),
  WORSE_ORES_AND_INGOTS(server, false),
  FURNACE_OUTPUT_SINGLETON(server, false),
  FURNACE_PLACEMENT_FLIPPED(server, true),
  RANDOM_PLACEMENT_DIRECTIONS(server, false),
  RANDOM_CREEPER_HISS(client, false),
  MOB_CRITS(server, true),
  RANDOMIZE_HUNGER_ON_WAKE(server, true),
  LOUD_CAVE_SOUNDS(client, true),
  DAMAGED_CHEST_LOOT(server, true),
  POVERTY_VILLAGES(server, true),
  NETHER_ROOF_PROTECTION(server, true),
  BREAK_NETHER_COORDS(server, true),
  UNSTABLE_CREEPERS(server, true),
  HOT_ITEM_FIRE(server, true),
  FLOATING_FISH(server, true),
  ALWAYS_RAID(server, false),
  MOB_STACKS(server, true),
  SWAP_POTATOES(server, true),
  CREEPER_EXPLOSION_CHAIN(server, true),
  RAIN_SILVERFISH(server, true),
  SWAP_REGEN_WITHER(server, false),
  SWAP_REGEN_WITHER_VISUAL(client, false),
  CLOSE_THIRD_PERSON(client, false),
  NETHER_WATER(server, true),
  MIDDLE_LOG_BREAK_STRIP(server, false),
  MOBS_DRIVE_BOATS(server, true),
  CREEPER_IGNITE_FIRE_DAMAGE(server, true),
  LETHAL_POISON(server, true),
  ANTI_VEIN_MINER(server, false),
//  FRACTAL_END(server, false),
  EMPATHETIC_OBSIDIAN(server, true),
  ENDER_DRAGON_REQUIRES_MELEE(server, true),
  TOUCHY_MENUS(client, true),
  FISHING(both, true),
  VILLAGER_CURING_NITWIT(server, true),
  AXE_SHEARING(server, true),
  STRIPPED_END_PORTAL(both, true),
  INVISIBLE_OBSIDIAN(client, false);

  private final String side;
  private final String name;
  private boolean value;
  Config(String side, boolean defaultValue) {
    this.side = side;
    this.name = this.name().toLowerCase(Locale.ROOT);
    this.value = defaultValue;
  }

  @Override
  public boolean get() {
    return this.value;
  }

  @Override
  public void set(boolean value) {
    this.value = value;
  }

  @Override
  public String getSide() {
    return this.side;
  }

  @Override
  public String getName() {
    return this.name;
  }

  private static void loadConfigFile(File configFile) throws RuntimeException, IOException {
    if (configFile.exists()) {

      try {

        FileReader fileReader = new FileReader(configFile);
        JsonObject jsonObject = JsonParser.parseReader(fileReader).getAsJsonObject();
        fileReader.close();

        all.forEach(property -> property.setFrom(jsonObject));

      } catch (Exception e) {
        throw new RuntimeException("AMTJMTGMA config failed to load.", e);
      }

    } else {

      LogUtils.getLogger().info("Creating new AMTJMTGMA config");

      configFile.getParentFile().mkdirs();
      configFile.createNewFile();

    }

    JsonObject configObject = new JsonObject();
    forEach(property -> property.storeTo(configObject));

    FileWriter writer = new FileWriter(configFile);
    writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(configObject));
    writer.close();

  }

  @ApiStatus.Internal
  public static void loadConfig() throws RuntimeException, IOException {
    LogUtils.getLogger().info("Loading AMTJMTGMA config");
    loadConfigFile(FabricLoader.getInstance().getConfigDir().resolve("a_mod_that_just_makes_the_game_more_annoying.json").toFile());
  }

  private static final List<ConfigProperty> all = new ArrayList<>(List.of(values()));

  public static void forEach(Consumer<ConfigProperty> consumer) {
    all.forEach(consumer);
  }

  public static ConfigProperty register(String side, String name, boolean defaultValue) {
    ConfigProperty configProperty = new ConfigProperty() {
      private boolean value = defaultValue;

      @Override
      public boolean get() {
        return this.value;
      }

      @Override
      public void set(boolean value) {
        this.value = value;
      }

      @Override
      public String getSide() {
        return side;
      }

      @Override
      public String getName() {
        return name;
      }
    };
    all.add(configProperty);
    return configProperty;
  }

}
