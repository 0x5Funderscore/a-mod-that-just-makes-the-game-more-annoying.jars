package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.nameless_deity;

import com.mojang.math.Transformation;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.bossevents.CustomBossEvent;
import net.minecraft.server.bossevents.CustomBossEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.hurtingprojectile.SmallFireball;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Range;
import org.joml.AxisAngle4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;

import java.util.List;
import java.util.function.Consumer;


public class NamelessDeity {
  // 20 armour, 8 toughness
  // maximum player expectation: 38.4 DPS
  // approximate: 20 DPS

  private static final Identifier BOSS_BAR_ID = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "nameless_deity");
  private static final int MAX_HEALTH = 3000;

  private @NotNull ServerLevel level;
  private @Nullable LivingEntity entity;

  @Range(from = -1, to = 2)
  private int phase = 0;
  private int subphase = -1;

  private Attack attack;
  private int nextAttackTime;
  private boolean reachedFinalAttack = false;

//  private static final Object2IntArrayMap<String> attackNames = new Object2IntArrayMap<>(
//      ImmutableMap.<String,Integer>builder()
//          .put("starburst", 0)
//          .put("starburst_ring", 1)
//          .build()
//  );

  private static final @NotNull Attack @NotNull [] @NotNull [] attacks = new Attack[][]{
      new Attack[]{
          Attack.STARBURST,
          Attack.DIMENSIONAL_SLASHES,
          Attack.STARBURST_RING,
          Attack.CAMELLIA_BURSTS,
          Attack.STARBURST,
          Attack.COLLAPSING_STAR,
          Attack.STARBURST,
          Attack.CAMELLIA_BURSTS
      },
      new Attack[]{
          Attack.JUDGEMENT_CUT,
          Attack.REALITY_SHATTER_PUNCHES,
          Attack.SOLAR_SPARKS,
          Attack.ORIONS_SWORD,
          Attack.CONVERGING_SUPERNOVA,
          Attack.REALITY_SHATTER_PUNCHES,
          Attack.SOLAR_SPARKS,
          Attack.COLLAPSING_STAR,
          Attack.ORIONS_SWORD,
          Attack.CONVERGING_SUPERNOVA
      },
      new Attack[]{
          Attack.LIGHT_SLASHES,
          Attack.CHRONOS_HAND,
          Attack.ORIONS_SWORD,
          Attack.NEBULA_GIGABEAM,
          Attack.MOMENT_OF_CREATION
      }
  };

  public static @NotNull LivingEntity createEntity(@NotNull ServerLevel level, @NotNull Vec3 pos) {
    LivingEntity entity = EntityTypes.VEX.create(level, new EntitySpawnRequest(EntitySpawnReason.MOB_SUMMONED, true));
    if (entity == null) throw new NullPointerException("failed to create nameless deity boss entity");
    level.addFreshEntity(entity);
    entity.setPos(pos);
    return entity;
  }

  public NamelessDeity(@NotNull ServerLevel level, @NotNull Vec3 pos) {
    this(createEntity(level, pos), level, false);
  }

  public NamelessDeity(@NotNull LivingEntity entity) {
    this(entity, (ServerLevel)entity.level(), true);
  }

  public NamelessDeity(@NotNull LivingEntity entity, @NotNull ServerLevel level, boolean loadFromTags) {
    this.entity = entity;
    this.level = level;
    if (loadFromTags) this.loadFromTags();
    this.applyAttributes();
    this.createPassengers();
    if (!loadFromTags) this.applyTags();
  }

  private @NotNull AttributeInstance requireAttribute(Holder<Attribute> attribute) {
    if (this.entity == null) throw new NullPointerException("entity is null");
    AttributeInstance attributeInstance = this.entity.getAttribute(attribute);
    if (attributeInstance == null) throw new NullPointerException("attribute not found: " + attribute.value().getDescriptionId());
    return attributeInstance;
  }

  public void applyAttributes() {
    if (this.entity == null) return;

    requireAttribute(Attributes.SCALE).setBaseValue(2.0d);
    requireAttribute(Attributes.FOLLOW_RANGE).setBaseValue(256.0d);
    requireAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(10.0d);
    requireAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0d);
    requireAttribute(Attributes.ARMOR).setBaseValue(20.0d);
    requireAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(8.0d);
    requireAttribute(Attributes.MAX_HEALTH).setBaseValue(MAX_HEALTH);
    entity.setHealth(MAX_HEALTH);
    entity.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
    entity.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);

    //
  }

  public void loadFromTags() {
    if (this.entity == null) return;
    this.phase = -1;
    this.subphase = -1;
    this.nextAttackTime = 0;
    this.entity.entityTags().forEach(tag -> {
      if (tag.startsWith("nameless_deity.phase.")) {
        try {
          int p = Integer.parseUnsignedInt(tag.substring(11));
          if (p >= 0 && p <= 2) {
            this.phase = p;
          }
        } catch (NumberFormatException ignored) {}
      } else if (tag.startsWith("nameless_deity.subphase.")) {
        try {
          this.subphase = Integer.parseUnsignedInt(tag.substring(14));
        } catch (NumberFormatException ignored) {}
      } else if (tag.startsWith("nameless_deity.cooldown.")) {
        try {
          this.nextAttackTime = Integer.parseUnsignedInt(tag.substring(14));
        } catch (NumberFormatException ignored) {}
      }
    });
    this.subphase %= attacks[this.phase].length;
    this.attack = attacks[this.phase][this.subphase];
  }

  public void applyTags() {
    if (this.entity == null) return;
    this.entity.entityTags().clear();
    this.entity.addTag("nameless_deity");
    if (this.phase >= 0) this.entity.addTag("nameless_deity.phase." + this.phase);
    if (this.subphase >= 0) this.entity.addTag("nameless_deity.subphase." + this.subphase);
    if (this.nextAttackTime >= 0) this.entity.addTag("nameless_deity.cooldown." + this.nextAttackTime);
  }

  private void createPassengersOnly(@NotNull LivingEntity entity) {
    //
  }

  public void createPassengers() {
    if (this.entity == null) return;
    this.entity.getPassengers().forEach(Entity::discard);
    this.createPassengersOnly(this.entity);
    this.tickPassengers();
  }

  public void tickPassengers() {
    if (this.entity == null) return;
  }

  public static void globalTickServer(ServerLevel level) {
    Attack.globalTick(level);
  }

  public void tickServer(ServerLevel level) {
    CustomBossEvents customBossEvents = level.getServer().getCustomBossEvents();
    CustomBossEvent bossBar = customBossEvents.get(BOSS_BAR_ID);

    if (this.entity == null || this.entity.isDeadOrDying() || this.entity.isRemoved()) {
      if (bossBar != null) customBossEvents.remove(bossBar);
      if (this.entity != null) {
        this.entity.discard();
        this.entity = null;
      }
      return;
    }

    if (bossBar == null) {
      bossBar = customBossEvents.create(level.getRandom(), BOSS_BAR_ID, Component.literal("Nameless Deity of Light"));
      bossBar.setMax(MAX_HEALTH);
    }
    bossBar.setOverlay(BossEvent.BossBarOverlay.PROGRESS);
    bossBar.setValue((int)this.entity.getHealth());

    this.tickAttack();
    this.tickPassengers();
    this.applyTags();
  }

  public void tickAttack() {
    if (this.entity == null || this.entity.isDeadOrDying() || this.entity.isRemoved()) return;
    if (this.phase < 0) return;

    this.nextAttackTime--;
    if (this.nextAttackTime <= 0) {

      if (this.attack != null) this.attack.end(this);

      int nextPhase = this.calculateNextPhase();
      if (nextPhase != this.phase) {
        this.phase = nextPhase;
        this.subphase = 0;

        if (this.phase < 0) {
          this.attack = null;
          this.nextAttackTime = Integer.MAX_VALUE;
          return;
        }

      } else {

        if (this.phase == 2 && !this.reachedFinalAttack && this.entity.getHealth() <= 1.0f) {
          this.subphase = attacks[this.phase].length - 1;
        } else {
          this.subphase++;
        }

      }

      this.subphase %= attacks[this.phase].length;
      this.attack = attacks[this.phase][this.subphase];

      this.nextAttackTime = this.attack.duration();
      this.attack.start(this);
    } else {
      this.attack.tick(this);
    }
  }

  public int calculateNextPhase() {
    if (this.entity == null || this.entity.isDeadOrDying() || this.entity.isRemoved()) return -1;
    float health = this.entity.getHealth();
    if (health == 0.0f) return -1;
    if (health > MAX_HEALTH * 0.65f) return 0;
    if (health > MAX_HEALTH * 0.3f) return 1;
    return 2;
  }

  public int getPhase() {
    return this.phase;
  }

  public Attack getAttack() {
    return this.attack;
  }

  public @Nullable LivingEntity getEntity() {
    return this.entity == null || this.entity.isRemoved() ? null : this.entity;
  }

  public boolean hasReachedFinalAttack() {
    return this.reachedFinalAttack;
  }

  public enum Attack {
    STARBURST(
        100,
        (body) -> {
          if (body.entity == null) return;
//          int progress = 100 - body.nextAttackTime;

          Player nearestPlayer = body.level.getNearestPlayer(TargetingConditions.forCombat(), body.entity);
          if (nearestPlayer != null) {

            Vec3 eyePos = body.entity.getEyePosition();
            Vec3 direction = nearestPlayer.getEyePosition().subtract(eyePos).normalize();
            Vec2 rotation = direction.rotation();

            float radius = 2.5f;
            for (int i = 0; i < 8; i++) {

              float ringAngle = i / 8f * Mth.TWO_PI;
              Vector3f offset = new Vector3f(0f, radius, 0f)
                  .rotateZ(ringAngle)
                  .rotateX(rotation.x * Mth.PI / 180f)
                  .rotateY(rotation.y * Mth.PI / 180f);

              SmallFireball fireball = new SmallFireball(body.level, body.entity, direction);
              fireball.setPos(eyePos.add(offset.x, offset.y, offset.z));
              body.level.addFreshEntity(fireball);

            }

            float bigRadius = 4.0f;
            float smallRadius = 1.0f;
            for (int i = 0; i < 6; i++) {

              float bigAngle = i / 6f * Mth.TWO_PI;
              Vector3f ringCenter = new Vector3f(0f, bigRadius, 0f)
                  .rotateZ(bigAngle)
                  .rotateX(rotation.x * Mth.PI / 180f)
                  .rotateY(rotation.y * Mth.PI / 180f);

              for (int j = 0; j < 4; j++) {
                float smallAngle = i / 4f * Mth.TWO_PI;
                Vector3f smallOffset = new Vector3f(0f, smallRadius, 0f)
                    .rotateZ(smallAngle)
                    .rotateX(rotation.x * Mth.PI / 180f)
                    .rotateY(rotation.y * Mth.PI / 180f);

                Attack.blueBolt(body.level).snapTo(eyePos.add(ringCenter.x, ringCenter.y, ringCenter.z).add(smallOffset.x, smallOffset.y, smallOffset.z), 0f, 90f);
              }

            }

          }
        },
        null,
        null,
        (level) -> level
            .getEntities(
                EntityTypeTest.forExactClass(Display.ItemDisplay.class),
                display -> display.entityTags().contains("nameless_deity.blue_bolt")
            )
            .forEach(display -> {

              double speed = 0.1d;
              for (String tag: display.entityTags()) {
                if (tag.startsWith("nameless_deity.blue_bolt.speed.")) {
                  try {
                    speed = Math.max(speed, Double.parseDouble(tag.substring(31)));
                    break;
                  } catch (NumberFormatException ignored) {}
                }
              }
              display.entityTags().removeIf(tag -> tag.startsWith("nameless_deity.blue_bolt.speed."));
              speed += 0.005d;
              display.addTag("nameless_deity.blue_bolt.speed." + speed);

              Vec3 direction = display.getLookAngle().normalize();

              Player nearestPlayer = level.getNearestPlayer(display.getX(), display.getY(), display.getZ(), 64d, true);
              if (nearestPlayer != null) {
                Vec3 offset = nearestPlayer.getEyePosition().subtract(display.position()).scale(1d / speed);
                if (offset.lengthSqr() > 1f) direction = offset.normalize();
                else direction = offset;
              }

              Vec3 nextPosition = display.position().add(direction.scale(speed));

              EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(
                  level,
                  display,
                  display.position(), nextPosition,
                  new AABB(display.position(), nextPosition),
                  EntitySelector.LIVING_ENTITY_STILL_ALIVE.and(EntitySelector.NO_CREATIVE_OR_SPECTATOR),
                  0.6f
              );
              if (entityHit != null) {
                entityHit.getEntity().hurtServer(level, level.damageSources().lightningBolt(), 1.0f);
                display.discard();
              } else {
                direction = direction.normalize();
                display.setPos(nextPosition);
                display.lookAt(EntityAnchorArgument.Anchor.FEET, nextPosition.add(direction));
              }
            })
    ),

    STARBURST_RING(
        0,
        null,
        null,
        null,
        null
    ),

    DIMENSIONAL_SLASHES(
        0,
        null,
        null,
        null,
        null
    ),

    CAMELLIA_BURSTS(
        0,
        null,
        null,
        null,
        null
    ),

    COLLAPSING_STAR(
        0,
        null,
        null,
        null,
        null
    ),

    JUDGEMENT_CUT(
        0,
        null,
        null,
        null,
        null
    ),

    REALITY_SHATTER_PUNCHES(
        0,
        null,
        null,
        null,
        null
    ),

    SOLAR_SPARKS(
        0,
        null,
        null,
        null,
        null
    ),

    ORIONS_SWORD(
        0,
        null,
        null,
        null,
        null
    ),

    CONVERGING_SUPERNOVA(
        0,
        null,
        null,
        null,
        null
    ),

    LIGHT_SLASHES(
        0,
        null,
        null,
        null,
        null
    ),

    CHRONOS_HAND(
        0,
        null,
        null,
        null,
        null
    ),

    NEBULA_GIGABEAM(
        0,
        null,
        null,
        null,
        null
    ),

    MOMENT_OF_CREATION(
        0,
        (body) -> {
          body.reachedFinalAttack = true;
        },
        null,
        null,
        null
    ),
    ;

    private static Display blueBolt(ServerLevel level) {
      Display.ItemDisplay itemDisplay = new Display.ItemDisplay(EntityTypes.ITEM_DISPLAY, level);
      level.addFreshEntity(itemDisplay);
      ItemStack itemStack = new ItemStack(Items.BREEZE_ROD, 1);
      itemStack.applyComponents(DataComponentPatch.builder().set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true).build());
      itemDisplay.setItemStack(itemStack);
      itemDisplay.setItemTransform(ItemDisplayContext.FIXED);
      itemDisplay.setPosRotInterpolationDuration(1);
      itemDisplay.setTransformation(
          new Transformation(
              new Vector3f(),
              new Quaternionf(new AxisAngle4f(Mth.PI / -4f, 0f, 1f, 0f)),
              new Vector3f(1f),
              new Quaternionf(new AxisAngle4f(Mth.HALF_PI, 1f, 0f, 0f))
          )
      );
      return itemDisplay;
    }

    private final int duration;
    private final @Nullable Consumer<NamelessDeity> start;
    private final @Nullable Consumer<NamelessDeity> tick;
    private final @Nullable Consumer<NamelessDeity> end;
    private final @Nullable Consumer<ServerLevel> globalTick;

    Attack(int duration, @Nullable Consumer<NamelessDeity> start, @Nullable Consumer<NamelessDeity> tick, @Nullable Consumer<NamelessDeity> end, @Nullable Consumer<ServerLevel> globalTick) {
      this.duration = duration;
      this.start = start;
      this.tick = tick;
      this.end = end;
      this.globalTick = globalTick;
    }

    public void start(NamelessDeity body) {
      if (this.start != null) this.start.accept(body);
    }

    public void tick(NamelessDeity body) {
      if (this.tick != null) this.tick.accept(body);
    }

    public void end(NamelessDeity body) {
      if (this.end != null) this.end.accept(body);
    }

    public static void globalTick(ServerLevel level) {
      for (Attack attack: values()) {
        if (attack.globalTick != null) attack.globalTick.accept(level);
      }
    }

    public int duration() {
      return this.duration;
    }
  }
}
