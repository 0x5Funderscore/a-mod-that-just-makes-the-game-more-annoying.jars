package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.hissbines;

import com.mojang.math.Transformation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.MultifaceBlock;
import net.minecraft.world.level.block.SupportType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.jspecify.annotations.NonNull;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;


public class Hissbine {

  public static final float MAX_TARGET_DISTANCE = 24.0f;
  public static final double PROJECTILE_FOLLOW_DISTANCE = 256.0d;
  public static final double PROJECTILE_SPEED = 0.05d;
  public static final int SHOOT_DELAY = 160;

  public enum DangerLevel {
    NORMAL(0.4f, 0.7f, 0.3f),
    DULL(0.6f, 0.6f, 0.2f),
    VIBRANT(0.8f, 0.3f, 0.2f);

    public final float r;
    public final float g;
    public final float b;

    DangerLevel(float r, float g, float b) {
      this.r = r;
      this.g = g;
      this.b = b;
    }
  }

  public final @NotNull Direction direction;
  public final @NotNull ServerLevel level;
  public final @NotNull BlockPos pos;
  public final @NotNull Display.BlockDisplay seagrass;
  public @Nullable Display.BlockDisplay coralFan;
  public @Nullable Display.BlockDisplay crimsonRoots;

  public final DangerLevel dangerLevel = DangerLevel.NORMAL;
  public final @NotNull HashSet<Vec3> projectiles;
  public int cooldown;

  public static @Nullable Hissbine createAutoDirection(BlockPos pos, ServerLevel level) {
    BlockState insideState = level.getBlockState(pos);
    if (insideState.isAir() || insideState.canBeReplaced() || insideState.is(Blocks.GLOW_LICHEN)) {
      Direction inwardDirection = getAutoDirection(pos, level);
      Direction outwardDirection = inwardDirection.getOpposite();
      if (!insideState.is(Blocks.GLOW_LICHEN)) insideState = Blocks.GLOW_LICHEN.defaultBlockState();
      insideState = insideState.setValue(MultifaceBlock.getFaceProperty(inwardDirection), true);
      level.setBlockAndUpdate(pos, insideState);
      return Hissbine.create(pos, outwardDirection, level);
    } else {
      return null;
    }
  }

  public static void addHissbineBaseAutoDirection(BlockPos pos, ServerLevel level) {
    if (level.getEntities(EntityTypeTest.forExactClass(Display.BlockDisplay.class), AABB.encapsulatingFullBlocks(pos, pos), e -> e.entityTags().contains("hissbine")).isEmpty()) {
      Display.BlockDisplay seagrass = createSeagrassWithoutAdding(level);
      Direction direction = getAutoDirection(pos, level);
      boolean isVertical = direction.getAxis() == Direction.Axis.Y;
      seagrass.snapTo(Vec3.atCenterOf(pos), isVertical ? 0f : direction.toYRot(), isVertical ? (direction == Direction.UP ? 90f : -90f) : 0f);
      level.addFreshEntity(seagrass);
    }
  }

  private static Direction getAutoDirection(BlockPos pos, ServerLevel level) {
    Set<Direction> available = new HashSet<>();
    Set<Direction> prioritised = new HashSet<>();
    for (Direction direction: Direction.values()) {
      BlockPos sidedPos = pos.relative(direction);
      BlockState blockState = level.getBlockState(sidedPos);
      Direction opposite = direction.getOpposite();
      if (blockState.isFaceSturdy(level, sidedPos, opposite, SupportType.CENTER)) {
        available.add(direction);
        if (level.getBlockState(pos.relative(opposite)).isAir()) {
          prioritised.add(direction);
        }
      }
    }
    RandomSource randomSource = RandomSource.create();
    return prioritised
        .stream()
        .skip(prioritised.isEmpty() ? 0 : randomSource.nextInt(prioritised.size()))
        .findFirst()
        .orElseGet(() ->
            available
                .stream()
                .skip(available.isEmpty() ? 0 : randomSource.nextInt(available.size()))
                .findFirst()
                .orElseGet(() ->
                    Direction.getRandom(randomSource)
                )
        );
  }

  public static Hissbine create(BlockPos pos, Direction direction, ServerLevel level) {
    Display.BlockDisplay seagrass = createSeagrassWithoutAdding(level);
    boolean isVertical = direction.getAxis() == Direction.Axis.Y;
    seagrass.snapTo(Vec3.atCenterOf(pos), isVertical ? 0f : direction.toYRot(), isVertical ? (direction == Direction.UP ? 90f : -90f) : 0f);
    level.addFreshEntity(seagrass);
    return new Hissbine(seagrass, direction, pos, level);
  }

  public static @Nullable Hissbine maybeAttachEntity(Entity entity) {
    if (entity instanceof Display.BlockDisplay bd && entity.entityTags().contains("hissbine")) {
      Level lvl = bd.level();
      if (lvl instanceof ServerLevel serverLevel) {
        Direction dir = Direction.getApproximateNearest(bd.getLookAngle());
        BlockPos pos = bd.blockPosition();
        return new Hissbine(bd, dir, pos, serverLevel);
      }
    }
    return null;
  }

  public Hissbine(Display.@NonNull BlockDisplay seagrass, @NotNull Direction direction, @NotNull BlockPos pos, @NotNull ServerLevel level) {

    this.level = level;
    this.pos = pos;
    this.direction = direction;
    this.seagrass = seagrass;

    this.projectiles = seagrass.entityTags()
        .stream()
        .filter(tag -> tag.startsWith("hissbine.projectile_"))
        .map(str -> parseVec3(str.substring(20)))
        .collect(Collectors.toCollection(HashSet::new));

    this.cooldown = seagrass.entityTags()
        .stream()
        .filter(tag -> tag.matches("hissbine\\.cooldown\\.\\d+"))
        .findAny()
        .map(tag -> Integer.parseUnsignedInt(tag.substring(18)))
        .orElse(0);

  }

  private static @Nullable Vec3 parseVec3(String txt) {
    String[] parts = txt.split("_");
    if (parts.length != 3) return null;
    try {
      return new Vec3(Double.parseDouble(parts[0]), Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
    } catch (NumberFormatException e) {
      return null;
    }
  }

  private static String stringVec3(Vec3 vec) {
    return vec.x + "_" + vec.y + "_" + vec.z;
  }

  private void updateTags() {
    new HashSet<>(seagrass.entityTags()).forEach(tag -> {
      if (!tag.equals("hissbine")) seagrass.removeTag(tag);
    });
    this.projectiles.forEach(projectile -> seagrass.addTag("hissbine.projectile_" + stringVec3(projectile)));
    if (this.cooldown > 0) seagrass.addTag("hissbine.cooldown." + this.cooldown);
    seagrass.addTag("hissbine");
  }

  private static @NotNull Display.BlockDisplay createSeagrassWithoutAdding(ServerLevel level) {
    Display.BlockDisplay blockDisplay = new Display.BlockDisplay(EntityTypes.BLOCK_DISPLAY, level);
    blockDisplay.setBlockState(Blocks.SEAGRASS.defaultBlockState());
    blockDisplay.setTransformation(new Transformation(
        new Matrix4f()
            .translation(-0.5f, -0.5f, -0.5f)
            .rotateLocalY(Mth.PI / 4f)
            .rotateLocalX(Mth.HALF_PI)
    ));
    blockDisplay.setCustomName(Component.literal("Hissbine"));
    blockDisplay.addTag("hissbine");
    blockDisplay.addTag("hissbine_part");
    return blockDisplay;
  }

  private static @NotNull Display.BlockDisplay createCoralFan(ServerLevel level) {
    Display.BlockDisplay blockDisplay = new Display.BlockDisplay(EntityTypes.BLOCK_DISPLAY, level);
    blockDisplay.setBlockState(Blocks.FIRE_CORAL_FAN.defaultBlockState());
    blockDisplay.setTransformation(new Transformation(
        new Matrix4f()
            .translation(-0.5f, -0.5f, -0.5f)
            .rotateLocalX(Mth.HALF_PI)
    ));
    blockDisplay.addTag("hissbine_part");
    level.addFreshEntity(blockDisplay);
    return blockDisplay;
  }

  private static @NotNull Display.BlockDisplay createCrimsonRoots(ServerLevel level) {
    Display.BlockDisplay blockDisplay = new Display.BlockDisplay(EntityTypes.BLOCK_DISPLAY, level);
    blockDisplay.setBlockState(Blocks.CRIMSON_ROOTS.defaultBlockState());
    blockDisplay.setTransformation(new Transformation(
        new Matrix4f()
            .translation(-0.5f, -0.5f, -0.5f)
            .rotateLocalX(Mth.HALF_PI)
    ));
    blockDisplay.addTag("hissbine_part");
    level.addFreshEntity(blockDisplay);
    return blockDisplay;
  }

  private void updateBlockDisplays() {
    if (this.coralFan == null || this.coralFan.isRemoved()) {
      Entity seagrassPassenger = this.seagrass.getFirstPassenger();
      if (seagrassPassenger instanceof Display.BlockDisplay bd) this.coralFan = bd;
      else this.coralFan = createCoralFan(level);
    } else {
      if (this.coralFan.getVehicle() == null) {
        this.coralFan.snapTo(this.seagrass.blockPosition(), this.seagrass.getYRot(), this.seagrass.getXRot());
        this.coralFan.startRiding(this.seagrass);
      }

      if (this.crimsonRoots == null || this.crimsonRoots.isRemoved()) {
        Entity coralFanPassenger = this.coralFan.getFirstPassenger();
        if (coralFanPassenger instanceof Display.BlockDisplay bd) this.crimsonRoots = bd;
        else this.crimsonRoots = createCrimsonRoots(level);
      } else {
        if (this.crimsonRoots.getVehicle() == null) {
          this.crimsonRoots.snapTo(this.seagrass.blockPosition(), this.seagrass.getYRot(), this.seagrass.getXRot());
          this.crimsonRoots.startRiding(this.coralFan);
        }
      }
    }
  }

  public void sendParticles() {
    projectiles.forEach(vec -> level.sendParticles(
        new DustParticleOptions(ARGB.colorFromFloat(0f, dangerLevel.r, dangerLevel.g, dangerLevel.b), 2.0f),
        false,
        false,
        vec.x,
        vec.y,
        vec.z,
        3,
        0.1,
        0.1,
        0.1,
        0.1
    ));
  }

  public void tickProjectiles() {
    Set<Vec3> movedProjectiles = new HashSet<>();
    for (Vec3 vec: this.projectiles) {
      var collisionAABB = AABB.ofSize(vec, 0.5d, 0.5d, 0.5d);
      if (!level.noCollision(collisionAABB)) {
        level.playSound(null, vec.x, vec.y, vec.z, SoundEvents.SHULKER_BULLET_HIT, SoundSource.HOSTILE, 1f, 1.4f);
      } else {
        Player nearestPlayer = level.getNearestPlayer(vec.x, vec.y, vec.z, PROJECTILE_FOLLOW_DISTANCE, true);
        if (nearestPlayer != null) {
          Vec3 offset = nearestPlayer.getEyePosition().subtract(vec);
          if (offset.lengthSqr() <= 1d) {
            nearestPlayer.addEffect(new MobEffectInstance(MobEffects.POISON, 200, 1));
            nearestPlayer.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 200, 0));
            nearestPlayer.hurtServer(level, level.damageSources().indirectMagic(seagrass, seagrass), 2f);
            level.playSound(null, vec.x, vec.y, vec.z, SoundEvents.SHULKER_BULLET_HIT, SoundSource.HOSTILE, 1f, 1.4f);
          } else {
            Vec3 moved = vec.add(offset.normalize().scale(PROJECTILE_SPEED));
            movedProjectiles.add(moved);
          }
        }
      }
    }
    this.projectiles.clear();
    this.projectiles.addAll(movedProjectiles);
  }

  public void tick() {
    if (this.isRemoved()) return;

    if (this.cooldown > 0) this.cooldown--;
    else {
      Vec3 center = Vec3.atCenterOf(pos);
      if (level.getNearestPlayer(center.x, center.y, center.z, MAX_TARGET_DISTANCE, true) != null) {
        level.playSound(null, center.x, center.y, center.z, SoundEvents.SHULKER_BULLET_HURT, SoundSource.HOSTILE, 1f, 0.7f);
        this.projectiles.add(center);
        this.cooldown = SHOOT_DELAY;
      }
    }

    BlockState blockState = level.getBlockState(pos);
    if (!blockState.is(Blocks.GLOW_LICHEN)) this.remove();
    else if (!blockState.getValue(MultifaceBlock.getFaceProperty(direction.getOpposite()))) this.remove();
    else {
      this.updateBlockDisplays();
      this.updateTags();
      this.tickProjectiles();
      this.sendParticles();
    }
  }

  public void remove() {
    this.seagrass.remove(Entity.RemovalReason.DISCARDED);
    if (this.coralFan != null) this.coralFan.remove(Entity.RemovalReason.DISCARDED);
    if (this.crimsonRoots != null) this.crimsonRoots.remove(Entity.RemovalReason.DISCARDED);
    this.projectiles.clear();
    this.cooldown = 0;
  }

  public boolean isRemoved() {
    return this.seagrass.isRemoved();
  }

}
