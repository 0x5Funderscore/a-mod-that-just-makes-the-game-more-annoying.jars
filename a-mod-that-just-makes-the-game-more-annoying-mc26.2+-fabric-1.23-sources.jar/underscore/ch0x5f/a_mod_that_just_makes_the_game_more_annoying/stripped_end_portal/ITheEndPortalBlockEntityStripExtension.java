package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal;

import org.intellij.lang.annotations.MagicConstant;


public interface ITheEndPortalBlockEntityStripExtension {
  @MagicConstant(intValues = {StrippedEndPortalConstants.NORMAL, StrippedEndPortalConstants.STRIPPED, StrippedEndPortalConstants.FLATTENED}) byte getStripType();
  void setStripType(byte type);

  boolean strip();
  boolean flatten();
}
