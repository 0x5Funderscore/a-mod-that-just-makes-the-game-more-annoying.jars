package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal;

public final class StrippedEndPortalConstants {
  public static final byte NORMAL = 0;
  public static final byte STRIPPED = 1;
  public static final byte FLATTENED = 2;
}
