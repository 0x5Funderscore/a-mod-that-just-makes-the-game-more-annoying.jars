package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.break_nether_coords;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.NetherPortalBlock;
import net.minecraft.world.level.border.WorldBorder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(NetherPortalBlock.class)
public abstract class NetherPortalBlockMixin {

  @WrapOperation(method = "getPortalDestination", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/border/WorldBorder;clampToBounds(DDD)Lnet/minecraft/core/BlockPos;"))
  private BlockPos wrapClampToBounds(
      WorldBorder instance, double x, double y, double z,
      Operation<BlockPos> original,
      @Local(name = "teleportationScale") double teleportationScale,
//      @Local(name = "newWorldBorder") WorldBorder newWorldBorder,
      @Local(name = "newLevel") ServerLevel newLevel
  ) {
    if (Config.BREAK_NETHER_COORDS.get() && teleportationScale != 1.0d) {
      double rotation = teleportationScale - 1.0d;
      if (teleportationScale < 1.0d) rotation = 1.0d - 1.0d / teleportationScale;
      double rot0 = rotation;
      rotation *= (RandomSource.create(newLevel.getSeed() ^ 8452547821666288963L).nextDouble() + 0.125) * Math.TAU;
      float cos = Mth.cos(rotation);
      float sin = Mth.sin(rotation);
      return original.call(instance, x * cos - z * sin, y, z * cos + x * sin);
    }
    return original.call(instance, x, y, z);
  }

}
