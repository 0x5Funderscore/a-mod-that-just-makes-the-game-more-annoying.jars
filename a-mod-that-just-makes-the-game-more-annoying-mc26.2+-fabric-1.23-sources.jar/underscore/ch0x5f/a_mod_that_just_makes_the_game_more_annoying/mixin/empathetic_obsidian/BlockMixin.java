package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.empathetic_obsidian;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;


@Mixin(Block.class)
public abstract class BlockMixin {

  @Unique
  private static Collection<@NotNull BlockPos> rb$spreadNext(Block target, BlockGetter level, Collection<@NotNull BlockPos> next, Collection<@NotNull BlockPos> contents) {
    Set<BlockPos> next2 = new HashSet<>();
    for (BlockPos pos: next) {
      BlockState blockState = level.getBlockState(pos);
      if (blockState.is(target)) {
        contents.add(pos);
        for (Direction direction: Direction.values()) {
          BlockPos relative = pos.relative(direction);
          if (!contents.contains(relative)) next2.add(relative);
        }
      }
    }
    return next2;
  }

  @Unique
  private static Collection<@NotNull BlockPos> rb$spread(Block target, BlockGetter level, Collection<@NotNull BlockPos> next, int maxCount) {
    Set<BlockPos> contents = new HashSet<>();
    while (contents.size() < maxCount && !next.isEmpty()) {
      next = rb$spreadNext(target, level, next, contents);
    }
    return contents;
  }

  @Inject(method = "playerDestroy", at = @At("TAIL"))
  private void postPlayerDestroy(Level level, Player player, BlockPos pos, BlockState state, BlockEntity blockEntity, ItemStack destroyedWith, CallbackInfo ci) {
    if (Config.EMPATHETIC_OBSIDIAN.get() && state.is(Blocks.OBSIDIAN) && !level.isClientSide()) {
      Set<BlockPos> next = new HashSet<>();
      Vec3 center = Vec3.atCenterOf(pos);
      RandomSource random = level.getRandom();
      for (int i = 0; i < 8; i++) {
        Vec3 offset = new Vec3(random.nextGaussian(), random.nextGaussian(), random.nextGaussian()).scale(5.0);
        if (offset.length() > 16.0) offset = offset.normalize().scale(16.0);
        BlockHitResult clipped = level.clip(new ClipContext(center, center.add(offset), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, CollisionContext.empty()));
        if (clipped.getType() == HitResult.Type.BLOCK) {
          BlockPos hitPos = clipped.getBlockPos();
          if (level.getBlockState(hitPos).is(Blocks.OBSIDIAN)) {
            next.add(hitPos);
          }
        }
      }
      Collection<@NotNull BlockPos> positions = rb$spread(state.getBlock(), level, next, 256);
      BlockState replacementState = Blocks.CRYING_OBSIDIAN.defaultBlockState();
      positions.forEach(orePos -> level.setBlockAndUpdate(orePos, replacementState));
    }
  }

}
