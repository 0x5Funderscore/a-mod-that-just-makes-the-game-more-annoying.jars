package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.every_zombie_is_a_leader;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.world.entity.monster.zombie.Zombie;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Zombie.class)
public abstract class ZombieMixin {

  @Definition(id = "random", field = "Lnet/minecraft/world/entity/monster/zombie/Zombie;random:Lnet/minecraft/util/RandomSource;")
  @Definition(id = "nextFloat", method = "Lnet/minecraft/util/RandomSource;nextFloat()F")
  @Expression("this.random.nextFloat() < ?")
  @ModifyExpressionValue(method = "handleAttributes", at = @At("MIXINEXTRAS:EXPRESSION"))
  private boolean modifyLeaderCheck(boolean original) {
    if (!Config.EVERY_ZOMBIE_IS_A_LEADER.get()) return true;
    return original;
  }

}
