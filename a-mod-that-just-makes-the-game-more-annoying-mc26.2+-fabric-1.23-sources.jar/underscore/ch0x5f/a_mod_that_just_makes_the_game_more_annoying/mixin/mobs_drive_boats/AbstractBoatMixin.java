package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.mobs_drive_boats;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.vehicle.VehicleEntity;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractBoat.class)
public abstract class AbstractBoatMixin extends VehicleEntity {

  public AbstractBoatMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tick", at = @At("HEAD"))
  private void preTick(CallbackInfo ci) {
    if (Config.MOBS_DRIVE_BOATS.get() && !this.level().isClientSide()) {
      AbstractBoat boat = (AbstractBoat)(Object)this;

      LivingEntity controller = boat.getControllingPassenger();
      if (controller instanceof Mob mob) {

        PathNavigation navigation = mob.getNavigation();
        Path path = navigation.getPath();
//        LogUtils.getLogger().info("path: {}", path);
        if (path != null && path.getNodeCount() > path.getNextNodeIndex()) {

          BlockPos nextNodePos = path.getNextNodePos();
//          LogUtils.getLogger().info("node: {}", nextNodePos);
          Vec3 nextNodeOffset = Vec3.atBottomCenterOf(nextNodePos).subtract(boat.position());

          float targetYaw = nextNodeOffset.rotation().y;
          float yaw = boat.getYRot();
          float yawOffset = (targetYaw - yaw + 540f) % 360f - 180f;

//          LogUtils.getLogger().info("targetYaw: {}; yaw: {}; yawOffset: {}", targetYaw, yaw, yawOffset);
          if (Math.abs(yawOffset) < 15f) yawOffset = 0f;
          boat.deltaRotation += Math.copySign(1f, yawOffset);
          boolean paddleLeft = yawOffset > 0f;
          boolean paddleRight = yawOffset < 0f;

          float acceleration = yawOffset != 0f ? 0.005f : 0.0f;
          if (Math.abs(yawOffset) < 30f) {
            acceleration = 0.04f;
            paddleLeft = true;
            paddleRight = true;
          }

          boat.setYRot((boat.getYRot() + boat.deltaRotation) % 360f);
          boat.setDeltaMovement(boat.getDeltaMovement().add(Mth.sin(-boat.getYRot() * ((float)Math.PI / 180F)) * acceleration, 0.0F, Mth.cos(boat.getYRot() * ((float)Math.PI / 180F)) * acceleration));
          boat.setPaddleState(paddleLeft, paddleRight);
        }
      }
    }
  }

}
