package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.swap_potatoes;

import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.food.Foods;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

  @Inject(method = "inventoryTick", at = @At("TAIL"))
  private void postInventoryTick(Level level, Entity owner, EquipmentSlot slot, CallbackInfo ci) {
    if (Config.SWAP_POTATOES.get() && !level.isClientSide()) {
      ItemStack itemStack = (ItemStack)(Object)this;
      if (itemStack.is(Items.POTATO)) {
        Consumable consumable = itemStack.get(DataComponents.CONSUMABLE);
        if (!Consumables.POISONOUS_POTATO.equals(consumable)) {
          itemStack.applyComponents(DataComponentPatch.builder().set(DataComponents.CONSUMABLE, Consumables.POISONOUS_POTATO).set(DataComponents.FOOD, Foods.POISONOUS_POTATO).build());
        }
      } else if (itemStack.is(Items.POISONOUS_POTATO)) {
        Consumable consumable = itemStack.get(DataComponents.CONSUMABLE);
        if (Consumables.POISONOUS_POTATO.equals(consumable)) {
          itemStack.applyComponents(DataComponentPatch.builder().set(DataComponents.CONSUMABLE, Consumables.DEFAULT_FOOD).set(DataComponents.FOOD, Foods.POTATO).build());
        }
      }
    }
  }

}
