package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.poverty_villages;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.Container;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.storage.loot.LootTable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CTags;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(RandomizableContainer.class)
public interface RandomizableContainerMixin extends Container {

  @Inject(method = "unpackLootTable", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/storage/loot/LootTable;fill(Lnet/minecraft/world/Container;Lnet/minecraft/world/level/storage/loot/LootParams;J)V", shift = At.Shift.AFTER))
  private void afterLootTableFilled(
      Player player, CallbackInfo ci,
      @Local(name = "lootTableKey") ResourceKey<LootTable> lootTableKey
  ) {
    if (Config.POVERTY_VILLAGES.get() && lootTableKey.identifier().getPath().startsWith("chests/village/")) {
      this.forEach(itemStack -> {
        if (itemStack.has(DataComponents.FOOD) || itemStack.is(CTags.Items.foods) || itemStack.is(CTags.Items.Gems.emerald)) itemStack.setCount(0);
      });
    }
  }

}
