package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.ender_dragon_requires_melee;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.EnderDragonPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderDragon.class)
public abstract class EnderDragonMixin {

  @Inject(method = "hurt(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/boss/enderdragon/EnderDragonPart;Lnet/minecraft/world/damagesource/DamageSource;F)Z", at = @At("HEAD"), cancellable = true)
  private void preHurt(ServerLevel level, EnderDragonPart part, DamageSource source, float damage, CallbackInfoReturnable<Boolean> cir) {
    if (Config.ENDER_DRAGON_REQUIRES_MELEE.get() && !(source.is(DamageTypes.PLAYER_ATTACK) || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY))) {
      cir.setReturnValue(false);
      cir.cancel();
    }
  }

}
