package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.nether_water;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InsideBlockEffectApplier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.material.WaterFluid;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(WaterFluid.class)
public abstract class WaterFluidMixin {

  @ModifyReturnValue(method = "getDropOff", at = @At("RETURN"))
  private int replaceDropOff(
      int original,
      @Local(name = "level", argsOnly = true) LevelReader level
  ) {
    if (Config.NETHER_WATER.get() && rb$isSlowWater(level)) {
      return original * 2;
    }
    return original;
  }

  @ModifyReturnValue(method = "getTickDelay", at = @At("RETURN"))
  private int replaceTickDelay(
      int original,
      @Local(name = "level", argsOnly = true) LevelReader level
  ) {
    if (Config.NETHER_WATER.get() && rb$isSlowWater(level)) {
      return original * 6;
    }
    return original;
  }

  @ModifyReturnValue(method = "getSlopeFindDistance", at = @At("RETURN"))
  private int replaceSlopeFindDistance(
      int original,
      @Local(name = "level", argsOnly = true) LevelReader level
  ) {
    if (Config.NETHER_WATER.get() && rb$isSlowWater(level)) {
      return original / 2;
    }
    return original;
  }

  @Inject(method = "entityInside", at = @At("HEAD"))
  private void preEntityInside(Level level, BlockPos pos, Entity entity, InsideBlockEffectApplier effectApplier, CallbackInfo ci) {
    if (rb$isHotWater(level) && level instanceof ServerLevel serverLevel) {
      if (entity.tickCount % 4 == 0) {
        float bbw = entity.getBbWidth();
        serverLevel.sendParticles(ParticleTypes.BUBBLE_COLUMN_UP, false, false, entity.getX(), entity.getY(), entity.getZ(), 4, bbw / 3f, 0.0, bbw / 3f, 0.01);
      }
      entity.hurtServer(serverLevel, serverLevel.damageSources().inFire(), 1.0f);
    }
  }

  @Unique
  private static boolean rb$isSlowWater(final LevelReader level) {
    return !level.isClientSide() && level.environmentAttributes().getDimensionValue(EnvironmentAttributes.FAST_LAVA);
  }

  @Unique
  private static boolean rb$isHotWater(final LevelReader level) {
    return !level.isClientSide() && level.environmentAttributes().getDimensionValue(EnvironmentAttributes.WATER_EVAPORATES);
  }

}
