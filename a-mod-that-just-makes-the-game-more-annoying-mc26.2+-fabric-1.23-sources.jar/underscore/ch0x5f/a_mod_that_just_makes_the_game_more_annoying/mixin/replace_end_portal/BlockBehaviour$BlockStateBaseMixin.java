package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_portal;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class BlockBehaviour$BlockStateBaseMixin {

  @ModifyReturnValue(method = "getDestroySpeed", at = @At("TAIL"))
  private float modifyDestroySpeed(
      float original,
      @Local(name = "level", argsOnly = true) BlockGetter level,
      @Local(name = "pos", argsOnly = true) BlockPos pos
  ) {
    if (Config.REPLACE_END_PORTAL.get() && level.getBlockState(pos).is(Blocks.END_PORTAL_FRAME)) {
      return 10.0f;
    }
    return original;
  }

}
