package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.sweeping_damages_self;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Player.class)
public abstract class PlayerMixin {

  @Definition(id = "nearby", local = @Local(type = LivingEntity.class, name = "nearby"))
  @Expression("nearby != this")
  @WrapOperation(method = "doSweepAttack", at = @At("MIXINEXTRAS:EXPRESSION"))
  private boolean allowSelfAttacking(Object left, Object right, Operation<Boolean> original) {
    if (!Config.SWEEPING_DAMAGES_SELF.get()) return original.call(left, right);
    return true;
  }

  @WrapOperation(
      method = "doSweepAttack",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/entity/player/Player;isAlliedTo(Lnet/minecraft/world/entity/Entity;)Z"
      )
  )
  private boolean modifyAlliedTo(Player instance, Entity entity, Operation<Boolean> original) {
    return original.call(instance, entity) || (instance == entity && Config.SWEEPING_DAMAGES_SELF.get());
  }

}
