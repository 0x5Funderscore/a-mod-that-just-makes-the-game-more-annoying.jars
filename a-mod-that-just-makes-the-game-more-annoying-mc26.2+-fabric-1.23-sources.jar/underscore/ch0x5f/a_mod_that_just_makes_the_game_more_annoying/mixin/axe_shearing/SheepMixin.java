package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.axe_shearing;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.sheep.Sheep;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Sheep.class)
public abstract class SheepMixin extends Animal {

  protected SheepMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @WrapOperation(method = "mobInteract", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Ljava/lang/Object;)Z"))
  private boolean wrapIsShears(ItemStack instance, Object o, Operation<Boolean> original) {
    if (this.level() instanceof ServerLevel && Config.AXE_SHEARING.get()) {
      return instance.is(ItemTags.AXES);
    } else {
      return original.call(instance, o);
    }
  }

}
