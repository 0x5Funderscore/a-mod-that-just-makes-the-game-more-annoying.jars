package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.villager_curing_nitwit;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.monster.zombie.ZombieVillager;
import net.minecraft.world.entity.npc.villager.VillagerData;
import net.minecraft.world.entity.npc.villager.VillagerProfession;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ZombieVillager.class)
public abstract class ZombieVillagerMixin extends Zombie {

  public ZombieVillagerMixin(EntityType<? extends Zombie> type, Level level) {
    super(type, level);
  }

  @ModifyArg(method = "lambda$finishConversion$0", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/npc/villager/Villager;setVillagerData(Lnet/minecraft/world/entity/npc/villager/VillagerData;)V"))
  private VillagerData modifyVillagerData(VillagerData data) {
    if (Config.VILLAGER_CURING_NITWIT.get()) {
      return data.withProfession(this.level().registryAccess(), VillagerProfession.NITWIT);
    }
    return data;
  }

}
