package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.foxes_scan_inventories;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.fox.Fox;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Fox.class)
public abstract class FoxMixin {

  @Unique
  private static boolean rb$hasFood(ServerPlayer player) {
    return player.getInventory().contains(ItemTags.FOX_FOOD);
  }

  @ModifyArgs(method = "registerGoals", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/goal/target/NearestAttackableTargetGoal;<init>(Lnet/minecraft/world/entity/Mob;Ljava/lang/Class;IZZLnet/minecraft/world/entity/ai/targeting/TargetingConditions$Selector;)V"))
  private void modifyNearestAttackableTargetArgs(Args args) {
    if (Config.FOXES_SCAN_INVENTORIES.get() && args.get(1) == Animal.class) {
      LivingEntity self = args.get(0);
      TargetingConditions.Selector originalSelector = args.get(5);
      TargetingConditions playerPreTargeter = TargetingConditions.forCombat();
      args.set(1, LivingEntity.class);
      args.set(5, (TargetingConditions.Selector)((target, level) -> originalSelector.test(target, level) || playerPreTargeter.test(level, self, target) && target instanceof ServerPlayer serverPlayer && rb$hasFood(serverPlayer)));
    }
  }

  @ModifyReturnValue(method = "trusts", at = @At("TAIL"))
  private boolean modifyTrust(
      boolean original,
      @Local(name = "entity", argsOnly = true) LivingEntity entity
  ) {
    if (Config.FOXES_SCAN_INVENTORIES.get() && !original && entity instanceof ServerPlayer serverPlayer) {
      if (rb$hasFood(serverPlayer)) {
        return true;
      }
    }
    return original;
  }

}
