package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.thunderstorm_screw_you_in_particular;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.saveddata.WeatherData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.HashMap;
import java.util.Map;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Unique
  private final Map<EquipmentSlot,Boolean> rb$trackedEquippedCopper = new HashMap<>(Map.of(
      EquipmentSlot.FEET, true,
      EquipmentSlot.LEGS, true,
      EquipmentSlot.CHEST, true,
      EquipmentSlot.HEAD, true
  ));

  @Unique
  private int rb$screwYouLightningTimer = -1;

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (!Config.THUNDERSTORM_SCREW_YOU_IN_PARTICULAR.get()) return;
    if (this.tickCount > 8) {
      boolean canLightning = this.level().canSeeSky(this.blockPosition()) && this.level().canHaveWeather();
      if (rb$screwYouLightningTimer >= 0) {
        rb$screwYouLightningTimer++;
        if (rb$screwYouLightningTimer >= 200) {
          rb$screwYouLightningTimer = -1;
        } else if (rb$screwYouLightningTimer == 100 && canLightning && rb$trackedEquippedCopper.containsValue(Boolean.TRUE)) {
          LightningBolt lb = new LightningBolt(EntityTypes.LIGHTNING_BOLT, this.level());
          lb.setPos(this.position());
          this.level().addFreshEntity(lb);
        }
      }
      if (canLightning && this.level().getGameRules().get(GameRules.ADVANCE_WEATHER)) {
        ItemStack copperIngot = new ItemStack(Items.COPPER_INGOT);
        for (EquipmentSlot slot: rb$trackedEquippedCopper.keySet().toArray(EquipmentSlot[]::new)) {
          ItemStack itemInSlot = this.getItemBySlot(slot);
          boolean isCopper = itemInSlot.isValidRepairItem(copperIngot);
          boolean wasCopper = Boolean.TRUE.equals(rb$trackedEquippedCopper.put(slot, isCopper));
          if (rb$screwYouLightningTimer < 0 && isCopper && !wasCopper) {
            WeatherData weatherData = this.level().getWeatherData();
            weatherData.setClearWeatherTime(0);
            weatherData.setRainTime(Math.max(weatherData.isRaining() ? weatherData.getRainTime() : 0, 100));
            weatherData.setThunderTime(Math.max(weatherData.isThundering() ? weatherData.getThunderTime() : 0, 100));
            weatherData.setRaining(true);
            weatherData.setThundering(true);
            rb$screwYouLightningTimer = 0;
          }
        }
      }
    }
  }

}
