package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.stripped_end_portal;

import net.minecraft.world.level.block.entity.TheEndPortalBlockEntity;
import org.intellij.lang.annotations.MagicConstant;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.ITheEndPortalBlockEntityStripExtension;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.StrippedEndPortalConstants;


@Mixin(TheEndPortalBlockEntity.class)
@Implements(@Interface(iface = ITheEndPortalBlockEntityStripExtension.class, prefix = "i$"))
public abstract class TheEndPortalBlockEntityMixin {

  @MagicConstant(intValues = {StrippedEndPortalConstants.NORMAL, StrippedEndPortalConstants.STRIPPED, StrippedEndPortalConstants.FLATTENED})
  @Unique
  private byte rb$stripType;

  public @MagicConstant(intValues = {StrippedEndPortalConstants.NORMAL, StrippedEndPortalConstants.STRIPPED, StrippedEndPortalConstants.FLATTENED}) byte i$getStripType() {
    return this.rb$stripType;
  }

  public void i$setStripType(byte type) {
    //noinspection MagicConstant
    this.rb$stripType = type;
  }

  public boolean i$strip() {
    if (this.rb$stripType == StrippedEndPortalConstants.NORMAL) {
      this.rb$stripType = StrippedEndPortalConstants.STRIPPED;
      return true;
    }
    return false;
  }

  public boolean i$flatten() {
    if (this.rb$stripType == StrippedEndPortalConstants.NORMAL) {
      this.rb$stripType = StrippedEndPortalConstants.FLATTENED;
      return true;
    }
    return false;
  }

}
