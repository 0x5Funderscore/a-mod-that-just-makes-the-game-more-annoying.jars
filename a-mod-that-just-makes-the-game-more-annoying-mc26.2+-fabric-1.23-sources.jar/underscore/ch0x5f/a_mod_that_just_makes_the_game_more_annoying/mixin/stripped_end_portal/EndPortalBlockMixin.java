package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.stripped_end_portal;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InsideBlockEffectApplier;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EndPortalBlock;
import net.minecraft.world.level.block.entity.TheEndPortalBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.ITheEndPortalBlockEntityStripExtension;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.StrippedEndPortalConstants;


@Mixin(EndPortalBlock.class)
public abstract class EndPortalBlockMixin {

  @Unique
  private static final VoxelShape rb$FLAT_SHAPE = Block.column(16.0f, 0f, 0.03125f);

  @ModifyReturnValue(method = "getShape", at = @At("TAIL"))
  private VoxelShape modifyShape(
      VoxelShape original,
      @Local(name = "pos", argsOnly = true) BlockPos pos,
      @Local(name = "level", argsOnly = true) BlockGetter level
  ) {
    if (level.getBlockEntity(pos) instanceof TheEndPortalBlockEntity endPortalBlockEntity) {
      if (((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).getStripType() == StrippedEndPortalConstants.FLATTENED) {
        return rb$FLAT_SHAPE;
      }
    }
    return original;
  }

  @Inject(method = "entityInside", at = @At("HEAD"), cancellable = true)
  private void preEntityInside(BlockState state, Level level, BlockPos pos, Entity entity, InsideBlockEffectApplier effectApplier, boolean isPrecise, CallbackInfo ci) {
    if (!level.isClientSide() && Config.STRIPPED_END_PORTAL.get()) {
      if (level.getBlockEntity(pos) instanceof TheEndPortalBlockEntity endPortalBlockEntity) {
        if (((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).getStripType() != StrippedEndPortalConstants.NORMAL) {
          ci.cancel();
        }
      }
    }
  }

}
