package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.stripped_end_portal;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.TheEndPortalBlockEntity;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.ITheEndPortalBlockEntityStripExtension;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.StrippedEndPortalConstants;


@Mixin(BlockEntity.class)
public abstract class BlockEntityMixin {

  @Inject(method = "saveAdditional", at = @At("HEAD"))
  private void preSaveAdditional(ValueOutput output, CallbackInfo ci) {
    BlockEntity blockEntity = (BlockEntity)(Object)this;
    if (Config.STRIPPED_END_PORTAL.get() && blockEntity instanceof TheEndPortalBlockEntity endPortalBlockEntity) {
      output.putByte("strip_type", ((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).getStripType());
    }
  }

  @Inject(method = "loadAdditional", at = @At("HEAD"))
  private void preLoadAdditional(ValueInput input, CallbackInfo ci) {
    BlockEntity blockEntity = (BlockEntity)(Object)this;
    if (Config.STRIPPED_END_PORTAL.get() && blockEntity instanceof TheEndPortalBlockEntity endPortalBlockEntity) {
      ((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).setStripType(input.getByteOr("strip_type", StrippedEndPortalConstants.NORMAL));
    }
  }

  @ModifyReturnValue(method = "getUpdatePacket", at = @At("TAIL"))
  private @Nullable Packet<ClientGamePacketListener> postGetUpdatePacket(@Nullable Packet<ClientGamePacketListener> original) {
    if (original == null && Config.STRIPPED_END_PORTAL.get())
      if ((BlockEntity)(Object)this instanceof TheEndPortalBlockEntity endPortalBlockEntity) {
        return ClientboundBlockEntityDataPacket.create(endPortalBlockEntity);
      }
    return original;
  }

  @ModifyReturnValue(method = "getUpdateTag", at = @At("TAIL"))
  public CompoundTag postGetUpdateTag(CompoundTag original) {
    BlockEntity blockEntity = (BlockEntity)(Object)this;
    if (Config.STRIPPED_END_PORTAL.get() && blockEntity instanceof TheEndPortalBlockEntity endPortalBlockEntity) {
      original.putByte("strip_type", ((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).getStripType());
    }
    return original;
  }


}
