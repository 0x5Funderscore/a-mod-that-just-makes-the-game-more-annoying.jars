package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.stripped_end_portal;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.TheEndPortalBlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.ITheEndPortalBlockEntityStripExtension;


@Mixin(BlockBehaviour.class)
public abstract class BlockBehaviourMixin {

  @Inject(method = "useItemOn", at = @At("HEAD"))
  private void preUseItemOn(ItemStack itemStack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult, CallbackInfoReturnable<InteractionResult> cir) {
    if (!level.isClientSide() && Config.STRIPPED_END_PORTAL.get() && state.is(Blocks.END_PORTAL)) {
      if (level.getBlockEntity(pos) instanceof TheEndPortalBlockEntity endPortalBlockEntity) {
        if (itemStack.getItem() instanceof ShovelItem) {
          if (level.getBlockState(pos.above()).isAir()) {
            if (((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).flatten()) {
              level.playSound(null, pos, SoundEvents.SHOVEL_FLATTEN, SoundSource.BLOCKS, 1f, 1f);
              player.swing(hand, true);
              level.sendBlockUpdated(pos, state, state, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
              level.blockEntityChanged(pos);
            }
          }
        } else if (itemStack.getItem() instanceof AxeItem) {
          if (((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).strip()) {
            level.playSound(null, pos, SoundEvents.AXE_STRIP, SoundSource.BLOCKS, 1f, 1f);
            player.swing(hand, true);
            level.sendBlockUpdated(pos, state, state, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
            level.blockEntityChanged(pos);
          }
        }
      }
    }
  }

}
