package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.unstable_creepers;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Creeper.class)
public abstract class CreeperMixin {

  @Shadow
  public int maxSwell;

  @Inject(method = "<init>", at = @At("TAIL"))
  private void postInit(EntityType<?> type, Level level, CallbackInfo ci) {
    if (Config.UNSTABLE_CREEPERS.get() && !level.isClientSide()) {
      this.maxSwell = (int)(this.maxSwell * (Math.random() + 0.5d));
    }
  }

}
