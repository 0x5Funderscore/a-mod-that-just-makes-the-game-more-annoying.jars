package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fishing;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing.IServerPlayerFishingExtension;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing.ServerFishing;


@Mixin(FishingHook.class)
public abstract class FishingHookMixin {

  @Shadow
  public int nibble;

  @Shadow
  private @Nullable Entity hookedIn;

  @Shadow
  public abstract @Nullable Player getPlayerOwner();

  @WrapOperation(method = "retrieve", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/storage/loot/LootTable;getRandomItems(Lnet/minecraft/world/level/storage/loot/LootParams;)Lit/unimi/dsi/fastutil/objects/ObjectArrayList;"))
  private ObjectArrayList<ItemStack> wrapGetRandomItems(
      LootTable instance, LootParams params, Operation<ObjectArrayList<ItemStack>> original
  ) {
    if (Config.FISHING.get()) {
      if (this.getPlayerOwner() instanceof ServerPlayer serverPlayer) {
        ServerFishing newFishing = ((IServerPlayerFishingExtension)serverPlayer).getNewFishing();
        if (newFishing != null) {
//          LogUtils.getLogger().info("server get fishing items");
          return newFishing.getItems((FishingHook)(Object)this);
        }
      }
      return new ObjectArrayList<>();
    }
    return original.call(instance, params);
  }

  @WrapOperation(method = "retrieve", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/FishingHook;discard()V"))
  private void wrapDiscard(FishingHook instance, Operation<Void> original) {
    if (Config.FISHING.get() && this.nibble > 0 && this.hookedIn == null) {
      if (this.getPlayerOwner() instanceof ServerPlayer serverPlayer) {
        IServerPlayerFishingExtension fishingExtension = (IServerPlayerFishingExtension)serverPlayer;
        if (fishingExtension.getNewFishing() == null) {
          fishingExtension.startNewFishing();
//          LogUtils.getLogger().info("server start fishing");
          return;
        }
      } else return;
    }
    original.call(instance);
  }

}
