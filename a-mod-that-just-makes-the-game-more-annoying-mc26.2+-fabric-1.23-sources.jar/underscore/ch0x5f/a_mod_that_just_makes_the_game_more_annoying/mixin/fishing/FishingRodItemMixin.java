package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fishing;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.logging.LogUtils;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing.IServerPlayerFishingExtension;


@Mixin(FishingRodItem.class)
public abstract class FishingRodItemMixin {

  @Inject(method = "use", at = @At("HEAD"), cancellable = true)
  private void preUse(Level level, Player player, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
    if (player instanceof ServerPlayer serverPlayer) {
      IServerPlayerFishingExtension fishingExtension = (IServerPlayerFishingExtension)serverPlayer;
      if (fishingExtension.getNewFishing() != null) {
        cir.setReturnValue(InteractionResult.FAIL);
        cir.cancel();
      } else {
        fishingExtension.queueNextFishingContext(player.getItemInHand(hand), hand);
      }
    }
  }

  @Definition(id = "level", local = @Local(type = Level.class, name = "level", argsOnly = true))
  @Definition(id = "playSound", method = "Lnet/minecraft/world/level/Level;playSound(Lnet/minecraft/world/entity/Entity;DDDLnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;FF)V")
  @Definition(id = "FISHING_BOBBER_RETRIEVE", field = "Lnet/minecraft/sounds/SoundEvents;FISHING_BOBBER_RETRIEVE:Lnet/minecraft/sounds/SoundEvent;")
  @Expression("level.playSound(?, ?, ?, ?, FISHING_BOBBER_RETRIEVE, ?, ?, ?)")
  @WrapOperation(method = "use", at = @At("MIXINEXTRAS:EXPRESSION"))
  private void wrapPlayRetrieveSound(
      Level instance, Entity except, double x, double y, double z, SoundEvent sound, SoundSource source, float volume, float pitch, Operation<Void> original,
      @Local(name = "player", argsOnly = true) Player player
  ) {
    if (Config.FISHING.get()) {
      if (!(player instanceof ServerPlayer serverPlayer)) return;
      if (((IServerPlayerFishingExtension)serverPlayer).getNewFishing() != null) return;
    }
    original.call(instance, except, x, y, z, sound, source, volume, pitch);
  }

}
