package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fishing;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing.ServerFishing;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing.IServerPlayerFishingExtension;

import java.util.Objects;


@Mixin(ServerPlayer.class)
@Implements(@Interface(iface = IServerPlayerFishingExtension.class, prefix = "i$"))
public abstract class ServerPlayerMixin extends Player {

  @Unique
  private ServerFishing rb$newServerFishing;

  @Unique private @Nullable ItemStack rb$fishingContextItemStack = null;
  @Unique private @NotNull InteractionHand rb$fishingContextHand = InteractionHand.MAIN_HAND;

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  public @Nullable ServerFishing i$getNewFishing() {
    return this.rb$newServerFishing;
  }

  public void i$queueNextFishingContext(@NotNull ItemStack itemStack, @NotNull InteractionHand hand) {
    this.rb$fishingContextHand = hand;
    this.rb$fishingContextItemStack = itemStack;
  }

  public void i$startNewFishing() {
    this.rb$newServerFishing = new ServerFishing((ServerPlayer)(Object)this, this.rb$fishingContextItemStack == null ? ItemStack.EMPTY : this.rb$fishingContextItemStack, this.rb$fishingContextHand);
    if (this.fishing != null) this.fishing.nibble = 20;
  }

  public void i$clearNewFishing() {
    this.rb$newServerFishing = null;
    if (this.fishing != null) this.fishing.nibble = 0;
  }

  @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayerGameMode;tick()V", shift = At.Shift.AFTER))
  private void afterGameModeTick(CallbackInfo ci) {
    if (this.rb$newServerFishing != null) {
      this.rb$newServerFishing.tick();
    }
  }

}
