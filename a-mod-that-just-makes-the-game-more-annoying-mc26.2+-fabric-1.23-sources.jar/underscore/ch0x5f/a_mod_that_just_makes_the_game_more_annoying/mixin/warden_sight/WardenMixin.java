package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.warden_sight;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.warden.AngerManagement;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.entity.EntityTypeTest;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Optional;


@Mixin(Warden.class)
public abstract class WardenMixin extends Monster {

  @Unique
  private static final double rb$MAX_DISTANCE_SQR = 16d * 16d;

  @Shadow
  public abstract void setAttackTarget(LivingEntity target);

  @Shadow
  public abstract Optional<LivingEntity> getEntityAngryAt();

  @Shadow
  private AngerManagement angerManagement;

  protected WardenMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.WARDEN_SIGHT.get() && this.level() instanceof ServerLevel serverLevel) {
      if (this.getEntityAngryAt().isEmpty()) {
        LivingEntity nearestEntity = serverLevel.getNearestEntity(serverLevel.getEntities(EntityTypeTest.forClass(LivingEntity.class), (entity) -> entity != this && entity.distanceToSqr(this) < rb$MAX_DISTANCE_SQR), TargetingConditions.forCombat(), this, this.getX(), this.getY(), this.getZ());
        if (nearestEntity != null) {
          this.angerManagement.increaseAnger(nearestEntity, 2);
        }
      }
    }
  }

}
