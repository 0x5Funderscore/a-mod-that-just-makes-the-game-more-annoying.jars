package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_monster_room_upgrade;

import net.minecraft.world.level.levelgen.feature.MonsterRoomFeature;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(MonsterRoomFeature.class)
public abstract class MonsterRoomFeatureMixin {
  //SoundEvents.ANVIL_LAND
  //SoundEvents.ENDER_EYE_DEATH
  //SoundEvents.PLAYER_BREATH
  //SoundEvents.TRIAL_SPAWNER_SPAWN_MOB
}
