package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.timid_sheep;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.sheep.Sheep;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Sheep.class)
public abstract class SheepMixin extends Animal {

  protected SheepMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "registerGoals", at = @At("TAIL"))
  private void registerExtraGoals(CallbackInfo ci) {
    if (Config.TIMID_SHEEP.get()) {
//      this.goalSelector.addGoal(3, new AvoidEntityGoal<>(this, Wolf.class, (entity) -> entity.getDeltaMovement().horizontalDistanceSqr() > 0.2d, 6f, 2d, 2d, EntitySelector.NO_CREATIVE_OR_SPECTATOR));
      this.goalSelector.addGoal(3, new AvoidEntityGoal<>(this, Player.class, 6f, 2d, 2d));
    }
  }

}
