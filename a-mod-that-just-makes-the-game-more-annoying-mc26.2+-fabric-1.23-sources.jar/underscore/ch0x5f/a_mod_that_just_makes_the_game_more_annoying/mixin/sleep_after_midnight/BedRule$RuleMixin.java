package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.sleep_after_midnight;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.attribute.BedRule;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BedRule.Rule.class)
public abstract class BedRule$RuleMixin {

  @ModifyExpressionValue(
      method = "test",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/level/Level;isDarkOutside()Z"
      )
  )
  private boolean modifyIsDarkOutside(
      boolean original,
      @Local(name = "level", argsOnly = true) Level level
  ) {
    return original && (!Config.SLEEP_AFTER_MIDNIGHT.get() || ((level.getDefaultClockTime() % 24000L) > 18000L));
  }

}
