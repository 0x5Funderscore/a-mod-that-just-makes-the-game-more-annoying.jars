package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;


import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing.ServerFishing;


public final class AMTJMTGMA implements ModInitializer {
  public static final String MOD_ID = "a_mod_that_just_makes_the_game_more_annoying";

  public static final String KILL_WHEN_NO_PASSENGER = "kill_when_no_passenger";

  public static final Identifier FOUND_PORTAL_ROOM_ADVANCEMENT = Identifier.fromNamespaceAndPath(MOD_ID, "stronghold_portal_room");

  @Override
  public void onInitialize() {
    ServerFishing.register();
  }
}
