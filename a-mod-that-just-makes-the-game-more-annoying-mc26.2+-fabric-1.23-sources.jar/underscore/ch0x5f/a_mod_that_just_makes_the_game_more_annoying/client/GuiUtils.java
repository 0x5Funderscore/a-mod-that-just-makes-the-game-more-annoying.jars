package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.datafixers.util.Pair;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;


public final class GuiUtils {

  public record Tiling(boolean repeat, int size) {

    private static final Tiling NO_REPEAT = new Tiling(false, 0);

    public static Tiling repeat(int tileSize) {
      return new Tiling(true, tileSize);
    }

    public static Tiling noRepeat() {
      return NO_REPEAT;
    }

    public int step(int dim) {
      return repeat ? size : dim;
    }
  }

  public record NineSlice(int left, int top, int right, int bottom) {

    public NineSlice clamp(int width, int height) {
      int cx = Math.clamp((left + width - right) / 2, 0, width);
      int cy = Math.clamp((top + height - bottom) / 2, 0, height);
      return new NineSlice(
          Math.min(left, cx),
          Math.min(top, cy),
          Math.min(right, width - cx),
          Math.min(bottom, height - cy)
      );
    }

    public NineSlice copyScale(NineSlice from, NineSlice to) {
      return new NineSlice(
          (int)((double)this.left * ((double)to.left / (double)Math.max(from.left, 1))),
          (int)((double)this.top * ((double)to.top / (double)Math.max(from.top, 1))),
          (int)((double)this.right * ((double)to.right / (double)Math.max(from.right, 1))),
          (int)((double)this.bottom * ((double)to.bottom / (double)Math.max(from.bottom, 1)))
      );
    }

  }

  public static void tile(
      GuiGraphicsExtractor graphics, RenderPipeline pipeline, Identifier texture,
      int x, int y,
      int u, int v,
      int width, int height,
      int srcWidth, int srcHeight,
      int textureWidth, int textureHeight,
      Tiling xTile, Tiling yTile
  ) {
    if (width > 0 && height > 0) {
      int xs = Math.max(xTile.step(width), 1);
      int ys = Math.max(yTile.step(height), 1);
      for (int dx = 0; dx < width; dx += xs) {
        for (int dy = 0; dy < height; dy += ys) {
          int dstX = Math.min(width - dx, xs);
          int dstY = Math.min(height - dy, ys);
          graphics.blit(
              pipeline, texture,
              x + dx, y + dy,
              u, v,
              dstX, dstY,
              (int)((double)srcWidth * ((double)dstX / (double)xs)), (int)((double)srcHeight * ((double)dstY / (double)ys)),
              textureWidth, textureHeight
          );
        }
      }
    }
  }

  public static void nineSlice(
      GuiGraphicsExtractor graphics, RenderPipeline pipeline, Identifier texture,
      int x, int y,
      int u, int v,
      int width, int height,
      int srcWidth, int srcHeight,
      int textureWidth, int textureHeight,
      NineSlice settings,
      NineSlice srcSettings,
      Tiling xTile, Tiling yTile
  ) {

    NineSlice originalSettings = settings;
    NineSlice originalSrcSettings = srcSettings;
    settings = originalSettings.clamp(width, height);
    srcSettings = originalSrcSettings.copyScale(originalSettings, settings);

    int[] dxA = {x, x + settings.left, x + width - settings.right};
    int[] dwA = {settings.left, width - settings.left - settings.right, settings.right};
    int[] dyA = {y, y + settings.top, y + height - settings.bottom};
    int[] dhA = {settings.top, height - settings.top - settings.bottom, settings.bottom};

    int[] sxA = {u, u + srcSettings.left, u + srcWidth - srcSettings.right};
    int[] swA = {srcSettings.left, srcWidth - srcSettings.left - srcSettings.right, srcSettings.right};
    int[] syA = {v, v + srcSettings.top, v + srcHeight - srcSettings.bottom};
    int[] shA = {srcSettings.top, srcHeight - srcSettings.top - srcSettings.bottom, srcSettings.bottom};

    for (int ix: new int[]{0,1,2}) {
      for (int iy: new int[]{0,1,2}) {
        tile(
            graphics, pipeline, texture,
            dxA[ix], dyA[iy], sxA[ix], syA[iy],
            dwA[ix], dhA[iy], swA[ix], shA[iy],
            textureWidth, textureHeight,
            ix == 1 ? xTile : Tiling.noRepeat(),
            iy == 1 ? yTile : Tiling.noRepeat()
        );
      }
    }

  }

  public static void nineSlice(
      GuiGraphicsExtractor graphics, RenderPipeline pipeline, Identifier texture,
      int x, int y,
      int width, int height,
      int textureWidth, int textureHeight,
      NineSlice settings,
      NineSlice srcSettings,
      Tiling xTile, Tiling yTile
  ) {
    nineSlice(graphics, pipeline, texture, x, y, 0, 0, width, height, textureWidth, textureHeight, textureWidth, textureHeight, settings, srcSettings, xTile, yTile);
  }

  public static void nineSlice(
      GuiGraphicsExtractor graphics, RenderPipeline pipeline, Identifier texture,
      int x, int y,
      int width, int height,
      int textureWidth, int textureHeight,
      NineSlice settings,
      Tiling xTile, Tiling yTile
  ) {
    nineSlice(graphics, pipeline, texture, x, y, 0, 0, width, height, textureWidth, textureHeight, textureWidth, textureHeight, settings, settings, xTile, yTile);
  }

}
