package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.NotNull;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fishing.NewFishing;

import java.util.Objects;


public class ClientFishing {

  public static final Identifier BACKGROUND_TEXTURE = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/gui/fishing/frame.png");
  public static final Identifier BAR_TEXTURE = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/gui/fishing/bar.png");
  public static final Identifier PROGRESS_FILLED_TEXTURE = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/gui/fishing/progress.png");

  private final LocalPlayer player;

  private int heightKeyframeProgress = 0;
  private float[] keyframes = new float[NewFishing.NUM_KEYFRAMES];
  private float fishHeight = 0f;
  private float barSize = 0f;
  private float progressDecreaseSpeed = 0f;
  private float progressIncreaseSpeed = 0f;
  private float barForce = 0f;
  private float barGravity = 0f;
  private float barBounce = 0f;
  private float progress = 0.3f;
//  private TextureAtlasSprite itemSprite;

  private float barHeight = 0f;
  private float velocity = 0f;

  private boolean won = false;

  private boolean perfect = false;
  private int perfectTicks = 0;

  public ClientFishing(LocalPlayer player) {
    this.player = player;
  }

  private float oBarSize = barSize;
  public float getBarSize(float partialTicks) {
    return Mth.lerp(partialTicks, oBarSize, barSize);
  }

  private float oBarHeight = barHeight;
  public float getBarY(float partialTicks) {
    return Mth.lerp(partialTicks, oBarHeight, barHeight);
  }

  private float oProgress = 0f;
  public float getProgress(float partialTicks) {
    return Mth.lerp(partialTicks, oProgress, progress);
  }

  private float oFishHeight = 0f;
  public float getFishHeight(float partialTicks) {
    return Mth.lerp(partialTicks, oFishHeight, this.fishHeight);
  }

  public boolean isPerfect() {
    return perfect;
  }
  public int getPerfectTicks() {
    return perfectTicks;
  }

  public @NotNull ItemStack getFishItem() {
    return new ItemStack(Items.COD, 1);
  }

  private boolean isPushingUp() {
    return Minecraft.getInstance().options.keyUse.isDown();
  }

  public float getFishHeight() {
    float keyframe = Math.clamp((float)this.heightKeyframeProgress / (float)NewFishing.KEYFRAME_INTERVAL, 0f, this.keyframes.length - 1);
    int keyframe0 = Mth.floor(keyframe);
    int keyframe1 = Mth.ceil(keyframe);
    if (keyframe0 == keyframe1) return this.keyframes[keyframe0];
    return Mth.lerp(keyframe - keyframe0, this.keyframes[keyframe0], this.keyframes[keyframe1]);
  }

  public void tick() {
    if (this.player.fishing == null || this.player.fishing.isRemoved()) {
      ((ILocalPlayerFishingExtension)this.player).clearNewFishing();
      return;
    }
    if (perfect) perfectTicks++;
    this.heightKeyframeProgress++;

    this.oBarSize = this.barSize;
    this.oBarHeight = this.barHeight;
    this.oProgress = this.progress;
    this.oFishHeight = this.fishHeight;

    if (!won) {
      float fishY = this.fishHeight = this.getFishHeight();

      float deltaV = this.isPushingUp() ? this.barForce : -this.barGravity;
      this.velocity += deltaV;
      this.barHeight += this.velocity;

      float upperBound = 1f - this.barSize;

      if (this.barHeight < 0f) {
        this.barHeight = -this.barHeight;
        this.velocity = Math.abs(this.velocity) * this.barBounce;
      } else if (this.barHeight > upperBound) {
        this.barHeight = upperBound + upperBound - this.barHeight;
        this.velocity = -Math.abs(this.velocity) * this.barBounce;
      }

      float barY0 = this.barHeight;
      float barY1 = this.barHeight + this.barSize;
      boolean isOnBar = barY0 <= fishY && fishY <= barY1;
      float deltaProgress = isOnBar || won ? this.progressIncreaseSpeed : -this.progressDecreaseSpeed;
      this.progress = Math.clamp(this.progress + deltaProgress, 0f, 1f);
      if (this.progress >= 1f) won = true;
      ClientPlayNetworking.send(NewFishing.FishingPacketPayload.serverbound(this.progress));
    } else {
      ClientPlayNetworking.send(NewFishing.FishingPacketPayload.serverboundCompleted());
    }
//    LogUtils.getLogger().info("progress: {} | height: {} | fish height: {}", this.progress, this.barHeight, fishY);
  }

  public void handlePacket(@NotNull NewFishing.FishingPacketPayload payload, @NotNull ClientPlayNetworking.Context context) {
//    LogUtils.getLogger().info("client handle packet");
    if (payload.shorterVersion()) {
      if (payload.perfect()) {
        perfect = true;
      } else {
        ((ILocalPlayerFishingExtension)this.player).clearNewFishing();
      }
      return;
    }
    heightKeyframeProgress = 0;
    keyframes = Objects.requireNonNull(payload.heights());
    barSize = payload.barSize();
    progressDecreaseSpeed = payload.progressDecreaseSpeed();
    progressIncreaseSpeed = payload.progressIncreaseSpeed();
    barForce = payload.barForce();
    barGravity = payload.barGravity();
    barBounce = payload.barBounce();
    String itemName = payload.fishItemName();
    if (itemName != null) {
      // ?
    }
  }

  private static void handlePacketStatic(@NotNull NewFishing.FishingPacketPayload payload, @NotNull ClientPlayNetworking.Context context) {
    ((ILocalPlayerFishingExtension)context.player()).getOrCreateNewFishing().handlePacket(payload, context);
  }

  public static void register() {
    ClientPlayConnectionEvents.INIT.register((listener, client) -> ClientPlayNetworking.registerReceiver(NewFishing.TYPE, ClientFishing::handlePacketStatic));
  }
}
