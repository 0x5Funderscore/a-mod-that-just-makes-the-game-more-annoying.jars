package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing;


import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;


public interface ILocalPlayerFishingExtension {
  @NotNull ClientFishing getOrCreateNewFishing();
  @Nullable ClientFishing getNewFishing();
  void clearNewFishing();
}
