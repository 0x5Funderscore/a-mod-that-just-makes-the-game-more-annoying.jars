package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client;

import net.fabricmc.api.ClientModInitializer;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing.ClientFishing;


public class AMTJMTGMAClient implements ClientModInitializer {

  @Override
  public void onInitializeClient() {
    ClientFishing.register();
  }
}
