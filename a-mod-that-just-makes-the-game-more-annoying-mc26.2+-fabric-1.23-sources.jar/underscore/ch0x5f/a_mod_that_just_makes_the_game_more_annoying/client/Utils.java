package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client;

public final class Utils {
  public static double ifNaN(double x, double or) {
    return Double.isNaN(x) ? or : x;
  }
  public static float ifNaN(float x, float or) {
    return Float.isNaN(x) ? or : x;
  }
}
