package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.fishing;

import com.mojang.logging.LogUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.player.LocalPlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing.ClientFishing;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing.ILocalPlayerFishingExtension;

import java.util.Objects;


@Mixin(LocalPlayer.class)
@Implements(@Interface(iface = ILocalPlayerFishingExtension.class, prefix = "i$"))
@Environment(EnvType.CLIENT)
public class LocalPlayerMixin {

  @Unique
  private ClientFishing rb$newClientFishing;

  public @NotNull ClientFishing i$getOrCreateNewFishing() {
//    LogUtils.getLogger().info("local player: new fishing");
    return Objects.requireNonNullElseGet(this.rb$newClientFishing, () -> (this.rb$newClientFishing = new ClientFishing((LocalPlayer)(Object)this)));
  }

  public @Nullable ClientFishing i$getNewFishing() {
    return this.rb$newClientFishing;
  }

  public void i$clearNewFishing() {
//    LogUtils.getLogger().info("local player: fishing cleared");
    this.rb$newClientFishing = null;
  }

  @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/AbstractClientPlayer;tick()V", shift = At.Shift.AFTER))
  private void afterSuperTick(CallbackInfo ci) {
    if (this.rb$newClientFishing != null) this.rb$newClientFishing.tick();
  }

}
