package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.fishing;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.GuiUtils;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing.ClientFishing;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing.ILocalPlayerFishingExtension;

import java.util.concurrent.atomic.AtomicInteger;


@Mixin(Hud.class)
@Environment(EnvType.CLIENT)
public abstract class HudMixin {

  @Shadow
  public abstract Font getFont();

  @Inject(method = "extractRenderState", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;nextStratum()V", shift = At.Shift.AFTER))
  private void extractRenderStateLayer2(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker, CallbackInfo ci) {
    if (Config.FISHING.get()) {
      rb$extractNewFishingOverlay(graphics, deltaTracker);
    }
  }

  @Unique
  private void rb$extractNewFishingOverlay(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
    LocalPlayer player = Minecraft.getInstance().player;
    if (player != null) {
      ClientFishing newFishing = ((ILocalPlayerFishingExtension)player).getNewFishing();
      if (newFishing != null) {
        float partialTicks = deltaTracker.getGameTimeDeltaTicks();
        float fishYF = newFishing.getFishHeight(partialTicks);
        float barYF = newFishing.getBarY(partialTicks);
        float barSizeF = newFishing.getBarSize(partialTicks);
        float progressF = newFishing.getProgress(partialTicks);

        int margin = 6;
        int gap = 4;
        int edge = 0;

        int fishBarInnerWidth = 12;
        int fishBarOuterWidth = edge + fishBarInnerWidth + edge;

        int progressBarInnerWidth = 8;
        int progressBarOuterWidth = edge + progressBarInnerWidth + edge;

        int innerTotalBarHeight = 192;

        int insideWidth = progressBarOuterWidth + gap + fishBarOuterWidth;
        int insideHeight = edge + innerTotalBarHeight + edge;

        int width = margin + insideWidth + margin;
        int height = margin + insideHeight + margin;

        int x = Math.min((int)(graphics.guiWidth() * 0.6f), graphics.guiWidth() - width - 2);
        int y = (graphics.guiHeight() - height) / 2;

        int fishBarOuterLeft = x + margin + progressBarOuterWidth + gap;
        int fishBarCenter = fishBarOuterLeft + fishBarOuterWidth / 2;
        int fishBarInnerLeft = fishBarOuterLeft + edge;

        int barOuterTop = y + margin;
        int barOuterBottom = barOuterTop + insideHeight;

        int barInnerTop = barOuterTop + edge;
        int barInnerBottom = barOuterBottom - edge;

        int progressHeight = Math.round(innerTotalBarHeight * progressF);
        int progressTop = barInnerBottom - progressHeight;
        int progressBarOuterLeft = x + margin;

        int fishY = Mth.lerpInt(fishYF, barInnerBottom, barInnerTop);

        int fishFillY1 = Mth.lerpInt(barYF, barInnerBottom, barInnerTop);
        int fishFillY2 = Mth.lerpInt(barYF + barSizeF, barInnerBottom, barInnerTop);

        int fishFillY = Math.min(fishFillY1, fishFillY2);
        int fishFillHeight = Math.abs(fishFillY1 - fishFillY2);
        graphics.blit(RenderPipelines.GUI_TEXTURED, ClientFishing.BACKGROUND_TEXTURE, x, y, 0, 0, width, height, 64, 256);
        graphics.blit(RenderPipelines.GUI_TEXTURED, ClientFishing.PROGRESS_FILLED_TEXTURE, progressBarOuterLeft + edge, progressTop, 0, innerTotalBarHeight - progressHeight, progressBarInnerWidth, progressHeight, progressBarInnerWidth, innerTotalBarHeight);
        GuiUtils.nineSlice(
            graphics, RenderPipelines.GUI_TEXTURED, ClientFishing.BAR_TEXTURE,
            fishBarInnerLeft, fishFillY,
            fishBarInnerWidth, fishFillHeight,
            12, 12,
            new GuiUtils.NineSlice(0, 4, 0, 4),
            GuiUtils.Tiling.noRepeat(),
            GuiUtils.Tiling.repeat(4)
        );
        graphics.item(newFishing.getFishItem(), fishBarCenter - 8, fishY - 8);

        if (newFishing.isPerfect()) {
          Font font = getFont();
          FormattedCharSequence text = Component.translatable("fishing.perfect").getVisualOrderText();
          int offsetX = font.width(text) / -2;

          int baseX = x + width / 2 + offsetX;
          int baseY = y - font.lineHeight - 4;
          int color = ARGB.color(255, 0xffd700);

          float perfectFrac = Math.clamp((newFishing.getPerfectTicks() + partialTicks) / 20f, 0f, 1f);

          AtomicInteger charPosition = new AtomicInteger();
          text.accept((position, style, codepoint) -> {
            float phase = (float)position * 2f + perfectFrac * 12f;
            int charX = baseX + charPosition.get();
            int charY = (int)((float)baseY + Mth.sin(phase) * Mth.lerp(Math.min(perfectFrac * 2f, 1f), 3f, 0f));
            FormattedCharSequence singleChar = FormattedCharSequence.codepoint(codepoint, style);
            graphics.text(font, singleChar, charX, charY, color, true);
            charPosition.addAndGet(font.width(singleChar));
            return true;
          });
        }
      }
    }
  }

}
