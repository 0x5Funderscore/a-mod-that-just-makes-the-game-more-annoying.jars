package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.fishing;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.fishing.ILocalPlayerFishingExtension;


@Mixin(FishingRodItem.class)
@Environment(EnvType.CLIENT)
public class FishingRodItemMixin {

  @Inject(method = "use", at = @At("HEAD"), cancellable = true)
  private void preUse(Level level, Player player, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
    if (player instanceof LocalPlayer localPlayer && ((ILocalPlayerFishingExtension)localPlayer).getNewFishing() != null) {
      cir.setReturnValue(InteractionResult.FAIL);
      cir.cancel();
    }
  }

}
