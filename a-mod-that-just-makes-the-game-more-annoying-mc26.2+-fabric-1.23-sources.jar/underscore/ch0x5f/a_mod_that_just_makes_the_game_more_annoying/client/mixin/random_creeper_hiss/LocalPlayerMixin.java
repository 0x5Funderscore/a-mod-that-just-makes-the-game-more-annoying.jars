package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.random_creeper_hiss;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LocalPlayer.class)
@Environment(EnvType.CLIENT)
public abstract class LocalPlayerMixin extends AbstractClientPlayer {

  public LocalPlayerMixin(ClientLevel level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.RANDOM_CREEPER_HISS.get() && Math.random() < 0.0002) {
      Vec3 behind = this.getEyePosition().add(this.getLookAngle().scale(-1.0d - 2.0d * Math.random()));
      Minecraft.getInstance().getSoundManager().play(new SimpleSoundInstance(
          SoundEvents.CREEPER_PRIMED,
          SoundSource.HOSTILE,
          1.0f,
          1.0f,
          this.random,
          behind.x, behind.y, behind.z
      ));
    }
  }

}
