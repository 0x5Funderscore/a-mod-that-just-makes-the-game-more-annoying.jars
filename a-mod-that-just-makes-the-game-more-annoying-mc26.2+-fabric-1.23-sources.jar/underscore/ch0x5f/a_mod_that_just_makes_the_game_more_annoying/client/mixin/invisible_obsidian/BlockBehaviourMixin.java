package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.invisible_obsidian;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BlockBehaviour.class)
@Environment(EnvType.CLIENT)
public abstract class BlockBehaviourMixin {

  @ModifyReturnValue(method = "getRenderShape", at = @At("TAIL"))
  private RenderShape modifyRenderShape(RenderShape original) {
    if (Config.INVISIBLE_OBSIDIAN.get())
      if ((Object)this == Blocks.OBSIDIAN) {
        return RenderShape.INVISIBLE;
      }
    return original;
  }

}
