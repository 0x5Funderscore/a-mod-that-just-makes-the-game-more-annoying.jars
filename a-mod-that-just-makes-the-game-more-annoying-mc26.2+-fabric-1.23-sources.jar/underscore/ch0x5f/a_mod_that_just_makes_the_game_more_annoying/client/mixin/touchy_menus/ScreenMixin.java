package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.touchy_menus;

import it.unimi.dsi.fastutil.floats.Float2BooleanFunction;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.events.AbstractContainerEventHandler;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.options.OptionsSubScreen;
import net.minecraft.client.gui.screens.options.WorldOptionsScreen;
import net.minecraft.client.gui.screens.worldselection.AbstractGameRulesScreen;
import org.jetbrains.annotations.Contract;
import org.joml.Vector2f;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.ITouchyScreenExtension;

import java.util.*;
import java.util.stream.Collectors;


@Mixin(Screen.class)
@Environment(EnvType.CLIENT)
@Implements(@Interface(iface = ITouchyScreenExtension.class, prefix = "i$"))
public abstract class ScreenMixin extends AbstractContainerEventHandler {

  @Shadow
  @Final
  public List<Renderable> renderables;
  @Shadow
  public int width;
  @Shadow
  public int height;

  @Unique private int lastMouseX;
  @Unique private int lastMouseY;
  @Unique private boolean haveMouse = false;
  @Unique private boolean funny = false;

  /*

  @Unique
  private static void rb$traverse2D(int fromX, int fromY, int toX, int toY, IntIntBiConsumer consumer) {

    int dx = toX - fromX;
    int dy = toY - fromY;

    int signX = Integer.compare(dx, 0);
    int signY = Integer.compare(dy, 0);

    double tDeltaX = signX == 0 ? Double.MAX_VALUE : (double)signX / dx;
    double tDeltaY = signY == 0 ? Double.MAX_VALUE : (double)signY / dy;

    double tX = tDeltaX * (signX > 0 ? 1d - Mth.frac(tDeltaX) : Mth.frac(tDeltaX));
    double tY = tDeltaY * (signY > 0 ? 1d - Mth.frac(tDeltaY) : Mth.frac(tDeltaY));

    int x = fromX;
    int y = fromY;

    consumer.accept(x, y);
    while (tX <= 1.0d || tY <= 1.0d) {
      if (tX < tY) {
        x += signX;
        tX += tDeltaX;
      } else {
        y += signY;
        tY += tDeltaY;
      }
      consumer.accept(x, y);
    }
  }

  @Unique
  private void rb$moveMouse(int mouseX, int mouseY) {
    if (this.haveMouse) {
      rb$traverse2D(lastMouseX, lastMouseY, mouseX, mouseY, this::rb$affectWidgets);
    }
    this.lastMouseX = mouseX;
    this.lastMouseY = mouseY;
    this.haveMouse = true;
  }

  @Unique
  private void rb$affectWidgets(int mouseX, int mouseY) {

    List<AbstractButton> widgets = this.renderables.stream().filter(renderable -> renderable instanceof AbstractButton).map(renderable -> (AbstractButton)renderable).toList();
    int numWidgets = widgets.size();

    boolean[] blockedLeft = new boolean[numWidgets];
    boolean[] blockedRight = new boolean[numWidgets];
    boolean[] blockedUp = new boolean[numWidgets];
    boolean[] blockedDown = new boolean[numWidgets];

    for (int i = 0; i < numWidgets; i++) {
      AbstractButton widget = widgets.get(i);
      if (widget.getX() <= 0) blockedLeft[i] = true;
      if (widget.getY() <= 0) blockedUp[i] = true;
      if (widget.getRight() >= this.width) blockedRight[i] = true;
      if (widget.getBottom() >= this.height) blockedDown[i] = true;
    }

    for (int i = 1; i < numWidgets; i++) {

      AbstractButton widget1 = widgets.get(i);
      int aMinX = widget1.getX();
      int aMinY = widget1.getY();
      int aMaxX = widget1.getRight();
      int aMaxY = widget1.getBottom();

      for (int j = 0; j < i; j++) {

        AbstractButton widget2 = widgets.get(j);
        int bMinX = widget2.getX();
        int bMinY = widget2.getY();
        int bMaxX = widget2.getRight();
        int bMaxY = widget2.getBottom();

        if (
            aMinX <= bMaxX &&
            aMaxX >= bMinX &&
            aMinY <= bMaxY &&
            aMaxY >= bMinY
        ) {

          // edge collisions

          boolean aLeft = bMinX <= aMinX;//&&aMinX <= bMaxX
          boolean aRight = aMaxX <= bMaxX;//bMinX <= aMaxX&&
          boolean aTop = bMinY <= aMinY;//&&aMinY <= bMaxY
          boolean aBottom = aMaxY <= bMaxY;//bMinY <= aMaxY&&

          boolean bLeft = aMinX <= bMinX;//&&bMinX <= aMaxX
          boolean bRight = bMaxX <= aMaxX;//aMinX <= bMaxX&&
          boolean bTop = aMinY <= bMinY;//&&bMinY <= aMaxY
          boolean bBottom = bMaxY <= aMaxY;//aMinY <= bMaxY&&

          blockedLeft[i] |= aLeft;
          blockedRight[i] |= aRight;
          blockedUp[i] |= aTop;
          blockedDown[i] |= aBottom;

          blockedLeft[j] |= bLeft;
          blockedRight[j] |= bRight;
          blockedUp[j] |= bTop;
          blockedDown[j] |= bBottom;

        }
      }
    }

    for (int i = 0; i < numWidgets; i++) {
      AbstractButton widget = widgets.get(i);

      int minX = widget.getX();
      int minY = widget.getY();
      int maxX = widget.getRight();
      int maxY = widget.getBottom();

      if (mouseY >= minY && mouseY < maxY) {
        if (mouseX >= minX - 1 && mouseX <= minX && !blockedRight[i]) {
          widget.setX(minX + 1);
        } else if (mouseX >= maxX - 1 && mouseX <= maxX && !blockedLeft[i]) {
          widget.setX(minX - 1);
        }
      }
      if (mouseX >= minX && mouseX < maxX) {
        if (mouseY >= minY - 1 && mouseY <= minY && !blockedDown[i]) {
          widget.setY(minY + 1);
        }
        if (mouseY >= maxY - 1 && mouseY <= maxY && !blockedUp[i]) {
          widget.setY(minY - 1);
        }
      }
    }

  }
  */

  @Unique private final Map<AbstractWidget,Vector2f> rb$widgetPosition = new HashMap<>();
  @Unique private final Map<AbstractWidget,Vector2f> rb$widgetVelocity = new HashMap<>();

  @Unique
  @Contract(pure = true)
  private Vector2f rb$CCD(Vector2f aMin, Vector2f aMax, Vector2f va, Vector2f bMin, Vector2f bMax, Vector2f vb) {

    Vector2f bCenter = bMin.add(bMax, new Vector2f()).div(2f);
    Vector2f bRadius = bMax.sub(bMin, new Vector2f()).div(2f);

    Vector2f bigMin = aMin.sub(bRadius, new Vector2f()).sub(bCenter);
    Vector2f bigMax = aMax.add(bRadius, new Vector2f()).sub(bCenter);

    Vector2f vel = vb.sub(va, new Vector2f());

    Float2BooleanFunction fractionCheckX = f -> {
      float x = vel.x * f;
      return x >= bigMin.x && x <= bigMax.x;
    };
    Float2BooleanFunction fractionCheckY = f -> {
      float y = vel.y * f;
      return y >= bigMin.y && y <= bigMax.y;
    };

    float fracMinX = bigMin.x / vel.x;
    float fracMaxX = bigMax.x / vel.x;
    float fracMinY = bigMin.y / vel.y;
    float fracMaxY = bigMax.y / vel.y;

    if (vel.x <= 0f || fracMinX < 0f || !fractionCheckY.get(fracMinX)) fracMinX = Float.MAX_VALUE;
    if (vel.x >= 0f || fracMaxX < 0f || !fractionCheckY.get(fracMaxX)) fracMaxX = Float.MAX_VALUE;
    if (vel.y <= 0f || fracMinY < 0f || !fractionCheckX.get(fracMinY)) fracMinY = Float.MAX_VALUE;
    if (vel.y >= 0f || fracMaxY < 0f || !fractionCheckX.get(fracMaxY)) fracMaxY = Float.MAX_VALUE;

    float fracX = Math.min(fracMinX, fracMaxX);
    float fracY = Math.min(fracMinY, fracMaxY);
    if (fracX > 1.0f) fracX = Float.NaN;
    if (fracY > 1.0f) fracY = Float.NaN;
    return new Vector2f(fracX, fracY);
  }

  /*
  @Unique
  private <T> Map<T,Collection<T>> rb$reassociate(Collection<Map.Entry<T,T>> pairs) {
    HashMap<T,Collection<T>> map = new HashMap<>();
    Function<T, HashSet<T>> blankFunction = k -> new HashSet<>();
    for (Map.Entry<T,T> pair: pairs) {
      T left = pair.getKey();
      T right = pair.getValue();
      if (left != right) {
        map.computeIfAbsent(left, blankFunction).add(right);
        map.computeIfAbsent(right, blankFunction).add(left);
      }
    }
    return map;
  }
  */

  public void i$tickTouchyScreen() {
    if (!this.funny) return;

    Set<AbstractWidget> widgets = this.renderables.stream()
        .filter(renderable -> renderable instanceof AbstractButton || renderable instanceof AbstractSliderButton)
        .map(renderable -> (AbstractWidget)renderable)
        .collect(Collectors.toUnmodifiableSet());

    int numWidgets = widgets.size();

    for (AbstractWidget button: widgets) {
      this.rb$widgetPosition.computeIfAbsent(button, w -> new Vector2f(w.getX(), w.getY()));
      Vector2f velocity = this.rb$widgetVelocity.computeIfAbsent(button, w -> new Vector2f());

      Vector2f mouse = new Vector2f(this.lastMouseX, this.lastMouseY);

      if (this.haveMouse && button.areCoordinatesInRectangle(this.lastMouseX, this.lastMouseY)) {
        Vector2f center = new Vector2f(button.getX(), button.getY()).add(button.getWidth() / 2f, button.getHeight() / 2f);
        Vector2f offset = center.sub(mouse).normalize();
        if (offset.isFinite()) {
          velocity.add(offset.mul(6f));
        }
      }
    }

    List<AbstractWidget> widgetList = List.copyOf(widgets);

    float[] fractionsX = new float[numWidgets];
    float[] fractionsY = new float[numWidgets];
    Arrays.fill(fractionsX, 1.0f);
    Arrays.fill(fractionsY, 1.0f);

//    Map<AbstractWidget, AbstractWidget> shareVelocityX = new HashMap<>();
//    Map<AbstractWidget, AbstractWidget> shareVelocityY = new HashMap<>();

    for (int i = 1; i < numWidgets; i++) {

      AbstractWidget widget1 = widgetList.get(i);
      int aMinX = widget1.getX();
      int aMinY = widget1.getY();
      int aMaxX = widget1.getRight();
      int aMaxY = widget1.getBottom();

      Vector2f aMin = new Vector2f(aMinX, aMinY);
      Vector2f aMax = new Vector2f(aMaxX, aMaxY);
      Vector2f aVel = this.rb$widgetVelocity.get(widget1);

      for (int j = 0; j < i; j++) {

        AbstractWidget widget2 = widgetList.get(j);
        int bMinX = widget2.getX();
        int bMinY = widget2.getY();
        int bMaxX = widget2.getRight();
        int bMaxY = widget2.getBottom();

        Vector2f bMin = new Vector2f(bMinX, bMinY);
        Vector2f bMax = new Vector2f(bMaxX, bMaxY);
        Vector2f bVel = this.rb$widgetVelocity.get(widget2);

        Vector2f frac = this.rb$CCD(aMin, aMax, aVel, bMin, bMax, bVel);
        float fracX = frac.x;
        float fracY = frac.y;
        if (fracX < fractionsX[i]) {
          fractionsX[i] = fracX;
//          shareVelocityX.put(widget1, widget2);
        }
        if (fracY < fractionsY[i]) {
          fractionsY[i] = fracY;
//          shareVelocityY.put(widget1, widget2);
        }
        if (fracX < fractionsX[j]) {
          fractionsX[j] = fracX;
//          shareVelocityX.put(widget2, widget1);
        }
        if (fracY < fractionsY[j]) {
          fractionsY[j] = fracY;
//          shareVelocityY.put(widget2, widget1);
        }
      }
    }

    for (int i = 0; i < numWidgets; i++) {
      AbstractWidget widget = widgetList.get(i);

      Vector2f position = this.rb$widgetPosition.get(widget);
      Vector2f velocity = this.rb$widgetVelocity.get(widget);

      if (velocity.lengthSquared() > 0.0625f) {

        float fracX = fractionsX[i];
        if (fracX < 1.0f && Float.isFinite(fracX)) {
          position.x += velocity.x * (fracX - 1e-3f);
          velocity.x = 0f;
        } else position.x += velocity.x;

        float fracY = fractionsY[i];
        if (fracY < 1.0f && Float.isFinite(fracY)) {
          position.y += velocity.y * (fracY - 1e-3f);
          velocity.y = 0f;
        } else position.y += velocity.y;

        velocity.mul(0.75f);

      } else velocity.mul(0f);

      if (position.x < 0f) {
        position.x = 0f;
        velocity.x = Math.max(velocity.x * -0.5f, 0f);
      }
      if (position.x + widget.getWidth() > this.width) {
        position.x = this.width - widget.getWidth();
        velocity.x = Math.min(velocity.x * -0.5f, 0f);
      }
      if (position.y < 0f) {
        position.y = 0f;
        velocity.y = Math.max(velocity.y * -0.5f, 0f);
      }
      if (position.y + widget.getHeight() > this.height) {
        position.y = this.height - widget.getHeight();
        velocity.y = Math.min(velocity.y * -0.5f, 0f);
      }

      widget.setPosition((int)position.x, (int)position.y);
    }

    /*
    Map<AbstractButton, Collection<AbstractButton>> shareVelocityXDistributed = rb$reassociate(shareVelocityX.entrySet());
    Map<AbstractButton, Collection<AbstractButton>> shareVelocityYDistributed = rb$reassociate(shareVelocityY.entrySet());

    Object2FloatMap<AbstractButton> newVelocityX = new Object2FloatArrayMap<>();
    Object2FloatMap<AbstractButton> newVelocityY = new Object2FloatArrayMap<>();

    for (AbstractButton widget: widgets) {

      Collection<AbstractButton> shareWithX = shareVelocityXDistributed.get(widget);
      Collection<AbstractButton> shareWithY = shareVelocityYDistributed.get(widget);

      Vector2f velocity = this.rb$widgetVelocity.get(widget);

      if (shareWithX != null) {
        int n = shareWithX.size();
        float sharedVelocity = velocity.x / n;
        newVelocityX.putIfAbsent(widget, 0f);
        for (AbstractButton other: shareWithX) {
          newVelocityX.put(other, newVelocityX.getOrDefault(other, 0f) + sharedVelocity);
        }
      }

      if (shareWithY != null) {
        int n = shareWithY.size();
        float sharedVelocity = velocity.y / n;
        newVelocityY.putIfAbsent(widget, 0f);
        for (AbstractButton other: shareWithY) {
          newVelocityY.put(other, newVelocityY.getOrDefault(other, 0f) + sharedVelocity);
        }
      }

    }

    newVelocityX.forEach((widget, vx) -> this.rb$widgetVelocity.get(widget).x = vx);
    newVelocityY.forEach((widget, vy) -> this.rb$widgetVelocity.get(widget).y = vy);
    */
  }

  @Unique
  private void rb$moveMouse(int mouseX, int mouseY) {
    if (lastMouseX != mouseX || lastMouseY != mouseY) {
      this.lastMouseX = mouseX;
      this.lastMouseY = mouseY;
    }
    this.haveMouse = true;
  }

  @Inject(method = "rebuildWidgets", at = @At("TAIL"))
  private void postBuildWidgets(CallbackInfo ci) {
    if (funny) {
      this.haveMouse = false;
      this.rb$widgetPosition.clear();
      this.rb$widgetVelocity.clear();
    }
  }

  @Inject(method = "extractRenderStateWithTooltipAndSubtitles", at = @At("HEAD"))
  private void preExtractRenderStateWithTooltipAndSubtitles(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a, CallbackInfo ci) {
    if (Config.TOUCHY_MENUS.get() && funny) this.rb$moveMouse(mouseX, mouseY);
    else this.haveMouse = false;
  }

  @Inject(method = "init(II)V", at = @At("HEAD"))
  private void preInit(int width, int height, CallbackInfo ci) {
    Screen screen = (Screen)(AbstractContainerEventHandler)this;
    this.funny = screen instanceof PauseScreen ||
                 screen instanceof OptionsScreen ||
                 screen instanceof WorldOptionsScreen
    ;
  }

  @Inject(method = "resize", at = @At("TAIL"))
  private void postResize(int width, int height, CallbackInfo ci) {
    if (funny) {
      this.haveMouse = false;
      this.rb$widgetPosition.clear();
      this.rb$widgetVelocity.clear();
    }
  }

}
