package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.touchy_menus;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.ITouchyScreenExtension;


@Mixin(Gui.class)
@Environment(EnvType.CLIENT)
public abstract class GuiMixin {

  @WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;tick()V"))
  private void wrapScreenTick(Screen instance, Operation<Void> original) {
    if (Config.TOUCHY_MENUS.get()) ((ITouchyScreenExtension)instance).tickTouchyScreen();
    original.call(instance);
  }

}
