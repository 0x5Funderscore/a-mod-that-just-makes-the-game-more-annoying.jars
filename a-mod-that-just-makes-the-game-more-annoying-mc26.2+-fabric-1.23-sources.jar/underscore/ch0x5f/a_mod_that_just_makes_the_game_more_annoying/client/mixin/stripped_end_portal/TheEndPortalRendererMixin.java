package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.stripped_end_portal;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.logging.LogUtils;
import com.mojang.math.Transformation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.blockentity.AbstractEndPortalRenderer;
import net.minecraft.client.renderer.blockentity.TheEndPortalRenderer;
import net.minecraft.client.renderer.blockentity.state.EndPortalRenderState;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.TheEndPortalBlockEntity;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.ITheEndPortalBlockEntityStripExtension;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.stripped_end_portal.StrippedEndPortalConstants;


@Mixin(TheEndPortalRenderer.class)
@Environment(EnvType.CLIENT)
public abstract class TheEndPortalRendererMixin {

  @Unique
  private static final RenderType rb$STRIPPED_END_PORTAL = RenderType.create("end_portal", RenderSetup.builder(RenderPipelines.END_PORTAL).withTexture("Sampler0", AbstractEndPortalRenderer.END_SKY_LOCATION).withTexture("Sampler1", Identifier.withDefaultNamespace("textures/misc/shadow.png")).createRenderSetup());

  @Unique
  private static final Transformation rb$FLAT_TRANSFORMATION = new Transformation(new Vector3f(0f, -0.96875f, 0f), null, new Vector3f(1f), null);

  @Definition(id = "TRANSFORMATION", field = "Lnet/minecraft/client/renderer/blockentity/TheEndPortalRenderer;TRANSFORMATION:Lcom/mojang/math/Transformation;")
  @Expression("TRANSFORMATION")
  @ModifyExpressionValue(method = "submit(Lnet/minecraft/client/renderer/blockentity/state/EndPortalRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V", at = @At("MIXINEXTRAS:EXPRESSION"))
  private Transformation modifyTransformation(
      Transformation original,
      @Local(name = "state", argsOnly = true) EndPortalRenderState state
  ) {
    ClientLevel level = Minecraft.getInstance().level;
    if (level != null) {
      BlockEntity blockEntity = level.getBlockEntity(state.blockPos);
      if (blockEntity instanceof TheEndPortalBlockEntity endPortalBlockEntity) {
        if (((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).getStripType() == StrippedEndPortalConstants.FLATTENED) {
          return rb$FLAT_TRANSFORMATION;
        }
      }
    }
    return original;
  }

  @Definition(id = "endPortal", method = "Lnet/minecraft/client/renderer/rendertype/RenderTypes;endPortal()Lnet/minecraft/client/renderer/rendertype/RenderType;")
  @Expression("endPortal()")
  @ModifyExpressionValue(method = "submit(Lnet/minecraft/client/renderer/blockentity/state/EndPortalRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V", at = @At("MIXINEXTRAS:EXPRESSION"))
  private RenderType modifyRenderType(
      RenderType original,
      @Local(name = "state", argsOnly = true) EndPortalRenderState state
  ) {
    ClientLevel level = Minecraft.getInstance().level;
    if (level != null) {
      if (level.getBlockEntity(state.blockPos) instanceof TheEndPortalBlockEntity endPortalBlockEntity) {
        if (((ITheEndPortalBlockEntityStripExtension)endPortalBlockEntity).getStripType() == StrippedEndPortalConstants.STRIPPED) {
          return rb$STRIPPED_END_PORTAL;
        }
      }
    }
    return original;
  }

}
