package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.swap_regen_wither_client;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Hud.class)
@Environment(EnvType.CLIENT)
public abstract class HudMixin {

  @Shadow
  private int tickCount;
  @Unique
  private static boolean rb$modifiedWitherHeart = false;

  @Unique
  private static void rb$updateWitherHeart(boolean modify) {
    rb$modifiedWitherHeart = modify;
    Hud.HeartType withered = Hud.HeartType.WITHERED;
    if (modify) {
      withered.full = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "hud/heart/white_withered_full");
      withered.fullBlinking = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "hud/heart/white_withered_full_blinking");
      withered.half = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "hud/heart/white_withered_half");
      withered.halfBlinking = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "hud/heart/white_withered_half_blinking");
      withered.hardcoreFull = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "hud/heart/white_withered_hardcore_full");
      withered.hardcoreFullBlinking = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "hud/heart/white_withered_hardcore_full_blinking");
      withered.hardcoreHalf = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "hud/heart/white_withered_hardcore_half");
      withered.hardcoreHalfBlinking = Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "hud/heart/white_withered_hardcore_half_blinking");
    } else {
      withered.full = Identifier.withDefaultNamespace("hud/heart/withered_full");
      withered.fullBlinking = Identifier.withDefaultNamespace("hud/heart/withered_full_blinking");
      withered.half = Identifier.withDefaultNamespace("hud/heart/withered_half");
      withered.halfBlinking = Identifier.withDefaultNamespace("hud/heart/withered_half_blinking");
      withered.hardcoreFull = Identifier.withDefaultNamespace("hud/heart/withered_hardcore_full");
      withered.hardcoreFullBlinking = Identifier.withDefaultNamespace("hud/heart/withered_hardcore_full_blinking");
      withered.hardcoreHalf = Identifier.withDefaultNamespace("hud/heart/withered_hardcore_half");
      withered.hardcoreHalfBlinking = Identifier.withDefaultNamespace("hud/heart/withered_hardcore_half_blinking");
    }
  }

  @Inject(method = "extractHeart", at = @At("HEAD"))
  private void preExtractHeart(GuiGraphicsExtractor graphics, Hud.HeartType type, int xo, int yo, boolean isHardcore, boolean blinks, boolean half, CallbackInfo ci) {
    if (type == Hud.HeartType.WITHERED) {
      boolean modify = Config.SWAP_REGEN_WITHER_VISUAL.get();
      if (modify != rb$modifiedWitherHeart) rb$updateWitherHeart(modify);
    }
  }

  @Definition(id = "tickCount", field = "Lnet/minecraft/client/gui/Hud;tickCount:I")
  @Definition(id = "ceil", method = "Lnet/minecraft/util/Mth;ceil(F)I")
  @Definition(id = "maxHealth", local = @Local(type = float.class, name = "maxHealth"))
  @Expression("this.tickCount % ceil(maxHealth + ?)")
  @ModifyExpressionValue(method = "extractPlayerHealth", at = @At("MIXINEXTRAS:EXPRESSION"))
  private int modifyHeartOffsetCalculation(
      int original,
      @Local(name = "maxHealth") float maxHealth
  ) {
    if (Config.SWAP_REGEN_WITHER_VISUAL.get()) {
      return Math.floorMod(-this.tickCount, Mth.ceil(maxHealth + 5.0f));
    }
    return original;
  }

}
