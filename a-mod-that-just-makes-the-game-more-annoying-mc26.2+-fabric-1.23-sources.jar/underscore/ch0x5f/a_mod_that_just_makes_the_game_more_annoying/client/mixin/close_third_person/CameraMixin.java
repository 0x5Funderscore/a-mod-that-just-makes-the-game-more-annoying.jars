package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.close_third_person;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Camera.class)
@Environment(EnvType.CLIENT)
public abstract class CameraMixin {

  @ModifyArg(method = "alignWithEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;getMaxZoom(F)F"))
  private float modifyCameraDist(float cameraDist) {
    if (Config.CLOSE_THIRD_PERSON.get()) {
      return cameraDist / 12.0f;
    }
    return cameraDist;
  }

}
