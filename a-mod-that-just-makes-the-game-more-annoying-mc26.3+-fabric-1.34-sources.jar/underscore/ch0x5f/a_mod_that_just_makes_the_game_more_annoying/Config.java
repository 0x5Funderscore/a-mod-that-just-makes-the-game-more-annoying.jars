package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.fabricmc.loader.api.FabricLoader;
import org.jetbrains.annotations.ApiStatus;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import static underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.ConfigTags.*;


public enum Config implements ConfigProperty {

  BEDS_TP_TO_NETHER(server, true, "Beds have a chance to teleport players to the nether"),
  SHIELD_BLOCKING_DISABLES(server, true, "Shields have a chance to disable when hit by anything"),
  PHANTOMS_PICK_UP_PLAYERS(server, true, "Phantoms can pick you up and drop you from high up"),
  ALWAYS_SPAWN_PHANTOMS(server, true, "Phantoms can spawn every night"),
  OFFSET_CROSSHAIR(client, true, "The crosshair is slightly offset"),
  OFFSET_HUNGER_BAR(client, true, "The hunger bar is 2 pixels higher"),
  PIGLINS_BLOW_UP(server, false, "Piglins explode if they don't drop ender pearls"),
  EMERALD_INFLATION(server, false, "Every villager wants at least 64 emeralds"),
  SHUFFLE_CHESTS_ON_OPEN(server, true, "Chests randomize every time they're opened"),
  INVISIBLE_CREEPERS(client, true, "Creepers are invisible until they flash"),
  LOUD_CREEPER_EXPLOSIONS(server, true, "Explosions are 20 times louder"),
  UNCAPPED_VOLUME(client, true, "There's no limit on sound volume"),
  BROKEN_RECIPES(server, false, "Crafting recipe shapes are randomized every time an item is moved"),
  ITEMS_BREAK_RANDOMLY(server, true, "Items with durability have a chance to break when any durability is used, depending on the maximum durability of that item"),
  RANDOMLY_STOP_SNEAKING_IN_NETHER(client, true, "When sneaking in the nether, you have a chance to stop sneaking sometimes"),
  FRAGILE_OBSIDIAN(server, false, "Obsidian breaks (without dropping) when an entity stands on top of it"),
  GOOFY_SPIDERS(server, true, "Spiders track players from 96 blocks away and jump around a lot, gaining speed"),
  VICIOUS_HORSES(server, true, "Horses attack players and iron golems"),
  REQUIRE_BALANCED_DIET(server, true, "If you eat the same food 3 times in a Minecraft day, you die from not eating a balanced diet"),
  INVENTORY_GLASS_PANES_TROLL(server, true, "Empty inventory slots have a chance to become light gray stained glass pane (with curse of vanishing, no tooltip, and stack size of 1)"),
  BLOCK_DROPS_RANDOM_ATTRIBUTE_MODIFIERS(server, true, "Blocks can occasionally drop with random attribute modifiers"),
  DO_NOT_SWIM(both, true, "Just... don't swim..."),
  DISABLE_PAUSE(both, false, "Pausing in singleplayer doesn't actually pause the local server"),
  DESTROYING_BLOCKS_WITH_HAND_HURTS(server, true, "Destroying blocks with an empty hand makes you take damage"),
  ENVIRONMENTAL_TEMPERATURE_DAMAGE(server, false, "Players take freezing damage in cold biomes and fire damage in hot biomes"),
  SUPER_BOUNCY(both, true, "Bouncy things (slime, beds) are extremely bouncy"),
  REPLACE_END_PORTAL(both, true, "Strongholds no longer contain end portal frames (go to a stronghold to find out more information)"),
  BEEHIVES_EXPLODE_NEAR_PLAYERS(server, true, "Beehives explode when players get near, spawning 100 times as many bees"),
  BEES_STING_ENDLESSLY(server, true, "Bees don't lose their stinger or calm down after stinging"),
  ANXIOUS_ENDERMEN(server, true, "Endermen pick up and place blocks much more commonly"),
  ENDERMEN_RANDOMLY_GET_BOOM(server, true, "Endermen can randomly obtain TNT, redstone blocks, and fire"),
  GOOFY_ENDER_DRAGON(client, true, "The ender dragon's animations have been removed"),
  REPLACE_END_PLATFORM(server, true, "The end platform is made of barriers"),
  DIG_DOWN_LAVA_TROLL(server, true, "Underground in the overworld, or anywhere in the nether, if you mine straight down, you can encounter one block of lava"),
  QUICKGRAVEL(server, true, "Gravel jumps up and acts like quicksand when an entity stands on it"),
  GRAVEL_AND_STONES_FALL_ON_YOUR_HEAD(server, true, "When standing other gravel, dripstone, or any other overworld or nether stone, it can fall on your head"),
  HALVE_DRAGON_DAMAGE(server, false, "The ender dragon takes 50% less damage"),
  DRAGON_EGGS_TELEPORT_FURTHER(both, true, "Dragon eggs can teleport really far away"),
  REQUIRE_8_CRYSTALS_FOR_RESPAWN(server, true, "You now need 8 crystals to respawn the dragon"),
  END_CRYSTALS_REQUIRE_PLAYER_PUNCH(server, false, "End crystals need player (melee) attacks to break"),
  LESS_COAL_ORE(server, true, "Coal veins are much smaller"),
  COAL_BURNS_FAST(server, false, "Coal and charcoal burn much faster"),
  FURNACE_COOKING_TIME_X5(server, false, "Furnaces and campfires take 5 times as long to cook"),
  FURNACE_EXPONENTIAL_PROGRESS(client, true, "The furnace progress meter is inverse exponential (slows down as it gets more)"),
  FALL_DAMAGE_AT_2_BLOCKS(both, false, "You take fall damage at 2 blocks"),
  DIFFERENT_END_BED_EXPLOSION(server, true, "Beds spawn an acid cloud instead of exploding in the end"),
  SLEEP_LATE(server, true, "You can only sleep late"),
  TERRIBLE_REPUTATION(server, true, "Villager reputation starts really bad and stays really bad"),
  SWEET_BERRY_BUSHES_SPREAD(server, true, "Sweet berry bushes can spread to nearby blocks"),
  SWEET_BERRY_BUSHES_APPLY_EFFECTS(server, true, "Sweet berry bushes apply poison, nausea, and slowness"),
  EVERY_ZOMBIE_IS_A_LEADER(server, true, "Every zombie is a leader zombie (stronger and can spawn allies)"),
  REALLY_HARD_MODE(server, true, "Local difficulty is always at 10 (the maximum possible in vanilla is 9)"),
  THIN_BRIDGES_BREAK(server, true, "One block wide bridges break when you stand on them"),
  THIN_ICE(server, true, "When you stand on ice in a cold biome, it melts instantly"),
  ENDERMEN_TELEPORT_A_LOT(server, false, "Endermen constantly teleport"),
  TTS_GUIDE(client, false, "There's a \"helpful\" TTS guide that gives you tips when you die"),
  END_PORTAL_NEEDS_FRAME(server, true, "End portals break if they aren't adjacent to other end portals, end portal frames, or bedrock"),
  FALL_THROUGH_LEAVES(both, false, "Leaves have no hitbox and deal damage to mobs moving inside them"),
  WITHER_SKELETONS_COMBINE(server, true, "Three wither skeletons near each other can combine into a wither"),
  SPLASH_POTIONS_EXPLODE(server, true, "Splash potions have a chance to explode when they land"),
  ANIMALS_STOP_SLEEP(server, true, "For the purposes of sleeping, anything other than a player is a monster"),
  DOORS_CHANGE_RANDOMLY(server, true, "Doors occasionally change direction and state"),
  ALL_ZOMBIES_ARE_BABIES(server, false, "All zombies are babies"),
  MINING_FATIGUE_UNAFFECTED_BY_MILK(server, false, "Mining fatigue can't be removed by milk (doesn't work with lactose_intolerance)"),
  REPLACE_LAVA_SOLIDIFICATION(server, true, "Lava can turn into any of a whole list of metamorphic rocks, and can't make obsidian next to other obsidian"),
  ELDER_GUARDIAN_INCREASED_RANGE(server, true, "Elder guardians have increased mining fatigue checking speed and range"),
  TAMING_ANIMALS_EXPLODES(server, false, "Animals explode when tamed"),
  BED_WETTING(server, true, "There's a chance to spawn a water block above the feet of the bed when you sleep"),
  INVERSE_ABSORPTION(both, true, "Absorption is negative for players"),
  LOWER_STEP_HEIGHT(both, true, "Player step height is lowered"),
  DOORS_ARE_AFRAID_OF_WATER(server, false, "Doors start flying around when they touch water"),
  RARE_ITEMS_FLY_AWAY(both, true, "Items with a rarity more than common, beacon payment items, books, and armor trim materials are pushed away from players"),
  SWEEPING_DAMAGES_SELF(server, true, "Sweeping attacks don't exclude the attacker"),
  ORIGIN_DESERT(server, false, "Everything within 500 blocks of spawn is replaced with a desert, without any structures"),
  EXPERIENCE_ORBS_HURT(server, true, "Experience orbs hurt players"),
  NO_XP(server, false, "Players can't gain experience"),
  SKELETON_HOMING_ARROWS(server, true, "Skeleton arrows curve towards their target"),
  NO_ENCHANTING_TABLES(server, true, "You can't have enchanting tables in your inventory"),
  EXPLODE_ON_PLACE(server, false, "There's a chance blocks explode when you place them"),
  ANNOYING_TRAPPED_CHESTS(server, false, "Trapped chests close and taunt you"),
  FAST_GHASTS(server, true, "Ghasts shoot at 2 fireballs per second"),
  FURNACE_TOUCH_DAMAGE(server, true, "You take fire damage when you have the furnace GUI open if it's lit"),
  LAVA_SPREADS_LAVA(server, false, "Lava spreads lava instead of fire"),
  EDGING_TNT(server, true, "TNT stops just before the explosion (and becomes invisible) until a player approaches"),
  FALL_HEART_ATTACKS(server, false, "Every 5 seconds there's a chance you die of fall damage"),
  FUEL_ALWAYS_BURNS(server, true, "Fuel burns in a furnace without ingredients"),
  OVERCOOKING(server, false, "Attempting to smelt the 5th item in a furnace turns the entire result slot into 4 charcoal"),
  HOLDING_LAVA_HURTS(server, true, "You take fire damage while holding a lava bucket"),
  LAVA_BLOWS_UP_FURNACES(server, true, "Lava blows up furnaces when used as fuel"),
  ENCHANTMENTS_DISAPPEAR(server, true, "When an enchanted item takes durability, there's a chance a random enchantment is removed"),
  LACTOSE_INTOLERANCE(server, true, "Milk doesn't clear any effects and applies nausea instead (doesn't work with mining_fatigue_unaffected_by_milk)"),
  SHORT_ENDERMAN_HITBOX(both, true, "Endermen's hitboxes are now 1.8 blocks tall"),
  ENDERMEN_SOCIAL_ANXIETY(server, true, "Endermen get angry if you look anywhere near them"),
  ENDERMEN_DONT_FREEZE(server, true, "Endermen don't freeze when looked at"),
  ENDERMEN_HOLD_ANYTHING(server, true, "Endermen can pick up anything (except wither immune blocks)"),
  ENDERMEN_HOLD_WITHER_IMMUNE(server, false, "Endermen can pick up wither immune blocks"),
  FRAGILE_END_PORTAL(server, false, "After entering an end portal, there's a chance it breaks"),
  SLOW_ARMOR(server, false, "For players, each worn non-leather armor piece multiplies speed by 80%"),
  ALTITUDE_TEMPERATURE_DAMAGE(server, false, "You take freezing damage at high altitudes and fire damage at low altitudes"),
  EXPLOSIVE_RABBITS(server, true, "Rabbits have bombs and explode when they die"),
  NORMAL_RAILS_ARE_POWERED_OFF(server, true, "All rails have the same speed as powered rails without redstone"),
  ENDERMEN_UNAFFECTED_BY_WATER(server, true, "Endermen aren't affected by water"),
  BATS_TARGET_EYES(server, true, "Bats fly towards nearby players' eyes"),
  BEDROCK_OFFHAND_OR_LIGHTNING(server, true, "If your offhand contains something that you can't offhand in Bedrock, it's forcefully dropped and struck by lightning"),
  ITEMS_DIE_NEAR_PLAYERS(server, true, "Items despawn faster when players are nearby"),
  RAILS_SPAWN_FURNACE_MINECARTS(server, true, "Rails can spawn furnace minecarts sometimes"),
  FURNACE_MINECARTS_USELESS(server, true, "Furnace minecarts don't do anything"),
  INVENTORY_WATER_BUCKET_SPILLING(server, true, "Water in your inventory can spill onto other slots when you make sudden movements"),
  ENDERMEN_TARGET_IMPORTANT_BLOCKS(server, true, "Endermen target \"important\" blocks more"),
  LANDMINES(server, true, "Landmines exist: They can spawn randomly when another mob spawns, slowly move towards the nearest player, and cannot be killed or broken"),
  MOSTLY_REMOVE_SQUIDS(server, false, "Squids are much rarer"),
//  TALL_LANDS(server, false, "Tall Lands (my other mod)"),
  REMOVE_TOOLTIP_BACKGROUNDS(client, true, "Tooltips don't have a background anymore"),
  NO_SLOT_HIGHLIGHT(client, false, "Item slot highlights are removed"),
  OFFSET_SLOT_HIGHLIGHT(client, true, "Item slot highlights are offset by 1.5 slots"),
  WILD_TAMED_ANIMALS(server, true, "Tamed animals go wild when they take damage"),
  LLAMA_SPIT_LAUNCH(server, true, "Llama spit has extreme knockback"),
  IRON_GOLEM_EXTENDED_REACH(server, true, "Iron golems have extended reach"),
  IRON_GOLEM_SPACE_PROGRAM(server, true, ":)"),
  NERVOUS_HORSES(server, true, "Horses dismount if they fall or take damage"),
  SHULKER_MACHINE_GUNS(server, true, "Shulkers are machin guns"),
  SKELETON_SHOTGUNS(server, false, "Skeletons have arrow shotguns"),
  FIFTY_SKELETON_HORSES(server, true, "Trap skeleton horses spawn 50 horsemen instead of 4"),
  CHICKENS_V2(server, true, "Chickens are version 2"),
  LAVA_FLOWS_FAST(server, true, "Lava flows faster than water"),
  FLYING_SQUIDS(server, true, "Squids can fly"),
  NEUTRAL_LEVITATION(both, true, "Levitation doesn't make you go up, but removes your gravity"),
  CREEPERS_IGNORE_CATS(server, true, "Creepers are chill around cats"),
  FURNACES_LITERALLY(server, true, "Blast furnaces blast, and smokers smoke"),
  FLETCHING_TABLES_SHOOT(server, true, "Fletching tables shoot arrows"),
  SHULKERS_SHOOT_CLOSED(server, true, "Shulkers don't have to open to shoot"),
  UNBREAKING_ELYTRA_FLIES_SLOWER(both, true, "Elytra enchanted with unbreaking flies slower"),
//  END_SOUL_SAND_AND_BASALT_DELTAS(server, true),
  ENDER_PEARLS_MOVE_SLOWLY(both, true, "Ender pearls move much slower"),
  SKELETON_DODGING(server, false, "Skeletons dodge melee attacks"),
  HISSBINES(server, true, "Hissbines from ASTRONEER (a plant that shoots slow acid balls)"),
//  INCREASED_PLAYER_HEIGHT(both, false),
  MONSTERS_WITH_HELMETS(server, true, "Any mob that can spawn with armor will spawn with at least a helmet"),
  SMALLER_BABY_ZOMBIES(both, false, "Baby zombies are twice as small"),
  FASTER_BABY_ZOMBIES(server, true, "Baby zombies are much faster"),
  BLAZE_MACHINE_GUNS(server, true, "Blaze fireball volleys are endless"),
  NETHERITE_WITHER_SKELETONS(server, false, "Wither skeletons spawn with full netherite armor and iron swords (but none of it can drop)"),
  SHORT_WITHER_SKELETON_HITBOX(both, true, "Wither skeletons' hitboxes are now 1.8 blocks tall"),
  MOBS_DONT_DAMAGE_HELMETS(server, true, "Helmets protecting mobs from sunlight no longer take damage when they burn"),
  MOB_ARMOR_BINDING_CURSE(server, true, "All armor dropped from mobs has curse of binding"),
  NO_OFFHAND_KEY(client, false, "\"Swap mainhand and offhand\" key no longer works (but it works inside inventory for some reason)"),
  MORE_LIGHTNING(server, true, "Lightning bolts are more common and concentrated towards players who have anything made of copper or repairable with copper"),
  MORE_THUNDERSTORMS(server, true, "Clear weather lasts one fifth as long"),
  NAUSEA_INVERTED_MOVEMENT(client, true, "Nausea inverts movement"),
  WITCHES_THROW_LINGERING(server, true, "Witches throw lingering potions"),
  WITCHES_THROW_DIFFERENT_POTIONS(server, true, "Witches can throw harming, poison, slowness, weakness, weaving, and oozing potions, as well as longer and higher level potions"),
//  MORE_WITCH_SPAWNS(server, true),
  BOILING_NETHER_WATER_CAULDRONS(server, true, "Water cauldrons in the nether boil players inside them"),
  SUPER_SURGE_CONDUCTOR(server, true, "Holding a lightning rod or channeling trident in a storm makes you get struck by lightning a lot"),
  SUN_GLARE(client, true, "Looking towards the sun or an end flash puts a glare effect over your screen"),
  SOLIDIFYING_LAVA(server, true, "Lava turns into obsidian in dimensions that don't have fast lava (namely, the overworld and end)"),
  COPPER_GOLEM_LIGHTNING(server, true, "Copper golems exposed to the sky get obliterated by Zeus"),
  TIMID_SHEEP(server, true, "Sheep run away from players"),
  NO_STRING_WOOL(server, true, "Wool cannot be crafted from string"),
  LOUD_LEAF_LITTER(both, true, "Leaf litter is very loud"),
  VAULTS_DISPENSE_MOBS(server, true, "Instead of dropping items, vaults dispense mobs that drop those items"),
  THUNDERSTORM_SCREW_YOU_IN_PARTICULAR(server, true, "When you equip copper armor, a thunderstorm starts, you get struck by lightning, and the thunderstorm stops"),
  FAST_WARDEN(server, false, "The warden moves faster"),
  FOXES_SCAN_INVENTORIES(server, true, "Foxes are hostile to players who have fox food in their inventory"),
  CAVE_FLOWER_HAYFEVER(server, true, "Standing under a spore blossom or azalea flowers gives you nausea and poison"),
  CATS_SCAN_INVENTORIES(server, true, "Cats are hostile towards players with egg or fish in their inventories"),
  SAME_SIZE_SLIMES(server, true, "Slimes don't get smaller when they split, but all slimes drop slime balls"),
  SHY_FURNACES(server, false, "Furnaces are shy and won't light unless you're looking away and give them space"),
  DISAPPEARING_CATS(server, false, "Cats instantly disappear when you're within 5 blocks of them and not holding fish"),
  WARDEN_SIGHT(server, true, "The warden can see"),
  GLOW_SQUIDS_HATCH_SILVERFISH(server, false, "Glow squids that die of drowning (air) hatch silverfish"),
  NO_VIBRATION_OCCLUDING(server, true, "Wool doesn't block vibrations anymore"),
  WILDER_WOLVES(server, true, "Wolves are hostile towards players who aren't holding meat or bone"),
  CHANGE_PIGLIN_BARTER_LOOT(server, true, "Piglins no longer have useful trades"),
  SMART_BLOCK_DROPS(server, true, "Items dropped from blocks try to drop into lava, fire, void, or away from the player"),
  WORSE_ORES_AND_INGOTS(server, false, "Ingots don't stack, and ores and raw materials have a chance of smelting into themselves"),
  FURNACE_OUTPUT_SINGLETON(server, false, "Furnaces can't smelt if their output is occupied"),
  FURNACE_PLACEMENT_FLIPPED(server, true, "Furnaces have a 50% chance of being placed facing the opposite direction"),
  RANDOM_PLACEMENT_DIRECTIONS(server, false, "Placement directions are all randomized"),
  RANDOM_CREEPER_HISS(client, false, "There's a chance every tick that a creeper hiss plays behind you"),
  MOB_CRITS(server, true, "Mobs can do critical attacks"),
  RANDOMIZE_HUNGER_ON_WAKE(server, true, "Hunger is randomized when you wake up, but can't increase"),
  LOUD_CAVE_SOUNDS(client, true, "Cave sounds are much louder"),
  DAMAGED_CHEST_LOOT(server, true, "Any randomized loot that has durability will spawn with 2 durability left"),
  POVERTY_VILLAGES(server, true, "Village loot cannot generate food or emeralds"),
  NETHER_ROOF_PROTECTION(server, true, "You can't build above the nether roof"),
  BREAK_NETHER_COORDS(server, true, "Nether coordinate conversion is broken (but consistent for the same world)"),
  UNSTABLE_CREEPERS(server, true, "Creeper fuse time is randomized between 0.5 and 1.5 times as long"),
  HOT_ITEM_FIRE(server, true, "Holding a hot item deals fire damage"),
  FLOATING_FISH(server, true, "Fish float when they're out of water"),
  ALWAYS_RAID(server, false, "Every player can start a level 1 raid (but isn't rewarded for it)"),
  MOB_STACKS(server, true, "The Tower (from Minecraft Dungeons) can spawn with any zombie variant"),
  SWAP_POTATOES(server, true, "The consumption results of normal and poisonous potatoes are swapped"),
  CREEPER_EXPLOSION_CHAIN(server, true, "Creepers ignite when exploded, instead of taking damage"),
  RAIN_SILVERFISH(server, true, "During rain, silverfish spawn"),
  SWAP_REGEN_WITHER(server, true, "The effects of wither and regeneration are swapped"),
  SWAP_REGEN_WITHER_VISUAL(client, true, "Wither and regeneration are visually swapped (wither is white, regeneration goes left)"),
  CLOSE_THIRD_PERSON(client, false, "Third person is uselessly close"),
  NETHER_WATER(server, true, "You can put water in the nether, but it boils players"),
//  MIDDLE_LOG_BREAK_STRIP(server, false),
//  MOBS_DRIVE_BOATS(server, true, "Mobs can drive boats"),
  CREEPER_IGNITE_FIRE_DAMAGE(server, true, "Creepers ignite when they take fire damage"),
  LETHAL_POISON(server, true, "Poison can kill"),
  ANTI_VEIN_MINER(server, false, "When you break an ore, all connected ores are converted into their base stone variants"),
//  FRACTAL_END(server, false),
  EMPATHETIC_OBSIDIAN(server, true, "Obsidian cries when you break nearby obsidian"),
  ENDER_DRAGON_REQUIRES_MELEE(server, true, "The ender dragon only takes damage from melee attacks"),
  TOUCHY_MENUS(client, true, "Menu buttons run away from the cursor"),
  FISHING(both, true, "I love fishing :3"),
  VILLAGER_CURING_NITWIT(server, true, "Curing a villager makes them a nitwit"),
  AXE_SHEARING(server, true, "You have to strip sheep instead of shearing them"),
  STRIPPED_END_PORTAL(both, true, "End portal can be stripped (with an axe) and flattened (with a shovel)"),
  INVISIBLE_OBSIDIAN(client, false, "Obsidian is invisible (but weird and buggy)"),
  FALLING_BLOCKS_DROP_LOOT(server, true, "Falling blocks drop by their loot tables instead of their item forms"),
  SKELETON_INCREASED_RANGE(server, true, "Skeletons can see from 50 blocks away"),
  ANVILS_FALL_UP(server, true, "Anvils fall up instead of down"),
  EXPLODING_ENDER_EYES(server, true, "Thrown ender eyes explode if they break"),
  END_PORTAL_FRAME_MISCLICK(server, true, "Inserting an eye into an end portal frame only works 25% of the time"),
  ROTATED_MAP_ICONS(client, true, "Map decorations are rotated incorrectly"),
  VILLAGER_VENGEANCE(server, false, "Killing a villager turns nearby villagers into vindicators with diamond axes"),
  SMALL_BUGS(both, false, "Spiders, cave spiders, silverfish, endermites, and bees are very small"),
  STONECUTTER_DAMAGE(server, true, "Stonecutters damage players (only)"),
  LEGACY_BOAT_COLLISION(server, true, "Boats break when they hit blocks, like in older versions"),
  FIGHTING_FISH(server, true, "The fish fight back (salmon, cod, and tropical fish)"),
  TRAPPED_BURIED_TREASURE(server, true, "Buried treasure is a trap"),
  SPAWN_POINT_FAILURE(server, false, "Respawning sometimes fails and resets your spawn point"),
  MORE_COPPER_ORE(server, true, "Copper ore veins are bigger"),
  ELYTRA_GENERATES_BROKEN(server, true, "Elytra in end city ships generate with no durability left"),
  DECONSTRUCT_FURNACES(server, true, "Furnaces decompose into their components when destroyed"),
  MOVE_BURIED_TREASURE(server, false, "Buried treasure chests have moved, leaving a notice at their previous location"),
  DISABLE_ITEM_GROUPING(server, false, "Items no longer merge together"),
  SHOUTOUT_YAHIAMICE(client, () -> AMTJMTGMA.playerUsername.equalsIgnoreCase("yahiamice"), "A tribute to Yahiamice"),
  POPUP_ADS(client, true, "Pop-up ads appear on screen occasionally"),
  MONSTER_SHIPWRECKS(server, true, "Beware of shipwrecks in deep oceans..."),
  MAGMA_BREAKS_FALLING_BLOCKS(server, true, "Falling blocks break when they hit magma blocks"),
  WHERE_IS_VILLAGE(server, true, "Tells you where the nearest village is when you respawn without a bed"),
  FAST_BUBBLE_COLUMNS(both, true, "Bubble columns are much stronger"),
  INSUFFICIENT_BUBBLE_COLUMNS(server, true, "Bubble columns only keep your oxygen the same, instead of regenerating it"),
  THIEVING_PIGLINS(server, true, "Piglins can't stop themselves from getting their grubby hands on your nice shiny gold armor"),
  RABBITS_LOVE_PLAYERS(server, true, "Rabbits LOVE players"),
  STRONGER_NAUSEA_EFFECT(client, true, "Nausea screen warping is much worse"),
  SCRAPE_STONE(both, false, "Walking on stone-sound blocks without shoes makes scraping sounds")
  ;

  private final String side;
  private final String name;
  private boolean value;
  private final BooleanSupplier defaultValueSupplier;

  public final String description;

  Config(String side, boolean defaultValue, String description) {
    this(side, () -> defaultValue, description);
  }

  Config(String side, BooleanSupplier defaultValueSupplier, String description) {
    this.side = side;
    this.name = this.name().toLowerCase(Locale.ROOT);
    this.value = (this.defaultValueSupplier = defaultValueSupplier).getAsBoolean();
    this.description = description;
  }

  @Override
  public boolean get() {
    return this.value;
  }

  @Override
  public boolean getDefault() {
    return this.defaultValueSupplier.getAsBoolean();
  }

  @Override
  public void set(boolean value) {
    this.value = value;
  }

  @Override
  public String getSide() {
    return this.side;
  }

  @Override
  public String getName() {
    return this.name;
  }

  @Override
  public String getDescription() {
    return this.description;
  }

  private static void loadConfigFile(File configFile) throws RuntimeException, IOException {
    if (configFile.exists()) {

      try {

        FileReader fileReader = new FileReader(configFile);
        JsonObject jsonObject = JsonParser.parseReader(fileReader).getAsJsonObject();
        fileReader.close();

        all.forEach(property -> property.setFrom(jsonObject));

      } catch (Exception e) {
        throw new RuntimeException("AMTJMTGMA config failed to load.", e);
      }

    } else {

      LogUtils.getLogger().info("Creating new AMTJMTGMA config");

      configFile.getParentFile().mkdirs();
      configFile.createNewFile();

    }

    JsonObject configObject = new JsonObject();
    forEach(property -> property.storeTo(configObject));

    FileWriter writer = new FileWriter(configFile);
    writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(configObject));
    writer.close();

  }

  @ApiStatus.Internal
  public static void loadConfig() throws RuntimeException, IOException {
    LogUtils.getLogger().info("Loading AMTJMTGMA config");
    loadConfigFile(FabricLoader.getInstance().getConfigDir().resolve("a_mod_that_just_makes_the_game_more_annoying.json").toFile());
  }

  public static void saveConfig() {
    File configFile = FabricLoader.getInstance().getConfigDir().resolve("a_mod_that_just_makes_the_game_more_annoying.json").toFile();

    JsonObject configObject = new JsonObject();
    forEach(property -> property.storeTo(configObject));

    try {
      FileWriter writer = new FileWriter(configFile);
      writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(configObject));
      writer.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private static final List<ConfigProperty> all = new ArrayList<>(List.of(values()));

  public static void forEach(Consumer<ConfigProperty> consumer) {
    all.forEach(consumer);
  }

  public static ConfigProperty register(String side, String name, boolean defaultValue, String description) {
    ConfigProperty configProperty = new ConfigProperty() {
      private boolean value = defaultValue;

      @Override
      public boolean get() {
        return this.value;
      }

      @Override
      public boolean getDefault() {
        return defaultValue;
      }

      @Override
      public void set(boolean value) {
        this.value = value;
      }

      @Override
      public String getSide() {
        return side;
      }

      @Override
      public String getName() {
        return name;
      }

      @Override
      public String getDescription() {
        return description;
      }
    };
    all.add(configProperty);
    return configProperty;
  }

}
