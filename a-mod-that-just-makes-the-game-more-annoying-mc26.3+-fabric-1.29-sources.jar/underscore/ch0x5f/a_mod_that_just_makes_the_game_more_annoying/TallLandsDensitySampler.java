package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import net.minecraft.world.level.levelgen.densityfunction.DensityBuffer;
import net.minecraft.world.level.levelgen.densityfunction.DensitySampler;
import net.minecraft.world.level.levelgen.densityfunction.DensityVolume;
import net.minecraft.world.level.levelgen.densityfunction.SamplerContext;


public class TallLandsDensitySampler implements DensitySampler {

  private final DensitySampler original;

  public TallLandsDensitySampler(DensitySampler original) {
    this.original = original;
  }

  @Override
  public void sampleVolume(SamplerContext context, DensityBuffer outputBuffer, DensityVolume volume) {
    this.original.sampleVolume(context, outputBuffer, volume);
  }

  @Override
  public float sampleValue(SamplerContext context, int blockX, int blockY, int blockZ) {
    return this.original.sampleValue(context, blockX, blockY, blockZ) * (Config.TALL_LANDS.get() ? 128f : 0f);
  }
}
