package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.tall_lands;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.level.levelgen.densityfunction.DensitySampler;
import net.minecraft.world.level.levelgen.synth.BlendedNoise;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.TallLandsDensitySampler;


@Mixin(BlendedNoise.class)
public abstract class BlendedNoiseMixin {

  @ModifyReturnValue(method = "compileSampler(Lnet/minecraft/util/RandomSource;)Lnet/minecraft/world/level/levelgen/densityfunction/DensitySampler;", at = @At("RETURN"))
  private DensitySampler modifySampler(DensitySampler original) {
    return new TallLandsDensitySampler(original);
  }

}
