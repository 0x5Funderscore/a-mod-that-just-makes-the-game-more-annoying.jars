package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.small_bugs;

import net.minecraft.core.Holder;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CTags;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Objects;


@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity {

  @Shadow
  public abstract @Nullable AttributeInstance getAttribute(Holder<Attribute> attribute);

  public LivingEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tick", at = @At("HEAD"))
  private void preTick(CallbackInfo ci) {
    if (this.is(EntityTypeTags.ARTHROPOD) || this.is(EntityTypeTags.BEEHIVE_INHABITORS) && this.tickCount <= 0 && Config.SMALL_BUGS.get()) {
      Objects.requireNonNull(this.getAttribute(Attributes.SCALE)).setBaseValue(0.2d);
    }
  }
}
