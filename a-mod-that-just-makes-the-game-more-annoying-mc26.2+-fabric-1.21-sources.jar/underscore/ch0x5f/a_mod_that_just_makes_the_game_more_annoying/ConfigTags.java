package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import com.mojang.logging.LogUtils;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.*;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.timeline.Timeline;
import org.jetbrains.annotations.Contract;
import org.slf4j.Logger;

import java.util.Collection;
import java.util.HashSet;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public final class ConfigTags {
  static String server = "server";
  static String client = "client";
  static String both = "*";

  public static final class Affects {

    private final RegistryCollection<DamageType> damageType = new RegistryCollection<>(Registries.DAMAGE_TYPE);
    private final RegistryCollection<EntityType<?>> entityType = new RegistryCollection<>(Registries.ENTITY_TYPE);
    private final RegistryCollection<Item> item = new RegistryCollection<>(Registries.ITEM);
    private final RegistryCollection<Block> block = new RegistryCollection<>(Registries.BLOCK);
    private final RegistryCollection<Fluid> fluid = new RegistryCollection<>(Registries.FLUID);
    private final RegistryCollection<Biome> biome = new RegistryCollection<>(Registries.BIOME);
    private final RegistryCollection<Enchantment> enchantment = new RegistryCollection<>(Registries.ENCHANTMENT);
    private final RegistryCollection<ConfiguredFeature<?,?>> feature = new RegistryCollection<>(Registries.CONFIGURED_FEATURE);
    private final RegistryCollection<GameEvent> gameEvent = new RegistryCollection<>(Registries.GAME_EVENT);
    private final RegistryCollection<Potion> potion = new RegistryCollection<>(Registries.POTION);
    private final RegistryCollection<Structure> structure = new RegistryCollection<>(Registries.STRUCTURE);
    private final RegistryCollection<Timeline> timeline = new RegistryCollection<>(Registries.TIMELINE);
    private final RegistryCollection<MobEffect> mobEffect = new RegistryCollection<>(Registries.MOB_EFFECT);

    private Affects() {
    }

//    public Affects affects(Object... items) {
//      for (Object item: items) {
//        if (item instanceof TagKey<?> tagKey) {
//          var targetRegistryKey = tagKey.registry();
//
//          Optional<RegistryCollection<?>> targetCollection = Stream.of(
//              this.damageType,
//              this.entityType,
//              this.item,
//              this.block,
//              this.fluid,
//              this.biome,
//              this.enchantment,
//              this.feature,
//              this.gameEvent,
//              this.potion,
//              this.structure,
//              this.timeline,
//              this.mobEffect
//          )
//              .filter(registryCollection -> registryCollection.isForRegistry(targetRegistryKey))
//              .findAny();
//
//          if (targetCollection.isPresent()) {
//            //
//          } else {
//            throw new IllegalArgumentException("invalid affect tag registry: " + targetRegistryKey);
//          }
//
//        } else {
//          RegistryCollection<?> targetCollection = switch (item) {
//            case DamageType ignored -> this.damageType;
//            case EntityType<?> ignored -> this.entityType;
//            case Item ignored -> this.item;
//            case Block ignored -> this.block;
//            case Fluid ignored -> this.fluid;
//            case Biome ignored -> this.biome;
//            case Enchantment ignored -> this.enchantment;
//            case ConfiguredFeature<?,?> ignored -> this.feature;
//            case GameEvent ignored -> this.gameEvent;
//            case Potion ignored -> this.potion;
//            case Structure ignored -> this.structure;
//            case Timeline ignored -> this.timeline;
//            case MobEffect ignored -> this.mobEffect;
//            default -> throw new IllegalArgumentException("invalid affect target: " + item);
//          };
//          //noinspection unchecked
//          ((RegistryCollection<Object>)targetCollection).add(Holder.direct(item));
//        }
//      }
//    }

    public static class RegistryCollection <T> {

      private final Collection<String> tagsUnresolved = new HashSet<>();
      private final Collection<String> individualUnresolved = new HashSet<>();

      private final Collection<Holder<T>> resolved = new HashSet<>();

      private final ResourceKey<Registry<T>> registryKey;

      public RegistryCollection(ResourceKey<Registry<T>> registryKey) {
        this.registryKey = registryKey;
      }

      public boolean isForRegistry(ResourceKey<? extends Registry<?>> registryKey) {
        return this.registryKey.equals(registryKey);
      }

      public boolean check(TagKey<T> tag) {
        return this.resolved.parallelStream().anyMatch(holder -> holder.is(tag));
      }
      public boolean check(Identifier identifier) {
        return this.resolved.parallelStream().anyMatch(holder -> holder.is(identifier));
      }
      public boolean check(ResourceKey<T> key) {
        return this.resolved.parallelStream().anyMatch(holder -> holder.is(key));
      }
      public boolean check(Holder<T> holder) {
        return this.resolved.parallelStream().anyMatch(otherHolder -> otherHolder.value() == holder.value());
      }
      public boolean check(T value) {
        return this.resolved.parallelStream().anyMatch(holder -> holder.value() == value);
      }

      public Collection<T> getValues() {
        return this.resolved.parallelStream().map(Holder::value).collect(Collectors.toUnmodifiableSet());
      }

      @Contract(value = "_ -> this", mutates = "this")
      public RegistryCollection<T> resolve(RegistryAccess registryAccess) {
        Logger logger = LogUtils.getLogger();

        Registry<T> registry = registryAccess.lookupOrThrow(this.registryKey);

        this.tagsUnresolved
            .forEach(tagString -> {
              for (Holder<T> holder: registry.getTagOrEmpty(TagKey.create(registryKey, Identifier.parse(tagString))))
                this.resolved.add(holder);
            });
        this.tagsUnresolved.clear();

        this.individualUnresolved
            .forEach(idString -> registry.get(Identifier.parse(idString)).ifPresentOrElse(
                this.resolved::add,
                () -> logger.warn("AMTJMTGMA: unknown target for {}: {}", registry.key(), idString)
            ));
        this.individualUnresolved.clear();

        return this;
      }

      @Contract(value = "_ -> this", mutates = "this")
      public RegistryCollection<T> tag(String tag) {
        tagsUnresolved.add(tag);
        return this;
      }

      @Contract(value = "_ -> this", mutates = "this")
      public RegistryCollection<T> one(String one) {
        individualUnresolved.add(one);
        return this;
      }

      @Contract(value = "_ -> this", mutates = "this")
      public RegistryCollection<T> add(Holder<T> holder) {
        this.resolved.add(holder);
        return this;
      }
    }
  }
}
