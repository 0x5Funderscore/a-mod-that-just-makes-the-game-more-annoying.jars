package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client;

import com.mojang.text2speech.Narrator;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import org.jetbrains.annotations.Nullable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


public class TTSGuide {

  public static final Narrator narrator = Narrator.getNarrator();

  public static void sayRandom(String ...messages) {
    narrator.say(messages[Mth.floor(Math.random() * messages.length)], true, 1f);
  }

  public static void provideContextualAdvice(ClientLevel level, LocalPlayer player) {
    if (!Config.TTS_GUIDE.get()) return;
  }

  public static void provideDeathAdvice(ClientLevel level, LocalPlayer player, @Nullable DamageSource deathSource) {
    if (!Config.TTS_GUIDE.get() || deathSource == null) return;
    if (deathSource.is(DamageTypes.IN_FIRE)) {
      sayRandom(
          "tip: fire hurts you"
      );
    } else if (deathSource.is(DamageTypes.CAMPFIRE)) {
      sayRandom(
          "tip: campfires are fires"
      );
    } else if (deathSource.is(DamageTypes.LIGHTNING_BOLT)) {
      sayRandom(
          "tip: don't get struck by lightning"
      );
    } else if (deathSource.is(DamageTypes.ON_FIRE)) {
      sayRandom(
          "tip: don't burn"
      );
    } else if (deathSource.is(DamageTypes.LAVA)) {
      sayRandom(
          "tip: don't eat lava"
      );
    } else if (deathSource.is(DamageTypes.HOT_FLOOR)) {
      sayRandom(
          "tip: don't stand on hot rocks"
      );
    } else if (deathSource.is(DamageTypes.IN_WALL)) {
      sayRandom(
          "tip: don't suffocate"
      );
    } else if (deathSource.is(DamageTypes.CRAMMING)) {
      sayRandom(
          "tip: don't jump into a mosh pit"
      );
    } else if (deathSource.is(DamageTypes.DROWN)) {
      sayRandom(
          "tip: don't drown"
      );
    } else if (deathSource.is(DamageTypes.STARVE)) {
      sayRandom(
          "tip: eat properly"
      );
    } else if (deathSource.is(DamageTypes.CACTUS)) {
      sayRandom(
          "tip: don't touch prickly things"
      );
    } else if (deathSource.is(DamageTypes.FALL)) {
      sayRandom(
          "tip: don't fall"
      );
    } else if (deathSource.is(DamageTypes.ENDER_PEARL)) {
      sayRandom(
          "tip: don't die from ender pearls"
      );
    } else if (deathSource.is(DamageTypes.FLY_INTO_WALL)) {
      sayRandom(
          "tip: don't fly into walls"
      );
    } else if (deathSource.is(DamageTypes.FELL_OUT_OF_WORLD)) {
      sayRandom(
          "tip: don't fall out of the world"
      );
    } else if (deathSource.is(DamageTypes.MAGIC)) {
      sayRandom(
          "tip: don't expose yourself to magic"
      );
    } else if (deathSource.is(DamageTypes.WITHER)) {
      sayRandom(
          "tip: don't wither away"
      );
    } else if (deathSource.is(DamageTypes.DRAGON_BREATH)) {
      sayRandom(
          "tip: don't stand in acid"
      );
    } else if (deathSource.is(DamageTypes.DRY_OUT)) {
      sayRandom(
          "tip: don't dry out"
      );
    } else if (deathSource.is(DamageTypes.SWEET_BERRY_BUSH)) {
      sayRandom(
          "tip: don't walk through spiky bushes"
      );
    } else if (deathSource.is(DamageTypes.FREEZE)) {
      sayRandom(
          "tip: don't freeze"
      );
    } else if (deathSource.is(DamageTypes.STALAGMITE)) {
      sayRandom(
          "tip: don't fall onto spikes"
      );
    } else if (deathSource.is(DamageTypes.FALLING_BLOCK)) {
      sayRandom(
          "tip: don't stand under falling blocks"
      );
    } else if (deathSource.is(DamageTypes.FALLING_ANVIL)) {
      sayRandom(
          "tip: don't stand under anvils"
      );
    } else if (deathSource.is(DamageTypes.FALLING_STALACTITE)) {
      sayRandom(
          "tip: don't stand under spikes"
      );
    } else if (deathSource.is(DamageTypes.STING)) {
      sayRandom(
          "tip: don't make bees angry"
      );
    } else if (deathSource.is(DamageTypes.MOB_ATTACK)) {
      sayRandom(
          "tip: don't die"
      );
    } else if (deathSource.is(DamageTypes.MOB_ATTACK_NO_AGGRO)) {
      sayRandom(
          "tip: don't die"
      );
    } else if (deathSource.is(DamageTypes.PLAYER_ATTACK)) {
      sayRandom(
          "tip: don't die"
      );
    } else if (deathSource.is(DamageTypes.SPEAR)) {
      sayRandom(
          "tip: don't get poked"
      );
    } else if (deathSource.is(DamageTypes.ARROW)) {
      sayRandom(
          "tip: don't get sniped"
      );
    } else if (deathSource.is(DamageTypes.TRIDENT)) {
      sayRandom(
          "tip: don't get stabbed"
      );
    } else if (deathSource.is(DamageTypes.MOB_PROJECTILE)) {
      sayRandom(
          "tip: don't get hit"
      );
    } else if (deathSource.is(DamageTypes.SPIT)) {
      sayRandom(
          "tip: don't get hit by spit"
      );
    } else if (deathSource.is(DamageTypes.WIND_CHARGE)) {
      sayRandom(
          "tip: don't get hit"
      );
    } else if (deathSource.is(DamageTypes.FIREWORKS)) {
      sayRandom(
          "tip: don't stand in fireworks"
      );
    } else if (deathSource.is(DamageTypes.FIREBALL)) {
      sayRandom(
          "tip: don't stand in front of oncoming fireballs"
      );
    } else if (deathSource.is(DamageTypes.UNATTRIBUTED_FIREBALL)) {
      sayRandom(
          "tip: don't stand in front of oncoming fireballs"
      );
    } else if (deathSource.is(DamageTypes.WITHER_SKULL)) {
      sayRandom(
          "tip: don't stand in front of flying black skulls"
      );
    } else if (deathSource.is(DamageTypes.THROWN)) {
      sayRandom(
          "tip: don't get hit"
      );
    } else if (deathSource.is(DamageTypes.INDIRECT_MAGIC)) {
      sayRandom(
          "tip: don't expose yourself to magic"
      );
    } else if (deathSource.is(DamageTypes.THORNS)) {
      sayRandom(
          "tip: don't die to thorns"
      );
    } else if (deathSource.is(DamageTypes.EXPLOSION) || deathSource.is(DamageTypes.PLAYER_EXPLOSION)) {
      sayRandom(
          "tip: don't blow up"
      );
    } else if (deathSource.is(DamageTypes.SONIC_BOOM)) {
      sayRandom(
          "tip: don't listen to really loud sounds"
      );
    } else if (deathSource.is(DamageTypes.BAD_RESPAWN_POINT)) {
      sayRandom(
          "tip: check your respawn points properly"
      );
    } else if (deathSource.is(DamageTypes.OUTSIDE_BORDER)) {
      sayRandom(
          "tip: don't leave the world"
      );
    } else if (deathSource.is(DamageTypes.MACE_SMASH)) {
      sayRandom(
          "tip: don't stand under maces"
      );
    }
  }

}
