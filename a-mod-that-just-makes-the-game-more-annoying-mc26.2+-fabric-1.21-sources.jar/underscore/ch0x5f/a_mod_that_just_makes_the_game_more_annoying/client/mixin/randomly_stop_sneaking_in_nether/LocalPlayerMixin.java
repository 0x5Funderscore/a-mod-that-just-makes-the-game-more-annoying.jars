package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.randomly_stop_sneaking_in_nether;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LocalPlayer.class)
@Environment(EnvType.CLIENT)
public abstract class LocalPlayerMixin extends AbstractClientPlayer {

  public LocalPlayerMixin(ClientLevel level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @ModifyReturnValue(method = "isShiftKeyDown", at = @At("RETURN"))
  private boolean modifyShiftKeyDown(boolean original) {
    if (Config.RANDOMLY_STOP_SNEAKING_IN_NETHER.get()) {
      if (this.level().dimension() == ClientLevel.NETHER) {
        if (Math.random() < 0.002) {
          return false;
        }
      }
    }
    return original;
  }

}
