package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.goofy_ender_dragon;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.monster.dragon.EnderDragonModel;
import net.minecraft.client.renderer.entity.state.EnderDragonRenderState;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderDragonModel.class)
@Environment(EnvType.CLIENT)
public abstract class EnderDragonModelMixin {

  @Shadow
  @Final
  private ModelPart body;

  @Shadow
  @Final
  private ModelPart leftWing;

  @Shadow
  @Final
  private ModelPart leftWingTip;

  @Shadow
  @Final
  private ModelPart leftFrontLeg;

  @Shadow
  @Final
  private ModelPart leftFrontLegTip;

  @Shadow
  @Final
  private ModelPart leftFrontFoot;

  @Shadow
  @Final
  private ModelPart leftRearLeg;

  @Shadow
  @Final
  private ModelPart leftRearLegTip;

  @Shadow
  @Final
  private ModelPart leftRearFoot;

  @Shadow
  @Final
  private ModelPart rightWing;

  @Shadow
  @Final
  private ModelPart rightWingTip;

  @Shadow
  @Final
  private ModelPart rightFrontLeg;

  @Shadow
  @Final
  private ModelPart rightFrontLegTip;

  @Shadow
  @Final
  private ModelPart rightFrontFoot;

  @Shadow
  @Final
  private ModelPart rightRearLeg;

  @Shadow
  @Final
  private ModelPart rightRearLegTip;

  @Shadow
  @Final
  private ModelPart rightRearFoot;

  @Unique
  private void rb$clear(ModelPart part) {
    part.xRot = 0f;
    part.yRot = 0f;
    part.zRot = 0f;
    part.xScale = 1f;
    part.yScale = 1f;
    part.zScale = 1f;
  }

  @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/EnderDragonRenderState;)V", at = @At("HEAD"), cancellable = true)
  public void setupAnim(EnderDragonRenderState state, CallbackInfo ci) {
    if (!Config.GOOFY_ENDER_DRAGON.get()) return;
    rb$clear(this.body);
    rb$clear(this.leftWing);
    rb$clear(this.leftWingTip);
    rb$clear(this.leftFrontLeg);
    rb$clear(this.leftFrontLegTip);
    rb$clear(this.leftFrontFoot);
    rb$clear(this.leftRearLeg);
    rb$clear(this.leftRearLegTip);
    rb$clear(this.leftRearFoot);
    rb$clear(this.rightWing);
    rb$clear(this.rightWingTip);
    rb$clear(this.rightFrontLeg);
    rb$clear(this.rightFrontLegTip);
    rb$clear(this.rightFrontFoot);
    rb$clear(this.rightRearLeg);
    rb$clear(this.rightRearLegTip);
    rb$clear(this.rightRearFoot);
    ci.cancel();
  }
}
