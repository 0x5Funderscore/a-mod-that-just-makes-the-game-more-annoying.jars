package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.offset_crosshair;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Hud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Hud.class)
@Environment(EnvType.CLIENT)
public abstract class HudMixin {

  @ModifyArgs(method = "extractCrosshair", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V"))
  private void modifyBlitCrosshair(Args args) {
    if (!Config.OFFSET_CROSSHAIR.get()) return;
    args.set(2, (int)args.get(2) + 2);
    args.set(3, (int)args.get(3) + 2);
  }

}
