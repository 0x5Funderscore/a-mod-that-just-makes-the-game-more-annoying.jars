package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.tts_guide;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.TTSGuide;


@Mixin(LocalPlayer.class)
@Environment(EnvType.CLIENT)
public abstract class LocalPlayerMixin extends AbstractClientPlayer {

  public LocalPlayerMixin(ClientLevel level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tickDeath", at = @At("HEAD"))
  private void tickDeathHEAD(CallbackInfo ci) {
    if (!Config.TTS_GUIDE.get()) return;
    if (this.deathTime == 0) {
      TTSGuide.provideDeathAdvice((ClientLevel)this.level(), (LocalPlayer)(Object)this, this.getLastDamageSource());
    }
  }

}
