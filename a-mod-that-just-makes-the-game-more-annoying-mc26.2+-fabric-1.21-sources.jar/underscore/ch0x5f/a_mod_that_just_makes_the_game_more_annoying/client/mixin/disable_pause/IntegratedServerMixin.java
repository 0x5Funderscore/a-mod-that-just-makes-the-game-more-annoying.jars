package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.disable_pause;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.server.IntegratedServer;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.function.BooleanSupplier;


@Mixin(IntegratedServer.class)
@Environment(EnvType.CLIENT)
public abstract class IntegratedServerMixin {

  @Shadow
  private boolean paused;

  @Inject(method = "tickServer", at = @At(value = "FIELD", target = "Lnet/minecraft/client/server/IntegratedServer;paused:Z", ordinal = 0, shift = At.Shift.AFTER, opcode = Opcodes.PUTFIELD))
  private void unpause(BooleanSupplier haveTime, CallbackInfo ci) {
    if (Config.DISABLE_PAUSE.get())
      this.paused = false;
  }

}
