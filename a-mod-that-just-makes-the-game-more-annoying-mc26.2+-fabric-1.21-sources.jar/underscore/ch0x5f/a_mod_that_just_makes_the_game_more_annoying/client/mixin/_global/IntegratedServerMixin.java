package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin._global;

import com.mojang.logging.LogUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.server.IntegratedServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.io.IOException;


@Mixin(IntegratedServer.class)
@Environment(EnvType.CLIENT)
public abstract class IntegratedServerMixin {

  @Inject(method = "initServer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/server/IntegratedServer;initializeKeyPair()V", shift = At.Shift.AFTER))
  private void preInitServer(CallbackInfoReturnable<Boolean> cir) {
    try {
      Config.loadConfig();
    } catch (IOException e) {
      LogUtils.getLogger().error("I/O error while loading AMTJMTGMA config.", e);
    }
  }

}
