package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin._global;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.LogoRenderer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.screens.AMTJMTGMAScreenConstants;

import java.util.List;


@Mixin(LogoRenderer.class)
@Environment(EnvType.CLIENT)
public abstract class LogoRendererMixin {

  @Definition(id = "graphics", local = @Local(type = GuiGraphicsExtractor.class, name = "graphics", argsOnly = true))
  @Definition(id = "blit", method = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blit(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIFFIIIII)V")
  @Definition(id = "GUI_TEXTURED", field = "Lnet/minecraft/client/renderer/RenderPipelines;GUI_TEXTURED:Lcom/mojang/blaze3d/pipeline/RenderPipeline;")
  @Definition(id = "MINECRAFT_EDITION", field = "Lnet/minecraft/client/gui/components/LogoRenderer;MINECRAFT_EDITION:Lnet/minecraft/resources/Identifier;")
  @Expression("graphics.blit(GUI_TEXTURED, MINECRAFT_EDITION, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
  @WrapOperation(method = "extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IFI)V", at = @At("MIXINEXTRAS:EXPRESSION"), require = 0)
  private void wrapBlitEdition(GuiGraphicsExtractor instance, RenderPipeline renderPipeline, Identifier texture, int x, int y, float u, float v, int width, int height, int textureWidth, int textureHeight, int color, Operation<Void> original) {
    AMTJMTGMAScreenConstants.EDITION_BOXES_CALCULATED.clear();
    x -= width / 2;
    width *= 2;
    y -= height / 2;
    height *= 2;
    float alpha = ARGB.vector4fFromARGB32(color).w;
    for (int idx = 0; idx < AMTJMTGMAScreenConstants.EDITION_BOXES.length; idx += 5) {
      int x0 = (int)((AMTJMTGMAScreenConstants.EDITION_BOXES[idx] / 512f) * (float)width) + x;
      int y0 = (int)((AMTJMTGMAScreenConstants.EDITION_BOXES[idx+1] / 64f) * (float)height) + y;
      int x1 = (int)((AMTJMTGMAScreenConstants.EDITION_BOXES[idx+2] / 512f) * (float)width) + x;
      int y1 = (int)((AMTJMTGMAScreenConstants.EDITION_BOXES[idx+3] / 64f) * (float)height) + y;
      AMTJMTGMAScreenConstants.EDITION_BOXES_CALCULATED.addAll(List.of(x0, y0, x1 - x0, y1 - y0, AMTJMTGMAScreenConstants.EDITION_COLORS[AMTJMTGMAScreenConstants.EDITION_BOXES[idx+4]]));
      instance.fill(RenderPipelines.GUI, x0, y0, x1, y1, ARGB.color(alpha, AMTJMTGMAScreenConstants.EDITION_COLORS[AMTJMTGMAScreenConstants.EDITION_BOXES[idx+4]]));
    }
  }

}
