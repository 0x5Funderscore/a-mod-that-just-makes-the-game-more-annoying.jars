package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.offset_hunger_bar;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Hud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Hud.class)
@Environment(EnvType.CLIENT)
public abstract class HudMixin {

  @ModifyVariable(method = "extractFood", at = @At("HEAD"), name = "yLineBase", argsOnly = true)
  private int modifyYLineBase(int yLineBase) {
    if (!Config.OFFSET_HUNGER_BAR.get()) return yLineBase;
    return yLineBase - 2;
  }

}
