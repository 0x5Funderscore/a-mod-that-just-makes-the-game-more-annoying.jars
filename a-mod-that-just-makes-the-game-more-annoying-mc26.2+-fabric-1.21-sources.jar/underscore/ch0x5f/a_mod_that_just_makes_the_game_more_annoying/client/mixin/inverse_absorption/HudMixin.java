package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.inverse_absorption;

import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Hud.class)
@Environment(EnvType.CLIENT)
public abstract class HudMixin {

  @ModifyVariable(
      method = "extractHearts",
      at = @At("HEAD"),
      name = "absorption",
      argsOnly = true
  )
  private int modifyAbsorption(int absorption) {
    if (Config.INVERSE_ABSORPTION.get()) return 0;
    return absorption;
  }

  @Inject(
      method = "extractHearts",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/client/gui/Hud;extractHeart(Lnet/minecraft/client/gui/GuiGraphicsExtractor;Lnet/minecraft/client/gui/Hud$HeartType;IIZZZ)V",
          ordinal = 0,
          shift = At.Shift.AFTER
      )
  )
  private void renderInverseAbsorption(
      GuiGraphicsExtractor graphics,
      Player player,
      int xLeft,
      int yLineBase,
      int healthRowHeight,
      int heartOffsetIndex,
      float maxHealth,
      int currentHealth,
      int oldHealth,
      int absorption,
      boolean blink,
      CallbackInfo ci,
      @Local(name = "isHardcore") boolean isHardcore,
      @Local(name = "maxHealthHalvesCount") int maxHealthHalvesCount,
      @Local(name = "containerIndex") int containerIndex,
      @Local(name = "xo") int xo,
      @Local(name = "yo") int yo
  ) {
    if (!Config.INVERSE_ABSORPTION.get()) return;
    int halves = containerIndex * 2;
    int actualAbsorption = (int)player.getAbsorptionAmount();
    if (halves >= maxHealthHalvesCount - actualAbsorption - 1) {
      boolean halfHeart = ((maxHealthHalvesCount - actualAbsorption) % 2 == 1) && (halves == maxHealthHalvesCount - actualAbsorption - 1);
      Identifier spriteIdentifier = Hud.HeartType.ABSORBING.getSprite(isHardcore, halfHeart, false);
      TextureAtlasSprite sprite = graphics.guiSprites.getSprite(spriteIdentifier);
      float u0 = Math.max(sprite.u0, sprite.u1);
      float u1 = Math.min(sprite.u0, sprite.u1);
      sprite.u0 = u0;
      sprite.u1 = u1;
      graphics.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, xo, yo, 9, 9);
    }
  }

}
