package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import java.util.*;


/**
 * List that simply acts as a counter for non-null values.
 */
public class CounterList<T> extends AbstractList<T> {
  private int count;

  @Override
  public T get(int index) {
    if (index < 0 || index >= this.count) throw new IndexOutOfBoundsException(index);
    return null;
  }

  @Override
  public int size() {
    return this.count;
  }

  @Override
  public T set(int index, T element) {
    if (index < 0 || index >= this.count) throw new IndexOutOfBoundsException(index);
    if (element == null) this.count--;
    return null;
  }

  @Override
  public void add(int index, T element) {
    if (element != null) this.count++;
  }

  @Override
  public T remove(int index) {
    if (index < 0 || index >= this.count) throw new IndexOutOfBoundsException(index);
    this.count--;
    return null;
  }

}
