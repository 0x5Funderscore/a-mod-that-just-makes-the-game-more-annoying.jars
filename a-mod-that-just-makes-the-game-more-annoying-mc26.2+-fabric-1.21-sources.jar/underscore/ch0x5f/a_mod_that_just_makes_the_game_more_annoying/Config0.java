package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.fabricmc.loader.api.FabricLoader;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Predicate;


public final class Config0 {


  public static final ConfigProperty BEDS_TP_TO_NETHER = server("beds_tp_to_nether", true);
  public static final ConfigProperty SHIELD_BLOCKING_DISABLES = server("shield_blocking_disables", true);
  public static final ConfigProperty PHANTOMS_PICK_UP_PLAYERS = server("phantoms_pick_up_players", true);
  public static final ConfigProperty ALWAYS_SPAWN_PHANTOMS = server("always_spawn_phantoms", false);
  public static final ConfigProperty OFFSET_CROSSHAIR = client("offset_crosshair", true);
  public static final ConfigProperty OFFSET_HUNGER_BAR = client("offset_hunger_bar", true);
  public static final ConfigProperty PIGLINS_BLOW_UP = server("piglins_blow_up", false);
  public static final ConfigProperty EMERALD_INFLATION = server("emerald_inflation", false);
  public static final ConfigProperty SHUFFLE_CHESTS_ON_OPEN = server("shuffle_chests_on_open", true);
  public static final ConfigProperty INVISIBLE_CREEPERS = client("invisible_creepers", true);
  public static final ConfigProperty LOUD_CREEPER_EXPLOSIONS = server("loud_creeper_explosions", true);
  public static final ConfigProperty UNCAPPED_VOLUME = client("uncapped_volume", true);
  public static final ConfigProperty BROKEN_RECIPES = server("broken_recipes", false);
  public static final ConfigProperty ITEMS_BREAK_RANDOMLY = server("items_break_randomly", true);
  public static final ConfigProperty RANDOMLY_STOP_SNEAKING_IN_NETHER = client("randomly_stop_sneaking_in_nether", true);
  public static final ConfigProperty FRAGILE_OBSIDIAN = server("fragile_obsidian", true);
  public static final ConfigProperty GOOFY_SPIDERS = server("goofy_spiders", true);
  public static final ConfigProperty VICIOUS_HORSES = server("vicious_horses", true);
  public static final ConfigProperty REQUIRE_BALANCED_DIET = server("require_balanced_diet", true);
  public static final ConfigProperty INVENTORY_GLASS_PANES_TROLL = server("inventory_glass_panes_troll", true);
  public static final ConfigProperty BLOCK_DROPS_RANDOM_ATTRIBUTE_MODIFIERS = server("block_drops_random_attribute_modifiers", true);
  public static final ConfigProperty DO_NOT_SWIM = both("do_not_swim", true);
  public static final ConfigProperty DISABLE_PAUSE = both("disable_pause", false);
  public static final ConfigProperty DESTROYING_BLOCKS_WITH_HAND_HURTS = server("destroying_blocks_with_hand_hurts", true);
  public static final ConfigProperty ENVIRONMENTAL_TEMPERATURE_DAMAGE = server("environmental_temperature_damage", true);
  public static final ConfigProperty SUPER_BOUNCY = both("super_bouncy", true);
  public static final ConfigProperty REPLACE_END_PORTAL = both("replace_end_portal", true);
  public static final ConfigProperty BEEHIVES_EXPLODE_NEAR_PLAYERS = server("beehives_explode_near_players", true);
  public static final ConfigProperty BEES_STING_ENDLESSLY = server("bees_sting_endlessly", true);
  public static final ConfigProperty ANXIOUS_ENDERMEN = server("anxious_endermen", true);
  public static final ConfigProperty ENDERMEN_RANDOMLY_GET_BOOM = server("endermen_randomly_get_boom", true);
  public static final ConfigProperty GOOFY_ENDER_DRAGON = client("goofy_ender_dragon", true);
  public static final ConfigProperty REPLACE_END_PLATFORM = server("replace_end_platform", true);
  public static final ConfigProperty DIG_DOWN_LAVA_TROLL = server("dig_down_lava_troll", true);
  public static final ConfigProperty QUICKGRAVEL = server("quickgravel", true);
  public static final ConfigProperty GRAVEL_AND_STONES_FALL_ON_YOUR_HEAD = server("gravel_and_stones_fall_on_your_head", true);
  public static final ConfigProperty HALVE_DRAGON_DAMAGE = server("halve_dragon_damage", true);
  public static final ConfigProperty DRAGON_EGGS_TELEPORT_FURTHER = both("dragon_eggs_teleport_further", true);
  public static final ConfigProperty REQUIRE_8_CRYSTALS_FOR_RESPAWN = server("require_8_crystals_for_respawn", true);
  public static final ConfigProperty END_CRYSTALS_REQUIRE_PLAYER_PUNCH = server("end_crystals_require_player_punch", true);
  public static final ConfigProperty LESS_COAL_ORE = server("less_coal_ore", true);
  public static final ConfigProperty COAL_BURNS_FAST = server("coal_burns_fast", true);
  public static final ConfigProperty FURNACE_COOKING_TIME_X5 = server("furnace_cooking_time_x5", true);
  public static final ConfigProperty FURNACE_EXPONENTIAL_PROGRESS = client("furnace_exponential_progress", true);
  public static final ConfigProperty FALL_DAMAGE_AT_2_BLOCKS = both("fall_damage_at_2_blocks", false);
  public static final ConfigProperty DIFFERENT_END_BED_EXPLOSION = server("different_end_bed_explosion", true);
  public static final ConfigProperty SLEEP_AFTER_MIDNIGHT = server("sleep_after_midnight", true);
  public static final ConfigProperty TERRIBLE_REPUTATION = server("terrible_reputation", true);
  public static final ConfigProperty SWEET_BERRY_BUSHES_SPREAD = server("sweet_berry_bushes_spread", true);
  public static final ConfigProperty SWEET_BERRY_BUSHES_APPLY_EFFECTS = server("sweet_berry_bushes_apply_effects", true);
  public static final ConfigProperty EVERY_ZOMBIE_IS_A_LEADER = server("every_zombie_is_a_leader", true);
  public static final ConfigProperty REALLY_HARD_MODE = server("really_hard_mode", true);
  public static final ConfigProperty THIN_BRIDGES_BREAK = server("thin_bridges_break", true);
  public static final ConfigProperty THIN_ICE = server("thin_ice", true);
  public static final ConfigProperty ENDERMEN_TELEPORT_A_LOT = server("endermen_teleport_a_lot", false);
  public static final ConfigProperty TTS_GUIDE = client("tts_guide", true);
  public static final ConfigProperty END_PORTAL_NEEDS_FRAME = server("end_portal_needs_frame", true);
  public static final ConfigProperty FALL_THROUGH_LEAVES = both("fall_through_leaves", false);
  public static final ConfigProperty WITHER_SKELETONS_COMBINE = server("wither_skeletons_combine", true);
  public static final ConfigProperty SPLASH_POTIONS_EXPLODE = server("spash_potions_explode", true);
  public static final ConfigProperty ANIMALS_STOP_SLEEP = server("animals_stop_sleep", true);
  public static final ConfigProperty DOORS_CHANGE_RANDOMLY = server("doors_change_randomly", true);
  public static final ConfigProperty ALL_ZOMBIES_ARE_BABIES = server("all_zombies_are_babies", false);
  public static final ConfigProperty MINING_FATIGUE_UNAFFECTED_BY_MILK = server("mining_fatigue_unaffected_by_milk", false);
  public static final ConfigProperty REPLACE_LAVA_SOLIDIFICATION = server("replace_lava_solidification", true);
  public static final ConfigProperty ELDER_GUARDIAN_INCREASED_RANGE = server("elder_guardian_increased_range", true);
  public static final ConfigProperty TAMING_ANIMALS_EXPLODES = server("taming_animals_explodes", false);
  public static final ConfigProperty BED_WETTING = server("bed_wetting", true);
  public static final ConfigProperty INVERSE_ABSORPTION = both("inverse_absorption", true);
  public static final ConfigProperty LOWER_STEP_HEIGHT = both("lower_step_height", true);
  public static final ConfigProperty DOORS_ARE_AFRAID_OF_WATER = server("doors_are_afraid_of_water", true);
  public static final ConfigProperty RARE_ITEMS_FLY_AWAY = both("rare_items_fly_away", true);
  public static final ConfigProperty SWEEPING_DAMAGES_SELF = server("sweeping_damages_self", true);
  public static final ConfigProperty ORIGIN_DESERT = server("origin_desert", false);
  public static final ConfigProperty EXPERIENCE_ORBS_HURT = server("experience_orbs_hurt", true);
  public static final ConfigProperty NO_XP = server("no_xp", true);
  public static final ConfigProperty SKELETON_HOMING_ARROWS = server("skeleton_homing_arrows", true);
  public static final ConfigProperty NO_ENCHANTING_TABLES = server("no_enchanting_tables", true);
  public static final ConfigProperty EXPLODE_ON_PLACE = server("explode_on_place", true);
  public static final ConfigProperty ANNOYING_TRAPPED_CHESTS = server("annoying_trapped_chests", true);
  public static final ConfigProperty FAST_GHASTS = server("fast_ghasts", true);
  public static final ConfigProperty FURNACE_TOUCH_DAMAGE = server("furnace_touch_damage", true);
  public static final ConfigProperty LAVA_SPREADS_LAVA = server("lava_spreads_lava", false);
  public static final ConfigProperty EDGING_TNT = server("edging_tnt", true);
  public static final ConfigProperty FALL_HEART_ATTACKS = server("fall_heart_attacks", false);
  public static final ConfigProperty OVERCOOKING = server("overcooking", true);
  public static final ConfigProperty FUEL_ALWAYS_BURNS = server("fuel_always_burns", true);
  public static final ConfigProperty HOLDING_LAVA_HURTS = server("holding_lava_hurts", true);
  public static final ConfigProperty ENCHANTMENTS_DISAPPEAR = server("enchantments_disappear", true);
  public static final ConfigProperty LAVA_BLOWS_UP_FURNACES = server("lava_blows_up_furnaces", true);
  public static final ConfigProperty LACTOSE_INTOLERANCE = server("lactose_intolerance", true);
  public static final ConfigProperty SHORT_ENDERMAN_HITBOX = both("short_enderman_hitbox", true);
  public static final ConfigProperty ENDERMEN_SOCIAL_ANXIETY = server("enderman_social_anxiety", true);
  public static final ConfigProperty ENDERMEN_DONT_FREEZE = server("endermen_dont_freeze", true);
  public static final ConfigProperty ENDERMEN_HOLD_ANYTHING = server("endermen_hold_anything", true);
  public static final ConfigProperty ENDERMEN_HOLD_WITHER_IMMUNE = server("endermen_hold_wither_immune", false);
  public static final ConfigProperty SLOW_ARMOUR = server("slow_armour", true);
  public static final ConfigProperty ALTITUDE_TEMPERATURE_DAMAGE = server("altitude_temperature_damage", true);
  public static final ConfigProperty EXPLOSIVE_RABBITS = server("explosive_rabbits", true);
  public static final ConfigProperty NORMAL_RAILS_ARE_POWERED_OFF = server("normal_rails_are_powered_off", true);
  public static final ConfigProperty ENDERMEN_UNAFFECTED_BY_WATER = server("endermen_unaffected_by_water", true);
  public static final ConfigProperty BATS_TARGET_EYES = server("bats_target_eyes", true);
  public static final ConfigProperty BEDROCK_OFFHAND_OR_LIGHTNING = server("bedrock_offhand_or_lightning", true);
  public static final ConfigProperty ITEMS_DIE_NEAR_PLAYERS = server("items_die_near_players", true);
  public static final ConfigProperty RAILS_SPAWN_FURNACE_MINECARTS = server("rails_spawn_furnace_minecraft", true);
  public static final ConfigProperty INVENTORY_WATER_BUCKET_SPILLING = server("inventory_water_bucket_spilling", true);
  public static final ConfigProperty FURNACE_MINECARTS_USELESS = server("furnace_minecarts_useless", true);
  public static final ConfigProperty ENDERMEN_TARGET_IMPORTANT_BLOCKS = server("endermen_target_important_blocks", true);
  public static final ConfigProperty LANDMINES = server("landmines", true);
  public static final ConfigProperty MOSTLY_REMOVE_SQUIDS = server("mostly_remove_squids", false);
  public static final ConfigProperty TALL_LANDS = server("tall_lands", false);
  public static final ConfigProperty REMOVE_TOOLTIP_BACKGROUNDS = client("remove_tooltip_backgrounds", true);
  public static final ConfigProperty NO_SLOT_HIGHLIGHT = client("no_slot_highlight", false);
  public static final ConfigProperty OFFSET_SLOT_HIGHLIGHT = client("offset_slot_highlight", true);
  public static final ConfigProperty WILD_TAMED_ANIMALS = server("wild_tamed_animals", true);
  public static final ConfigProperty LLAMA_SPIT_LAUNCH = server("llama_spit_launch", true);
  public static final ConfigProperty IRON_GOLEM_EXTENDED_REACH = server("iron_golem_extended_reach", true);
  public static final ConfigProperty IRON_GOLEM_SPACE_PROGRAM = server("iron_golem_space_program", true);
  public static final ConfigProperty NERVOUS_HORSES = server("nervous_horses", true);
  public static final ConfigProperty SHULKER_MACHINE_GUNS = server("shulker_machine_guns", true);
  public static final ConfigProperty SKELETON_SHOTGUNS = server("skeleton_shotguns", false);
  public static final ConfigProperty FIFTY_SKELETON_HORSES = server("fifty_skeleton_horses", true);
  public static final ConfigProperty CHICKENS_V2 = server("chickens_v2", true);
  public static final ConfigProperty LAVA_FLOWS_FAST = server("lava_flows_fast", true);
  public static final ConfigProperty FLYING_SQUIDS = server("flying_squids", true);
  public static final ConfigProperty NEUTRAL_LEVITATION = both("neutral_levitation", true);
  public static final ConfigProperty CREEPERS_IGNORE_CATS = server("creepers_ignore_cats", true);
  public static final ConfigProperty FURNACES_LITERALLY = server("furnaces_literally", true);
  public static final ConfigProperty FLETCHING_TABLES_SHOOT = server("fletching_tables_shoot", true);
  public static final ConfigProperty SHULKERS_SHOOT_CLOSED = server("shulkers_shoot_closed", true);
  public static final ConfigProperty UNBREAKING_ELYTRA_FLIES_SLOWER = both("unbreaking_elytra_flies_slower", true);
//  public static final ConfigProperty END_SOUL_SAND_AND_BASALT_DELTAS = server("end_soul_sand_and_basalt_deltas", true);
  public static final ConfigProperty ENDER_PEARLS_MOVE_SLOWLY = both("ender_pearls_move_slowly", true);
  public static final ConfigProperty SKELETON_DODGING = server("skeleton_dodging", false);
  public static final ConfigProperty HISSBINES = server("hissbines", true);
//  public static final ConfigProperty INCREASED_PLAYER_HEIGHT = both("increased_player_height", false);
  public static final ConfigProperty MONSTERS_WITH_HELMETS = server("monsters_with_helmets", true);
  public static final ConfigProperty SMALLER_BABY_ZOMBIES = both("small_baby_zombies", false);
  public static final ConfigProperty BLAZE_MACHINE_GUNS = server("blaze_machine_guns", true);
  public static final ConfigProperty NETHERITE_WITHER_SKELETONS = server("netherite_wither_skeletons", false);
  public static final ConfigProperty SHORT_WITHER_SKELETON_HITBOX = both("short_wither_skeleton_hitbox", true);
  public static final ConfigProperty MOBS_DONT_DAMAGE_HELMETS = server("mobs_dont_damage_helmets", true);
  public static final ConfigProperty MOB_ARMOR_BINDING_CURSE = server("mob_armor_binding_curse", true);
  public static final ConfigProperty NO_OFFHAND_KEY = client("no_offhand_key", false);
  public static final ConfigProperty MORE_LIGHTNING = server("more_lightning", true);
  public static final ConfigProperty MORE_THUNDERSTORMS = server("more_thunderstorms", true);
  public static final ConfigProperty NAUSEA_INVERTED_MOVEMENT = client("nausea_inverted_movement", true);
  public static final ConfigProperty WITCHES_THROW_LINGERING = server("witches_throw_lingering", true);
  public static final ConfigProperty WITCHES_THROW_DIFFERENT_POTIONS = server("witches_throw_different_potions", true);
//  public static final ConfigProperty MORE_WITCH_SPAWNS = server("more_witch_spawns", true);
  public static final ConfigProperty BOILING_NETHER_WATER_CAULDRONS = server("boiling_nether_water_cauldrons", true);
  public static final ConfigProperty SUPER_SURGE_CONDUCTOR = server("super_surge_conductor", true);
  public static final ConfigProperty SUN_GLARE = client("sun_glare", true);
  public static final ConfigProperty SOLIDIFYING_LAVA = server("solidifying_lava", true);
  public static final ConfigProperty COPPER_GOLEM_LIGHTNING = server("copper_golem_lightning", true);
  public static final ConfigProperty TIMID_SHEEP = server("timid_sheep", true);
  public static final ConfigProperty NO_STRING_WOOL = server("no_string_wool", true);
  public static final ConfigProperty LOUD_LEAF_LITTER = both("loud_leaf_litter", true);
  public static final ConfigProperty VAULTS_DISPENSE_MOBS = server("vaults_dispense_mobs", true);
  public static final ConfigProperty THUNDERSTORM_SCREW_YOU_IN_PARTICULAR = server("thunderstorm_screw_you_in_particular", true);
  public static final ConfigProperty FAST_WARDEN = server("fast_warden", true);
  public static final ConfigProperty FOXES_SCAN_INVENTORIES = server("foxes_scan_inventories", true);
  public static final ConfigProperty CAVE_FLOWER_HAYFEVER = server("cave_flower_hayfever", true);
  public static final ConfigProperty CATS_SCAN_INVENTORIES = server("cats_scan_inventories", true);
  public static final ConfigProperty SAME_SIZE_SLIMES = server("same_size_slimes", true);
  public static final ConfigProperty SHY_FURNACES = server("shy_furnaces", false);
  public static final ConfigProperty DISAPPEARING_CATS = server("disappearing_cats", false);
  public static final ConfigProperty WARDEN_SIGHT = server("warden_sight", true);
  public static final ConfigProperty GLOW_SQUIDS_HATCH_SILVERFISH = server("glow_squids_hatch_silverfish", false);
  public static final ConfigProperty NO_VIBRATION_OCCLUDING = server("no_vibration_occluding", true);
  public static final ConfigProperty WILDER_WOLVES = server("wilder_wolves", true);
  public static final ConfigProperty CHANGE_PIGLIN_BARTER_LOOT = server("change_piglin_barter_loot", true);
  public static final ConfigProperty SMART_BLOCK_DROPS = server("smart_block_drops", true);
  public static final ConfigProperty WORSE_ORES_AND_INGOTS = server("worse_ores_and_ingots", false);
  public static final ConfigProperty FURNACE_OUTPUT_SINGLETON = server("furnace_output_singleton", false);
  public static final ConfigProperty FURNACE_PLACEMENT_FLIPPED = server("furnace_placement_flipped", true);
  public static final ConfigProperty RANDOM_PLACEMENT_DIRECTIONS = server("random_placement_directions", false);
  public static final ConfigProperty RANDOM_CREEPER_HISS = client("random_creeper_hiss", false);
  public static final ConfigProperty MOB_CRITS = server("mob_crits", true);
  public static final ConfigProperty RANDOMIZE_HUNGER_ON_WAKE = server("randomize_hunger_on_wake", true);
  public static final ConfigProperty LOUD_CAVE_SOUNDS = client("loud_cave_sounds", true);
  public static final ConfigProperty DAMAGED_CHEST_LOOT = server("damaged_chest_loot", true);
  public static final ConfigProperty POVERTY_VILLAGES = server("poverty_villages", true);
  public static final ConfigProperty NETHER_ROOF_PROTECTION = server("nether_roof_protection", true);
  public static final ConfigProperty BREAK_NETHER_COORDS = server("break_nether_coords", true);
  public static final ConfigProperty UNSTABLE_CREEPERS = server("unstable_creepers", true);
  public static final ConfigProperty HOT_ITEM_FIRE = server("hot_item_fire", true);
  public static final ConfigProperty FLOATING_FISH = server("floating_fish", true);
  public static final ConfigProperty ALWAYS_RAID = server("always_raid", false);
  public static final ConfigProperty MOB_STACKS = server("mob_stacks", true);
  public static final ConfigProperty SWAP_POTATOES = server("swap_potatoes", true);
  public static final ConfigProperty CREEPER_EXPLOSION_CHAIN = server("creeper_explosion_chain", true);
  public static final ConfigProperty RAIN_SILVERFISH = server("rain_silverfish", true);
  public static final ConfigProperty SWAP_REGEN_WITHER = server("swap_regen_wither", false);
  public static final ConfigProperty SWAP_REGEN_WITHER_VISUAL = client("swap_regen_wither_visual", false);
  public static final ConfigProperty CLOSE_THIRD_PERSON = client("close_third_person", false);
  public static final ConfigProperty NETHER_WATER = server("nether_water", true);
  public static final ConfigProperty MIDDLE_LOG_BREAK_STRIP = server("middle_log_break_strip", false);
  public static final ConfigProperty MOBS_DRIVE_BOATS = server("mobs_drive_boats", true);
  public static final ConfigProperty CREEPER_IGNITE_FIRE_DAMAGE = server("creeper_ignite_fire_damage", true);
  public static final ConfigProperty LETHAL_POISON = server("lethal_poison", true);
  public static final ConfigProperty ANTI_VEIN_MINER = server("anti_vein_miner", true);


  private static @NotNull ConfigProperty client(final String name, final boolean defaultValue) {
    return new ConfigProperty("client", name, defaultValue);
  }

  private static @NotNull ConfigProperty server(final String name, final boolean defaultValue) {
    return new ConfigProperty("server", name, defaultValue);
  }

  private static @NotNull ConfigProperty both(final String name, final boolean defaultValue) {
    return new ConfigProperty("*", name, defaultValue);
  }

  private static void loadConfigFile(File configFile) throws RuntimeException, IOException {
    if (configFile.exists()) {

      try {

        FileReader fileReader = new FileReader(configFile);
        JsonObject jsonObject = JsonParser.parseReader(fileReader).getAsJsonObject();
        fileReader.close();

        ConfigProperty.allProperties.forEach(property -> property.setFrom(jsonObject));

      } catch (Exception e) {
        throw new RuntimeException("AMTJMTGMA config failed to load.", e);
      }

    } else {

      LogUtils.getLogger().info("Creating new AMTJMTGMA config");

      configFile.getParentFile().mkdirs();
      configFile.createNewFile();

    }

    JsonObject configObject = new JsonObject();
    ConfigProperty.allProperties.forEach(property -> property.storeTo(configObject));

    FileWriter writer = new FileWriter(configFile);
    writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(configObject));
    writer.close();

  }

  public static void loadConfig() throws RuntimeException, IOException {
    LogUtils.getLogger().info("Loading AMTJMTGMA config");
    loadConfigFile(FabricLoader.getInstance().getConfigDir().resolve("a_mod_that_just_makes_the_game_more_annoying.json").toFile());
  }

  public static void forEachProperty(Consumer<ConfigProperty> consumer, Predicate<ConfigProperty> predicate) {
    ConfigProperty.allProperties.stream().filter(predicate).forEach(consumer);
  }

  public static void forEachProperty(Consumer<ConfigProperty> consumer) {
    ConfigProperty.allProperties.forEach(consumer);
  }

  public static final class ConfigProperty implements BooleanSupplier {
    private static final List<ConfigProperty> allProperties = new ArrayList<>();

    public final String side;
    public String name;
    private boolean value;

    private ConfigProperty(String side, String name, boolean defaultValue) {
      this.side = side;
      this.name = name;
      this.value = defaultValue;
      allProperties.add(this);
    }

    public boolean get() {
      return this.value;
    }

    public void set(Boolean newValue) {
      this.value = newValue;
    }

    void setFrom(JsonObject object) {
      @NotNull JsonObject subobject = new JsonObject();
      try {
        subobject = Objects.requireNonNull(object.getAsJsonObject(this.side));
      } catch (Exception e) {
        if (!object.has(this.side)) {
          throw new RuntimeException("AMTJMTGMA config error: Missing property " + this.side + " (object)");
        }
      }
      if (!subobject.has(this.name)) {
        LogUtils.getLogger().warn("AMTJMTGMA config warning: Missing property {}/{} (using default value {})", this.side, this.name, this.value);
        return;
      }
      try {
        this.value = subobject.get(this.name).getAsBoolean();
      } catch (Exception e) {
        throw new RuntimeException("AMTJMTGMA config error: Invalid side for property " + this.side + "/" + this.name + " (should be boolean)");
      }
    }

    void storeTo(JsonObject object) {
      if (!object.has(this.side)) object.add(this.side, new JsonObject());
      object.getAsJsonObject(this.side).addProperty(this.name, this.value);
    }

    @Override
    public boolean equals(Object obj) {
      if (obj instanceof ConfigProperty) {
        return this.value == ((ConfigProperty)obj).value;
      } else if (obj instanceof Boolean) {
        return this.value == (boolean)obj;
      } else return super.equals(obj);
    }

    @Override
    public boolean getAsBoolean() {
      return this.get();
    }
  }
}
