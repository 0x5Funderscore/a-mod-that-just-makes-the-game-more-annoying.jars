package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Items;


public abstract class CatStuff {
  public static boolean hasFood(ServerPlayer player) {
    return player.getInventory().contains(itemStack -> (
        itemStack.is(ItemTags.EGGS) ||
        itemStack.is(ItemTags.FISHES) ||
        itemStack.is(ItemTags.CAT_FOOD) ||
        itemStack.is(CTags.Items.Drinks.milk)
    ));
  }
}
