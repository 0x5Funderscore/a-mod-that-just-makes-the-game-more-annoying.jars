package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.block_control;

import net.minecraft.world.level.levelgen.structure.BoundingBox;

import java.util.stream.Stream;


public interface IServerLevelBlockControlExtension {

  void addUnbreakableRegion(UnbreakableRegion region);
  default UnbreakableRegion addUnbreakableRegion(BoundingBox boundingBox) {
    UnbreakableRegion region = new UnbreakableRegion(boundingBox);
    this.addUnbreakableRegion(region);
    return region;
  }

  void removeUnbreakableRegion(UnbreakableRegion region);

  Stream<UnbreakableRegion> getUnbreakableRegions();
  default Stream<UnbreakableRegion> getUnbreakableRegions(BoundingBox collidingWith) {
    Stream<UnbreakableRegion> allRegions = getUnbreakableRegions();
    return allRegions.filter(region -> region.boundingBox().intersects(collidingWith));
  }

}
