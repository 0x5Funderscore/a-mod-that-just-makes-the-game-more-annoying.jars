package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.block_control;

import net.minecraft.world.level.levelgen.structure.BoundingBox;


public record UnbreakableRegion(BoundingBox boundingBox) {
}
