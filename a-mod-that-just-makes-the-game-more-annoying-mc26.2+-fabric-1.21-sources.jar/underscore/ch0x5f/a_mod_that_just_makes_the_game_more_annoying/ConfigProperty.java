package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;


public interface ConfigProperty extends java.util.function.BooleanSupplier, io.netty.util.BooleanSupplier {
  @Override
  boolean get();
  void set(boolean value);

  @Override
  default boolean getAsBoolean() { return this.get(); }

  String getSide();
  String getName();

  @ApiStatus.Internal
  default void setFrom(JsonObject object) {
    @NotNull JsonObject subobject = new JsonObject();
    try {
      if (object.has(this.getSide()) && object.get(this.getSide()).isJsonObject()) {
        subobject = Objects.requireNonNull(object.getAsJsonObject(this.getSide()));
      } else {
        object.add(this.getSide(), subobject);
        LogUtils.getLogger().warn("AMTJMTGMA config warning: Missing property {} (creating empty object)", this.getSide());
      }
    } catch (Exception e) {
      throw new RuntimeException("AMTJMTGMA config error", e);
    }
    if (!subobject.has(this.getName())) {
      LogUtils.getLogger().warn("AMTJMTGMA config warning: Missing property {}/{} (using default value {})", this.getSide(), this.getName(), this.get());
      return;
    }
    try {
      this.set(subobject.get(this.getName()).getAsBoolean());
    } catch (Exception e) {
      throw new RuntimeException("AMTJMTGMA config error: Invalid type for property " + this.getSide() + "/" + this.getName() + " (should be boolean)");
    }
  }

  @ApiStatus.Internal
  default void storeTo(JsonObject object) {
    if (!object.has(this.getSide())) object.add(this.getSide(), new JsonObject());
    object.getAsJsonObject(this.getSide()).addProperty(this.getName(), this.get());
  }
}
