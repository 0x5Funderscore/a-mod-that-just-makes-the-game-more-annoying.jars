package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import net.minecraft.core.Direction;
import org.jetbrains.annotations.NotNull;


public interface IUseOnContextDirectionExtension {
  @NotNull Direction[] getRandomNearestLookingDirections();
  @NotNull Direction getRandomNearestDirection();
  @NotNull Direction getRandomNearestHorizontalDirection();
  @NotNull Direction getRandomNearestVerticalDirection();
}
