package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fractal;

public class Fractal {
  public static final double[] z0 = Complex.of(-0.42810925841331, 0.39251494407654);
  public static final double cx = -0.22261835;
  public static final double cy = 0.73909682;
  public static final double scale = 0.00000005;

  public static boolean sample(double x, double y) {
    double[] z = z0;
    double[] c = Complex.of(x * scale + cx, y * scale + cy);
    for (int i = 0; i < 64; i++) {
      z = Complex.add(Complex.square(z), c);
      if (z[0] * z[0] + z[1] * z[1] >= 4d) return false;
    }
    return true;
  }
}
