package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.fractal;

public final class Complex {
  public static double[] of(double real) {
    return new double[]{real, 0d};
  }
  public static double[] of(double real, double imag) {
    return new double[]{real, imag};
  }
  public static double[] add(double[] a, double[] b) {
    return new double[]{a[0] + b[0], a[1] + b[1]};
  }
  public static double[] subtract(double[] a, double[] b) {
    return new double[]{a[0] - b[0], a[1] - b[1]};
  }
  public static double[] multiply(double[] a, double[] b) {
    return new double[]{a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0]};
  }
  public static double[] divide(double[] a, double[] b) {
    return new double[]{a[0] / b[0] - a[1] / b[1], a[0] / b[1] + a[1] / b[0]};
  }
  public static double[] square(double[] x) {
    return new double[]{x[0] * x[0] - x[1] * x[1], 2d * x[0] * x[1]};
  }
  public static double real(double[] x) {
    return x[0];
  }
  public static double imag(double[] x) {
    return x[1];
  }
}
