package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.material.Fluid;


public final class CTags {
  public static final class Blocks {
    public static final class Barrels {
      public static final TagKey<Block> wooden = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "barrels/wooden"));
    }
    public static final class Bars {
      public static final TagKey<Block> copper = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "bars/copper"));
      public static final TagKey<Block> iron = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "bars/iron"));
    }
    public static final class Chests {
      public static final TagKey<Block> ender = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "chests/ender"));
      public static final TagKey<Block> trapped = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "chests/trapped"));
      public static final TagKey<Block> wooden = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "chests/wooden"));
    }
    public static final class Cobblestones {
      public static final TagKey<Block> deepslate = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "cobblestones/deepslate"));
      public static final TagKey<Block> infested = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "cobblestones/infested"));
      public static final TagKey<Block> mossy = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "cobblestones/mossy"));
      public static final TagKey<Block> normal = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "cobblestones/normal"));
    }
    public static final class Dyed {
      public static final TagKey<Block> black = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/black"));
      public static final TagKey<Block> blue = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/blue"));
      public static final TagKey<Block> brown = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/brown"));
      public static final TagKey<Block> cyan = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/cyan"));
      public static final TagKey<Block> gray = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/gray"));
      public static final TagKey<Block> green = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/green"));
      public static final TagKey<Block> light_blue = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/light_blue"));
      public static final TagKey<Block> light_gray = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/light_gray"));
      public static final TagKey<Block> lime = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/lime"));
      public static final TagKey<Block> magenta = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/magenta"));
      public static final TagKey<Block> orange = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/orange"));
      public static final TagKey<Block> pink = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/pink"));
      public static final TagKey<Block> purple = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/purple"));
      public static final TagKey<Block> red = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/red"));
      public static final TagKey<Block> white = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/white"));
      public static final TagKey<Block> yellow = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed/yellow"));
    }
    public static final class Fences {
      public static final TagKey<Block> nether_brick = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "fences/nether_brick"));
      public static final TagKey<Block> wooden = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "fences/wooden"));
    }
    public static final class FenceGates {
      public static final TagKey<Block> wooden = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "fence_gates/wooden"));
    }
    public static final class Flowers {
      public static final TagKey<Block> small = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "flowers/small"));
      public static final TagKey<Block> tall = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "flowers/tall"));
    }
    public static final class GlassBlocks {
      public static final TagKey<Block> cheap = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "glass_blocks/cheap"));
      public static final TagKey<Block> colorless = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "glass_blocks/colorless"));
      public static final TagKey<Block> tinted = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "glass_blocks/tinted"));
    }
    public static final class GlassPanes {
      public static final TagKey<Block> colorless = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "glass_panes/colorless"));
    }
    public static final class NaturalLogs {
      public static final TagKey<Block> nether = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "natural_logs/nether"));
      public static final TagKey<Block> overworld = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "natural_logs/overworld"));
    }
    public static final class Obsidians {
      public static final TagKey<Block> crying = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "obsidians/crying"));
      public static final TagKey<Block> normal = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "obsidians/normal"));
    }
    public static final class Ores {
      public static final TagKey<Block> coal = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/coal"));
      public static final TagKey<Block> copper = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/copper"));
      public static final TagKey<Block> diamond = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/diamond"));
      public static final TagKey<Block> emerald = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/emerald"));
      public static final TagKey<Block> gold = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/gold"));
      public static final TagKey<Block> iron = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/iron"));
      public static final TagKey<Block> lapis = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/lapis"));
      public static final TagKey<Block> netherite_scrap = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/netherite_scrap"));
      public static final TagKey<Block> quartz = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/quartz"));
      public static final TagKey<Block> redstone = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores/redstone"));
    }
    public static final class OresInGround {
      public static final TagKey<Block> deepslate = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores_in_ground/deepslate"));
      public static final TagKey<Block> netherrack = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores_in_ground/netherrack"));
      public static final TagKey<Block> stone = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores_in_ground/stone"));
    }
    public static final class OreBearingGround {
      public static final TagKey<Block> deepslate = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ore_bearing_ground/deepslate"));
      public static final TagKey<Block> netherrack = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ore_bearing_ground/netherrack"));
      public static final TagKey<Block> stone = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ore_bearing_ground/stone"));
    }
    public static final class OreRates {
      public static final TagKey<Block> dense = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ore_rates/dense"));
      public static final TagKey<Block> singular = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ore_rates/singular"));
      public static final TagKey<Block> sparse = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ore_rates/sparse"));
    }
    public static final class PlayerWorkstations {
      public static final TagKey<Block> crafting_tables = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "player_workstations/crafting_tables"));
      public static final TagKey<Block> furnaces = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "player_workstations/furnaces"));
    }
    public static final class Pumpkins {
      public static final TagKey<Block> carved = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "pumpkins/carved"));
      public static final TagKey<Block> jack_o_lanterns = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "pumpkins/jack_o_lanterns"));
      public static final TagKey<Block> normal = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "pumpkins/normal"));
    }
    public static final class Sands {
      public static final TagKey<Block> colorless = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sands/colorless"));
      public static final TagKey<Block> red = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sands/red"));
    }
    public static final class Sandstone {
      public static final TagKey<Block> blocks = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sandstone/blocks"));
      public static final TagKey<Block> red_blocks = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sandstone/red_blocks"));
      public static final TagKey<Block> red_slabs = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sandstone/red_slabs"));
      public static final TagKey<Block> red_stairs = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sandstone/red_stairs"));
      public static final TagKey<Block> slabs = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sandstone/slabs"));
      public static final TagKey<Block> stairs = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sandstone/stairs"));
      public static final TagKey<Block> uncolored_blocks = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sandstone/uncolored_blocks"));
      public static final TagKey<Block> uncolored_slabs = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sandstone/uncolored_slabs"));
      public static final TagKey<Block> uncolored_stairs = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sandstone/uncolored_stairs"));
    }
    public static final class StorageBlocks {
      public static final TagKey<Block> bone_meal = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/bone_meal"));
      public static final TagKey<Block> coal = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/coal"));
      public static final TagKey<Block> copper = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/copper"));
      public static final TagKey<Block> diamond = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/diamond"));
      public static final TagKey<Block> dried_kelp = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/dried_kelp"));
      public static final TagKey<Block> emerald = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/emerald"));
      public static final TagKey<Block> gold = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/gold"));
      public static final TagKey<Block> iron = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/iron"));
      public static final TagKey<Block> lapis = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/lapis"));
      public static final TagKey<Block> netherite = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/netherite"));
      public static final TagKey<Block> raw_copper = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/raw_copper"));
      public static final TagKey<Block> raw_gold = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/raw_gold"));
      public static final TagKey<Block> raw_iron = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/raw_iron"));
      public static final TagKey<Block> redstone = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/redstone"));
      public static final TagKey<Block> resin = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/resin"));
      public static final TagKey<Block> slime = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/slime"));
      public static final TagKey<Block> wheat = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks/wheat"));
    }
    public static final TagKey<Block> barrels = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "barrels"));
    public static final TagKey<Block> bars = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "bars"));
    public static final TagKey<Block> bookshelves = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "bookshelves"));
    public static final TagKey<Block> budding_blocks = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "budding_blocks"));
    public static final TagKey<Block> buds = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "buds"));
    public static final TagKey<Block> chains = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "chains"));
    public static final TagKey<Block> chests = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "chests"));
    public static final TagKey<Block> clusters = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "clusters"));
    public static final TagKey<Block> cobblestones = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "cobblestones"));
    public static final TagKey<Block> concretes = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "concretes"));
    public static final TagKey<Block> dyed = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "dyed"));
    public static final TagKey<Block> end_stones = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "end_stones"));
    public static final TagKey<Block> fences = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "fences"));
    public static final TagKey<Block> fence_gates = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "fence_gates"));
    public static final TagKey<Block> flowers = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "flowers"));
    public static final TagKey<Block> froglights = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "froglights"));
    public static final TagKey<Block> glass_blocks = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "glass_blocks"));
    public static final TagKey<Block> glass_panes = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "glass_panes"));
    public static final TagKey<Block> glazed_terracottas = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "glazed_terracottas"));
    public static final TagKey<Block> gravels = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "gravels"));
    public static final TagKey<Block> hidden_from_recipe_viewers = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "hidden_from_recipe_viewers"));
    public static final TagKey<Block> natural_logs = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "natural_logs"));
    public static final TagKey<Block> natural_woods = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "natural_woods"));
    public static final TagKey<Block> netherracks = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "netherracks"));
    public static final TagKey<Block> obsidians = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "obsidians"));
    public static final TagKey<Block> ores = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ores"));
    public static final TagKey<Block> pumpkins = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "pumpkins"));
    public static final TagKey<Block> relocation_not_supported = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "relocation_not_supported"));
    public static final TagKey<Block> ropes = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "ropes"));
    public static final TagKey<Block> sands = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "sands"));
    public static final TagKey<Block> skulls = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "skulls"));
    public static final TagKey<Block> stones = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "stones"));
    public static final TagKey<Block> storage_blocks = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "storage_blocks"));
    public static final TagKey<Block> stripped_logs = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "stripped_logs"));
    public static final TagKey<Block> stripped_woods = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "stripped_woods"));
    public static final TagKey<Block> villager_job_sites = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", "villager_job_sites"));
  }
  public static final class Enchantments {
    public static final TagKey<Enchantment> entity_auxiliary_movement_enhancements = TagKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath("c", "entity_auxiliary_movement_enhancements"));
    public static final TagKey<Enchantment> entity_defense_enhancements = TagKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath("c", "entity_defense_enhancements"));
    public static final TagKey<Enchantment> entity_speed_enhancements = TagKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath("c", "entity_speed_enhancements"));
    public static final TagKey<Enchantment> hidden_from_recipe_viewers = TagKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath("c", "hidden_from_recipe_viewers"));
    public static final TagKey<Enchantment> increase_block_drops = TagKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath("c", "increase_block_drops"));
    public static final TagKey<Enchantment> increase_entity_drops = TagKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath("c", "increase_entity_drops"));
    public static final TagKey<Enchantment> weapon_damage_enhancements = TagKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath("c", "weapon_damage_enhancements"));
  }
  public static final class EntityTypes {
    public static final TagKey<EntityType<?>> boats = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("c", "boats"));
    public static final TagKey<EntityType<?>> bosses = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("c", "bosses"));
    public static final TagKey<EntityType<?>> capturing_not_supported = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("c", "capturing_not_supported"));
    public static final TagKey<EntityType<?>> item_frames = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("c", "item_frames"));
    public static final TagKey<EntityType<?>> minecarts = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("c", "minecarts"));
    public static final TagKey<EntityType<?>> teleporting_not_supported = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("c", "teleporting_not_supported"));
  }
  public static final class Fluids {
    public static final TagKey<Fluid> beetroot_soup = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "beetroot_soup"));
    public static final TagKey<Fluid> experience = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "experience"));
    public static final TagKey<Fluid> gaseous = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "gaseous"));
    public static final TagKey<Fluid> hidden_from_recipe_viewers = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "hidden_from_recipe_viewers"));
    public static final TagKey<Fluid> honey = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "honey"));
    public static final TagKey<Fluid> lava = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "lava"));
    public static final TagKey<Fluid> milk = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "milk"));
    public static final TagKey<Fluid> mushroom_stew = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "mushroom_stew"));
    public static final TagKey<Fluid> potion = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "potion"));
    public static final TagKey<Fluid> rabbit_stew = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "rabbit_stew"));
    public static final TagKey<Fluid> suspicious_stew = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "suspicious_stew"));
    public static final TagKey<Fluid> water = TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath("c", "water"));
  }
  public static final class Items {
    public static final class Armors {
      public static final TagKey<Item> horse = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "armors/horse"));
      public static final TagKey<Item> humanoid = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "armors/humanoid"));
      public static final TagKey<Item> nautilus = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "armors/nautilus"));
      public static final TagKey<Item> wolf = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "armors/wolf"));
    }
    public static final class Barrels {
      public static final TagKey<Item> wooden = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "barrels/wooden"));
    }
    public static final class Bars {
      public static final TagKey<Item> copper = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "bars/copper"));
      public static final TagKey<Item> iron = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "bars/iron"));
    }
    public static final class Bricks {
      public static final TagKey<Item> nether = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "bricks/nether"));
      public static final TagKey<Item> normal = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "bricks/normal"));
      public static final TagKey<Item> resin = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "bricks/resin"));
    }
    public static final class Buckets {
      public static final TagKey<Item> empty = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "buckets/empty"));
      public static final TagKey<Item> entity_dry = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "buckets/entity_dry"));
      public static final TagKey<Item> entity_water = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "buckets/entity_water"));
      public static final TagKey<Item> lava = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "buckets/lava"));
      public static final TagKey<Item> milk = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "buckets/milk"));
      public static final TagKey<Item> powder_snow = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "buckets/powder_snow"));
      public static final TagKey<Item> water = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "buckets/water"));
    }
    public static final class Chests {
      public static final TagKey<Item> ender = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "chests/ender"));
      public static final TagKey<Item> trapped = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "chests/trapped"));
      public static final TagKey<Item> wooden = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "chests/wooden"));
    }
    public static final class Clumps {
      public static final TagKey<Item> resin = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "clumps/resin"));
    }
    public static final class Cobblestones {
      public static final TagKey<Item> deepslate = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "cobblestones/deepslate"));
      public static final TagKey<Item> infested = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "cobblestones/infested"));
      public static final TagKey<Item> mossy = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "cobblestones/mossy"));
      public static final TagKey<Item> normal = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "cobblestones/normal"));
    }
    public static final class Crops {
      public static final TagKey<Item> beetroot = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/beetroot"));
      public static final TagKey<Item> cactus = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/cactus"));
      public static final TagKey<Item> carrot = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/carrot"));
      public static final TagKey<Item> cocoa_bean = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/cocoa_bean"));
      public static final TagKey<Item> melon = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/melon"));
      public static final TagKey<Item> nether_wart = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/nether_wart"));
      public static final TagKey<Item> potato = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/potato"));
      public static final TagKey<Item> pumpkin = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/pumpkin"));
      public static final TagKey<Item> sugar_cane = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/sugar_cane"));
      public static final TagKey<Item> wheat = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops/wheat"));
    }
    public static final class Drinks {
      public static final TagKey<Item> honey = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drinks/honey"));
      public static final TagKey<Item> juice = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drinks/juice"));
      public static final TagKey<Item> magic = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drinks/magic"));
      public static final TagKey<Item> milk = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drinks/milk"));
      public static final TagKey<Item> ominous = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drinks/ominous"));
      public static final TagKey<Item> water = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drinks/water"));
      public static final TagKey<Item> watery = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drinks/watery"));
    }
    public static final class DrinkContaining {
      public static final TagKey<Item> bottle = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drink_containing/bottle"));
      public static final TagKey<Item> bucket = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drink_containing/bucket"));
    }
    public static final class Dusts {
      public static final TagKey<Item> glowstone = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dusts/glowstone"));
      public static final TagKey<Item> redstone = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dusts/redstone"));
    }
    public static final class Dyed {
      public static final TagKey<Item> black = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/black"));
      public static final TagKey<Item> blue = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/blue"));
      public static final TagKey<Item> brown = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/brown"));
      public static final TagKey<Item> cyan = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/cyan"));
      public static final TagKey<Item> gray = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/gray"));
      public static final TagKey<Item> green = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/green"));
      public static final TagKey<Item> light_blue = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/light_blue"));
      public static final TagKey<Item> light_gray = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/light_gray"));
      public static final TagKey<Item> lime = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/lime"));
      public static final TagKey<Item> magenta = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/magenta"));
      public static final TagKey<Item> orange = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/orange"));
      public static final TagKey<Item> pink = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/pink"));
      public static final TagKey<Item> purple = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/purple"));
      public static final TagKey<Item> red = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/red"));
      public static final TagKey<Item> white = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/white"));
      public static final TagKey<Item> yellow = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed/yellow"));
    }
    public static final class Dyes {
      public static final TagKey<Item> black = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/black"));
      public static final TagKey<Item> blue = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/blue"));
      public static final TagKey<Item> brown = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/brown"));
      public static final TagKey<Item> cyan = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/cyan"));
      public static final TagKey<Item> gray = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/gray"));
      public static final TagKey<Item> green = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/green"));
      public static final TagKey<Item> light_blue = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/light_blue"));
      public static final TagKey<Item> light_gray = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/light_gray"));
      public static final TagKey<Item> lime = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/lime"));
      public static final TagKey<Item> magenta = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/magenta"));
      public static final TagKey<Item> orange = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/orange"));
      public static final TagKey<Item> pink = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/pink"));
      public static final TagKey<Item> purple = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/purple"));
      public static final TagKey<Item> red = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/red"));
      public static final TagKey<Item> white = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/white"));
      public static final TagKey<Item> yellow = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/yellow"));
    }
    public static final class Fences {
      public static final TagKey<Item> nether_brick = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "fences/nether_brick"));
      public static final TagKey<Item> wooden = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "fences/wooden"));
    }
    public static final class FenceGates {
      public static final TagKey<Item> wooden = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "fence_gates/wooden"));
    }
    public static final class Flowers {
      public static final TagKey<Item> small = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "flowers/small"));
      public static final TagKey<Item> tall = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "flowers/tall"));
    }
    public static final class Foods {
      public static final TagKey<Item> berry = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/berry"));
      public static final TagKey<Item> bread = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/bread"));
      public static final TagKey<Item> candy = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/candy"));
      public static final TagKey<Item> cooked_fish = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/cooked_fish"));
      public static final TagKey<Item> cooked_meat = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/cooked_meat"));
      public static final TagKey<Item> cookie = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/cookie"));
      public static final TagKey<Item> dough = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/dough"));
      public static final TagKey<Item> edible_when_placed = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/edible_when_placed"));
      public static final TagKey<Item> food_poisoning = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/food_poisoning"));
      public static final TagKey<Item> fruit = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/fruit"));
      public static final TagKey<Item> golden = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/golden"));
      public static final TagKey<Item> pie = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/pie"));
      public static final TagKey<Item> raw_fish = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/raw_fish"));
      public static final TagKey<Item> raw_meat = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/raw_meat"));
      public static final TagKey<Item> soup = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/soup"));
      public static final TagKey<Item> vegetable = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods/vegetable"));
    }
    public static final class Gems {
      public static final TagKey<Item> amethyst = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "gems/amethyst"));
      public static final TagKey<Item> diamond = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "gems/diamond"));
      public static final TagKey<Item> emerald = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "gems/emerald"));
      public static final TagKey<Item> lapis = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "gems/lapis"));
      public static final TagKey<Item> prismarine = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "gems/prismarine"));
      public static final TagKey<Item> quartz = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "gems/quartz"));
    }
    public static final class GlassBlocks {
      public static final TagKey<Item> cheap = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "glass_blocks/cheap"));
      public static final TagKey<Item> colorless = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "glass_blocks/colorless"));
      public static final TagKey<Item> tinted = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "glass_blocks/tinted"));
    }
    public static final class GlassPanes {
      public static final TagKey<Item> colorless = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "glass_panes/colorless"));
    }
    public static final class Ingots {
      public static final TagKey<Item> copper = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ingots/copper"));
      public static final TagKey<Item> gold = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ingots/gold"));
      public static final TagKey<Item> iron = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ingots/iron"));
      public static final TagKey<Item> netherite = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ingots/netherite"));
    }
    public static final class NaturalLogs {
      public static final TagKey<Item> nether = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "natural_logs/nether"));
      public static final TagKey<Item> overworld = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "natural_logs/overworld"));
    }
    public static final class Nuggets {
      public static final TagKey<Item> copper = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "nuggets/copper"));
      public static final TagKey<Item> gold = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "nuggets/gold"));
      public static final TagKey<Item> iron = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "nuggets/iron"));
    }
    public static final class Obsidians {
      public static final TagKey<Item> crying = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "obsidians/crying"));
      public static final TagKey<Item> normal = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "obsidians/normal"));
    }
    public static final class Ores {
      public static final TagKey<Item> coal = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/coal"));
      public static final TagKey<Item> copper = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/copper"));
      public static final TagKey<Item> diamond = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/diamond"));
      public static final TagKey<Item> emerald = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/emerald"));
      public static final TagKey<Item> gold = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/gold"));
      public static final TagKey<Item> iron = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/iron"));
      public static final TagKey<Item> lapis = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/lapis"));
      public static final TagKey<Item> netherite_scrap = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/netherite_scrap"));
      public static final TagKey<Item> quartz = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/quartz"));
      public static final TagKey<Item> redstone = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores/redstone"));
    }
    public static final class OresInGround {
      public static final TagKey<Item> deepslate = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores_in_ground/deepslate"));
      public static final TagKey<Item> netherrack = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores_in_ground/netherrack"));
      public static final TagKey<Item> stone = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores_in_ground/stone"));
    }
    public static final class OreBearingGround {
      public static final TagKey<Item> deepslate = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ore_bearing_ground/deepslate"));
      public static final TagKey<Item> netherrack = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ore_bearing_ground/netherrack"));
      public static final TagKey<Item> stone = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ore_bearing_ground/stone"));
    }
    public static final class OreRates {
      public static final TagKey<Item> dense = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ore_rates/dense"));
      public static final TagKey<Item> singular = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ore_rates/singular"));
      public static final TagKey<Item> sparse = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ore_rates/sparse"));
    }
    public static final class PlayerWorkstations {
      public static final TagKey<Item> crafting_tables = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "player_workstations/crafting_tables"));
      public static final TagKey<Item> furnaces = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "player_workstations/furnaces"));
    }
    public static final class Potions {
      public static final TagKey<Item> bottle = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "potions/bottle"));
    }
    public static final class Pumpkins {
      public static final TagKey<Item> carved = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "pumpkins/carved"));
      public static final TagKey<Item> jack_o_lanterns = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "pumpkins/jack_o_lanterns"));
      public static final TagKey<Item> normal = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "pumpkins/normal"));
    }
    public static final class RawMaterials {
      public static final TagKey<Item> copper = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "raw_materials/copper"));
      public static final TagKey<Item> gold = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "raw_materials/gold"));
      public static final TagKey<Item> iron = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "raw_materials/iron"));
    }
    public static final class Rods {
      public static final TagKey<Item> blaze = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "rods/blaze"));
      public static final TagKey<Item> breeze = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "rods/breeze"));
      public static final TagKey<Item> wooden = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "rods/wooden"));
    }
    public static final class Sands {
      public static final TagKey<Item> colorless = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sands/colorless"));
      public static final TagKey<Item> red = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sands/red"));
    }
    public static final class Sandstone {
      public static final TagKey<Item> blocks = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sandstone/blocks"));
      public static final TagKey<Item> red_blocks = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sandstone/red_blocks"));
      public static final TagKey<Item> red_slabs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sandstone/red_slabs"));
      public static final TagKey<Item> red_stairs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sandstone/red_stairs"));
      public static final TagKey<Item> slabs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sandstone/slabs"));
      public static final TagKey<Item> stairs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sandstone/stairs"));
      public static final TagKey<Item> uncolored_blocks = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sandstone/uncolored_blocks"));
      public static final TagKey<Item> uncolored_slabs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sandstone/uncolored_slabs"));
      public static final TagKey<Item> uncolored_stairs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sandstone/uncolored_stairs"));
    }
    public static final class Seeds {
      public static final TagKey<Item> beetroot = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "seeds/beetroot"));
      public static final TagKey<Item> melon = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "seeds/melon"));
      public static final TagKey<Item> pitcher_plant = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "seeds/pitcher_plant"));
      public static final TagKey<Item> pumpkin = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "seeds/pumpkin"));
      public static final TagKey<Item> torchflower = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "seeds/torchflower"));
      public static final TagKey<Item> wheat = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "seeds/wheat"));
    }
    public static final class StorageBlocks {
      public static final TagKey<Item> bone_meal = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/bone_meal"));
      public static final TagKey<Item> coal = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/coal"));
      public static final TagKey<Item> copper = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/copper"));
      public static final TagKey<Item> diamond = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/diamond"));
      public static final TagKey<Item> dried_kelp = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/dried_kelp"));
      public static final TagKey<Item> emerald = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/emerald"));
      public static final TagKey<Item> gold = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/gold"));
      public static final TagKey<Item> iron = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/iron"));
      public static final TagKey<Item> lapis = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/lapis"));
      public static final TagKey<Item> netherite = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/netherite"));
      public static final TagKey<Item> raw_copper = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/raw_copper"));
      public static final TagKey<Item> raw_gold = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/raw_gold"));
      public static final TagKey<Item> raw_iron = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/raw_iron"));
      public static final TagKey<Item> redstone = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/redstone"));
      public static final TagKey<Item> resin = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/resin"));
      public static final TagKey<Item> slime = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/slime"));
      public static final TagKey<Item> wheat = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks/wheat"));
    }
    public static final class Tools {
      public static final TagKey<Item> bow = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/bow"));
      public static final TagKey<Item> brush = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/brush"));
      public static final TagKey<Item> crossbow = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/crossbow"));
      public static final TagKey<Item> fishing_rod = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/fishing_rod"));
      public static final TagKey<Item> igniter = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/igniter"));
      public static final TagKey<Item> mace = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/mace"));
      public static final TagKey<Item> melee_weapon = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/melee_weapon"));
      public static final TagKey<Item> mining_tool = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/mining_tool"));
      public static final TagKey<Item> ranged_weapon = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/ranged_weapon"));
      public static final TagKey<Item> shear = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/shear"));
      public static final TagKey<Item> shield = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/shield"));
      public static final TagKey<Item> trident = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/trident"));
      public static final TagKey<Item> wrench = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools/wrench"));
    }
    public static final TagKey<Item> animal_foods = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "animal_foods"));
    public static final TagKey<Item> armors = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "armors"));
    public static final TagKey<Item> barrels = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "barrels"));
    public static final TagKey<Item> bars = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "bars"));
    public static final TagKey<Item> bones = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "bones"));
    public static final TagKey<Item> bookshelves = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "bookshelves"));
    public static final TagKey<Item> bricks = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "bricks"));
    public static final TagKey<Item> buckets = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "buckets"));
    public static final TagKey<Item> budding_blocks = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "budding_blocks"));
    public static final TagKey<Item> buds = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "buds"));
    public static final TagKey<Item> chains = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "chains"));
    public static final TagKey<Item> chests = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "chests"));
    public static final TagKey<Item> clumps = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "clumps"));
    public static final TagKey<Item> clusters = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "clusters"));
    public static final TagKey<Item> cobblestones = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "cobblestones"));
    public static final TagKey<Item> concretes = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "concretes"));
    public static final TagKey<Item> concrete_powders = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "concrete_powders"));
    public static final TagKey<Item> crops = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "crops"));
    public static final TagKey<Item> drinks = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "drinks"));
    public static final TagKey<Item> dusts = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dusts"));
    public static final TagKey<Item> dyed = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyed"));
    public static final TagKey<Item> dyes = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes"));
    public static final TagKey<Item> eggs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "eggs"));
    public static final TagKey<Item> enchantables = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "enchantables"));
    public static final TagKey<Item> ender_pearls = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ender_pearls"));
    public static final TagKey<Item> end_stones = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "end_stones"));
    public static final TagKey<Item> feathers = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "feathers"));
    public static final TagKey<Item> fences = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "fences"));
    public static final TagKey<Item> fence_gates = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "fence_gates"));
    public static final TagKey<Item> fertilizers = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "fertilizers"));
    public static final TagKey<Item> flowers = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "flowers"));
    public static final TagKey<Item> foods = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "foods"));
    public static final TagKey<Item> froglights = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "froglights"));
    public static final TagKey<Item> gems = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "gems"));
    public static final TagKey<Item> glass_blocks = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "glass_blocks"));
    public static final TagKey<Item> glass_panes = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "glass_panes"));
    public static final TagKey<Item> glazed_terracottas = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "glazed_terracottas"));
    public static final TagKey<Item> gravels = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "gravels"));
    public static final TagKey<Item> gunpowders = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "gunpowders"));
    public static final TagKey<Item> hidden_from_recipe_viewers = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "hidden_from_recipe_viewers"));
    public static final TagKey<Item> ingots = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ingots"));
    public static final TagKey<Item> leathers = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "leathers"));
    public static final TagKey<Item> mushrooms = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "mushrooms"));
    public static final TagKey<Item> music_discs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "music_discs"));
    public static final TagKey<Item> natural_logs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "natural_logs"));
    public static final TagKey<Item> natural_woods = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "natural_woods"));
    public static final TagKey<Item> netherracks = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "netherracks"));
    public static final TagKey<Item> nether_stars = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "nether_stars"));
    public static final TagKey<Item> nuggets = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "nuggets"));
    public static final TagKey<Item> obsidians = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "obsidians"));
    public static final TagKey<Item> ores = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ores"));
    public static final TagKey<Item> potions = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "potions"));
    public static final TagKey<Item> pumpkins = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "pumpkins"));
    public static final TagKey<Item> raw_materials = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "raw_materials"));
    public static final TagKey<Item> rods = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "rods"));
    public static final TagKey<Item> ropes = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "ropes"));
    public static final TagKey<Item> sands = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "sands"));
    public static final TagKey<Item> seeds = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "seeds"));
    public static final TagKey<Item> shulker_boxes = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "shulker_boxes"));
    public static final TagKey<Item> slime_balls = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "slime_balls"));
    public static final TagKey<Item> stones = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "stones"));
    public static final TagKey<Item> storage_blocks = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "storage_blocks"));
    public static final TagKey<Item> strings = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "strings"));
    public static final TagKey<Item> stripped_logs = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "stripped_logs"));
    public static final TagKey<Item> stripped_woods = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "stripped_woods"));
    public static final TagKey<Item> tools = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "tools"));
    public static final TagKey<Item> villager_job_sites = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "villager_job_sites"));
  }
  public static final class Potions {
    public static final TagKey<Potion> hidden_from_recipe_viewers = TagKey.create(Registries.POTION, Identifier.fromNamespaceAndPath("c", "hidden_from_recipe_viewers"));
  }
  public static final class Worldgen {
    public static final class Biomes {
      public static final class IsCold {
        public static final TagKey<Biome> end = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_cold/end"));
        public static final TagKey<Biome> nether = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_cold/nether"));
        public static final TagKey<Biome> overworld = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_cold/overworld"));
      }
      public static final class IsDenseVegetation {
        public static final TagKey<Biome> end = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dense_vegetation/end"));
        public static final TagKey<Biome> nether = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dense_vegetation/nether"));
        public static final TagKey<Biome> overworld = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dense_vegetation/overworld"));
      }
      public static final class IsDry {
        public static final TagKey<Biome> end = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dry/end"));
        public static final TagKey<Biome> nether = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dry/nether"));
        public static final TagKey<Biome> overworld = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dry/overworld"));
      }
      public static final class IsHot {
        public static final TagKey<Biome> end = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_hot/end"));
        public static final TagKey<Biome> nether = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_hot/nether"));
        public static final TagKey<Biome> overworld = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_hot/overworld"));
      }
      public static final class IsMountain {
        public static final TagKey<Biome> peak = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_mountain/peak"));
        public static final TagKey<Biome> slope = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_mountain/slope"));
      }
      public static final class IsSparseVegetation {
        public static final TagKey<Biome> end = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_sparse_vegetation/end"));
        public static final TagKey<Biome> nether = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_sparse_vegetation/nether"));
        public static final TagKey<Biome> overworld = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_sparse_vegetation/overworld"));
      }
      public static final class IsTemperate {
        public static final TagKey<Biome> end = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_temperate/end"));
        public static final TagKey<Biome> nether = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_temperate/nether"));
        public static final TagKey<Biome> overworld = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_temperate/overworld"));
      }
      public static final class IsTree {
        public static final TagKey<Biome> coniferous = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_tree/coniferous"));
        public static final TagKey<Biome> deciduous = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_tree/deciduous"));
        public static final TagKey<Biome> jungle = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_tree/jungle"));
        public static final TagKey<Biome> savanna = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_tree/savanna"));
      }
      public static final class IsWet {
        public static final TagKey<Biome> end = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_wet/end"));
        public static final TagKey<Biome> nether = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_wet/nether"));
        public static final TagKey<Biome> overworld = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_wet/overworld"));
      }
      public static final class PrimaryWoodType {
        public static final TagKey<Biome> acacia = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/acacia"));
        public static final TagKey<Biome> bamboo = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/bamboo"));
        public static final TagKey<Biome> birch = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/birch"));
        public static final TagKey<Biome> cherry = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/cherry"));
        public static final TagKey<Biome> crimson = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/crimson"));
        public static final TagKey<Biome> dark_oak = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/dark_oak"));
        public static final TagKey<Biome> jungle = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/jungle"));
        public static final TagKey<Biome> mangrove = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/mangrove"));
        public static final TagKey<Biome> oak = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/oak"));
        public static final TagKey<Biome> pale_oak = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/pale_oak"));
        public static final TagKey<Biome> spruce = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/spruce"));
        public static final TagKey<Biome> warped = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type/warped"));
      }
      public static final TagKey<Biome> hidden_from_locator_selection = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "hidden_from_locator_selection"));
      public static final TagKey<Biome> is_aquatic = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_aquatic"));
      public static final TagKey<Biome> is_aquatic_icy = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_aquatic_icy"));
      public static final TagKey<Biome> is_badlands = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_badlands"));
      public static final TagKey<Biome> is_beach = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_beach"));
      public static final TagKey<Biome> is_birch_forest = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_birch_forest"));
      public static final TagKey<Biome> is_cave = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_cave"));
      public static final TagKey<Biome> is_cold = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_cold"));
      public static final TagKey<Biome> is_dark_forest = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dark_forest"));
      public static final TagKey<Biome> is_dead = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dead"));
      public static final TagKey<Biome> is_deep_ocean = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_deep_ocean"));
      public static final TagKey<Biome> is_dense_vegetation = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dense_vegetation"));
      public static final TagKey<Biome> is_desert = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_desert"));
      public static final TagKey<Biome> is_dry = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_dry"));
      public static final TagKey<Biome> is_end = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_end"));
      public static final TagKey<Biome> is_floral = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_floral"));
      public static final TagKey<Biome> is_flower_forest = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_flower_forest"));
      public static final TagKey<Biome> is_forest = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_forest"));
      public static final TagKey<Biome> is_hill = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_hill"));
      public static final TagKey<Biome> is_hot = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_hot"));
      public static final TagKey<Biome> is_icy = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_icy"));
      public static final TagKey<Biome> is_jungle = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_jungle"));
      public static final TagKey<Biome> is_lush = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_lush"));
      public static final TagKey<Biome> is_magical = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_magical"));
      public static final TagKey<Biome> is_mountain = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_mountain"));
      public static final TagKey<Biome> is_mushroom = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_mushroom"));
      public static final TagKey<Biome> is_nether = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_nether"));
      public static final TagKey<Biome> is_nether_forest = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_nether_forest"));
      public static final TagKey<Biome> is_ocean = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_ocean"));
      public static final TagKey<Biome> is_old_growth = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_old_growth"));
      public static final TagKey<Biome> is_outer_end_island = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_outer_end_island"));
      public static final TagKey<Biome> is_overworld = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_overworld"));
      public static final TagKey<Biome> is_plains = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_plains"));
      public static final TagKey<Biome> is_plateau = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_plateau"));
      public static final TagKey<Biome> is_rare = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_rare"));
      public static final TagKey<Biome> is_river = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_river"));
      public static final TagKey<Biome> is_sandy = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_sandy"));
      public static final TagKey<Biome> is_savanna = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_savanna"));
      public static final TagKey<Biome> is_shallow_ocean = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_shallow_ocean"));
      public static final TagKey<Biome> is_snowy = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_snowy"));
      public static final TagKey<Biome> is_snowy_plains = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_snowy_plains"));
      public static final TagKey<Biome> is_sparse_vegetation = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_sparse_vegetation"));
      public static final TagKey<Biome> is_spooky = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_spooky"));
      public static final TagKey<Biome> is_stony_shores = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_stony_shores"));
      public static final TagKey<Biome> is_swamp = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_swamp"));
      public static final TagKey<Biome> is_taiga = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_taiga"));
      public static final TagKey<Biome> is_temperate = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_temperate"));
      public static final TagKey<Biome> is_underground = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_underground"));
      public static final TagKey<Biome> is_void = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_void"));
      public static final TagKey<Biome> is_wasteland = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_wasteland"));
      public static final TagKey<Biome> is_wet = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_wet"));
      public static final TagKey<Biome> is_windswept = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "is_windswept"));
      public static final TagKey<Biome> no_default_monsters = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "no_default_monsters"));
      public static final TagKey<Biome> primary_wood_type = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("c", "primary_wood_type"));
    }
    public static final class Structures {
      public static final TagKey<Structure> hidden_from_displayers = TagKey.create(Registries.STRUCTURE, Identifier.fromNamespaceAndPath("c", "hidden_from_displayers"));
      public static final TagKey<Structure> hidden_from_locator_selection = TagKey.create(Registries.STRUCTURE, Identifier.fromNamespaceAndPath("c", "hidden_from_locator_selection"));
    }
  }
}
