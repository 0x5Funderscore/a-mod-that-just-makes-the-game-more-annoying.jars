package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fall_damage_at_2_blocks;

import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Player.class)
public abstract class PlayerMixin {

  @Inject(method = "createAttributes", at = @At("TAIL"))
  private static void modifyCreatedAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (Config.FALL_DAMAGE_AT_2_BLOCKS.get()) cir.getReturnValue()
        .add(Attributes.SAFE_FALL_DISTANCE, 1.0f);
  }

}
