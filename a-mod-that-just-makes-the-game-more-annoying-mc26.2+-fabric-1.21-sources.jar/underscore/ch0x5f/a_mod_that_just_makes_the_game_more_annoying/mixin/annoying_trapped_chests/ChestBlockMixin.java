package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.annoying_trapped_chests;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.TrappedChestBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.IChestSelfClosingExtension;


@Mixin(ChestBlock.class)
public abstract class ChestBlockMixin {

  @ModifyReturnValue(method = "getTicker", at = @At("TAIL"))
  private <T extends BlockEntity> @Nullable BlockEntityTicker<T> modifyTicker(
      @Nullable BlockEntityTicker<T> original,
      @Local(name = "level", argsOnly = true) Level level
  ) {
    if (Config.ANNOYING_TRAPPED_CHESTS.get() && !level.isClientSide()) {

      ChestBlock chestBlock = (ChestBlock)(Object)this;
      if (chestBlock instanceof TrappedChestBlock) {

        BlockEntityTicker<T> postTicker = (level1, pos, state, entity) -> {
          if (entity instanceof ChestBlockEntity chest) {

            IChestSelfClosingExtension extended = (IChestSelfClosingExtension)chest;
            if (extended.willSelfClose() && extended.tickSelfClosing()) {
              chest.getEntitiesWithContainerOpen().forEach(cu -> {
                if (cu instanceof ServerPlayer player) player.closeContainer();
              });
            }

          }
        };

        return original == null ? postTicker : original.andThen(postTicker);
      }
    }
    return original;
  }

}
