package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.annoying_trapped_chests;

import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ContainerUser;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.IChestSelfClosingExtension;


@Mixin(ChestBlockEntity.class)
@Implements(@Interface(iface = IChestSelfClosingExtension.class, prefix = "i$"))
public abstract class ChestBlockEntityMixin extends RandomizableContainerBlockEntity implements IChestSelfClosingExtension {

  @Unique
  private boolean rb$willClose = false;

  @Unique
  private int rb$selfClosingTicks = 0;

  public boolean i$willSelfClose() {
    return this.rb$willClose;
  }
  public boolean i$tickSelfClosing() {
    if ((this.rb$selfClosingTicks--) <= 0) {
      this.rb$willClose = false;
      this.rb$selfClosingTicks = 0;
      return true;
    } else return false;
  }

  protected ChestBlockEntityMixin(BlockEntityType<?> type, BlockPos worldPosition, BlockState blockState) {
    super(type, worldPosition, blockState);
  }

  @Inject(method = "startOpen", at = @At("TAIL"))
  private void startOpenExtra(ContainerUser containerUser, CallbackInfo ci) {
    if (Config.ANNOYING_TRAPPED_CHESTS.get() && this.level instanceof ServerLevel serverLevel) {
      ChestBlockEntity chestBlockEntity = (ChestBlockEntity)(RandomizableContainerBlockEntity)this;
      if (chestBlockEntity instanceof TrappedChestBlockEntity) {
        if (Math.random() < 0.8d) {
          serverLevel.playSound(null, this.getBlockPos(), SoundEvents.SHULKER_AMBIENT, SoundSource.BLOCKS, 1.0F, 1.0F);
          this.rb$willClose = true;
          this.rb$selfClosingTicks = 2;
        } else {
          this.rb$willClose = false;
          this.rb$selfClosingTicks = 0;
        }
      }
    }
  }

}
