package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.nether_water;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BucketItem.class)
public abstract class BucketItemMixin {

  @Definition(id = "getValue", method = "Lnet/minecraft/world/attribute/EnvironmentAttributeSystem;getValue(Lnet/minecraft/world/attribute/EnvironmentAttribute;Lnet/minecraft/core/BlockPos;)Ljava/lang/Object;")
  @Definition(id = "WATER_EVAPORATES", field = "Lnet/minecraft/world/attribute/EnvironmentAttributes;WATER_EVAPORATES:Lnet/minecraft/world/attribute/EnvironmentAttribute;")
  @Expression("?.getValue(WATER_EVAPORATES, ?)")
  @ModifyExpressionValue(method = "emptyContents", at = @At("MIXINEXTRAS:EXPRESSION"))
  private Object modifyWaterEvaporates(
      Object original,
      @Local(name = "level", argsOnly = true) Level level
  ) {
    if (Config.NETHER_WATER.get() && rb$isSlowWater(level)) return false;
    return original;
  }

  @Unique
  private static boolean rb$isSlowWater(final LevelReader level) {
    return !level.isClientSide() && level.environmentAttributes().getDimensionValue(EnvironmentAttributes.FAST_LAVA);
  }

}
