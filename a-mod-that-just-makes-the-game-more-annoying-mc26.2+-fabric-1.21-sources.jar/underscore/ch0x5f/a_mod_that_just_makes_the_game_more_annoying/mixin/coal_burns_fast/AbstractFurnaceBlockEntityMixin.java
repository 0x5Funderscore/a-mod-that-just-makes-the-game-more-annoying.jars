package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.coal_burns_fast;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.FuelValues;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CTags;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  @ModifyReturnValue(method = "getBurnDuration", at = @At("TAIL"))
  private int modifyBurnDuration(
      int original,
//      @Local(name = "fuelValues", argsOnly = true) FuelValues fuelValues,
      @Local(name = "itemStack", argsOnly = true) ItemStack itemStack
  ) {
    if (Config.COAL_BURNS_FAST.get() && (itemStack.is(ItemTags.COALS) || itemStack.is(Items.COAL_BLOCK))) {
      return original / 16;
    }
    return original;
  }

}
