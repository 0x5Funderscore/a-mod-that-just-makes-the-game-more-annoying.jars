package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.hissbines;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.entity.EntityTypeTest;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.hissbines.Hissbine;

import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;
import java.util.stream.Collectors;


@Mixin(ServerLevel.class)
public abstract class ServerLevelMixin {

  @Shadow
  public abstract <T extends Entity> List<? extends T> getEntities(EntityTypeTest<Entity,T> type, Predicate<? super T> selector);

  @Unique
  private final List<Hissbine> rb$hissbines = new ArrayList<>();

  @Inject(method = "addEntity", at = @At("TAIL"))
  private void postAddEntity(Entity entity, CallbackInfoReturnable<Boolean> cir) {
    Hissbine potentialHissbine = Hissbine.maybeAttachEntity(entity);
    if (potentialHissbine != null) {
      this.rb$hissbines.add(potentialHissbine);
    }
  }

  @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;runBlockEvents()V"))
  private void tickLandmines(BooleanSupplier haveTime, CallbackInfo ci) {
    Set<Display.BlockDisplay> countedBlockDisplays = this.rb$hissbines.stream().map(hissbine -> hissbine.seagrass).collect(Collectors.toSet());
    this.getEntities(
        EntityTypeTest.forExactClass(Display.BlockDisplay.class),
        d -> d.entityTags().contains("hissbine") && !countedBlockDisplays.contains(d)
    ).forEach(d -> Optional.ofNullable(Hissbine.maybeAttachEntity(d)).ifPresentOrElse(this.rb$hissbines::add, d::discard));
    this.rb$hissbines.forEach(Hissbine::tick);
    this.rb$hissbines.removeIf(Hissbine::isRemoved);

    Set<Display.BlockDisplay> allowedHissbineParts = new HashSet<>();
    this.rb$hissbines.forEach(hissbine -> {
      allowedHissbineParts.add(hissbine.seagrass);
      if (hissbine.coralFan != null) allowedHissbineParts.add(hissbine.coralFan);
      if (hissbine.crimsonRoots != null) allowedHissbineParts.add(hissbine.crimsonRoots);
    });
    this.getEntities(
        EntityTypeTest.forExactClass(Display.BlockDisplay.class),
        d -> d.entityTags().contains("hissbine_part") && !allowedHissbineParts.remove(d)
    ).forEach(Entity::discard);
  }

}
