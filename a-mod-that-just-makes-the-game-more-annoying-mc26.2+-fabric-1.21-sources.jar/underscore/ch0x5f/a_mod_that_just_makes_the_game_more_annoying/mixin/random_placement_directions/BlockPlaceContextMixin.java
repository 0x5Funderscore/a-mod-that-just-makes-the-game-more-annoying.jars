package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.random_placement_directions;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.IUseOnContextDirectionExtension;


@Mixin(BlockPlaceContext.class)
public abstract class BlockPlaceContextMixin extends UseOnContext {

  public BlockPlaceContextMixin(Player player, InteractionHand hand, BlockHitResult hitResult) {
    super(player, hand, hitResult);
  }

  @ModifyReturnValue(method = "getNearestLookingDirection", at = @At("TAIL"))
  private Direction modifyNearestLookingDirection(@NotNull Direction original) {
    if (Config.RANDOM_PLACEMENT_DIRECTIONS.get() && !this.getLevel().isClientSide()) {
      BlockPlaceContext blockPlaceContext = (BlockPlaceContext)(Object)this;
      return ((IUseOnContextDirectionExtension)blockPlaceContext).getRandomNearestDirection();
    }
    return original;
  }

  @ModifyReturnValue(method = "getNearestLookingVerticalDirection", at = @At("TAIL"))
  private Direction modifyNearestLookingVerticalDirection(@NotNull Direction original) {
    if (Config.RANDOM_PLACEMENT_DIRECTIONS.get() && !this.getLevel().isClientSide()) {
      BlockPlaceContext blockPlaceContext = (BlockPlaceContext)(Object)this;
      return ((IUseOnContextDirectionExtension)blockPlaceContext).getRandomNearestVerticalDirection();
    }
    return original;
  }

  @ModifyReturnValue(method = "getNearestLookingDirections", at = @At("TAIL"))
  private Direction[] modifyNearestLookingDirections(@NotNull Direction[] original) {
    if (Config.RANDOM_PLACEMENT_DIRECTIONS.get() && !this.getLevel().isClientSide()) {
      BlockPlaceContext blockPlaceContext = (BlockPlaceContext)(Object)this;
      return ((IUseOnContextDirectionExtension)blockPlaceContext).getRandomNearestLookingDirections();
    }
    return original;
  }

}
