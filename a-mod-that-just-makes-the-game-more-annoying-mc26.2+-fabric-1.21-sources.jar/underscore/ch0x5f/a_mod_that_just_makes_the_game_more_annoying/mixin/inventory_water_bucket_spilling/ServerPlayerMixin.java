package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.inventory_water_bucket_spilling;

import com.mojang.authlib.GameProfile;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Objects;
import java.util.Optional;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Unique
  private static boolean[] rb$union(boolean[] a, boolean[] b) {
    boolean[] x = new boolean[27];
    for (int i = 0; i < 27; i++) x[i] = a[i] || b[i];
    return x;
  }

  @Unique
  private static boolean rb$isSlotFilled(boolean[] filledSlots, int x, int y) {
    if (x < 0 || x >= 9) return true;
    if (y < 0 || y >= 3) return true;
    return filledSlots[y * 9 + x];
  }

  @Unique
  private static boolean[] rb$spreadWater(boolean[] filledSlots, int sourceX, int sourceY) {
    boolean[] wetSlots = new boolean[27];
    int x = sourceX;
    int y = sourceY;
    while (x >= 0) {
      boolean d = false;
      while (x == sourceX && y == sourceY || !rb$isSlotFilled(filledSlots, x, y)) {
        if (!(x == sourceX && y == sourceY)) wetSlots[y * 9 + x] = true;
        y++; d = true;
      }
      if (d) y--;
      x--;
    }
    x = sourceX;
    y = sourceY;
    while (x <= 8) {
      boolean d = false;
      while (x == sourceX && y == sourceY || !rb$isSlotFilled(filledSlots, x, y)) {
        if (!(x == sourceX && y == sourceY)) wetSlots[y * 9 + x] = true;
        y++; d = true;
      }
      if (d) y--;
      x++;
    }
    return wetSlots;
  }

  @Unique
  private static boolean[] rb$makeFilledSlots(Inventory inventory) {
    boolean[] filledSlots = new boolean[27];
    for (int i = 0; i < 27; i++) {
      ItemStack itemStack = inventory.getItem(i + 9);
      if (!itemStack.isEmpty()) {
        if (
            itemStack.is(Items.DYE.white()) &&
            Objects.equals(itemStack.get(DataComponents.MAX_STACK_SIZE), 1) &&
            Objects.equals(itemStack.get(DataComponents.ENCHANTMENT_GLINT_OVERRIDE), true)
        ) {
          continue;
        }
        if (
            itemStack.is(Items.STAINED_GLASS_PANE.lightGray()) &&
            Objects.equals(itemStack.get(DataComponents.MAX_STACK_SIZE), 1) &&
            Objects.equals(itemStack.get(DataComponents.ENCHANTMENT_GLINT_OVERRIDE), false) &&
            Optional.ofNullable(itemStack.get(DataComponents.TOOLTIP_DISPLAY)).map(TooltipDisplay::hideTooltip).orElse(false)
        ) {
          continue;
        }
        filledSlots[i] = true;
      }
    }
    return filledSlots;
  }

  @Unique
  private static void rb$applyWaterFlow(Inventory inventory, boolean[] flowSlots) {
    for (int i = 0; i < 27; i++) {
      if (flowSlots[i]) {
        ItemStack itemStack = new ItemStack(Items.DYE.white());
        itemStack.set(DataComponents.MAX_STACK_SIZE, 1);
        itemStack.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
        itemStack.set(DataComponents.ITEM_MODEL, Identifier.withDefaultNamespace("blue_stained_glass_pane"));
        itemStack.set(DataComponents.ITEM_NAME, Component.translatable("block.minecraft.water"));
        inventory.setItem(i + 9, itemStack);
      }
    }
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.INVENTORY_WATER_BUCKET_SPILLING.get()) {
      if (this.isSprinting() && this.getDeltaMovement().y > 0.35d && Math.random() < 0.1d) {
        Inventory inventory = this.getInventory();
        IntList waterBuckets = new IntArrayList();
        for (int i = 0; i < 27; i++) {
          if (inventory.getItem(i + 9).is(Items.WATER_BUCKET)) {
            waterBuckets.add(i);
          }
        }
        if (!waterBuckets.isEmpty()) {
          final boolean[] filledSlots = rb$makeFilledSlots(inventory);
          boolean[] waterSlots = new boolean[27];
          for (int waterBucketSlot: waterBuckets) {
            int x = waterBucketSlot % 9;
            int y = waterBucketSlot / 9;
            waterSlots = rb$union(waterSlots, rb$spreadWater(filledSlots, x, y));
            inventory.setItem(waterBucketSlot + 9, new ItemStack(Items.BUCKET));
          }
          rb$applyWaterFlow(inventory, waterSlots);
        }
      }
    }
  }

}
