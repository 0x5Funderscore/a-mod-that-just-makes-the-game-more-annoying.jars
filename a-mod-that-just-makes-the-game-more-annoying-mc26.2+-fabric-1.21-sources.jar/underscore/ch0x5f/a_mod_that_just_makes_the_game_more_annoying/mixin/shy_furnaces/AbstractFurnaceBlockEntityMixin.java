package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.shy_furnaces;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Position;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.FurnaceBlock;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  @Unique
  private static final TargetingConditions rb$PLAYER_TARGETER = TargetingConditions.forNonCombat();

  @Unique
  private static final double rb$MAX_DISTANCE_SQR = 64d * 64d;
  @Unique
  private static final double rb$CLOSE_DISTANCE_SQR = 4d * 4d;

//  @Unique
//  private static double rb$getCubeRadius(Position normal) {
//    return 0.5d / Math.max(Math.max(Math.abs(normal.x()), Math.abs(normal.y())), Math.abs(normal.z()));
//  }

  @Definition(id = "items", field = "Lnet/minecraft/world/level/block/entity/AbstractFurnaceBlockEntity;items:Lnet/minecraft/core/NonNullList;")
  @Definition(id = "get", method = "Lnet/minecraft/core/NonNullList;get(I)Ljava/lang/Object;")
  @Definition(id = "entity", local = @Local(type = AbstractFurnaceBlockEntity.class, name = "entity", argsOnly = true))
  @Expression("entity.items.get(?)")
  @WrapOperation(method = "serverTick", at = @At("MIXINEXTRAS:EXPRESSION"))
  private static Object replaceFuel(
      NonNullList<ItemStack> instance, int index, Operation<ItemStack> original,
//      @Local(name = "entity", argsOnly = true) AbstractFurnaceBlockEntity entity,
      @Local(name = "level", argsOnly = true) ServerLevel level,
      @Local(name = "pos", argsOnly = true) BlockPos pos,
      @Local(name = "state", argsOnly = true) BlockState state
  ) {
    ItemStack fuel = instance.get(index);
    if (Config.SHY_FURNACES.get() && index == 1 && !fuel.isEmpty()) {
      if (rb$isBeingLookedAt(level, pos, state)) {
        return ItemStack.EMPTY;
      }
    }
    return fuel;
  }

  @Unique
  private static boolean rb$isBeingLookedAt(ServerLevel level, BlockPos pos, BlockState state) {
    Vec3 blockCenter = Vec3.atCenterOf(pos);

    Player tooClosePlayer = level.getNearestPlayer(rb$PLAYER_TARGETER, blockCenter.x, blockCenter.y, blockCenter.z);
    if (tooClosePlayer != null && tooClosePlayer.getEyePosition().distanceToSqr(blockCenter) <= rb$CLOSE_DISTANCE_SQR) {
      return true;
    }

    Vec3 furnaceFacingAngle = state.getValue(FurnaceBlock.FACING).getUnitVec3();
    Vec3 faceCenter = blockCenter.add(furnaceFacingAngle.scale(0.5d + 1e-3d));

    return level.players().stream().anyMatch(player -> {
      if (player.distanceToSqr(blockCenter) > rb$MAX_DISTANCE_SQR) return false;
      if (!rb$PLAYER_TARGETER.test(level, null, player)) return false;

      Vec3 lookDir = player.getLookAngle();
      Vec3 eyePosition = player.getEyePosition();

      BlockHitResult clip = level.clip(
          new ClipContext(
              eyePosition,
              faceCenter,
              ClipContext.Block.VISUAL,
              ClipContext.Fluid.NONE,
              CollisionContext.empty()
          )
      );

      return lookDir.dot(furnaceFacingAngle) < -0.5d && clip.getType() == HitResult.Type.MISS;
    });
  }

}
