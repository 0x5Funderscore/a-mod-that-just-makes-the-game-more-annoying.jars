package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.end_crystals_require_player_punch;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EndCrystal.class)
public abstract class EndCrystalMixin extends Entity {
  public EndCrystalMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @WrapOperation(method = "hurtServer", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/boss/enderdragon/EndCrystal;isInvulnerableToBase(Lnet/minecraft/world/damagesource/DamageSource;)Z"))
  private boolean modifyInvulnerable(EndCrystal instance, DamageSource damageSource, Operation<Boolean> original) {
    if (original.call(instance, damageSource)) return true;
    if (Config.END_CRYSTALS_REQUIRE_PLAYER_PUNCH.get()) return !damageSource.is(DamageTypes.PLAYER_ATTACK);
    return false;
  }
}
