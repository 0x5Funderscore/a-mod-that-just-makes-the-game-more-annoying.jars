package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.goofy_spiders;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.spider.Spider;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.SpiderLeapAtTargetGoal;


@Mixin(Spider.class)
public abstract class SpiderMixin extends Monster {
  protected SpiderMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @Definition(id = "goalSelector", field = "Lnet/minecraft/world/entity/monster/spider/Spider;goalSelector:Lnet/minecraft/world/entity/ai/goal/GoalSelector;")
  @Definition(id = "addGoal", method = "Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V")
  @Definition(id = "LeapAtTargetGoal", type = LeapAtTargetGoal.class)
  @Expression("this.goalSelector.addGoal(?, new LeapAtTargetGoal(?, ?))")
  @WrapOperation(method = "registerGoals", at = @At("MIXINEXTRAS:EXPRESSION"))
  private void replaceLeapAtTargetGoal(GoalSelector instance, int prio, Goal goal, Operation<Void> original) {
    if (Config.GOOFY_SPIDERS.get()) {
      original.call(instance, prio, new SpiderLeapAtTargetGoal(this, 0.55f));
    } else {
      original.call(instance, prio, goal);
    }
  }

  @Inject(method = "createAttributes", at = @At("TAIL"))
  private static void modifyCreatedAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (Config.GOOFY_SPIDERS.get()) cir.getReturnValue()
        .add(Attributes.FOLLOW_RANGE, 96.0d)
        .add(Attributes.FALL_DAMAGE_MULTIPLIER, 0.0d);
  }
}
