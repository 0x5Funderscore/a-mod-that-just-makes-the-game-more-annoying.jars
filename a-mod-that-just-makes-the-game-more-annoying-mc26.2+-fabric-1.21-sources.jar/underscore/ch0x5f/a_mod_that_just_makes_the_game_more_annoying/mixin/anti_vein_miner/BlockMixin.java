package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.anti_vein_miner;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CTags;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.*;


@Mixin(Block.class)
public class BlockMixin {

  @Unique
  private static Collection<@NotNull BlockPos> rb$spreadOresNext(Block target, BlockGetter level, Collection<@NotNull BlockPos> next, Collection<@NotNull BlockPos> contents) {
    Set<BlockPos> next2 = new HashSet<>();
    for (BlockPos pos: next) {
      BlockState blockState = level.getBlockState(pos);
      if (blockState.is(target)) {
        contents.add(pos);
        for (Direction direction: Direction.values()) {
          BlockPos relative = pos.relative(direction);
          if (!contents.contains(relative)) next2.add(relative);
        }
      }
    }
    return next2;
  }

  @Unique
  private static Collection<@NotNull BlockPos> rb$spreadOres(Block target, BlockGetter level, Collection<@NotNull BlockPos> next, int maxCount) {
    Set<BlockPos> contents = new HashSet<>();
    while (contents.size() < maxCount && !next.isEmpty()) {
      next = rb$spreadOresNext(target, level, next, contents);
    }
    return contents;
  }

  @Inject(method = "playerDestroy", at = @At("TAIL"))
  private void postPlayerDestroy(Level level, Player player, BlockPos pos, BlockState state, BlockEntity blockEntity, ItemStack destroyedWith, CallbackInfo ci) {
    if (Config.ANTI_VEIN_MINER.get() && state.is(CTags.Blocks.ores) && !level.isClientSide()) {
      Block replacement = null;
      if (state.is(CTags.Blocks.OresInGround.deepslate)) {
        replacement = Blocks.DEEPSLATE;
      } else if (state.is(CTags.Blocks.OresInGround.stone)) {
        replacement = Blocks.STONE;
      } else if (state.is(CTags.Blocks.OresInGround.netherrack)) {
        replacement = Blocks.NETHERRACK;
      }
      if (replacement != null) {
        Set<BlockPos> next = new HashSet<>();
        for (Direction direction: Direction.values()) {
          next.add(pos.relative(direction));
        }
        Collection<@NotNull BlockPos> ores = rb$spreadOres(state.getBlock(), level, next, 256);
        BlockState replacementState = replacement.defaultBlockState();
        ores.forEach(orePos -> level.setBlockAndUpdate(orePos, replacementState));
      }
    }
  }

}
