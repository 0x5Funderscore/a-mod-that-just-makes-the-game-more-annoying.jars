package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.skeleton_homing_arrows;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.IArrowHomingExtension;


@Mixin(AbstractArrow.class)
@Implements(@Interface(iface = IArrowHomingExtension.class, prefix = "homing$"))
public abstract class AbstractArrowMixin extends Entity implements IArrowHomingExtension {

  public AbstractArrowMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Unique
  private @Nullable Entity rb$homingTarget = null;

  public @Nullable Entity homing$getHomingTarget() {
    return this.rb$homingTarget;
  }

  public void homing$setHomingTarget(@Nullable Entity homingTarget) {
    this.rb$homingTarget = homingTarget;
  }

  @Unique
  private static final float rb$MAX_HOMING_NORM_DELTA_LENGTH = 1.0f;

  @Inject(method = "tick", at = @At("HEAD"))
  private void tickHoming(CallbackInfo ci) {
    if (!Config.SKELETON_HOMING_ARROWS.get()) return;
    Entity target = this.rb$homingTarget;
    if (target == null) return;
    Vec3 targetOffset = target.getEyePosition().subtract(this.makeBoundingBox().getCenter());
    Vec3 targetDirection = targetOffset.normalize();
    Vec3 velocity = this.getDeltaMovement();
    double speed = velocity.length();
    Vec3 velocityDirection = velocity.normalize();
    Vec3 deltaVelocityDirection = targetDirection.subtract(velocityDirection);
    if (deltaVelocityDirection.length() > rb$MAX_HOMING_NORM_DELTA_LENGTH) {
      deltaVelocityDirection = deltaVelocityDirection.normalize().scale(rb$MAX_HOMING_NORM_DELTA_LENGTH);
    }
    velocityDirection = velocityDirection.add(deltaVelocityDirection);
    velocity = velocityDirection.scale(speed);
    this.setDeltaMovement(velocity);
  }

}
