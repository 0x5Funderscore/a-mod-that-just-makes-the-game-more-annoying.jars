package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.always_raid;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.village.poi.PoiManager;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.raid.Raid;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Optional;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract ServerLevel level();

  @Shadow
  @Final
  private static Logger LOGGER;

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.ALWAYS_RAID.get() && !this.isSpectator()) {
      if (!this.hasEffect(MobEffects.HERO_OF_THE_VILLAGE)) {
        Optional<BlockPos> poi = this.level().getPoiManager().findClosest(type -> type.is(PoiTypes.MEETING), this.blockPosition(), 32, PoiManager.Occupancy.ANY);
        if (poi.isPresent() && !this.level().isRaided(poi.get())) {
          Raid raid = this.level().getRaids().createOrExtendRaid((ServerPlayer)(Player)this, poi.get());
          if (raid != null) raid.setRaidOmenLevel(Math.max(0, raid.getRaidOmenLevel()));
        }
      }
    }
  }

}
