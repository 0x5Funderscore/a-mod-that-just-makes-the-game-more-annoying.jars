package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.swap_regen_wither;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.RegenerationMobEffect;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(RegenerationMobEffect.class)
public abstract class RegenerationMobEffectMixin {

  @Inject(method = "applyEffectTick", at = @At("HEAD"), cancellable = true)
  private void preApplyEffectTick(ServerLevel level, LivingEntity mob, int amplification, CallbackInfoReturnable<Boolean> cir) {
    if (Config.SWAP_REGEN_WITHER.get() && mob instanceof Player) {
      mob.hurtServer(level, level.damageSources().wither(), 1.0f);
      cir.setReturnValue(true);
      cir.cancel();
    }
  }

}
