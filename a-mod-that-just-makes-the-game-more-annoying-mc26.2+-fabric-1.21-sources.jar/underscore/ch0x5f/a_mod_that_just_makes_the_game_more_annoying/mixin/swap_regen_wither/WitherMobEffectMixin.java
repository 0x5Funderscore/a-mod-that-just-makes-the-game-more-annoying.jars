package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.swap_regen_wither;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.WitherMobEffect;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(WitherMobEffect.class)
public abstract class WitherMobEffectMixin {

  @WrapOperation(method = "applyEffectTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;hurtServer(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;F)Z"))
  private boolean wrapHurtServer(LivingEntity instance, ServerLevel level, DamageSource source, float damage, Operation<Boolean> original) {
    if (Config.SWAP_REGEN_WITHER.get() && instance instanceof Player) {
      instance.heal(damage);
      return false;
    } else {
      return original.call(instance, level, source, damage);
    }
  }

}
