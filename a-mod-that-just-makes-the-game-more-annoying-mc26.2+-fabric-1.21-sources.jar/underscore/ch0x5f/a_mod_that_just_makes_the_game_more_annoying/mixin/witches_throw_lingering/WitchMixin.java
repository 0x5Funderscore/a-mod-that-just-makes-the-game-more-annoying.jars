package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.witches_throw_lingering;

import net.minecraft.world.entity.monster.Witch;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownLingeringPotion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Witch.class)
public abstract class WitchMixin {

  @ModifyArg(method = "performRangedAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/Projectile;spawnProjectileUsingShoot(Lnet/minecraft/world/entity/projectile/Projectile$ProjectileFactory;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;DDDFF)Lnet/minecraft/world/entity/projectile/Projectile;"))
  private Projectile.ProjectileFactory<? extends Projectile> modifyProjectileCreator(Projectile.ProjectileFactory<? extends Projectile> creator) {
    if (Config.WITCHES_THROW_LINGERING.get()) return ThrownLingeringPotion::new;
    return creator;
  }

}
