package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_lava_solidification;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LiquidBlock.class)
public abstract class LiquidBlockMixin {

  @Definition(id = "convertToBlock", local = @Local(type = Block.class, name = "convertToBlock"))
  @Definition(id = "defaultBlockState", method = "Lnet/minecraft/world/level/block/Block;defaultBlockState()Lnet/minecraft/world/level/block/state/BlockState;")
  @Expression("convertToBlock.defaultBlockState()")
  @ModifyExpressionValue(method = "shouldSpreadLiquid", at = @At("MIXINEXTRAS:EXPRESSION"))
  private BlockState modifyConvertedBlockState(
      BlockState original,
      @Local(name = "pos", argsOnly = true) BlockPos pos,
      @Local(name = "level", argsOnly = true) Level level
  ) {
    if (Config.REPLACE_LAVA_SOLIDIFICATION.get()) {

      boolean includeObsidian = original.is(Blocks.OBSIDIAN);
      if (includeObsidian) {
        for (Direction direction: Direction.values()) {
          if (level.getBlockState(pos.relative(direction)).is(Blocks.OBSIDIAN)) {
            includeObsidian = false;
            break;
          }
        }
      }

      Block[] replacements = new Block[]{
          Blocks.ANDESITE,
          Blocks.DIORITE,
          Blocks.GRANITE,
          Blocks.BASALT,
          Blocks.SMOOTH_BASALT,
          Blocks.TUFF,
          Blocks.COBBLESTONE,
          Blocks.STONE,

          Blocks.OBSIDIAN,
          Blocks.CRYING_OBSIDIAN
      };
      int bound = includeObsidian ? replacements.length : replacements.length - 2;

      return replacements[level.getRandom().nextInt(bound)].defaultBlockState();
    }
    return original;
  }

}
