package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.floating_fish;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.fish.AbstractFish;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity {

  public LivingEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @ModifyReturnValue(method = "getEffectiveGravity", at = @At("TAIL"))
  private double modifyEffectiveGravity(double original) {
    //noinspection ConstantValue
    if (Config.FLOATING_FISH.get() && this.level() instanceof ServerLevel && (LivingEntity)(Entity)this instanceof AbstractFish) return 0d;
    return original;
  }

}
