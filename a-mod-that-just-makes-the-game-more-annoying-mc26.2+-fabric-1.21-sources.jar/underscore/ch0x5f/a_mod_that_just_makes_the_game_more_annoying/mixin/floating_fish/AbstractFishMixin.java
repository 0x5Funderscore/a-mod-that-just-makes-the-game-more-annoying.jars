package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.floating_fish;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.fish.AbstractFish;
import net.minecraft.world.entity.animal.fish.WaterAnimal;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.PathType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFish.class)
public abstract class AbstractFishMixin extends WaterAnimal {

  protected AbstractFishMixin(EntityType<? extends WaterAnimal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "<init>", at = @At("TAIL"))
  private void postInit(EntityType<?> type, Level level, CallbackInfo ci) {
    if (Config.FLOATING_FISH.get()) {
      this.setPathfindingMalus(PathType.WATER, PathType.OPEN.getMalus());
      this.setPathfindingMalus(PathType.WATER_BORDER, PathType.OPEN.getMalus());
    }
  }

  @ModifyExpressionValue(method = "aiStep", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/animal/fish/AbstractFish;isInWater()Z"))
  private boolean replaceIsInWater(boolean original) {
    if (Config.FLOATING_FISH.get()) return true;
    return original;
  }

}
