package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.floating_fish;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.behavior.BehaviorUtils;
import net.minecraft.world.entity.animal.fish.AbstractFish;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BehaviorUtils.class)
public abstract class BehaviorUtilsMixin {

  @Definition(id = "WATER", field = "Lnet/minecraft/world/level/pathfinder/PathComputationType;WATER:Lnet/minecraft/world/level/pathfinder/PathComputationType;")
  @Definition(id = "isPathfindable", method = "Lnet/minecraft/world/level/block/state/BlockState;isPathfindable(Lnet/minecraft/world/level/pathfinder/PathComputationType;)Z")
  @Expression("?.isPathfindable(WATER)")
  @WrapOperation(method = "getRandomSwimmablePos", at = @At("MIXINEXTRAS:EXPRESSION"))
  private static boolean wrapIsPathfindable(
      BlockState instance, PathComputationType pathComputationType,
      Operation<Boolean> original,
      @Local(name = "body", argsOnly = true) PathfinderMob body
  ) {
    if (Config.FLOATING_FISH.get() && body instanceof AbstractFish) return original.call(instance, pathComputationType) || original.call(instance, PathComputationType.AIR);
    return original.call(instance, pathComputationType);
  }

}
