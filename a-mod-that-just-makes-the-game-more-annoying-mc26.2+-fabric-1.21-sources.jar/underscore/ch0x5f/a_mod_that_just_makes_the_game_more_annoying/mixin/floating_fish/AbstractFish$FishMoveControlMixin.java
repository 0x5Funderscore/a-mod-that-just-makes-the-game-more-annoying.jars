package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.floating_fish;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.world.entity.animal.fish.AbstractFish;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFish.FishMoveControl.class)
public abstract class AbstractFish$FishMoveControlMixin {

  @ModifyExpressionValue(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/animal/fish/AbstractFish;isEyeInFluid(Lnet/minecraft/tags/TagKey;)Z"))
  private boolean modifyEyeInFluid(boolean original) {
    if (Config.FLOATING_FISH.get()) return true;
    return original;
  }

}
