package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fast_warden;

import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.warden.Warden;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Warden.class)
public abstract class WardenMixin {

  @Inject(method = "createAttributes", at = @At("TAIL"))
  private static void modifyCreatedAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (Config.FAST_WARDEN.get()) cir.getReturnValue()
        .add(Attributes.MOVEMENT_SPEED, 3.0f);
  }

}
