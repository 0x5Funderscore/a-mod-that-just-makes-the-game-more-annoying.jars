package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.damaged_chest_loot;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.Container;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(RandomizableContainer.class)
public interface RandomizableContainerMixin extends Container {

  @Inject(method = "unpackLootTable", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/storage/loot/LootTable;fill(Lnet/minecraft/world/Container;Lnet/minecraft/world/level/storage/loot/LootParams;J)V", shift = At.Shift.AFTER))
  private void afterLootTableFilled(Player player, CallbackInfo ci) {
    if (Config.DAMAGED_CHEST_LOOT.get()) {
      this.forEach(itemStack -> {
        if (itemStack.has(DataComponents.DAMAGE) && itemStack.has(DataComponents.MAX_DAMAGE)) {
          itemStack.setDamageValue(itemStack.getMaxDamage() - 2);
        }
      });
    }
  }

}
