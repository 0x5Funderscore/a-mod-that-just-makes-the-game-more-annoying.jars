package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.hot_item_fire;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageSources;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InsideBlockEffectApplier;
import net.minecraft.world.entity.InsideBlockEffectType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CTags;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Entity.class)
public abstract class EntityMixin {

  @Shadow
  @Final
  private InsideBlockEffectApplier.StepBasedCollector insideEffectCollector;

  @Shadow
  private Level level;

  @Shadow
  public abstract DamageSources damageSources();

  @Shadow
  public abstract boolean hurtServer(ServerLevel level, DamageSource source, float damage);

  @Unique
  private boolean rb$isHot(ItemStack itemStack) {
    Registry<Enchantment> enchantmentRegistry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
    return (
        itemStack.is(CTags.Items.Buckets.lava) ||
        itemStack.is(CTags.Items.Rods.blaze) ||
        itemStack.is(Items.FIRE_CHARGE) ||
        itemStack.is(Items.BLAZE_POWDER) ||
        itemStack.is(Items.BLAZE_ROD) ||
        itemStack.is(Items.MAGMA_BLOCK) ||
        itemStack.is(Items.MAGMA_CREAM) ||
        itemStack.is(Items.CAMPFIRE) ||
        itemStack.is(Items.SOUL_CAMPFIRE) ||
        itemStack.isEnchanted() && (
            itemStack.getEnchantments().getLevel(enchantmentRegistry.getOrThrow(Enchantments.FIRE_ASPECT)) > 0 ||
            itemStack.getEnchantments().getLevel(enchantmentRegistry.getOrThrow(Enchantments.FLAME)) > 0
        )
    );
  }

  @Inject(method = "applyEffectsFromBlocks(Ljava/util/List;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;checkInsideBlocks(Ljava/util/List;Lnet/minecraft/world/entity/InsideBlockEffectApplier$StepBasedCollector;)V", shift = At.Shift.AFTER))
  private void postTick(CallbackInfo ci) {
    //noinspection ConstantValue
    if (Config.HOT_ITEM_FIRE.get() && (Entity)(Object)this instanceof ServerPlayer serverPlayer && !serverPlayer.isSpectator()) {
      if (rb$isHot(serverPlayer.getMainHandItem()) || rb$isHot(serverPlayer.getOffhandItem())) {
        this.insideEffectCollector.apply(InsideBlockEffectType.CLEAR_FREEZE);
        this.insideEffectCollector.apply(InsideBlockEffectType.FIRE_IGNITE);
        this.hurtServer(serverPlayer.level(), this.damageSources().onFire(), 1.0f);
      }
    }
  }

}
