package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.furnace_exponential_progress;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.inventory.AbstractFurnaceMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceMenu.class)
public abstract class AbstractFurnaceMenuMixin {
  @ModifyReturnValue(method = "getBurnProgress", at = @At("TAIL"))
  private float modifyBurnProgress(float original) {
    if (!Config.FURNACE_EXPONENTIAL_PROGRESS.get()) return original;
    return Math.clamp(1f - (float)Math.pow(5f, -original), 0f, 1f);
  }
}
