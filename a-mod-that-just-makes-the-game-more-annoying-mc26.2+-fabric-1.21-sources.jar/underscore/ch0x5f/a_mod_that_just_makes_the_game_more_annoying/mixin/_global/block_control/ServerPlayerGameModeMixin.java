package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin._global.block_control;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.block_control.IServerLevelBlockControlExtension;


@Mixin(ServerPlayerGameMode.class)
public abstract class ServerPlayerGameModeMixin {

  @Shadow
  protected ServerLevel level;

  @Inject(method = "destroyBlock", at = @At("HEAD"), cancellable = true)
  private void preDestroyBlock(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
    IServerLevelBlockControlExtension blockControl = (IServerLevelBlockControlExtension)this.level;
    if (blockControl.getUnbreakableRegions(new BoundingBox(pos)).findAny().isPresent()) {
      cir.setReturnValue(false);
      cir.cancel();
    }
  }

}
