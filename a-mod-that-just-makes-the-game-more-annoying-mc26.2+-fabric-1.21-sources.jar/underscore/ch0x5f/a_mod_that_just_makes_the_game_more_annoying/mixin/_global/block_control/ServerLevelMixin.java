package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin._global.block_control;

import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.storage.WritableLevelData;
import org.spongepowered.asm.mixin.*;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.block_control.IServerLevelBlockControlExtension;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.block_control.UnbreakableRegion;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;


@Mixin(ServerLevel.class)
@Implements(@Interface(iface = IServerLevelBlockControlExtension.class, prefix = "bc$"))
public abstract class ServerLevelMixin extends Level implements IServerLevelBlockControlExtension {

  protected ServerLevelMixin(WritableLevelData levelData, ResourceKey<Level> dimension, RegistryAccess registryAccess, Holder<DimensionType> dimensionTypeRegistration, boolean isClientSide, boolean isDebug, long biomeZoomSeed, int maxChainedNeighborUpdates) {
    super(levelData, dimension, registryAccess, dimensionTypeRegistration, isClientSide, isDebug, biomeZoomSeed, maxChainedNeighborUpdates);
  }

  @Unique
  private final Set<UnbreakableRegion> rb$unbreakableRegions = new HashSet<>();

  public void bc$addUnbreakableRegion(UnbreakableRegion region) {
    rb$unbreakableRegions.add(region);
  }
  public void bc$removeUnbreakableRegion(UnbreakableRegion region) {
    rb$unbreakableRegions.remove(region);
  }
  public Stream<UnbreakableRegion> bc$getUnbreakableRegions() {
    return rb$unbreakableRegions.stream();
  }

}
