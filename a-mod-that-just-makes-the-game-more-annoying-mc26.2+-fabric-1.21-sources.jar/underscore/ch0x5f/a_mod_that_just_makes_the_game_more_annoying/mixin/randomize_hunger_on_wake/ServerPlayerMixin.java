package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.randomize_hunger_on_wake;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "stopSleepInBed", at = @At("TAIL"))
  private void afterWake(boolean forcefulWakeUp, boolean updateLevelList, CallbackInfo ci) {
    if (Config.RANDOMIZE_HUNGER_ON_WAKE.get()) {
      this.foodData.setFoodLevel((int)(this.foodData.getFoodLevel() * Math.random()));
    }
  }

}
