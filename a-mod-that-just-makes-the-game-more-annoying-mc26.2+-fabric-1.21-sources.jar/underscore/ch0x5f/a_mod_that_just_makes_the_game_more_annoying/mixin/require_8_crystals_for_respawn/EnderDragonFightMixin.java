package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.require_8_crystals_for_respawn;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.level.dimension.end.EnderDragonFight;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;


@Mixin(EnderDragonFight.class)
public abstract class EnderDragonFightMixin {

  @WrapOperation(
      method = "tryRespawn",
      at = @At(
          value = "INVOKE",
          target = "Ljava/util/List;isEmpty()Z"
      )
  )
  private boolean replaceIsEmpty(List<EndCrystal> instance, Operation<Boolean> original) {
    if (original.call(instance)) return true;
    return !Config.REQUIRE_8_CRYSTALS_FOR_RESPAWN.get() || instance.size() < 2;
  }

}
