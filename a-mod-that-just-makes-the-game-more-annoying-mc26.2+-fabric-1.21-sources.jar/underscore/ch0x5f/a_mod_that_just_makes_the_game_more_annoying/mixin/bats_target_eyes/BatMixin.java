package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.bats_target_eyes;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ambient.AmbientCreature;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Optional;


@Mixin(Bat.class)
public abstract class BatMixin extends AmbientCreature {

  @Unique
  private @Nullable Vec3 rb$trackPlayerEye;

  protected BatMixin(EntityType<? extends AmbientCreature> type, Level level) {
    super(type, level);
  }

  @Definition(id = "targetPosition", field = "Lnet/minecraft/world/entity/ambient/Bat;targetPosition:Lnet/minecraft/core/BlockPos;")
  @Definition(id = "getX", method = "Lnet/minecraft/core/BlockPos;getX()I")
  @Expression("(double)this.targetPosition.getX()")
  @ModifyExpressionValue(method = "customServerAiStep", at = @At("MIXINEXTRAS:EXPRESSION"))
  private double changeX(double original) {
    if (Config.BATS_TARGET_EYES.get() && this.rb$trackPlayerEye != null) {
      return this.rb$trackPlayerEye.x - 0.5d;
    }
    return original;
  }

  @Definition(id = "targetPosition", field = "Lnet/minecraft/world/entity/ambient/Bat;targetPosition:Lnet/minecraft/core/BlockPos;")
  @Definition(id = "getY", method = "Lnet/minecraft/core/BlockPos;getY()I")
  @Expression("(double)this.targetPosition.getY()")
  @ModifyExpressionValue(method = "customServerAiStep", at = @At("MIXINEXTRAS:EXPRESSION"))
  private double changeY(double original) {
    if (Config.BATS_TARGET_EYES.get() && this.rb$trackPlayerEye != null) {
      return this.rb$trackPlayerEye.y - 0.5d;
    }
    return original;
  }

  @Definition(id = "targetPosition", field = "Lnet/minecraft/world/entity/ambient/Bat;targetPosition:Lnet/minecraft/core/BlockPos;")
  @Definition(id = "getZ", method = "Lnet/minecraft/core/BlockPos;getZ()I")
  @Expression("(double)this.targetPosition.getZ()")
  @ModifyExpressionValue(method = "customServerAiStep", at = @At("MIXINEXTRAS:EXPRESSION"))
  private double changeZ(double original) {
    if (Config.BATS_TARGET_EYES.get() && this.rb$trackPlayerEye != null) {
      return this.rb$trackPlayerEye.z - 0.5d;
    }
    return original;
  }

  @Definition(id = "targetPosition", field = "Lnet/minecraft/world/entity/ambient/Bat;targetPosition:Lnet/minecraft/core/BlockPos;")
  @Expression("this.targetPosition == null")
  @WrapOperation(method = "customServerAiStep", at = @At("MIXINEXTRAS:EXPRESSION"))
  private boolean alwaysAllowChangeTargetPosition(
      Object left, Object right, Operation<Boolean> original,
      @Local(name = "level", argsOnly = true) ServerLevel level
  ) {
    if (Config.BATS_TARGET_EYES.get()) {
      this.rb$trackPlayerEye = Optional.ofNullable(level.getNearestPlayer(this, 25d)).map(Entity::getEyePosition).map(vec3 -> vec3.offsetRandom(this.random, 0.4f)).orElse(null);
    }
    return original.call(left, right);
  }

}
