package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_end_soul_sand_and_basalt_deltas;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.QuartPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.biome.TheEndBiomeSource;
import net.minecraft.world.level.levelgen.DensityFunction;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(TheEndBiomeSource.class)
public abstract class TheEndBiomeSourceMixin {

  /*
  @Unique private static Holder<Biome> rb$basaltDeltas;
  @Unique private static Holder<Biome> rb$soulSandValley;

  @Shadow
  @Final
  private Holder<Biome> highlands;

  @Shadow
  @Final
  private Holder<Biome> midlands;

  @Inject(method = "create", at = @At("TAIL"))
  private static void postCreate(HolderGetter<Biome> biomes, CallbackInfoReturnable<TheEndBiomeSource> cir) {
    rb$basaltDeltas = biomes.getOrThrow(Biomes.BASALT_DELTAS);
    rb$soulSandValley = biomes.getOrThrow(Biomes.SOUL_SAND_VALLEY);
  }

  @ModifyReturnValue(method = "getNoiseBiome", at = @At("RETURN"))
  private Holder<Biome> modifyNoiseBiome(
      Holder<Biome> original,
      @Local(name = "quartX", argsOnly = true) int quartX,
      @Local(name = "quartY", argsOnly = true) int quartY,
      @Local(name = "quartZ", argsOnly = true) int quartZ,
      @Local(name = "sampler", argsOnly = true) Climate.Sampler sampler
  ) {
    if (Config.END_SOUL_SAND_AND_BASALT_DELTAS.get() && (original == this.highlands || original == this.midlands)) {
      int blockX = QuartPos.toBlock(quartX);
      int blockY = QuartPos.toBlock(quartY);
      int blockZ = QuartPos.toBlock(quartZ);
      int weirdBlockX = SectionPos.blockToSectionCoord(blockX) * 36;
      int weirdBlockZ = SectionPos.blockToSectionCoord(blockZ) * 36;
      double heightValue = sampler.erosion().compute(new DensityFunction.SinglePointContext(weirdBlockX, blockY, weirdBlockZ));
      if (heightValue >= 0.25f) return rb$basaltDeltas;
      if (heightValue <= 0.25f) return rb$soulSandValley;
    }
    return original;
  }
  */

}
