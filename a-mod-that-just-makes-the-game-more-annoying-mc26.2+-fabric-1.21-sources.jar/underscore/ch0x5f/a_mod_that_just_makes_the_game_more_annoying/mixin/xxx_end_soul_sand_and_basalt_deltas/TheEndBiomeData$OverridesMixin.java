package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_end_soul_sand_and_basalt_deltas;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.fabric.impl.biome.TheEndBiomeData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(TheEndBiomeData.Overrides.class)
public class TheEndBiomeData$OverridesMixin {

  /*
  @ModifyExpressionValue(
      method = "pick(IIILnet/minecraft/world/level/biome/Climate$Sampler;Lnet/minecraft/core/Holder;)Lnet/minecraft/core/Holder;",
      at = @At(
          value = "INVOKE",
          target = "Ljava/util/Map;containsKey(Ljava/lang/Object;)Z"
      )
  )
  private boolean modifyContainsKey(boolean original) {
    if (Config.END_SOUL_SAND_AND_BASALT_DELTAS.get()) return true;
    return original;
  }
  */

}
