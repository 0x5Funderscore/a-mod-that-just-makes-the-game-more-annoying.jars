package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.furnace_cooking_time_x5;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  @ModifyReturnValue(method = "getTotalCookTime", at = @At("TAIL"))
  private static int modifyTotalCookTime(int original) {
    if (Config.FURNACE_COOKING_TIME_X5.get()) return original * 5;// && original == 200
    return original;
  }

}
