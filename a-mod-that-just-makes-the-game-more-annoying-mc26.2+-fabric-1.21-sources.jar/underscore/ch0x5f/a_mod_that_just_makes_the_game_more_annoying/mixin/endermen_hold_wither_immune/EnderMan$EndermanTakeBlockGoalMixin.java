package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.endermen_hold_wither_immune;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.EndermanTakeBlockGoal.class)
public abstract class EnderMan$EndermanTakeBlockGoalMixin extends Goal {

  @Definition(id = "blockState", local = @Local(type = BlockState.class, name = "blockState"))
  @Definition(id = "is", method = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/tags/TagKey;)Z")
  @Definition(id = "ENDERMAN_HOLDABLE", field = "Lnet/minecraft/tags/BlockTags;ENDERMAN_HOLDABLE:Lnet/minecraft/tags/TagKey;")
  @Expression("blockState.is(ENDERMAN_HOLDABLE)")
  @WrapOperation(method = "tick", at = @At("MIXINEXTRAS:EXPRESSION"))
  private boolean modifyBlockStateIsEndermanHoldable(BlockState instance, TagKey<Block> tagKey, Operation<Boolean> original) {
    return original.call(instance, tagKey) || Config.ENDERMEN_HOLD_WITHER_IMMUNE.get() && !instance.isAir() && instance.is(BlockTags.WITHER_IMMUNE);
  }

}
