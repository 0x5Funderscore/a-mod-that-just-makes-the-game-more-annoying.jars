package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.endermen_unaffected_by_water;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.monster.EnderMan;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderMan.class)
public abstract class EnderManMixin {

  @ModifyReturnValue(method = "isSensitiveToWater", at = @At("TAIL"))
  private boolean modifyIsSensitiveToWater(boolean original) {
    if (Config.ENDERMEN_UNAFFECTED_BY_WATER.get()) return false;
    return original;
  }

}
