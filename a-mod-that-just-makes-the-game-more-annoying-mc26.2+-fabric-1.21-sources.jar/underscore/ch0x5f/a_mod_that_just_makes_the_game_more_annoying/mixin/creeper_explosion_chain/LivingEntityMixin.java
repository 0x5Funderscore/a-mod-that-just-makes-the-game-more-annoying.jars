package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.creeper_explosion_chain;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity {

  public LivingEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Inject(method = "hurtServer", at = @At("HEAD"), cancellable = true)
  private void preHurtServer(ServerLevel level, DamageSource source, float damage, CallbackInfoReturnable<Boolean> cir) {
    if (Config.CREEPER_EXPLOSION_CHAIN.get()) {
      if ((Entity)this instanceof Creeper creeper) {
        if (source.is(DamageTypeTags.IS_EXPLOSION)) {
          if (!creeper.isIgnited()) {
            creeper.ignite();
            creeper.swell = creeper.maxSwell - 10 - (int)Math.floor(Math.random() * 20d);
          }
          cir.setReturnValue(false);
          cir.cancel();
        }
      }
    }
  }

}
