package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.lethal_poison;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.effect.PoisonMobEffect;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(PoisonMobEffect.class)
public class PoisonMobEffectMixin {

  @Definition(id = "mob", local = @Local(type = LivingEntity.class, name = "mob", argsOnly = true))
  @Definition(id = "getHealth", method = "Lnet/minecraft/world/entity/LivingEntity;getHealth()F")
  @Expression("mob.getHealth() > ?")
  @ModifyExpressionValue(method = "applyEffectTick", at = @At("MIXINEXTRAS:EXPRESSION"))
  private boolean modifyHealthCheck(boolean original) {
    if (Config.LETHAL_POISON.get()) return true;
    return original;
  }

}
