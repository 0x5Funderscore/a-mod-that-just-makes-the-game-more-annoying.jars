package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.mob_crits;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.network.protocol.game.ClientboundAnimatePacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Mob.class)
public abstract class MobMixin extends LivingEntity {

  protected MobMixin(EntityType<? extends LivingEntity> type, Level level) {
    super(type, level);
  }

  @Unique
  private boolean rb$lastCrit = false;
  @Unique
  private boolean rb$lastAttackMagic = false;

  @Definition(id = "dmg", local = @Local(type = float.class, name = "dmg"))
  @Definition(id = "modifyDamage", method = "Lnet/minecraft/world/item/enchantment/EnchantmentHelper;modifyDamage(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;F)F")
  @Expression("modifyDamage(?, ?, ?, ?, dmg)")
  @WrapOperation(method = "doHurtTarget", at = @At("MIXINEXTRAS:EXPRESSION"))
  private float wrapDamageModification(ServerLevel serverLevel, ItemStack itemStack, Entity victim, DamageSource damageSource, float damage, Operation<Float> original) {
    float modifiedDamage = original.call(serverLevel, itemStack, victim, damageSource, damage);
    rb$lastAttackMagic = Config.MOB_CRITS.get() && modifiedDamage > damage;
    return modifiedDamage;
  }

  @ModifyVariable(method = "doHurtTarget", name = "dmg", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getDeltaMovement()Lnet/minecraft/world/phys/Vec3;"))
  private float modifyDamage(float dmg) {
    rb$lastCrit = false;
    if (Config.MOB_CRITS.get() && Math.random() < 0.2d) {
      rb$lastCrit = true;
      return dmg * 1.5f;
    } else {
      return dmg;
    }
  }

  @Inject(method = "doHurtTarget", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Mob;playAttackSound()V"))
  private void playCritSound(ServerLevel level, Entity target, CallbackInfoReturnable<Boolean> cir) {
    if (Config.MOB_CRITS.get() && this.level() instanceof ServerLevel serverLevel) {
      if (rb$lastCrit) {
        this.playSound(SoundEvents.PLAYER_ATTACK_CRIT);
        serverLevel.getChunkSource().sendToTrackingPlayersAndSelf(this, new ClientboundAnimatePacket(target, 4));
      }
      if (rb$lastAttackMagic) {
        serverLevel.getChunkSource().sendToTrackingPlayersAndSelf(this, new ClientboundAnimatePacket(target, 5));
      }
    }
  }

}
