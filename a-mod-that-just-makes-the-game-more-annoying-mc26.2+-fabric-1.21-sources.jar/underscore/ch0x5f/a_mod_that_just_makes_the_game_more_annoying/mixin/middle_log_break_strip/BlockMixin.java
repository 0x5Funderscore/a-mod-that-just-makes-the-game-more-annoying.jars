package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.middle_log_break_strip;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CTags;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Block.class)
public class BlockMixin {

  @WrapOperation(method = "playerDestroy", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;dropResources(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)V"))
  private void wrapDropResources(BlockState state, Level level, BlockPos pos, BlockEntity blockEntity, Entity breaker, ItemStack tool, Operation<Void> original) {
    if (Config.MIDDLE_LOG_BREAK_STRIP.get() && !level.isClientSide()) {

      if (state.is(BlockTags.LOGS) || state.is(CTags.Blocks.stripped_logs)) {

        Block block = state.getBlock();
        if (AxeItem.STRIPPABLES.containsValue(block) || AxeItem.STRIPPABLES.containsKey(block)) {

          if (state.getValueOrElse(RotatedPillarBlock.AXIS, Direction.Axis.X) == Direction.Axis.Y) {

            @Nullable Block stripped = AxeItem.STRIPPABLES.get(block);

            BlockState aboveState = level.getBlockState(pos.above());
            if (aboveState.getValueOrElse(RotatedPillarBlock.AXIS, Direction.Axis.Y) == Direction.Axis.Y) {
              Block aboveBlock = aboveState.getBlock();
              @Nullable Block aboveStripped = AxeItem.STRIPPABLES.get(aboveBlock);

              if (aboveBlock == block || aboveBlock == stripped || aboveStripped == block) {
                if (stripped == null) stripped = block;
                else level.playSound(null, pos, SoundEvents.AXE_STRIP, SoundSource.BLOCKS, 1.0f, 1.0f);
                level.setBlockAndUpdate(pos, stripped.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y));
                return;
              }
            }

          }

        }
      }
    }
    original.call(state, level, pos, blockEntity, breaker, tool);
  }

}
