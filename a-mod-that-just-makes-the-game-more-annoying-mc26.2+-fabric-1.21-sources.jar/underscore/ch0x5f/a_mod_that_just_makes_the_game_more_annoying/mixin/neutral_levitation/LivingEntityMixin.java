package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.neutral_levitation;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

  @Definition(id = "levitationEffect", local = @Local(type = MobEffectInstance.class, name = "levitationEffect"))
  @Definition(id = "getAmplifier", method = "Lnet/minecraft/world/effect/MobEffectInstance;getAmplifier()I")
  @Expression("levitationEffect.getAmplifier()")
  @ModifyExpressionValue(method = "travelInAir", at = @At("MIXINEXTRAS:EXPRESSION"))
  private int changeLevitationAmplifier(int original) {
    if (Config.NEUTRAL_LEVITATION.get()) return -1;
    return original;
  }

}
