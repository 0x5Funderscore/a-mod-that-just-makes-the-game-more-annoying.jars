package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.bees_sting_endlessly;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.animal.bee.Bee;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Bee.class)
public abstract class BeeMixin {
  @Shadow
  protected abstract void setHasStung(boolean hasStung);

  @Inject(method = "setHasStung", at = @At("HEAD"), cancellable = true)
  private void setHasStungHEAD(boolean hasStung, CallbackInfo ci) {
    if (!Config.BEES_STING_ENDLESSLY.get()) return;
    if (hasStung) {
      ci.cancel();
      this.setHasStung(false);
    }
  }

  @WrapOperation(method = "doHurtTarget", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/animal/bee/Bee;stopBeingAngry()V"))
  private void redirectStopBeingAngry(Bee instance, Operation<Void> original) {
    if (!Config.BEES_STING_ENDLESSLY.get()) original.call(instance);
  }
}
