package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_more_witch_spawns;

import net.minecraft.world.level.biome.MobSpawnSettings;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(MobSpawnSettings.class)
public abstract class MobSpawnSettingsMixin {

  /*
  @Mutable
  @Shadow
  @Final
  private Map<MobCategory,WeightedList<MobSpawnSettings.SpawnerData>> spawners;

  @Shadow
  @Final
  private static Logger LOGGER;

  @Inject(method = "getMobs", at = @At("HEAD"))
  private void preGetMobs(MobCategory category, CallbackInfoReturnable<WeightedList<MobSpawnSettings.SpawnerData>> cir) {
    if (this.spawners instanceof ImmutableMap<MobCategory,WeightedList<MobSpawnSettings.SpawnerData>>) {
      if (Config.MORE_WITCH_SPAWNS.get()) {
        LOGGER.info("change mob spawn settings");
        this.spawners = new HashMap<>(this.spawners);
        this.spawners.computeIfPresent(MobCategory.MONSTER, (mobCategory, spawnerDataWeightedList) -> {
          for (Weighted<MobSpawnSettings.SpawnerData> item: spawnerDataWeightedList.unwrap()) {
            if (item.value().type() == EntityTypes.WITCH) {
              item.weight *= 40;
            }
          }
          return spawnerDataWeightedList;
        });
      }
    }
  }
   */

}
