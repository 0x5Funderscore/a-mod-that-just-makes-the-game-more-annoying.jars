package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.holding_lava_hurts;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CTags;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract boolean hurtServer(ServerLevel level, DamageSource source, float damage);

  @Shadow
  public abstract ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Unique
  private static boolean rb$isLava(ItemStack itemStack) {
    return itemStack.is(CTags.Items.Buckets.lava);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void tickExtra(CallbackInfo ci) {
    if (Config.HOLDING_LAVA_HURTS.get()) {
      if (rb$isLava(this.getMainHandItem()) || rb$isLava(this.getOffhandItem())) {
        this.hurtServer(this.level(), this.level().damageSources().onFire(), 1.0f);
      }
    }
  }

}
