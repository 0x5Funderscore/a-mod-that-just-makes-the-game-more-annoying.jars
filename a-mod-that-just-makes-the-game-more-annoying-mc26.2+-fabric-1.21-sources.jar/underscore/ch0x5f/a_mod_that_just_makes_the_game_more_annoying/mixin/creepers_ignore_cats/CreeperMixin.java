package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.creepers_ignore_cats;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.monster.Creeper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Creeper.class)
public abstract class CreeperMixin {

  @Definition(id = "goalSelector", field = "Lnet/minecraft/world/entity/monster/Creeper;goalSelector:Lnet/minecraft/world/entity/ai/goal/GoalSelector;")
  @Definition(id = "addGoal", method = "Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V")
  @Definition(id = "AvoidEntityGoal", type = AvoidEntityGoal.class)
  @Expression("this.goalSelector.addGoal(?, new AvoidEntityGoal(?, ?, ?, ?, ?))")
  @WrapOperation(method = "registerGoals", at = @At("MIXINEXTRAS:EXPRESSION"))
  private void redirectAddGoal(GoalSelector instance, int prio, Goal goal, Operation<Void> original) {
    if (!Config.CREEPERS_IGNORE_CATS.get()) original.call(instance, prio, goal);
  }

}
