package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.super_bouncy;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.level.block.Block;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Block.class)
public abstract class BlockMixin {

  @ModifyReturnValue(method = "getBounceRestitution", at = @At("TAIL"))
  private float replaceBounceRestitution(float original) {
    if (Config.SUPER_BOUNCY.get()) return original * 10f;
    return original;
  }

}
