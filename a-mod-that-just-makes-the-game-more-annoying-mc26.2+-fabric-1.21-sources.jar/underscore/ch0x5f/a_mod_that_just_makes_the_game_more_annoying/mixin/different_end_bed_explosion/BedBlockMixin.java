package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.different_end_bed_explosion;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.projectile.hurtingprojectile.DragonFireball;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BedBlock.class)
public abstract class BedBlockMixin {

  @WrapOperation(
      method = "useWithoutItem",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/level/Level;explode(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;Lnet/minecraft/world/level/ExplosionDamageCalculator;Lnet/minecraft/world/phys/Vec3;FZLnet/minecraft/world/level/Level$ExplosionInteraction;)V"
      )
  )
  private void redirectExplode(
      Level instance,
      Entity source, DamageSource damageSource, ExplosionDamageCalculator damageCalculator, Vec3 boomPos, float r, boolean fire, Level.ExplosionInteraction blockInteraction,
      Operation<Void> original
  ) {
    if (Config.DIFFERENT_END_BED_EXPLOSION.get() && instance.dimension() == Level.END) {
      DragonFireball temporaryFireball = new DragonFireball(EntityTypes.DRAGON_FIREBALL, instance);
      temporaryFireball.setPos(boomPos);
      temporaryFireball.onHit(new BedExplodeHitResult(boomPos));
    } else {
      original.call(instance, source, damageSource, damageCalculator, boomPos, r, fire, blockInteraction);
    }
  }

  private static class BedExplodeHitResult extends BlockHitResult {
    protected BedExplodeHitResult(Vec3 location) {
      super(location, Direction.DOWN, BlockPos.containing(location), true);
    }

    @Override
    public @NonNull Type getType() {
      return Type.BLOCK;
    }
  }
}
