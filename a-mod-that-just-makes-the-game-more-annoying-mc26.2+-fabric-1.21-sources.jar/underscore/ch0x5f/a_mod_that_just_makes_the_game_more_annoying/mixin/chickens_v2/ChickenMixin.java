package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.chickens_v2;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Chicken.class)
public abstract class ChickenMixin extends Animal {

  protected ChickenMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "registerGoals", at = @At("TAIL"))
  private void postRegisterGoals(CallbackInfo ci) {
    if (Config.CHICKENS_V2.get()) {
      TargetingConditions.Selector selector = (target, level) -> !target.isSpectator() && !target.hasInfiniteMaterials() && target.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);
      this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
      this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true, selector));
      this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 2.0d, true));
    }
  }

  @Inject(method = "createAttributes", at = @At("TAIL"))
  private static void modifyCreatedAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (Config.CHICKENS_V2.get()) cir.getReturnValue()
        .add(Attributes.ATTACK_DAMAGE, 8.0f)
        .add(Attributes.ATTACK_KNOCKBACK, 2.0f)
        .add(Attributes.MAX_HEALTH, 20.0f);
  }

}
