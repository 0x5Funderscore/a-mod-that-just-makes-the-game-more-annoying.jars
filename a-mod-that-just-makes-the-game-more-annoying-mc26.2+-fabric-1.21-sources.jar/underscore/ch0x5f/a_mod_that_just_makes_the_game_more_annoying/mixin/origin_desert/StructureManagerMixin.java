package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.origin_desert;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.chunk.StructureAccess;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(StructureManager.class)
public abstract class StructureManagerMixin {

  @ModifyReturnValue(method = "getStartForStructure", at = @At("TAIL"))
  private StructureStart editStartForStructure(
      StructureStart original,
      @Local(name = "pos", argsOnly = true) SectionPos pos
  ) {
    if (Config.ORIGIN_DESERT.get() && original != StructureStart.INVALID_START) {
      BlockPos center = pos.center();
      long x = center.getX();
      long z = center.getZ();
      if (x * x + z * z < 250000L) {
        return StructureStart.INVALID_START;
      }
    }
    return original;
  }

}
