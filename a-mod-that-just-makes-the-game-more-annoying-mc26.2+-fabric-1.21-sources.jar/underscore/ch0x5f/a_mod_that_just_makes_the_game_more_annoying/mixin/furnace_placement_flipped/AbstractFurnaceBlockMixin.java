package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.furnace_placement_flipped;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlock.class)
public abstract class AbstractFurnaceBlockMixin {

  @ModifyReturnValue(method = "getStateForPlacement", at = @At("TAIL"))
  private BlockState modifyPlacementState(
      BlockState original,
      @Local(name = "context", argsOnly = true) BlockPlaceContext context
  ) {
    if (Config.FURNACE_PLACEMENT_FLIPPED.get() && !context.getLevel().isClientSide() && Math.random() < 0.5d) {
      return original.setValue(AbstractFurnaceBlock.FACING, original.getValue(AbstractFurnaceBlock.FACING).getOpposite());
    }
    return original;
  }

}
