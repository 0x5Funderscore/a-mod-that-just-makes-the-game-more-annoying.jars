package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.flying_squids;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.squid.Squid;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity {

  public LivingEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @ModifyReturnValue(method = "shouldTakeDrowningDamage", at = @At("TAIL"))
  private boolean modifyShouldTakeDrowningDamage(boolean original) {
    //noinspection ConstantValue
    if (Config.FLYING_SQUIDS.get() && (LivingEntity)(Entity)this instanceof Squid) return false;
    return original;
  }

}
