package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.mob_stacks;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Mob.class)
public abstract class MobMixin extends LivingEntity {

  protected MobMixin(EntityType<? extends LivingEntity> type, Level level) {
    super(type, level);
  }

  @Inject(method = "finalizeSpawn", at = @At("TAIL"))
  private void postFinalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, EntitySpawnReason spawnReason, SpawnGroupData groupData, CallbackInfoReturnable<SpawnGroupData> cir) {

    if (Config.MOB_STACKS.get()) {
      if ((this.is(EntityTypes.ZOMBIE) || this.is(EntityTypes.ZOMBIE_VILLAGER) || this.is(EntityTypes.ZOMBIFIED_PIGLIN)) && !this.isPassenger() && !this.isVehicle() && Math.random() < 0.005d) {

        Vec3 position = this.position();

        @SuppressWarnings("unchecked") EntityType<? extends Mob> type = (EntityType<? extends Mob>)this.getType();

        Chicken chicken = EntityTypes.CHICKEN.create(this.level(), EntitySpawnReason.NATURAL);
        if (chicken != null) {
          level.addFreshEntity(chicken);

          Mob stackBottom = null;
          for (int i = 0; i < 6; i++) {
            Mob stackItem = type.create(this.level(), EntitySpawnReason.NATURAL);
            if (stackItem == null) break;
            level.addFreshEntity(stackItem);
            stackItem.setBaby(true);
            stackItem.setPos(position);
            stackItem.rotate(Rotation.getRandom(this.random));
            if (stackBottom != null) stackBottom.startRiding(stackItem);
            stackBottom = stackItem;
          }

          chicken.setPos(position);
          chicken.rotate(Rotation.getRandom(this.random));
          chicken.setBaby(false);
          if (stackBottom != null) stackBottom.startRiding(chicken);

        }
      }
    }
  }

}
