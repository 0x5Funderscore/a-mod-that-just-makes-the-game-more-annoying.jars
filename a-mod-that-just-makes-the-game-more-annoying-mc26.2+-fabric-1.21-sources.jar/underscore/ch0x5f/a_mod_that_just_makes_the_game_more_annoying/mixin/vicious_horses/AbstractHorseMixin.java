package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.vicious_horses;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RunAroundLikeCrazyGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.entity.animal.golem.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractHorse.class)
public abstract class AbstractHorseMixin extends Animal {
  protected AbstractHorseMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Definition(id = "goalSelector", field = "Lnet/minecraft/world/entity/animal/equine/AbstractHorse;goalSelector:Lnet/minecraft/world/entity/ai/goal/GoalSelector;")
  @Definition(id = "addGoal", method = "Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V")
  @Definition(id = "RunAroundLikeCrazyGoal", type = RunAroundLikeCrazyGoal.class)
  @Expression("this.goalSelector.addGoal(?, new RunAroundLikeCrazyGoal(?, ?))")
  @WrapOperation(method = "registerGoals", at = @At("MIXINEXTRAS:EXPRESSION"))
  private void changeRunAroundGoal(GoalSelector instance, int prio, Goal goal, Operation<Void> original) {
    if (Config.VICIOUS_HORSES.get()) {
      this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
      this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
      this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
      original.call(instance, prio, new MeleeAttackGoal(this, 2.0d, true));
      return;
    }
    original.call(instance, prio, goal);
  }

  @Inject(method = "createBaseHorseAttributes", at = @At("TAIL"))
  private static void modifyHorseAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (Config.VICIOUS_HORSES.get()) cir.getReturnValue()
        .add(Attributes.ATTACK_DAMAGE, 5.0f)
        .add(Attributes.ATTACK_KNOCKBACK, 2.0f);
  }

}
