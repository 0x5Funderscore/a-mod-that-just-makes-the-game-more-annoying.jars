package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.short_enderman_hitbox;

import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EntityType.class)
public abstract class EntityTypeMixin {

  @Mutable
  @Shadow
  @Final
  private EntityDimensions dimensions;

  @Unique
  private void rb$fixDimensions() {
    if (Config.SHORT_ENDERMAN_HITBOX.get()) {
      //noinspection RedundantCast
      if (((EntityType<?>)(Object)this).equals(EntityTypes.ENDERMAN)) {
        if (this.dimensions.height() > 2.0f) {
          this.dimensions = new EntityDimensions(this.dimensions.width(), 1.8f, 1.8f, this.dimensions.attachments(), this.dimensions.fixed());
        }
      }
    }
  }

  @Inject(method = "getDimensions", at = @At("HEAD"))
  private void preGetDimensions(CallbackInfoReturnable<EntityDimensions> cir) {
    rb$fixDimensions();
  }

  @Inject(method = "getWidth", at = @At("HEAD"))
  private void preGetWidth(CallbackInfoReturnable<Float> cir) {
    rb$fixDimensions();
  }

  @Inject(method = "getHeight", at = @At("HEAD"))
  private void preGetHeight(CallbackInfoReturnable<Float> cir) {
    rb$fixDimensions();
  }

}
