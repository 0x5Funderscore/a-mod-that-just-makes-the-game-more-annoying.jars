package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.furnace_output_singleton;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  @Definition(id = "resultCount", local = @Local(type = int.class, name = "resultCount"))
  @Definition(id = "maxResultCount", local = @Local(type = int.class, name = "maxResultCount"))
  @Expression("resultCount <= maxResultCount")
  @ModifyExpressionValue(method = "canBurn", at = @At("MIXINEXTRAS:EXPRESSION"))
  private static boolean modifyCanBurnResultCheck(boolean original) {
    if (Config.FURNACE_OUTPUT_SINGLETON.get()) return false;
    return original;
  }

}
