package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.rain_silverfish;

import com.google.common.base.Predicates;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.monster.Silverfish;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.level.storage.WritableLevelData;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CounterList;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;


@Mixin(ServerLevel.class)
public abstract class ServerLevelMixin extends Level {

  @Shadow
  public abstract boolean addFreshEntity(@NonNull Entity entity);

  protected ServerLevelMixin(WritableLevelData levelData, ResourceKey<Level> dimension, RegistryAccess registryAccess, Holder<DimensionType> dimensionTypeRegistration, boolean isClientSide, boolean isDebug, long biomeZoomSeed, int maxChainedNeighborUpdates) {
    super(levelData, dimension, registryAccess, dimensionTypeRegistration, isClientSide, isDebug, biomeZoomSeed, maxChainedNeighborUpdates);
  }

  @ModifyExpressionValue(method = "tickPrecipitation", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;isRaining()Z", ordinal = 0))
  private boolean passthruIsRaining(
      boolean isRaining,
      @Local(name = "topPos") BlockPos topPos
  ) {
    if (isRaining && Config.RAIN_SILVERFISH.get() && Math.random() < 0.2d) {

      List<Silverfish> output = new CounterList<>();
      this.getEntities(EntityTypeTest.forExactClass(Silverfish.class), AABB.encapsulatingFullBlocks(topPos, topPos).inflate(7.5d), Predicates.alwaysTrue(), output, 4);
      if (output.size() < 4) {

        Player nearestPlayer = this.getNearestPlayer(topPos.getX() + 0.5, topPos.getY(), topPos.getZ() + 0.5, 48d, (entity) -> entity instanceof Player && !entity.isSpectator());
        if (nearestPlayer != null && nearestPlayer.distanceToSqr(topPos.getX() + 0.5, topPos.getY(), topPos.getZ() + 0.5) > 24d * 24d) {

          Silverfish silverfish = EntityTypes.SILVERFISH.create((ServerLevel)(Object)this, EntitySpawnReason.NATURAL);
          if (silverfish != null) {
            silverfish.setPos(Vec3.atBottomCenterOf(topPos));
            silverfish.rotate(Rotation.getRandom(this.getRandom()));
            this.addFreshEntity(silverfish);
          }

        }

      }
    }
    return isRaining;
  }

}
