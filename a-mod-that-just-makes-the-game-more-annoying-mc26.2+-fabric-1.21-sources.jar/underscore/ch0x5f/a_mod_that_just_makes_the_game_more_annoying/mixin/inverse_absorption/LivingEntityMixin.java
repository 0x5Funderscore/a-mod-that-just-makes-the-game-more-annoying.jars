package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.inverse_absorption;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity {

  @Shadow
  public abstract void setHealth(float health);

  @Shadow
  public abstract float getHealth();

  @Shadow
  public abstract double getAttributeValue(Holder<Attribute> attribute);

  public LivingEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @ModifyExpressionValue(method = "getMaxHealth", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getAttributeValue(Lnet/minecraft/core/Holder;)D"))
  private double modifyMaxHealthAttribute(double original) {
    if (!Config.INVERSE_ABSORPTION.get() || !this.is(EntityTypes.PLAYER)) return original;
    return Math.max(1.0f, original - this.getAttributeValue(Attributes.MAX_ABSORPTION));
  }

  @Inject(method = "setAbsorptionAmount", at = @At("HEAD"))
  private void updateHealthOnAbsorptionChange(float absorptionAmount, CallbackInfo ci) {
    if (!Config.INVERSE_ABSORPTION.get() || !this.is(EntityTypes.PLAYER)) return;
    if (absorptionAmount != 0.0f) this.setHealth(this.getHealth());
  }
}
