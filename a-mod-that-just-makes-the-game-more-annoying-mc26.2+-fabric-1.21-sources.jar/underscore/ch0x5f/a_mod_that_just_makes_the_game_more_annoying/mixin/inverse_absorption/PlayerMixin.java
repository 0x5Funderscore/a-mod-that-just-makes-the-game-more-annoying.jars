package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.inverse_absorption;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Player.class)
public abstract class PlayerMixin {

  @ModifyExpressionValue(method = "actuallyHurt", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getAbsorptionAmount()F"))
  private float modifyGetAbsorptionAmount(float original) {
    if (Config.INVERSE_ABSORPTION.get()) return 0f;
    return original;
  }

  @WrapOperation(method = "actuallyHurt", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;setAbsorptionAmount(F)V"))
  private void modifySetAbsorptionAmount(Player instance, float v, Operation<Void> original) {
    if (!Config.INVERSE_ABSORPTION.get()) original.call(instance, v);
  }

}
