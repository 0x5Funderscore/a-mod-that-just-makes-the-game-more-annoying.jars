package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;


import net.minecraft.resources.Identifier;


public final class AMTJMTGMA {
  public static final String MOD_ID = "a_mod_that_just_makes_the_game_more_annoying";

  public static final Identifier FOUND_PORTAL_ROOM_ADVANCEMENT = Identifier.fromNamespaceAndPath(MOD_ID, "stronghold_portal_room");
}
