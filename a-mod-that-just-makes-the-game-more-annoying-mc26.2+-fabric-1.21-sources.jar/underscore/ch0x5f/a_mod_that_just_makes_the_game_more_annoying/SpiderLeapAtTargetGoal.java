package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.phys.Vec3;


public class SpiderLeapAtTargetGoal extends LeapAtTargetGoal {
  public SpiderLeapAtTargetGoal(Mob mob, float yd) {
    super(mob, yd);
  }

  /*

  // lower score is better
  private static double measurePassbyScore(double vx, double vy, double targetX, final double targetVX, final double targetY, final double gravity, int maxTicks) {
    double bestPassbyScore = Double.MAX_VALUE;
    double x = 0.0, y = 0.0;
    for (int i = 0; i < maxTicks; ++i) {
      x += vx;
      y += vy;
      vx *= 0.98;
      vy *= 0.98;
      vy += gravity;
      double score = Math.max(0.25d, Vector2d.distanceSquared(x, y, targetX, targetY)) * (1.0d + 0.001d * i) * (1.0d + 0.7d * vx*vx);
      targetX += targetVX;
      if (score < bestPassbyScore) bestPassbyScore = score;
//      else if (score > bestPassbyScore * 1.5) break;
    }
    return bestPassbyScore;
  }

  private static final double LEARNING_RATE_CHANGED = 0.5d;
  private static final double LEARNING_RATE = 0.5d;

  private static double regressHorizonalLeapVelocity(double vx, double vy, final double targetX, final double targetVX, final double targetY, final double gravity, double deltaVX, double currentScore, int iterationsLeft) {
    if (iterationsLeft <= 0) return vx;
    var newVX1 = vx + deltaVX;
    var newVX2 = vx - deltaVX;
    var newScore1 = measurePassbyScore(newVX1, vy, targetX, targetVX, targetY, gravity, 30);
    var newScore2 = measurePassbyScore(newVX2, vy, targetX, targetVX, targetY, gravity, 25);
    LogUtils.getLogger().info("iterationsLeft {}, (vx, score) ({}, {}), deltaVX {}, (vx1, score1) ({}, {}), (vx2, score2) ({}, {})", iterationsLeft, vx, currentScore, deltaVX, newVX1, newScore1, newVX2, newScore2);
    if (newScore1 < currentScore || newScore2 < currentScore) {
      if (newScore1 < newScore2) {
        return regressHorizonalLeapVelocity(
            newVX1, vy,
            targetX, targetVX, targetY,
            gravity,
            deltaVX * LEARNING_RATE_CHANGED,
            newScore1,
            iterationsLeft - 1
        );
      } else {
        return regressHorizonalLeapVelocity(
            newVX2, vy,
            targetX, targetVX, targetY,
            gravity,
            deltaVX * LEARNING_RATE_CHANGED,
            newScore2,
            iterationsLeft - 1
        );
      }
    } else {
      return regressHorizonalLeapVelocity(
          vx, vy,
          targetX, targetVX, targetY,
          gravity,
          deltaVX * LEARNING_RATE,
          currentScore,
          iterationsLeft - 1
      );
    }
  }

  private static double regressHorizonalLeapVelocity(double vx, double vy, final double targetX, final double targetVX, final double targetY, final double gravity, double deltaVX, int iterationsLeft) {
    return regressHorizonalLeapVelocity(vx, vy, targetX, targetVX, targetY, gravity, deltaVX, measurePassbyScore(vx, vy, targetX, targetVX, targetY, gravity, 30), iterationsLeft);
  }

 */

  @Override
  public boolean canUse() {
    if (this.mob.hasControllingPassenger()) {
      return false;
    } else {
      //noinspection DataFlowIssue
      this.target = this.mob.getTarget();
      if (this.target == null) {
        return false;
      } else {
        double d = this.mob.distanceToSqr(this.target);
        if (d >= 4.0d && d <= 4096.0d && this.mob.hasLineOfSight(this.target)) { // distance = 2..64
          return this.mob.onGround();
        } else {
//          LogUtils.getLogger().info("target {} too far away / outside line of sight ({})", this.target, d);
          return false;
        }
      }
    }
  }

  @Override
  public void start() {
    Vec3 movement = this.mob.getDeltaMovement();
    Vec3 deltaH = new Vec3(this.target.getX() - this.mob.getX(), 0.0, this.target.getZ() - this.mob.getZ());
    if (deltaH.lengthSqr() > 1e-7) {
      deltaH = deltaH.normalize().scale(Math.min(movement.horizontalDistance() * 2.0d + 1.0d, deltaH.length() + 4.0d));
    }
    this.mob.setDeltaMovement(deltaH.x, this.yd, deltaH.z);

    float targetAngle = (float)Math.toDegrees(Math.atan2(-deltaH.x, deltaH.z));
    this.mob.setYRot(targetAngle);
    this.mob.setYBodyRot(targetAngle);
  }

  /*
  @Override
  public void start() {
    Vec3 movement = this.mob.getDeltaMovement();
    Vec3 deltaH = new Vec3(this.target.getX() - this.mob.getX(), 0.0, this.target.getZ() - this.mob.getZ());
    double targetY = (this.target.getY() + 0.1d) - this.mob.getY();
    double vy = Math.max(0.0, Math.pow(targetY, 1.1d)) / 30.0d + this.yd;
    if (deltaH.lengthSqr() > 1e-7) {
      double targetX = deltaH.horizontalDistance();
      double gravity = this.mob.getAttributeValue(Attributes.GRAVITY);
      double vx = regressHorizonalLeapVelocity(movement.scale(0.5d).horizontalDistance(), vy, targetX, this.target.getDeltaMovement().horizontalDistance(), targetY, -gravity, targetX, 4);
      deltaH = deltaH.normalize().scale(vx);
    }

    this.mob.setDeltaMovement(deltaH.x, vy, deltaH.z);
  }
  */

}
