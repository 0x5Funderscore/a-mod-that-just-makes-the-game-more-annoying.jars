package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.screens;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.DefaultUncaughtExceptionHandler;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Util;
import org.jspecify.annotations.NonNull;
import org.slf4j.Logger;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchIntegrationConnector;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;


public class TwitchIntegrationScreen extends Screen {

//  private static final Identifier INCOMPATIBLE_SPRITE = Identifier.withDefaultNamespace("server_list/incompatible");
  private static final Identifier DISCONNECTED_SPRITE = Identifier.withDefaultNamespace("server_list/unreachable");
  private static final Identifier CONNECTED_SPRITE = Identifier.withDefaultNamespace("server_list/ping_5");
  private static final Identifier PINGING_1_SPRITE = Identifier.withDefaultNamespace("server_list/pinging_1");
  private static final Identifier PINGING_2_SPRITE = Identifier.withDefaultNamespace("server_list/pinging_2");
  private static final Identifier PINGING_3_SPRITE = Identifier.withDefaultNamespace("server_list/pinging_3");
  private static final Identifier PINGING_4_SPRITE = Identifier.withDefaultNamespace("server_list/pinging_4");
  private static final Identifier PINGING_5_SPRITE = Identifier.withDefaultNamespace("server_list/pinging_5");

  private static final Logger LOGGER = LogUtils.getLogger();
  private static final ThreadPoolExecutor THREAD_POOL = new ScheduledThreadPoolExecutor(1, (new ThreadFactoryBuilder()).setNameFormat("Twitch Integration Connector").setDaemon(true).setUncaughtExceptionHandler(new DefaultUncaughtExceptionHandler(LOGGER)).build());

  private static final Component TITLE = Component.translatable("twitch_integration.title");
  private static final Component INFO = Component.translatable("twitch_integration.info");
  private static final Component INPUT_HINT = Component.translatable("twitch_integration.channel");
  private static final Component CONNECT = Component.translatable("selectWorld.edit.save");

  private final HeaderAndFooterLayout layout;
  private LinearLayout contentLayout;
  private LinearLayout statusLayout;
  private EditBox usernameBox;
  private Button connectButton;
  private StringWidget statusIconPlaceholder;

  public TwitchIntegrationScreen() {
    super(TITLE);
    this.layout = new HeaderAndFooterLayout(this, 12 + 9, 33);
  }

  @Override
  protected void init() {
    LinearLayout header = this.layout.addToHeader(LinearLayout.vertical().spacing(4));
    header.defaultCellSetting().alignHorizontallyCenter();
    header.addChild(new StringWidget(TITLE, this.font));

    TwitchIntegrationConnector.INSTANCE.loadChannelName();
    this.initContent();

    LinearLayout footer = this.layout.addToFooter(LinearLayout.horizontal().spacing(8));
    footer.addChild(Button.builder(CommonComponents.GUI_BACK, (button) -> this.onClose()).build());
    this.layout.visitWidgets(this::addRenderableWidget);

    this.repositionElements();
  }

  protected void initContent() {
    this.contentLayout = this.layout.addToContents(LinearLayout.vertical().spacing(4));
    this.contentLayout.addChild(FocusableTextWidget.builder(INFO.copy().withStyle(ChatFormatting.GOLD), this.font).maxWidth(200).build());
    this.usernameBox = this.contentLayout.addChild(new EditBox(this.font, 200, 15, Component.empty()));
    this.usernameBox.setHint(INPUT_HINT);
    this.usernameBox.setValue(Objects.requireNonNullElse(TwitchIntegrationConnector.INSTANCE.channelName, ""));
    this.statusLayout = this.contentLayout.addChild(LinearLayout.horizontal().spacing(4));
    this.connectButton = this.statusLayout.addChild(Button.builder(CONNECT, button -> {
      TwitchIntegrationConnector.INSTANCE.channelName = this.usernameBox.getValue();
      TwitchIntegrationConnector.INSTANCE.saveChannelName();
      THREAD_POOL.execute(TwitchIntegrationConnector.INSTANCE::attemptConnect);
    }).build());
    this.statusIconPlaceholder = this.statusLayout.addChild(new StringWidget(20, 20, Component.empty(), this.font));
  }

  @Override
  protected void repositionElements() {
    this.statusLayout.arrangeElements();
    this.contentLayout.arrangeElements();
    this.layout.arrangeElements();
  }

  protected void extractStatusIcon(GuiGraphicsExtractor graphics) {

    Identifier icon = switch (TwitchIntegrationConnector.INSTANCE.getStatus()) {
      case CONNECTED -> CONNECTED_SPRITE;

      case LOADING -> {

        int iconIndex = (int)(Util.getMillis() / 100L & 7L);
        if (iconIndex > 4) {
          iconIndex = 8 - iconIndex;
        }

        yield switch (iconIndex) {
          case 1 -> PINGING_2_SPRITE;
          case 2 -> PINGING_3_SPRITE;
          case 3 -> PINGING_4_SPRITE;
          case 4 -> PINGING_5_SPRITE;
          default -> PINGING_1_SPRITE;
        };
      }

      default -> DISCONNECTED_SPRITE;
    };

    int statusIconX = this.statusIconPlaceholder.getX() + 5;
    int statusIconY = this.statusIconPlaceholder.getY() + 6;
    graphics.blitSprite(RenderPipelines.GUI_TEXTURED, icon, statusIconX, statusIconY, 10, 8);

  }

  @Override
  public void extractRenderState(@NonNull GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
    this.extractStatusIcon(graphics);
    super.extractRenderState(graphics, mouseX, mouseY, a);
  }
}
