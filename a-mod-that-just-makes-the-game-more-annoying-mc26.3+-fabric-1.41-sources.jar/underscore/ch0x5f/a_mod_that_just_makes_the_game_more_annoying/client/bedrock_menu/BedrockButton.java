package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.bedrock_menu;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;


public class BedrockButton extends Button {

  private static final WidgetSprites SPRITES = new WidgetSprites(
      Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "bedrock_widget/button"),
      Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "bedrock_widget/button"),
      Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "bedrock_widget/button_highlighted")
  );

  private static final WidgetSprites SPRITES_REALMS = new WidgetSprites(
      Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "bedrock_widget/button_realms"),
      Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "bedrock_widget/button_realms"),
      Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "bedrock_widget/button_realms_highlighted")
  );

  public final boolean isRealms;

  public BedrockButton(int x, int y, int width, int height, Component message, OnPress onPress, CreateNarration createNarration, boolean isRealms) {
    super(x, y, width, height, message, onPress, createNarration);
    this.isRealms = isRealms;
  }

  @Override
  protected void extractContents(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
    graphics.blitSprite(RenderPipelines.GUI_TEXTURED, (isRealms ? SPRITES_REALMS : SPRITES).get(this.active, this.isHoveredOrFocused()), this.getX(), this.getY(), this.getWidth(), this.getHeight(), ARGB.white(this.alpha));
    this.extractScrollingStringOverContents(
        graphics.textRendererForWidget(this, GuiGraphicsExtractor.HoveredTextEffects.NONE),
        this.getMessage().copy()
            .withoutShadow()
            .withColor(this.isRealms || this.isHoveredOrFocused() ? 0xffffff : 0x4c4c4c),
        2
    );
  }
}
