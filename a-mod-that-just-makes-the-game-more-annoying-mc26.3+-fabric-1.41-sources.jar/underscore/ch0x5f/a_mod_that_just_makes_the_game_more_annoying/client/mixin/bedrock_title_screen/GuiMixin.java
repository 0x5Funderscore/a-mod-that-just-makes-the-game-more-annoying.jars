package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.bedrock_title_screen;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Gui;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Gui.class)
@Environment(EnvType.CLIENT)
public abstract class GuiMixin {

  @ModifyExpressionValue(method = "addInitialScreens", at = @At(value = "FIELD", target = "Lnet/minecraft/client/Options;onboardAccessibility:Z", opcode = Opcodes.GETFIELD))
  private boolean modifyOnboardAccessibility(boolean original) {
    if (Config.BEDROCK_TITLE_SCREEN.get()) return false;
    return original;
  }

}
