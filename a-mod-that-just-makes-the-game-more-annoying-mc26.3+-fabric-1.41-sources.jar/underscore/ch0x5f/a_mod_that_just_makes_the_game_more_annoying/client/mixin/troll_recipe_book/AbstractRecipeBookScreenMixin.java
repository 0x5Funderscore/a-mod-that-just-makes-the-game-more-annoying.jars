package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.troll_recipe_book;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.AbstractRecipeBookScreen;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.troll_recipe_book.TrollRecipeBookConstants;

import java.util.Objects;


@Mixin(AbstractRecipeBookScreen.class)
@Environment(EnvType.CLIENT)
public abstract class AbstractRecipeBookScreenMixin <T extends AbstractContainerMenu> extends AbstractContainerScreen<T> {

  @Unique
  private boolean rb$removedBook;

  public AbstractRecipeBookScreenMixin(T menu, Inventory inventory, Component title) {
    super(menu, inventory, title);
  }

  @Inject(method = "lambda$initButton$0", at = @At("HEAD"), cancellable = true)
  private void beforeButtonClick(Button button, CallbackInfo ci) {
    if (Config.TROLL_RECIPE_BOOK.get() && !this.rb$removedBook) {
      this.menu.setCarried(TrollRecipeBookConstants.TROLL_BOOK_TEMPLATE.get().create());
      this.rb$removedBook = true;
      ((ImageButton)button).sprites = new WidgetSprites(
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "troll_recipe_book/button"),
          Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "troll_recipe_book/button_highlighted")
      );
      Objects.requireNonNull(this.minecraft.getConnection()).send(new ServerboundContainerButtonClickPacket(this.menu.containerId, TrollRecipeBookConstants.TROLL_BUTTON_ID));
      ci.cancel();
    }
  }

}
