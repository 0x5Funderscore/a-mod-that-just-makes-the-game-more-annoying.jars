package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.popup_ads;

import com.mojang.logging.LogUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.popup_ads.AdSense;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.popup_ads.PopupAd;

import java.util.ArrayList;
import java.util.List;


@Mixin(Hud.class)
@Environment(EnvType.CLIENT)
public abstract class HudMixin {

  @Shadow
  @Final
  private Minecraft minecraft;

  @Unique
  private List<PopupAd> rb$ads;

  @Unique
  private AdSense rb$adSense;

  @Unique
  private float rb$timer = 0.0f;

  @Unique
  private long rb$randomSeed = 0L;

  @Inject(method = "extractRenderState", at = @At("TAIL"))
  private void postExtractRenderState(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker, CallbackInfo ci) {
    if (this.rb$ads == null) this.rb$ads = new ArrayList<>();

    if (Config.POPUP_ADS.get()) {

      if (this.minecraft.player == null) {
        this.rb$timer = 0f;
        this.rb$ads.clear();
      } else if (this.minecraft.gameMode != null &&
          this.minecraft.gameMode.canHurtPlayer() &&
          !this.minecraft.player.getInventory().contains(itemStack -> (
              itemStack.has(DataComponents.CUSTOM_DATA) &&
              itemStack.get(DataComponents.CUSTOM_DATA).copyTag().getBooleanOr("blocks_ads", false)
          ))
      ) {
        if (this.rb$adSense == null) this.rb$adSense = new AdSense(Minecraft.getInstance().player);
        else this.rb$adSense.checkPlayer(Minecraft.getInstance().player);

        if (this.minecraft.player.isDeadOrDying()) {
          this.rb$timer = 0f;
          this.rb$ads.clear();
          return;
        }

        float dt = deltaTracker.getRealtimeDeltaTicks();

        if (this.minecraft.getSingleplayerServer() instanceof IntegratedServer integratedServer) {
          float tickrate = integratedServer.tickRateManager().tickrate();
          if (tickrate > 20f) dt *= tickrate / 20f;
        }

        if (!this.minecraft.isPaused()) {
          this.rb$timer += dt;
          if (this.rb$timer > 5f) {
            this.rb$timer %= 5f;
            this.rb$randomSeed += 5L;

            if (this.rb$ads.size() < 6) {
              double nothingWeight = !this.rb$ads.isEmpty() && this.rb$ads.stream().anyMatch(ad -> ad.destroyProgress < 0.25) ? 2.0 : 2000.0;

              PopupAd ad = this.rb$adSense.pickAd(nothingWeight);

              if (ad != null) {
                this.rb$ads.add(ad.randomize());
                if (this.rb$ads.size() >= 3) {
                  this.rb$timer -= 180f;
                  this.rb$randomSeed += 180L;
                }
              }
            }
          }
        }

        long seed = this.rb$randomSeed + (long)Math.floor(this.rb$timer);

        MultiPlayerGameMode gameMode = this.minecraft.gameMode;
        boolean destroying = gameMode == null || gameMode.isDestroying();
        float destroySpeed = 1.0f;

        if (minecraft.player != null && gameMode != null && destroying) {
          BlockState destroyingState = minecraft.player.level().getBlockState(gameMode.destroyBlockPos);
          destroySpeed = minecraft.player.getDestroySpeed(destroyingState);
        }

        for (int i = 0; i < this.rb$ads.size(); i++) {
          PopupAd ad = this.rb$ads.get(i);
          if (destroying) ad.destroyProgress += dt / 100f * destroySpeed;
          if (ad.shouldRemove()) {
            this.rb$ads.remove(i--);
          } else {
            ad.render(graphics, dt, seed++);
          }
        }
      } else {
        this.rb$randomSeed++;
        this.rb$ads.clear();
      }
    } else {
      this.rb$randomSeed++;
      this.rb$ads.clear();
    }
  }

}
