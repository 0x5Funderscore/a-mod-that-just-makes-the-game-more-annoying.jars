package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.bouncy_snowballs;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.throwableitemprojectile.Snowball;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Snowball.class)
public abstract class SnowballMixin extends ThrowableItemProjectile {

  public SnowballMixin(EntityType<? extends ThrowableItemProjectile> type, Level level) {
    super(type, level);
  }

  @Inject(method = "onHit", at = @At("HEAD"), cancellable = true)
  private void beforeHit(HitResult hitResult, CallbackInfo ci) {
    if (Config.BOUNCY_SNOWBALLS.get() && this.level() instanceof ServerLevel && this.getDeltaMovement().lengthSqr() >= 0.01) {
      if (hitResult instanceof BlockHitResult blockHitResult) {
        this.setDeltaMovement(new Vec3(this.getDeltaMovement().toVector3f().reflect(blockHitResult.getDirection().getUnitVec3f()).mul(0.75f)));
        this.needsSync = true;
        ci.cancel();
      }
    }
  }

}
