package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.dying_advances_night;

import net.minecraft.core.registries.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.clock.WorldClocks;
import net.minecraft.world.damagesource.DamageSource;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin {

  @Shadow
  public abstract ServerLevel level();

  @Shadow
  @Final
  private MinecraftServer server;

  @Inject(method = "die", at = @At("RETURN"))
  private void beforeDie(DamageSource source, CallbackInfo ci) {
    if (Config.DYING_ADVANCES_NIGHT.get() && this.level() == this.server.overworld()) {
      long overworldClockTime = this.level().getOverworldClockTime() % 24000L;
      if (overworldClockTime > 14000L && overworldClockTime < 22000L) {
        this.server.clockManager().addTicks(this.server.registryAccess().lookupOrThrow(Registries.WORLD_CLOCK).getOrThrow(WorldClocks.OVERWORLD), Math.max(3000 / this.server.getPlayerCount(), 200));
      }
    }
  }

}
