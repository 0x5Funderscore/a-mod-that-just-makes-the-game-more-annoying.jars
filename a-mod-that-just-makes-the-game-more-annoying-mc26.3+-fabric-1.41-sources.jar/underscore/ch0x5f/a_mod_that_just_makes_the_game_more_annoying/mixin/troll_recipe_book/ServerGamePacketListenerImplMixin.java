package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.troll_recipe_book;

import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.troll_recipe_book.TrollRecipeBookConstants;


@Mixin(ServerGamePacketListenerImpl.class)
public abstract class ServerGamePacketListenerImplMixin {

  @Shadow
  public ServerPlayer player;

  @Shadow
  @Final
  private static Logger LOGGER;

  @Inject(method = "handleContainerButtonClick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;resetLastActionTime()V"), cancellable = true)
  private void interceptHandleContainerButtonClick(ServerboundContainerButtonClickPacket packet, CallbackInfo ci) {
    if (Config.TROLL_RECIPE_BOOK.get()) {
      if (this.player.containerMenu.containerId == packet.containerId() && !this.player.isSpectator()) {
        if (packet.buttonId() == TrollRecipeBookConstants.TROLL_BUTTON_ID) {
          this.player.containerMenu.setCarried(TrollRecipeBookConstants.TROLL_BOOK_TEMPLATE.get().create());
          ci.cancel();
        }
      }
    }
  }

}
