package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.moving_world_spawn;

import net.minecraft.core.*;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.PlayerList;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.storage.LevelData;
import net.minecraft.world.level.storage.WritableLevelData;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;


@Mixin(MinecraftServer.class)
public abstract class MinecraftServerMixin {

  @Shadow
  public abstract LevelData.RespawnData getRespawnData();

  @Shadow
  private int tickCount;

  @Shadow
  public abstract void setRespawnData(LevelData.RespawnData respawnData);

  @Shadow
  private PlayerList playerList;

  @Inject(method = "tickChildren", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/clock/ServerClockManager;tick()V"))
  private void atTickTime(BooleanSupplier haveTime, CallbackInfo ci) {
    if (Config.MOVING_WORLD_SPAWN.get() && this.tickCount % 5 == 0) {

      LevelData.RespawnData respawnData = this.getRespawnData();

      List<BlockPos> playerSpawnpoints = this.playerList.getPlayers()
          .stream()
          .map(ServerPlayer::getRespawnConfig)
          .filter(Objects::nonNull)
          .map(ServerPlayer.RespawnConfig::respawnData)
          .filter(data -> data.dimension() == respawnData.dimension())
          .map(LevelData.RespawnData::pos)
          .toList();

      if (!playerSpawnpoints.isEmpty()) {

        double toX = playerSpawnpoints.stream().mapToInt(BlockPos::getX).average().orElseThrow();
        double toY = playerSpawnpoints.stream().mapToInt(BlockPos::getY).average().orElseThrow();
        double toZ = playerSpawnpoints.stream().mapToInt(BlockPos::getZ).average().orElseThrow();

        Vec3 to = new Vec3(toX, toY, toZ);
        Vec3 respawnPos = Vec3.atBottomCenterOf(respawnData.pos());

        Vec3 offset = to.subtract(respawnPos);
        double lengthSqr = offset.lengthSqr();
        double chance = lengthSqr / 256.0;

        if (chance >= 1.0 || Math.random() < chance) {

          this.setRespawnData(
              LevelData.RespawnData.of(
                  respawnData.dimension(),
                  respawnData.pos().relative(Direction.getApproximateNearest(offset)),
                  respawnData.yaw(),
                  respawnData.pitch()
              )
          );

        }

      }

    }
  }

}
