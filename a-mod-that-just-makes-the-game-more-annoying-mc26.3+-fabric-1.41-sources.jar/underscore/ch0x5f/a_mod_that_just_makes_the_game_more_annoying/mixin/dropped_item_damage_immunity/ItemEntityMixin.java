package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.dropped_item_damage_immunity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin extends Entity {

  public ItemEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @WrapOperation(method = "hurtServer", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;canBeHurtBy(Lnet/minecraft/world/damagesource/DamageSource;)Z"))
  private boolean wrapCanBeHurtBy(ItemStack instance, DamageSource source, Operation<Boolean> original) {
    boolean originalValue = original.call(instance, source);
    if (Config.DROPPED_ITEM_DAMAGE_IMMUNITY.get() && originalValue) {
      return source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.is(DamageTypes.CACTUS) || source.is(DamageTypes.EXPLOSION) || source.is(DamageTypes.PLAYER_EXPLOSION) || source.is(DamageTypes.FELL_OUT_OF_WORLD);
    }
    return originalValue;
  }

}
