package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.egg_grenade;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.throwableitemprojectile.Snowball;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEgg;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ThrownEgg.class)
public abstract class ThrownEggMixin extends ThrowableItemProjectile {

  public ThrownEggMixin(EntityType<? extends ThrowableItemProjectile> type, Level level) {
    super(type, level);
  }

  @Inject(method = "onHit", at = @At("HEAD"))
  private void beforeHit(HitResult hitResult, CallbackInfo ci) {
    Level level = this.level();
    if (Config.EGG_GRENADES.get() && level instanceof ServerLevel serverLevel) {
      if (this.getItem().is(ItemTags.EGGS)) {
        serverLevel.explode(this, this.getX(), this.getY(), this.getZ(), 2f, false, Level.ExplosionInteraction.TNT);
      }
    }
  }

}
