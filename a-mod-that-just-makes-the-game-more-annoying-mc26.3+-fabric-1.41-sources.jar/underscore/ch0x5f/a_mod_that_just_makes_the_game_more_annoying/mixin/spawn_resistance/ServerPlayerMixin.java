package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.spawn_resistance;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.portal.TeleportTransition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Unique
  private static final Set<UUID> rb$applyResistance = new HashSet<>();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void afterTick(CallbackInfo ci) {
    if (Config.SPAWN_RESISTANCE.get() && this.tickCount == 1) {
      if (rb$applyResistance.contains(this.uuid)) {
        this.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 200, 4, true, true, true));
        rb$applyResistance.remove(this.uuid);
      }
    }
  }

  @Inject(method = "findRespawnPositionAndUseSpawnBlock", at = @At("RETURN"))
  private void respawnMissing(boolean consumeSpawnBlock, TeleportTransition.PostTeleportTransition postTeleportTransition, CallbackInfoReturnable<TeleportTransition> cir) {
    if (Config.SPAWN_RESISTANCE.get()) {
      rb$applyResistance.add(this.uuid);
    }
  }

}
