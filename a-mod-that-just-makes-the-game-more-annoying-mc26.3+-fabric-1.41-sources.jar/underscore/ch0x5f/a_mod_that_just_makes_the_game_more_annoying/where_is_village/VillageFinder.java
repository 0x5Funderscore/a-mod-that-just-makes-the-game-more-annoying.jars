package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.where_is_village;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.StructureTags;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.phys.Vec3;


public final class VillageFinder {

  public static void findAndSendVillage(ServerPlayer player, ServerLevel level, Position position) {

    Pair<BlockPos,Holder<Structure>> village = level.getChunkSource()
        .getGenerator()
        .findNearestMapStructure(
            level,
            level.registryAccess()
                .lookupOrThrow(Registries.STRUCTURE)
                .getOrThrow(StructureTags.VILLAGE),
            BlockPos.containing(position),
            32,
            false
        );

    Component foundVillage = Component.translatable("ragebait.where_is_village.none_nearby").withColor(TextColor.RED);

    if (village != null) {

      Vec3 where = Vec3.atBottomCenterOf(village.getFirst());
      Vec3 from = new Vec3(position.x(), position.y(), position.z()).with(Direction.Axis.Y, where.y);
      double distance = where.distanceTo(from);
      double angle = Math.atan2(where.x - from.x, from.z - where.z);

      if (distance <= 64.0d) {
        foundVillage = Component.translatable("ragebait.where_is_village.nearby").withColor(TextColor.GREEN);
      } else {
        int directionIndex = Math.floorMod((int)Math.round(angle / Math.PI * 4), 8);
        String direction = new String[]{"north", "north_east", "east", "south_east", "south", "south_west", "west", "north_west"}[directionIndex];
        foundVillage = Component.translatable("ragebait.where_is_village.location", Math.round(distance), Component.translatable("ragebait.where_is_village.direction." + direction).withColor(TextColor.YELLOW)).withColor(TextColor.YELLOW);
      }
    }

    player.sendSystemMessage(Component.translatable("ragebait.where_is_village.message", foundVillage).withColor(TextColor.GOLD));
  }

}
