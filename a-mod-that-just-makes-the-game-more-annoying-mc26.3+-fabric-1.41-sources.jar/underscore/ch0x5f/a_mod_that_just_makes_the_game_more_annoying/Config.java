package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.fabricmc.loader.api.FabricLoader;
import org.jetbrains.annotations.ApiStatus;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import static underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.ConfigTags.*;


public enum Config implements ConfigProperty {

  BEDS_TP_TO_NETHER("server/block/#beds/beds_tp_to_nether", true, "Beds have a chance to teleport players to the nether"),
  SHIELD_BLOCKING_DISABLES("server/item/shield/shield_blocking_disables", true, "Shields have a chance to disable when hit by anything"),
  PHANTOMS_PICK_UP_PLAYERS("server/entity/phantom/phantoms_pick_up_players", true, "Phantoms can pick you up and drop you from high up"),
  ALWAYS_SPAWN_PHANTOMS("server/entity/phantom/always_spawn_phantoms", false, "Phantoms can spawn every night"),
  OFFSET_CROSSHAIR("client/ui/offset_crosshair", true, "The crosshair is slightly offset"),
  OFFSET_HUNGER_BAR("client/ui/offset_hunger_bar", true, "The hunger bar is 2 pixels higher"),
  PIGLINS_BLOW_UP("server/entity/piglin/piglins_blow_up", false, "Piglins explode if they don't drop ender pearls"),
  EMERALD_INFLATION("server/entity/villager/emerald_inflation", false, "Every villager wants at least 64 emeralds"),
  SHUFFLE_CHESTS_ON_OPEN("server/block/chest/shuffle_chests_on_open", true, "Chests randomize every time they're opened"),
  INVISIBLE_CREEPERS("client/entity/creeper/invisible_creepers", true, "Creepers are invisible until they flash"),
  LOUD_CREEPER_EXPLOSIONS("server/sound/loud_creeper_explosions", true, "Explosions are 20 times louder"),
  UNCAPPED_VOLUME("client/sound/uncapped_volume", true, "There's no limit on sound volume"),
  BROKEN_RECIPES("server/crafting/broken_recipes", false, "Crafting recipe shapes are randomized every time an item is moved"),
  ITEMS_BREAK_RANDOMLY("server/item/[damage]/items_break_randomly", true, "Items with durability have a chance to break when any durability is used, depending on the maximum durability of that item"),
  RANDOMLY_STOP_SNEAKING_IN_NETHER("client/movement/randomly_stop_sneaking_in_nether", true, "When sneaking in the nether, you have a chance to stop sneaking sometimes"),
  FRAGILE_OBSIDIAN("server/block/obsidian/fragile_obsidian", false, "Obsidian breaks (without dropping) when an entity stands on top of it"),
  GOOFY_SPIDERS("server/entity/spider/goofy_spiders", true, "Spiders track players from 96 blocks away and jump around a lot, gaining speed"),
  VICIOUS_HORSES("server/entity/horse/vicious_horses", true, "Horses attack players and iron golems"),
  REQUIRE_BALANCED_DIET("server/item/[food]/require_balanced_diet", true, "If you eat the same food 3 times in a Minecraft day, you die from not eating a balanced diet"),
  INVENTORY_GLASS_PANES_TROLL("server/item/light_gray_stained_glass_pane/inventory_glass_panes_troll", true, "Empty inventory slots have a chance to become light gray stained glass pane (with curse of vanishing, no tooltip, and stack size of 1)"),
  BLOCK_DROPS_RANDOM_ATTRIBUTE_MODIFIERS("server/mining/block_drops_random_attribute_modifiers", true, "Blocks can occasionally drop with random attribute modifiers"),
  DO_NOT_SWIM("both/movement/do_not_swim", true, "Just... don't swim..."),
  DISABLE_PAUSE("both/disable_pause", false, "Pausing in singleplayer doesn't actually pause the local server"),
  DESTROYING_BLOCKS_WITH_HAND_HURTS("server/mining/destroying_blocks_with_hand_hurts", true, "Destroying blocks with an empty hand makes you take damage"),
  ENVIRONMENTAL_TEMPERATURE_DAMAGE("server/world/environmental_temperature_damage", false, "Players take freezing damage in cold biomes and fire damage in hot biomes"),
  SUPER_BOUNCY("both/block/slime/super_bouncy", true, "Bouncy things (slime, beds, shelf mushrooms) are extremely bouncy"),
  REPLACE_END_PORTAL("both/replace_end_portal", true, "Strongholds no longer contain end portal frames (go to a stronghold to find out more information)"),
  BEEHIVES_EXPLODE_NEAR_PLAYERS("server/block/bee_nest/beehives_explode_near_players", true, "Beehives explode when players get near, spawning 100 times as many bees"),
  BEES_STING_ENDLESSLY("server/entity/bee/bees_sting_endlessly", true, "Bees don't lose their stinger or calm down after stinging"),
  ANXIOUS_ENDERMEN("server/entity/enderman/anxious_endermen", true, "Endermen pick up and place blocks much more commonly"),
  ENDERMEN_RANDOMLY_GET_BOOM("server/entity/enderman/endermen_randomly_get_boom", true, "Endermen can randomly obtain TNT, redstone blocks, and fire"),
  GOOFY_ENDER_DRAGON("client/entity/ender_dragon/goofy_ender_dragon", true, "The ender dragon's animations have been removed"),
  REPLACE_END_PLATFORM("server/dimension/end/replace_end_platform", true, "The end platform is made of barriers"),
  DIG_DOWN_LAVA_TROLL("server/block/lava/dig_down_lava_troll", true, "Underground in the overworld, or anywhere in the nether, if you mine straight down, you can encounter one block of lava"),
  QUICKGRAVEL("server/block/gravel/quickgravel", true, "Gravel jumps up and acts like quicksand when an entity stands on it"),
  GRAVEL_AND_STONES_FALL_ON_YOUR_HEAD("server/block/gravel/gravel_and_stones_fall_on_your_head", true, "When standing other gravel, dripstone, or any other overworld or nether stone, it can fall on your head"),
  HALVE_DRAGON_DAMAGE("server/entity/ender_dragon/halve_dragon_damage", false, "The ender dragon takes 50% less damage"),
  DRAGON_EGGS_TELEPORT_FURTHER("both/block/dragon_egg/dragon_eggs_teleport_further", true, "Dragon eggs can teleport really far away"),
  REQUIRE_8_CRYSTALS_FOR_RESPAWN("server/entity/end_crystal/require_8_crystals_for_respawn", true, "You now need 8 crystals to respawn the dragon"),
  END_CRYSTALS_REQUIRE_PLAYER_PUNCH("server/entity/end_crystal/end_crystals_require_player_punch", false, "End crystals need player (melee) attacks to break"),
  LESS_COAL_ORE("server/block/coal_ore/less_coal_ore", true, "Coal veins are much smaller"),
  COAL_BURNS_FAST("server/item/coal/coal_burns_fast", false, "Coal and charcoal burn much faster"),
  FURNACE_COOKING_TIME_X5("server/block/furnace/furnace_cooking_time_x5", false, "Furnaces and campfires take 5 times as long to cook"),
  FURNACE_EXPONENTIAL_PROGRESS("client/block/furnace/furnace_exponential_progress", true, "The furnace progress meter is inverse exponential (slows down as it gets more)"),
  FALL_DAMAGE_AT_2_BLOCKS("both/entity/player/fall_damage_at_2_blocks", false, "You take fall damage at 2 blocks"),
  DIFFERENT_END_BED_EXPLOSION("server/different_end_bed_explosion", true, "Beds spawn an acid cloud instead of exploding in the end"),
  SLEEP_LATE("server/block/#beds/sleep_late", true, "You can only sleep late"),
  TERRIBLE_REPUTATION("server/entity/villager/terrible_reputation", true, "Villager reputation starts really bad and stays really bad"),
  SWEET_BERRY_BUSHES_SPREAD("server/block/sweet_berry_bush/sweet_berry_bushes_spread", true, "Sweet berry bushes can spread to nearby blocks"),
  SWEET_BERRY_BUSHES_APPLY_EFFECTS("server/block/sweet_berry_bush/sweet_berry_bushes_apply_effects", true, "Sweet berry bushes apply poison, nausea, and slowness"),
  EVERY_ZOMBIE_IS_A_LEADER("server/entity/zombie/every_zombie_is_a_leader", true, "Every zombie is a leader zombie (stronger and can spawn allies)"),
  REALLY_HARD_MODE("server/really_hard_mode", true, "Local difficulty is always at 10 (the maximum possible in vanilla is 9)"),
  THIN_BRIDGES_BREAK("server/entity/player/thin_bridges_break", true, "One block wide bridges (as well as overhangs) break when you stand on them"),
  THIN_ICE("server/block/ice/thin_ice", true, "When you stand on ice in a cold biome, it melts instantly"),
  ENDERMEN_TELEPORT_A_LOT("server/entity/enderman/endermen_teleport_a_lot", false, "Endermen constantly teleport"),
  TTS_GUIDE("client/tts_guide", false, "There's a \"helpful\" TTS guide that gives you tips when you die"),
  END_PORTAL_NEEDS_FRAME("server/block/end_portal/end_portal_needs_frame", true, "End portals break if they aren't adjacent to other end portals, end portal frames, or bedrock"),
  FALL_THROUGH_LEAVES("both/block/#leaves/fall_through_leaves", false, "Leaves have no hitbox and deal damage to mobs moving inside them"),
  WITHER_SKELETONS_COMBINE("server/entity/wither_skeleton/wither_skeletons_combine", true, "Three wither skeletons near each other can combine into a wither"),
  SPLASH_POTIONS_EXPLODE("server/entity/potion/splash_potions_explode", true, "Splash potions have a chance to explode when they land"),
  ANIMALS_STOP_SLEEP("server/block/#beds/animals_stop_sleep", true, "For the purposes of sleeping, anything other than players and villagers are monsters"),
  DOORS_CHANGE_RANDOMLY("server/block/#doors/doors_change_randomly", true, "Doors occasionally change direction and state"),
  ALL_ZOMBIES_ARE_BABIES("server/entity/zombie/all_zombies_are_babies", false, "All zombies are babies"),
  MINING_FATIGUE_UNAFFECTED_BY_MILK("server/effect/mining_fatigue/mining_fatigue_unaffected_by_milk", false, "Mining fatigue can't be removed by milk (doesn't work with lactose_intolerance)"),
  REPLACE_LAVA_SOLIDIFICATION("server/block/lava/replace_lava_solidification", true, "Lava can turn into any of a whole list of metamorphic rocks, and can't make obsidian next to other obsidian"),
  ELDER_GUARDIAN_INCREASED_RANGE("server/entity/elder_guardian/elder_guardian_increased_range", true, "Elder guardians have increased mining fatigue checking speed and range"),
  TAMING_ANIMALS_EXPLODES("server/entity/%tameable/taming_animals_explodes", false, "Animals explode when tamed"),
  BED_WETTING("server/block/#beds/bed_wetting", true, "There's a chance to spawn a water block above the feet of the bed when you sleep"),
  INVERSE_ABSORPTION("both/effect/absorption/inverse_absorption", true, "Absorption is negative for players"),
  LOWER_STEP_HEIGHT("both/entity/player/lower_step_height", true, "Player step height is lowered"),
  DOORS_ARE_AFRAID_OF_WATER("server/block/#doors/doors_are_afraid_of_water", false, "Doors start flying around when they touch water"),
  RARE_ITEMS_FLY_AWAY("both/entity/item/rare_items_fly_away", true, "Items with a rarity more than common, beacon payment items, books, and armor trim materials are pushed away from players"),
  SWEEPING_DAMAGES_SELF("server/entity/player/sweeping_damages_self", true, "Sweeping attacks don't exclude the attacker"),
  ORIGIN_DESERT("server/world/origin_desert", false, "Everything within 500 blocks of spawn is replaced with a desert, without any structures"),
  EXPERIENCE_ORBS_HURT("server/entity/experience_orb/experience_orbs_hurt", true, "Experience orbs hurt players"),
  NO_XP("server/entity/experience_orb/no_xp", false, "Players can't gain experience"),
  SKELETON_HOMING_ARROWS("server/entity/skeleton/skeleton_homing_arrows", true, "Skeleton arrows curve towards their target"),
  NO_ENCHANTING_TABLES("server/block/enchanting_table/no_enchanting_tables", true, "You can't have enchanting tables in your inventory"),
  EXPLODE_ON_PLACE("server/block/*/explode_on_place", false, "There's a chance blocks explode when you place them"),
  ANNOYING_TRAPPED_CHESTS("server/block/trapped_chest/annoying_trapped_chests", false, "Trapped chests close and taunt you"),
  FAST_GHASTS("server/entity/ghast/fast_ghasts", true, "Ghasts shoot at 2 fireballs per second"),
  FURNACE_TOUCH_DAMAGE("server/block/furnace/furnace_touch_damage", true, "You take fire damage when you have the furnace GUI open if it's lit"),
  LAVA_SPREADS_LAVA("server/block/lava/lava_spreads_lava", false, "Lava spreads lava instead of fire"),
  EDGING_TNT("server/entity/tnt/edging_tnt", true, "TNT stops just before the explosion (and becomes invisible) until a player approaches"),
  FALL_HEART_ATTACKS("server/entity/player/fall_heart_attacks", false, "Every 5 seconds there's a chance you die of fall damage"),
  FUEL_ALWAYS_BURNS("server/block/furnace/fuel_always_burns", true, "Fuel burns in a furnace without ingredients"),
  OVERCOOKING("server/block/furnace/overcooking", false, "Attempting to smelt the 5th item in a furnace turns the entire result slot into 4 charcoal"),
  HOLDING_LAVA_HURTS("server/item/lava_bucket/holding_lava_hurts", true, "You take fire damage while holding a lava bucket"),
  LAVA_BLOWS_UP_FURNACES("server/block/furnace/lava_blows_up_furnaces", true, "Lava blows up furnaces when used as fuel"),
  ENCHANTMENTS_DISAPPEAR("server/item/[enchantments]/enchantments_disappear", true, "When an enchanted item takes durability, there's a chance a random enchantment is removed"),
  LACTOSE_INTOLERANCE("server/item/milk_bucket/lactose_intolerance", true, "Milk doesn't clear any effects and applies nausea instead (doesn't work with mining_fatigue_unaffected_by_milk)"),
  SHORT_ENDERMAN_HITBOX("both/entity/enderman/short_enderman_hitbox", true, "Endermen's hitboxes are now 1.8 blocks tall"),
  ENDERMEN_SOCIAL_ANXIETY("server/entity/enderman/endermen_social_anxiety", true, "Endermen get angry if you look anywhere near them"),
  ENDERMEN_DONT_FREEZE("server/entity/enderman/endermen_dont_freeze", true, "Endermen don't freeze when looked at"),
  ENDERMEN_HOLD_ANYTHING("server/entity/enderman/endermen_hold_anything", true, "Endermen can pick up anything (except wither immune blocks)"),
  ENDERMEN_HOLD_WITHER_IMMUNE("server/entity/enderman/endermen_hold_wither_immune", false, "Endermen can pick up wither immune blocks"),
  FRAGILE_END_PORTAL("server/block/end_portal/fragile_end_portal", false, "After entering an end portal, there's a chance it breaks"),
  SLOW_ARMOR("server/item/[equippable]/slow_armor", false, "For players, each worn non-leather armor piece multiplies speed by 80%"),
  ALTITUDE_TEMPERATURE_DAMAGE("server/world/altitude_temperature_damage", false, "You take freezing damage at high altitudes and fire damage at low altitudes"),
  EXPLOSIVE_RABBITS("server/entity/rabbit/explosive_rabbits", true, "Rabbits have bombs and explode when they die"),
  NORMAL_RAILS_ARE_POWERED_OFF("server/block/rail/normal_rails_are_powered_off", true, "All rails have the same speed as powered rails without redstone"),
  ENDERMEN_UNAFFECTED_BY_WATER("server/entity/enderman/endermen_unaffected_by_water", true, "Endermen aren't affected by water"),
  BATS_TARGET_EYES("server/entity/bat/bats_target_eyes", true, "Bats fly towards nearby players' eyes"),
  BEDROCK_OFFHAND_OR_LIGHTNING("server/entity/player/bedrock_offhand_or_lightning", false, "If your offhand contains something that you can't offhand in Bedrock, it's forcefully dropped and struck by lightning"),
  ITEMS_DIE_NEAR_PLAYERS("server/entity/item/items_die_near_players", true, "Items despawn faster when players are nearby"),
  RAILS_SPAWN_FURNACE_MINECARTS("server/block/rail/rails_spawn_furnace_minecarts", true, "Rails can spawn furnace minecarts sometimes"),
  FURNACE_MINECARTS_USELESS("server/entity/furnace_minecart/furnace_minecarts_useless", true, "Furnace minecarts don't do anything"),
  INVENTORY_WATER_BUCKET_SPILLING("server/item/water_bucket/inventory_water_bucket_spilling", true, "Water in your inventory can spill onto other slots when you make sudden movements"),
  ENDERMEN_TARGET_IMPORTANT_BLOCKS("server/entity/enderman/endermen_target_important_blocks", true, "Endermen target \"important\" blocks more"),
  LANDMINES("server/landmines", true, "Landmines exist: They can spawn randomly when another mob spawns, slowly move towards the nearest player, and cannot be killed or broken"),
  MOSTLY_REMOVE_SQUIDS("server/entity/squid/mostly_remove_squids", false, "Squids are much rarer"),
  REMOVE_TOOLTIP_BACKGROUNDS("client/ui/remove_tooltip_backgrounds", true, "Tooltips don't have a background anymore"),
  NO_SLOT_HIGHLIGHT("client/ui/container/no_slot_highlight", false, "Item slot highlights are removed"),
  OFFSET_SLOT_HIGHLIGHT("client/ui/container/offset_slot_highlight", true, "Item slot highlights are offset by 1.5 slots"),
  WILD_TAMED_ANIMALS("server/entity/%tameable/wild_tamed_animals", true, "Tamed animals go wild when they take damage"),
  LLAMA_SPIT_LAUNCH("server/entity/llama_spit/llama_spit_launch", true, "Llama spit has extreme knockback"),
  IRON_GOLEM_EXTENDED_REACH("server/entity/iron_golem/iron_golem_extended_reach", true, "Iron golems have extended reach"),
  IRON_GOLEM_SPACE_PROGRAM("server/entity/iron_golem/iron_golem_space_program", true, ":)"),
  NERVOUS_HORSES("server/entity/horse/nervous_horses", true, "Horses dismount if they fall or take damage"),
  SHULKER_MACHINE_GUNS("server/entity/shulker/shulker_machine_guns", true, "Shulkers are machin guns"),
  SKELETON_SHOTGUNS("server/entity/skeleton/skeleton_shotguns", false, "Skeletons have arrow shotguns"),
  FIFTY_SKELETON_HORSES("server/entity/skeleton_horse/fifty_skeleton_horses", true, "Trap skeleton horses spawn 50 horsemen instead of 4"),
  CHICKENS_V2("server/entity/chicken/chickens_v2", true, "Chickens are version 2"),
  LAVA_FLOWS_FAST("server/block/lava/lava_flows_fast", true, "Lava flows faster than water"),
  FLYING_SQUIDS("server/entity/squid/flying_squids", true, "Squids can fly"),
  NEUTRAL_LEVITATION("both/effect/levitation/neutral_levitation", true, "Levitation doesn't make you go up, but removes your gravity"),
  CREEPERS_IGNORE_CATS("server/entity/creeper/creepers_ignore_cats", true, "Creepers are chill around cats"),
  FURNACES_LITERALLY("server/block/furnace/furnaces_literally", true, "Blast furnaces blast, and smokers smoke"),
  FLETCHING_TABLES_SHOOT("server/block/fletching_table/fletching_tables_shoot", true, "Fletching tables shoot arrows"),
  SHULKERS_SHOOT_CLOSED("server/entity/shulker/shulkers_shoot_closed", true, "Shulkers don't have to open to shoot"),
  UNBREAKING_ELYTRA_FLIES_SLOWER("both/item/elytra/unbreaking_elytra_flies_slower", true, "Elytra enchanted with unbreaking flies slower"),
  ENDER_PEARLS_MOVE_SLOWLY("both/entity/ender_pearl/ender_pearls_move_slowly", true, "Ender pearls move much slower"),
  SKELETON_DODGING("server/entity/skeleton/skeleton_dodging", false, "Skeletons dodge melee attacks"),
  HISSBINES("server/hissbines", true, "Hissbines from ASTRONEER (a plant that shoots slow acid balls)"),
  MONSTERS_WITH_HELMETS("server/entity/%mob/monsters_with_helmets", true, "Any mob that can spawn with armor will spawn with at least a helmet"),
  SMALLER_BABY_ZOMBIES("both/entity/zombie/smaller_baby_zombies", false, "Baby zombies are twice as small"),
  FASTER_BABY_ZOMBIES("server/entity/zombie/faster_baby_zombies", true, "Baby zombies are much faster"),
  BLAZE_MACHINE_GUNS("server/entity/blaze/blaze_machine_guns", true, "Blaze fireball volleys are endless"),
  NETHERITE_WITHER_SKELETONS("server/entity/wither_skeleton/netherite_wither_skeletons", false, "Wither skeletons spawn with full netherite armor and iron swords (but none of it can drop)"),
  SHORT_WITHER_SKELETON_HITBOX("both/entity/wither_skeleton/short_wither_skeleton_hitbox", true, "Wither skeletons' hitboxes are now 1.8 blocks tall"),
  MOBS_DONT_DAMAGE_HELMETS("server/entity/%mob/mobs_dont_damage_helmets", true, "Helmets protecting mobs from sunlight no longer take damage when they burn"),
  MOB_ARMOR_BINDING_CURSE("server/entity/%mob/mob_armor_binding_curse", true, "All armor dropped from mobs has curse of binding"),
  NO_OFFHAND_KEY("client/no_offhand_key", false, "\"Swap mainhand and offhand\" key no longer works (but it works inside inventory for some reason)"),
  MORE_LIGHTNING("server/weather/more_lightning", true, "Lightning bolts are more common and concentrated towards players who have anything made of copper or repairable with copper"),
  MORE_THUNDERSTORMS("server/weather/more_thunderstorms", false, "Clear weather lasts one fifth as long"),
  NAUSEA_INVERTED_MOVEMENT("client/effect/nausea/nausea_inverted_movement", true, "Nausea inverts movement"),
  WITCHES_THROW_LINGERING("server/entity/witch/witches_throw_lingering", true, "Witches throw lingering potions"),
  WITCHES_THROW_DIFFERENT_POTIONS("server/entity/witch/witches_throw_different_potions", true, "Witches can throw harming, poison, slowness, weakness, weaving, and oozing potions, as well as longer and higher level potions"),
  BOILING_NETHER_WATER_CAULDRONS("server/dimension/nether/boiling_nether_water_cauldrons", true, "Water cauldrons in the nether boil players inside them"),
  SUPER_SURGE_CONDUCTOR("server/weather/super_surge_conductor", true, "Holding a lightning rod or channeling trident in a storm makes you get struck by lightning a lot"),
  SUN_GLARE("client/world/sun_glare", true, "Looking towards the sun or an end flash puts a glare effect over your screen"),
  SOLIDIFYING_LAVA("server/block/lava/solidifying_lava", true, "Lava turns into obsidian in dimensions that don't have fast lava (namely, the overworld and end)"),
  COPPER_GOLEM_LIGHTNING("server/entity/copper_golem/copper_golem_lightning", true, "Copper golems exposed to the sky get obliterated by Zeus"),
  TIMID_SHEEP("server/entity/sheep/timid_sheep", true, "Sheep run away from players"),
  NO_STRING_WOOL("server/item/#wool/no_string_wool", true, "Wool cannot be crafted from string"),
  LOUD_LEAF_LITTER("both/block/leaf_litter/loud_leaf_litter", true, "Leaf litter is very loud"),
  VAULTS_DISPENSE_MOBS("server/block/vault/vaults_dispense_mobs", true, "Instead of dropping items, vaults dispense mobs that drop those items"),
  THUNDERSTORM_SCREW_YOU_IN_PARTICULAR("server/weather/thunderstorm_screw_you_in_particular", true, "When you equip copper armor, a thunderstorm starts, you get struck by lightning, and the thunderstorm stops"),
  FAST_WARDEN("server/entity/warden/fast_warden", false, "The warden moves faster"),
  FOXES_SCAN_INVENTORIES("server/entity/fox/foxes_scan_inventories", true, "Foxes are hostile to players who have fox food in their inventory"),
  CAVE_FLOWER_HAYFEVER("server/block/%cave_flowers/cave_flower_hayfever", false, "Standing under a spore blossom or azalea flowers gives you nausea and poison"),
  CATS_SCAN_INVENTORIES("server/entity/cat/cats_scan_inventories", true, "Cats are hostile towards players with egg or fish in their inventories"),
  SAME_SIZE_SLIMES("server/entity/%cube/same_size_slimes", true, "Slimes don't get smaller when they split, but all slimes drop slime balls"),
  SHY_FURNACES("server/block/furnace/shy_furnaces", false, "Furnaces are shy and won't light unless you're looking away and give them space"),
  DISAPPEARING_CATS("server/entity/cat/disappearing_cats", false, "Cats instantly disappear when you're within 5 blocks of them and not holding fish"),
  WARDEN_SIGHT("server/entity/warden/warden_sight", true, "The warden can see"),
  GLOW_SQUIDS_HATCH_SILVERFISH("server/entity/glow_squid/glow_squids_hatch_silverfish", false, "Glow squids that die of drowning (air) hatch silverfish"),
  NO_VIBRATION_OCCLUDING("server/block/#wool/no_vibration_occluding", true, "Wool doesn't block vibrations anymore"),
  WILDER_WOLVES("server/entity/wolf/wilder_wolves", true, "Wolves are hostile towards players who aren't holding meat or bone"),
  CHANGE_PIGLIN_BARTER_LOOT("server/entity/piglin/change_piglin_barter_loot", true, "Piglins no longer have useful trades"),
  SMART_BLOCK_DROPS("server/mining/smart_block_drops", true, "Items dropped from blocks try to drop into lava, fire, void, or away from the player"),
  WORSE_ORES_AND_INGOTS("server/item/%ingot/worse_ores_and_ingots", false, "Ingots don't stack, and ores and raw materials have a chance of smelting into themselves"),
  FURNACE_OUTPUT_SINGLETON("server/block/furnace/furnace_output_singleton", false, "Furnaces can't smelt if their output is occupied"),
  FURNACE_PLACEMENT_FLIPPED("server/block/furnace/furnace_placement_flipped", true, "Furnaces have a 50% chance of being placed facing the opposite direction"),
  RANDOM_PLACEMENT_DIRECTIONS("server/block/%directional/random_placement_directions", false, "Placement directions are all randomized"),
  RANDOM_CREEPER_HISS("client/sound/random_creeper_hiss", false, "There's a chance every tick that a creeper hiss plays behind you"),
  MOB_CRITS("server/entity/%mob/mob_crits", true, "Mobs can do critical attacks"),
  RANDOMIZE_HUNGER_ON_WAKE("server/entity/player/randomize_hunger_on_wake", true, "Hunger is randomized when you wake up, but can't increase"),
  LOUD_CAVE_SOUNDS("client/sound/loud_cave_sounds", true, "Cave sounds are much louder"),
  DAMAGED_CHEST_LOOT("server/block/chest/damaged_chest_loot", true, "Any randomized loot that has durability will spawn with 2 durability left"),
  POVERTY_VILLAGES("server/structure/village/poverty_villages", true, "Village loot cannot generate food or emeralds"),
  NETHER_ROOF_PROTECTION("server/dimension/nether/nether_roof_protection", true, "You can't build above the nether roof"),
  BREAK_NETHER_COORDS("server/dimension/nether/break_nether_coords", true, "Nether coordinate conversion is broken (but consistent for the same world)"),
  UNSTABLE_CREEPERS("server/entity/creeper/unstable_creepers", true, "Creeper fuse time is randomized between 0.5 and 1.5 times as long"),
  HOT_ITEM_FIRE("server/entity/player/hot_item_fire", true, "Holding a hot item deals fire damage"),
  FLOATING_FISH("server/entity/%fish/floating_fish", true, "Fish float when they're out of water"),
  ALWAYS_RAID("server/structure/village/always_raid", false, "Every player can start a level 1 raid (but isn't rewarded for it)"),
  MOB_STACKS("server/entity/zombie/mob_stacks", true, "The Tower (from Minecraft Dungeons) can spawn with any zombie variant"),
  SWAP_POTATOES("server/item/potato/swap_potatoes", true, "The consumption results of normal and poisonous potatoes are swapped"),
  CREEPER_EXPLOSION_CHAIN("server/entity/creeper/creeper_explosion_chain", true, "Creepers ignite when exploded, instead of taking damage"),
  RAIN_SILVERFISH("server/entity/silverfish/rain_silverfish", true, "During rain, silverfish spawn"),
  SWAP_REGEN_WITHER("server/effect/wither/swap_regen_wither", true, "The effects of wither and regeneration are swapped"),
  SWAP_REGEN_WITHER_VISUAL("client/effect/wither/swap_regen_wither_visual", true, "Wither and regeneration are visually swapped (wither is white, regeneration goes left)"),
  CLOSE_THIRD_PERSON("client/close_third_person", false, "Third person is uselessly close"),
  NETHER_WATER("server/dimension/nether/nether_water", true, "You can put water in the nether, but it boils players"),
  CREEPER_IGNITE_FIRE_DAMAGE("server/entity/creeper/creeper_ignite_fire_damage", true, "Creepers ignite when they take fire damage"),
  LETHAL_POISON("server/effect/poison/lethal_poison", true, "Poison can kill"),
  ANTI_VEIN_MINER("server/mining/anti_vein_miner", false, "When you break an ore, all connected ores are converted into their base stone variants"),
  EMPATHETIC_OBSIDIAN("server/block/obsidian/empathetic_obsidian", true, "Obsidian cries when you break nearby obsidian"),
  ENDER_DRAGON_REQUIRES_MELEE("server/entity/ender_dragon/ender_dragon_requires_melee", true, "The ender dragon only takes damage from melee attacks"),
  TOUCHY_MENUS("client/ui/touchy_menus", true, "Menu buttons run away from the cursor"),
  FISHING("both/fishing", true, "I love fishing :3"),
  VILLAGER_CURING_NITWIT("server/entity/villager/villager_curing_nitwit", true, "Curing a villager makes them a nitwit"),
  AXE_SHEARING("server/entity/sheep/axe_shearing", true, "You have to strip sheep instead of shearing them"),
  STRIPPED_END_PORTAL("both/block/end_portal/stripped_end_portal", true, "End portal can be stripped (with an axe) and flattened (with a shovel)"),
  INVISIBLE_OBSIDIAN("client/block/obsidian/invisible_obsidian", false, "Obsidian is invisible (but weird and buggy)"),
  FALLING_BLOCKS_DROP_LOOT("server/entity/falling_block/falling_blocks_drop_loot", true, "Falling blocks drop by their loot tables instead of their item forms"),
  SKELETON_INCREASED_RANGE("server/entity/skeleton/skeleton_increased_range", true, "Skeletons can see from 50 blocks away"),
  ANVILS_FALL_UP("server/block/anvil/anvils_fall_up", true, "Anvils fall up instead of down"),
  EXPLODING_ENDER_EYES("server/item/ender_eye/exploding_ender_eyes", true, "Thrown ender eyes explode if they break"),
  END_PORTAL_FRAME_MISCLICK("server/block/end_portal_frame/end_portal_frame_misclick", true, "Inserting an eye into an end portal frame only works 25% of the time"),
  ROTATED_MAP_ICONS("client/item/map/rotated_map_icons", true, "Map decorations are rotated incorrectly"),
  VILLAGER_VENGEANCE("server/entity/villager/villager_vengeance", false, "Killing a villager turns nearby villagers into vindicators with diamond axes"),
  SMALL_BUGS("server/entity/#arthropod/small_bugs", false, "Spiders, cave spiders, silverfish, endermites, and bees are very small"),
  STONECUTTER_DAMAGE("server/block/stonecutter/stonecutter_damage", true, "Stonecutters damage players (only)"),
  LEGACY_BOAT_COLLISION("server/entity/#boats/legacy_boat_collision", true, "Boats break when they hit blocks, like in older versions"),
  FIGHTING_FISH("server/entity/%fish/fighting_fish", true, "The fish fight back (salmon, cod, and tropical fish)"),
  TRAPPED_BURIED_TREASURE("server/structure/buried_treasure/trapped_buried_treasure", true, "Buried treasure is a trap"),
  SPAWN_POINT_FAILURE("server/entity/player/spawn_point_failure", false, "Respawning sometimes fails and resets your spawn point"),
  MORE_COPPER_ORE("server/block/copper_ore/more_copper_ore", true, "Copper ore veins are bigger"),
  ELYTRA_GENERATES_BROKEN("server/structure/end_city/elytra_generates_broken", true, "Elytra in end city ships generate with no durability left"),
  DECONSTRUCT_FURNACES("server/block/furnace/deconstruct_furnaces", true, "Furnaces decompose into their components when destroyed"),
  MOVE_BURIED_TREASURE("server/structure/buried_treasure/move_buried_treasure", false, "Buried treasure chests have moved, leaving a notice at their previous location"),
  DISABLE_ITEM_GROUPING("server/entity/item/disable_item_grouping", false, "Items no longer merge together"),
  SHOUTOUT_YAHIAMICE("client/shoutout_yahiamice", () -> AMTJMTGMA.playerUsername.equalsIgnoreCase("yahiamice"), "A tribute to Yahiamice"),
  POPUP_ADS("client/ui/popup_ads", true, "Personalized pop-up ads appear on screen occasionally"),
  MONSTER_SHIPWRECKS("server/structure/shipwreck/monster_shipwrecks", true, "Beware of shipwrecks in deep oceans..."),
  MAGMA_BREAKS_FALLING_BLOCKS("server/block/magma/magma_breaks_falling_blocks", true, "Falling blocks break when they hit magma blocks"),
  WHERE_IS_VILLAGE("server/where_is_village", true, "Tells you where the nearest village is when you respawn without a bed"),
  FAST_BUBBLE_COLUMNS("both/block/bubble_column/fast_bubble_columns", true, "Bubble columns are much stronger"),
  INSUFFICIENT_BUBBLE_COLUMNS("server/block/bubble_column/insufficient_bubble_columns", true, "Bubble columns only keep your oxygen the same, instead of regenerating it"),
  THIEVING_PIGLINS("server/entity/piglin/thieving_piglins", true, "Piglins can't stop themselves from getting their grubby hands on your nice shiny gold armor"),
  RABBITS_LOVE_PLAYERS("server/entity/rabbit/rabbits_love_players", true, "Rabbits LOVE players"),
  STRONGER_NAUSEA_EFFECT("client/effect/nausea/stronger_nausea_effect", true, "Nausea screen warping is much worse"),
  SCRAPE_STONE("both/sound/scrape_stone", false, "Walking on stone-sound blocks without shoes makes scraping sounds"),
  DISCORD_PING_PARROT("client/entity/parrot/discord_ping_parrot", true, "Parrot ambient sounds are replaced with Discord pings"),
  BITRATE_REDUCER("client/bitrate_reducer", true, "The game's bitrate can be reduced sometimes"),
  UPPER_VOID("server/world/upper_void", true, "There's a void above the world as well as below it"),
  POPUP_AD_BLOCKER("both/item/+/popup_ad_blocker", true, "There's item that can block pop-up ads"),
  YOU_BLOCK_ORIGIN("both/item/+/you_block_origin", true, "you block origin"),
  INFINITE_SNOW_ACCUMULATION("server/weather/infinite_snow_accumulation", true, "Snow can accumulate infinitely"),
  FROGS_EAT_PLAYERS("server/entity/frog/frogs_eat_players", true, "Frogs can eat players"),
  TWITCH_INTEGRATION__EXPERIMENTAL("twitch/twitch_chaos.experimental", false, "Enables Twitch integration and Twitch Chaos (experimental)"),
  TWITCH__TELEPORT_RANDOMLY("twitch/twitch_chaos/teleport_randomly", true, "Twitch chaos option: Teleport Randomly - all players teleport somewhere around their current location"),
  TWITCH__SKIP_WEATHER("twitch/twitch_chaos/skip_weather", true, "Twitch chaos option: Skip Weather - the current weather is skipped"),
  TWITCH__ADVANCE_6_HOURS("twitch/twitch_chaos/advance_6_hours", true, "Twitch chaos option: Advance 6 Hours - the overworld day cycle is advanced 6 hours"),
  TWITCH__NOTHING("twitch/twitch_chaos/nothing", true, "Twitch chaos option: Nothing - nothing happens"),
  TWITCH__RAINING_BLOCKS("twitch/twitch_chaos/raining_blocks", true, "Twitch chaos option: Raining Blocks - random blocks rain from the sky"),
  TWITCH__ORBITAL_STRIKE("twitch/twitch_chaos/orbital_strike", true, "Twitch chaos option: Orbital Strike - attempts to summon an orbital strike above random players in each dimension, if they're near open sky"),
  TWITCH__SPLEEF_MODE("twitch/twitch_chaos/spleef_mode", false, "Twitch chaos option: Spleef Mode - makes blocks fall as you run on them"),
  TWITCH__ANVIL_RAIN("twitch/twitch_chaos/anvil_rain", true, "Twitch chaos option: Anvil Rain - anvils rain from the sky"),
  TRIDENT_MINIGUNS("server/entity/drowned/trident_miniguns", true, "Trident drowned have miniguns"),
  TRIDENT_SNIPERS("server/entity/drowned/trident_snipers", false, "Drowned shoot tridents from much further away, but aren't more accurate"),
  KICKING_COWS("server/entity/cow/kicking_cows", true, "Cows kick you if you attack them"),
  MOVING_WORLD_SPAWN("server/moving_world_spawn", true, "The world spawn slowly moves towards players' spawnpoints"),
  BEDROCK_TITLE_SCREEN("client/ui/bedrock_title_screen", true, "The main menu is replaced with a Bedrock edition style title screen (doesn't work in demo version)"),
  TROLL_RECIPE_BOOK("both/troll_recipe_book", true, "The recipe book is an item"),
  DROPPED_ITEM_DAMAGE_IMMUNITY("server/entity/item/dropped_item_damage_immunity", true, "Dropped items are immune to most damage"),
  EGG_GRENADES("server/entity/egg/egg_grenades", true, "Eggs explode when thrown"),
  BOUNCY_SNOWBALLS("server/entity/snowball/bouncy_snowballs", true, "Snowballs bounce"),
  DYING_ADVANCES_NIGHT("server/time/dying_advances_night", true, "Dying in the overworld at night skips the day cycle forward"),
  SPAWN_RESISTANCE("server/spawn_resistance", true, "Upon respawning, you are given resistance"),
  ;

  private final String id;
  private boolean value;
  private final BooleanSupplier defaultValueSupplier;

  public final String description;

  Config(String id, boolean defaultValue, String description) {
    this(id, () -> defaultValue, description);
  }

  Config(String id, BooleanSupplier defaultValueSupplier, String description) {
    this.id = id;
    this.value = (this.defaultValueSupplier = defaultValueSupplier).getAsBoolean();
    this.description = description;
  }

  @Override
  public boolean get() {
    return this.value;
  }

  @Override
  public boolean getDefault() {
    return this.defaultValueSupplier.getAsBoolean();
  }

  @Override
  public void set(boolean value) {
    this.value = value;
  }

  @Override
  public String getId() {
    return this.id;
  }

  @Override
  public String getDescription() {
    return this.description;
  }

  private static void loadConfigFile(File configFile) throws RuntimeException, IOException {
    if (configFile.exists()) {

      try {

        FileReader fileReader = new FileReader(configFile);
        JsonObject jsonObject = JsonParser.parseReader(fileReader).getAsJsonObject();
        fileReader.close();

        all.forEach(property -> property.setFrom(jsonObject));

      } catch (Exception e) {
        throw new RuntimeException("AMTJMTGMA config failed to load.", e);
      }

    } else {

      LogUtils.getLogger().info("Creating new AMTJMTGMA config");

      configFile.getParentFile().mkdirs();
      configFile.createNewFile();

    }

    JsonObject configObject = new JsonObject();
    forEach(property -> property.storeTo(configObject));

    FileWriter writer = new FileWriter(configFile);
    writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(configObject));
    writer.close();

  }

  @ApiStatus.Internal
  public static void loadConfig() throws RuntimeException, IOException {
    LogUtils.getLogger().info("Loading AMTJMTGMA config");
    loadConfigFile(FabricLoader.getInstance().getConfigDir().resolve("a_mod_that_just_makes_the_game_more_annoying.json").toFile());
  }

  public static void saveConfig() {
    File configFile = FabricLoader.getInstance().getConfigDir().resolve("a_mod_that_just_makes_the_game_more_annoying.json").toFile();

    JsonObject configObject = new JsonObject();
    forEach(property -> property.storeTo(configObject));

    try {
      FileWriter writer = new FileWriter(configFile);
      writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(configObject));
      writer.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private static final List<ConfigProperty> all = new ArrayList<>(List.of(values()));

  public static void forEach(Consumer<ConfigProperty> consumer) {
    all.forEach(consumer);
  }

  @ApiStatus.Experimental
  public static ConfigProperty register(String name, boolean defaultValue, String description) {
    return register(name, () -> defaultValue, description);
  }

  @ApiStatus.Experimental
  public static ConfigProperty register(String name, BooleanSupplier defaultValue, String description) {
    ConfigProperty configProperty = new ConfigProperty() {
      private boolean value = defaultValue.getAsBoolean();

      @Override
      public boolean get() {
        return this.value;
      }

      @Override
      public boolean getDefault() {
        return defaultValue.getAsBoolean();
      }

      @Override
      public void set(boolean value) {
        this.value = value;
      }

      @Override
      public String getId() {
        return name;
      }

      @Override
      public String getDescription() {
        return description;
      }
    };
    all.add(configProperty);
    return configProperty;
  }

}
