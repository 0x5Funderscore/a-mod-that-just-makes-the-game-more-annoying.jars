package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;


public interface ConfigProperty extends java.util.function.BooleanSupplier, io.netty.util.BooleanSupplier {
  @Override
  boolean get();
  void set(boolean value);

  @Override
  default boolean getAsBoolean() { return this.get(); }

  boolean getDefault();

  String getId();
  String getDescription();

  @ApiStatus.Internal
  default void setFrom(JsonObject object) {
    if (!object.has(this.getId())) {
      LogUtils.getLogger().warn("AMTJMTGMA config warning: Missing property {} (using default value {})", this.getId(), this.get());
      return;
    }
    try {
      this.set(object.get(this.getId()).getAsBoolean());
    } catch (Exception e) {
      throw new RuntimeException("AMTJMTGMA config error: Invalid type for property " + this.getId() + " (should be boolean)");
    }
  }

  @ApiStatus.Internal
  default void storeTo(JsonObject object) {
    object.addProperty(this.getId(), this.get());
  }
}
