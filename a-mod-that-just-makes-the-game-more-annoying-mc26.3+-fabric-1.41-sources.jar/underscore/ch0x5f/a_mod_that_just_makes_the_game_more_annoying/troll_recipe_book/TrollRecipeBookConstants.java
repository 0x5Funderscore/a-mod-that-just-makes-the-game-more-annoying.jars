package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.troll_recipe_book;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import oshi.util.Memoizer;

import java.util.function.Supplier;


public final class TrollRecipeBookConstants {

  public static final Supplier<ItemStackTemplate> TROLL_BOOK_TEMPLATE = Memoizer.memoize(() -> new ItemStackTemplate(
      Holder.direct(Items.KNOWLEDGE_BOOK),
      1,
      DataComponentPatch.builder()
          .set(DataComponents.RARITY, Rarity.COMMON)
          .build()
  ));
  public static final int TROLL_BUTTON_ID = -16384;

}
