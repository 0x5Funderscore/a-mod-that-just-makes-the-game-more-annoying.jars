package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.skeleton_increased_range;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.skeleton.AbstractSkeleton;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractSkeleton.class)
public abstract class AbstractSkeletonMixin extends Monster {
  protected AbstractSkeletonMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @ModifyReturnValue(method = "createAttributes", at = @At("TAIL"))
  private static AttributeSupplier.Builder modifyAttributes(AttributeSupplier.Builder original) {
    if (Config.SKELETON_INCREASED_RANGE.get()) original.add(Attributes.FOLLOW_RANGE, 50d);
    return original;
  }

}
