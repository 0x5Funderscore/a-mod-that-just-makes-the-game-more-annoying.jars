package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.terraria_pale_gardens;

import net.minecraft.world.level.block.CreakingHeartBlock;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(CreakingHeartBlock.class)
public abstract class CreakingHeartBlockMixin {
}
