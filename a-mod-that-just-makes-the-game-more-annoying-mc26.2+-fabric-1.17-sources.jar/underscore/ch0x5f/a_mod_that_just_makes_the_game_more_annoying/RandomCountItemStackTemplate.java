package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying;

import net.minecraft.util.RandomSource;
import net.minecraft.util.valueproviders.ConstantInt;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;


public record RandomCountItemStackTemplate(ItemStackTemplate stack, IntProvider count) {

  public RandomCountItemStackTemplate(ItemStackTemplate stack, int count) {
    this(stack, ConstantInt.of(count));
  }

  public RandomCountItemStackTemplate(ItemStackTemplate stack, int min, int max) {
    this(stack, UniformInt.of(min, max));
  }

  public RandomCountItemStackTemplate(ItemStackTemplate stackWithCount) {
    this(stackWithCount, ConstantInt.of(stackWithCount.count()));
  }

  public RandomCountItemStackTemplate(Item item, IntProvider count) {
    this(new ItemStackTemplate(item), count);
  }

  public RandomCountItemStackTemplate(Item item, int count) {
    this(new ItemStackTemplate(item), count);
  }

  public RandomCountItemStackTemplate(Item item, int min, int max) {
    this(new ItemStackTemplate(item), min == max ? ConstantInt.of(min) : UniformInt.of(min, max));
  }

  public ItemStack create(RandomSource random) {
    ItemStack itemStack = stack.create();
    itemStack.setCount(count.sample(random));
    return itemStack;
  }
}
