package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.same_size_slimes;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.cubemob.AbstractCubeMob;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractCubeMob.class)
public abstract class AbstractCubeMobMixin extends AgeableMob {

  protected AbstractCubeMobMixin(EntityType<? extends AgeableMob> type, Level level) {
    super(type, level);
  }

  @Definition(id = "getSize", method = "Lnet/minecraft/world/entity/monster/cubemob/AbstractCubeMob;getSize()I")
  @Expression("this.getSize()")
  @ModifyExpressionValue(method = "remove", at = @At("MIXINEXTRAS:EXPRESSION"))
  private int replaceSize(int original) {
    if (Config.SAME_SIZE_SLIMES.get() && this instanceof Enemy && this.level().getEntitiesOfClass(this.getClass(), this.getBoundingBox().inflate(0.5d)).size() <= 4) return original * 2;
    return original;
  }

  @Definition(id = "width", local = @Local(type = float.class, name = "width"))
  @Expression("width / ?")
  @ModifyExpressionValue(method = "remove", at = @At("MIXINEXTRAS:EXPRESSION"))
  private float zeroWidth(float original) {
    if (Config.SAME_SIZE_SLIMES.get()) return 0f;
    return original;
  }

}
