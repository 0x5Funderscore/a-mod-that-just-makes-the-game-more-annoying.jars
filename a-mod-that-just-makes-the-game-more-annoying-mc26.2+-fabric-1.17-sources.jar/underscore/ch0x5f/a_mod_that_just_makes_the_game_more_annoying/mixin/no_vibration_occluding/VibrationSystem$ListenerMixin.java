package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.no_vibration_occluding;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.level.gameevent.vibrations.VibrationSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(VibrationSystem.Listener.class)
public abstract class VibrationSystem$ListenerMixin {

  @ModifyReturnValue(method = "isOccluded", at = @At("TAIL"))
  private static boolean modifyIsOccluded(boolean original) {
    if (Config.NO_VIBRATION_OCCLUDING.get()) return false;
    return original;
  }

}
