package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.drowning_glow_squids_hatch_silverfish;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.animal.squid.GlowSquid;
import net.minecraft.world.entity.animal.squid.Squid;
import net.minecraft.world.entity.monster.Silverfish;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(GlowSquid.class)
public abstract class GlowSquidMixin extends Squid {

  public GlowSquidMixin(EntityType<? extends Squid> type, Level level) {
    super(type, level);
  }

  @Definition(id = "hurtServer", method = "Lnet/minecraft/world/entity/animal/squid/Squid;hurtServer(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;F)Z")
  @Expression("super.hurtServer(?, ?, ?)")
  @ModifyExpressionValue(method = "hurtServer", at = @At("MIXINEXTRAS:EXPRESSION"))
  private boolean hurtServer(
      boolean original,
      @Local(name = "source", argsOnly = true) DamageSource damageSource
      ) {
    if (Config.GLOW_SQUIDS_HATCH_SILVERFISH.get() && this.isDeadOrDying() && damageSource.is(DamageTypes.DROWN)) {
      int n = 2 + this.random.nextInt(3);
      for (int i = 0; i < n; i++) {
        Silverfish silverfish = new Silverfish(EntityTypes.SILVERFISH, this.level());
        silverfish.setPos(this.position().add(0d, this.random.nextDouble() * 0.5d, 0d).offsetRandomXZ(this.random, 0.1f));
        this.level().addFreshEntity(silverfish);
      }
    }
    return original;
  }

}
