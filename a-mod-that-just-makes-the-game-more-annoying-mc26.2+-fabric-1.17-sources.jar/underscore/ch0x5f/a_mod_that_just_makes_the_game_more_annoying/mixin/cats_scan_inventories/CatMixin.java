package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.cats_scan_inventories;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.animal.feline.Cat;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CatStuff;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Cat.class)
public abstract class CatMixin extends TamableAnimal {

  protected CatMixin(EntityType<? extends TamableAnimal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "registerGoals", at = @At("TAIL"))
  private void registerExtraGoals(CallbackInfo ci) {
    if (Config.CATS_SCAN_INVENTORIES.get()) {
      TargetingConditions targetingConditions = TargetingConditions.forCombat();
      this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, false, (target, level) -> targetingConditions.test(level, this, target) && target instanceof ServerPlayer serverPlayer && CatStuff.hasFood(serverPlayer)));
    }
  }

}
