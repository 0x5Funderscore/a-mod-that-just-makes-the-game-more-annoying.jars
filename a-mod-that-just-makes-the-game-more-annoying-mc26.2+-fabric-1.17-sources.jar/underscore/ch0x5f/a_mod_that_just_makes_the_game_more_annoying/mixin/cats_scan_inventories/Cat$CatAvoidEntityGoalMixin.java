package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.cats_scan_inventories;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.feline.Cat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.CatStuff;

import java.util.function.Predicate;


@Mixin(Cat.CatAvoidEntityGoal.class)
class Cat$CatAvoidEntityGoalMixin {

  @ModifyArg(
      method = "<init>",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/goal/AvoidEntityGoal;<init>(Lnet/minecraft/world/entity/PathfinderMob;Ljava/lang/Class;FDDLjava/util/function/Predicate;)V"),
      index = 5
  )
  private static Predicate<? extends LivingEntity> modifySelector(Predicate<? extends LivingEntity> original) {
    return original.and((livingEntity -> !(livingEntity instanceof ServerPlayer serverPlayer && CatStuff.hasFood(serverPlayer))));
  }

}
