package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.thin_bridges_break;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SupportType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Block.class)
public abstract class BlockMixin {

  @Inject(method = "stepOn", at = @At("HEAD"))
  private void stepOnHEAD_thinBridges(Level level, BlockPos pos, BlockState onState, Entity entity, CallbackInfo ci) {
    if (!Config.THIN_BRIDGES_BREAK.get()) return;
    if (level.isClientSide()) return;
    if (!(entity instanceof ServerPlayer)) return;
    if (level instanceof ServerLevel serverLevel) {
      if (serverLevel.getServer().getTickCount() % 4 != 0) return;
      if (onState.hasBlockEntity()) return;
      RandomSource rs = serverLevel.getRandom().forkPositional().at(pos);
      rs.setSeed(rs.nextLong() ^ serverLevel.getServer().getTickCount());
      if (rs.nextFloat() < 0.1d) {
        int sturdyBlocks = 0;
        for (Direction direction: Direction.values()) {
          BlockPos otherPos = pos.relative(direction);
          if (direction == Direction.UP) otherPos = pos;
          BlockState otherState = serverLevel.getBlockState(otherPos);
          if (otherState.getBlock().getExplosionResistance() > 8f) {
            sturdyBlocks = 8;
            break;
          } else if (otherState.isAir()) continue;
          if (direction == Direction.UP) {
            sturdyBlocks++;
          } else if (onState.isFaceSturdy(serverLevel, pos, direction, SupportType.CENTER) && otherState.isFaceSturdy(serverLevel, otherPos, direction.getOpposite(), SupportType.CENTER)) {
            if (direction == Direction.DOWN) {
              sturdyBlocks = 8;
              break;
            }
            sturdyBlocks++;
          }
        }
        if (sturdyBlocks < 4) {
          BlockPos posBelow = pos.below();
          VoxelShape collisionShape = serverLevel.getBlockState(posBelow).getCollisionShape(level, posBelow);
          if (collisionShape.isEmpty() || collisionShape.max(Direction.Axis.Y) < 0.875) {
            FallingBlockEntity.fall(serverLevel, pos, onState);
          }
        }
      }
    }
  }

}
