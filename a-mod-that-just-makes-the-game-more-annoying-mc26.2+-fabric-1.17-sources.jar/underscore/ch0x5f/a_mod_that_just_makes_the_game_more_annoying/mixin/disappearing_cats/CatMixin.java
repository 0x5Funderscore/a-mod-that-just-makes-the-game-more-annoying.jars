package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.disappearing_cats;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.animal.feline.Cat;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Cat.class)
public abstract class CatMixin extends TamableAnimal {

  protected CatMixin(EntityType<? extends TamableAnimal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.DISAPPEARING_CATS.get() && this.level() instanceof ServerLevel serverLevel) {
      Player nearestPlayer = serverLevel.getNearestPlayer(TargetingConditions.forCombat().range(5d), this);
      if (nearestPlayer != null) {
        if (!nearestPlayer.getMainHandItem().is(ItemTags.CAT_FOOD) && !nearestPlayer.getOffhandItem().is(ItemTags.CAT_FOOD)) {
          this.remove(RemovalReason.DISCARDED);
        }
      }
    }
  }

}
