package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.smart_block_drops;

import com.llamalad7.mixinextras.sugar.Local;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.function.Supplier;


@Mixin(Block.class)
public abstract class BlockMixin {

  @Shadow
  @Final
  private static Logger LOGGER;

  @Inject(
      method = "popResource(Lnet/minecraft/world/level/Level;Ljava/util/function/Supplier;Lnet/minecraft/world/item/ItemStack;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/item/ItemEntity;setDefaultPickUpDelay()V", shift = At.Shift.AFTER)
  )
  private static void modifyItemEntity(
      Level level, Supplier<ItemEntity> entityFactory, ItemStack itemStack,
      CallbackInfo ci,
      @Local(name = "entity") ItemEntity entity
  ) {
    if (!Config.SMART_BLOCK_DROPS.get() || !(level instanceof ServerLevel serverLevel)) return;
    Vec3 originalDeltaMovement = entity.getDeltaMovement();
    LOGGER.info("vel: ({}, {}, {})", originalDeltaMovement.x, originalDeltaMovement.y, originalDeltaMovement.z);
    double speed = 0.08d;

    BlockPos pos = entity.blockPosition();

    float[] weight = new float[9];

    int idx = 0;
    for (int x = -1; x <= 1; x++) {
      for (int z = -1; z <= 1; z++) {
        BlockPos pos2 = pos.offset(x, 0, z);

        if (level.getHeight(Heightmap.Types.MOTION_BLOCKING, pos2.getX(), pos2.getZ()) == level.dimensionType().minY()) {
          weight[idx] = 4.0f;
        } else {

          int y = 0;

          BlockState blockState;
          do {
            if (pos2.getY() <= level.dimensionType().minY()) {
              weight[idx] = 4.0f;
              break;
            }
            blockState = serverLevel.getBlockState(pos2);
            if (blockState.getFluidState().is(FluidTags.LAVA)) {
              weight[idx] = 2.5f;
              break;
            } else if (blockState.is(BlockTags.FIRE)) {
              weight[idx] = 2.0f;
              break;
            }
            weight[idx] += y <= -8 ? 0.125f : 0.0625f;
            pos2 = pos2.below();
            y--;
          } while (blockState.getCollisionShape(serverLevel, pos2).isEmpty() && y > -16);

        }
        idx++;
      }
    }

    float[] weightAdd = new float[weight.length];
    int[] weightDiv = new int[weight.length];

    for (int x = 0; x < 3; x++) {
      for (int z = 0; z < 3; z++) {
        float w = weight[x*3 + z];
        weightAdd[x * 3 + z] += w;
        weightDiv[x * 3 + z]++;
        if (x < 2) {
          weightAdd[(x + 1) * 3 + z] += w;
          weightDiv[(x + 1) * 3 + z]++;
        }
        if (x > 0) {
          weightAdd[(x - 1) * 3 + z] += w;
          weightDiv[(x - 1) * 3 + z]++;
        }
        if (z < 2) {
          weightAdd[x * 3 + z + 1] += w;
          weightDiv[x * 3 + z + 1]++;
        }
        if (z > 0) {
          weightAdd[x * 3 + z - 1] += w;
          weightDiv[x * 3 + z - 1]++;
        }
      }
    }

    for (int i = 0; i < 9; i++) {
      weightAdd[i] /= weightDiv[i];
    }

    IntList argmax = new IntArrayList();
    float max = 0f;
    for (float f: weightAdd) max = Math.max(max, f);
    for (int i = 0; i < 9; i++) if (weightAdd[i] == max) argmax.add(i);

    Player nearestPlayer = level.getNearestPlayer(entity, 4d);

    Vec3 deltaMovement = Vec3.ZERO;
    if (max > 0.5f) {
      int dropIndex = argmax.getInt((int)(Math.random() * argmax.size()));
      int vx = (dropIndex / 3) - 1;
      int vz = (dropIndex % 3) - 1;
      deltaMovement = new Vec3(vx * speed, 0d, vz * speed);
      entity.setDeltaMovement(deltaMovement.add(originalDeltaMovement.multiply(0.2d, 1.0d, 0.2d)));
    }

    if (deltaMovement.horizontalDistanceSqr() > 0.01d) {
      if (nearestPlayer != null) {
        Vec3 offset = nearestPlayer.position().subtract(entity.position());
        entity.setPickUpDelay(Math.max(entity.pickupDelay, offset.normalize().dot(deltaMovement.normalize()) > 0d ? 30 : 15));
      }
    }

  }

}
