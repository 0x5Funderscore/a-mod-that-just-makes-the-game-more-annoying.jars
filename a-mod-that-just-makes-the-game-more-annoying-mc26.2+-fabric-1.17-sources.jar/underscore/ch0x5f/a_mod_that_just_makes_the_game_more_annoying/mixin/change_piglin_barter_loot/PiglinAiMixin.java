package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.change_piglin_barter_loot;

import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.util.random.WeightedList;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinAi;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.RandomCountItemStackTemplate;

import java.util.Collections;
import java.util.List;


@Mixin(PiglinAi.class)
public class PiglinAiMixin {

  @Unique
  private static WeightedList<RandomCountItemStackTemplate> rb$itemList;

  @Unique
  private static WeightedList<RandomCountItemStackTemplate> rb$generateNewItemList() {
    DataComponentPatch waterPotionPatch = DataComponentPatch.builder().set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.WATER)).build();
    ItemStackTemplate WATER_BOTTLE = new ItemStackTemplate(Items.POTION, waterPotionPatch);
    ItemStackTemplate WATER_BOTTLE_SPLASH = new ItemStackTemplate(Items.SPLASH_POTION, waterPotionPatch);
    ItemStackTemplate WATER_BOTTLE_LINGERING = new ItemStackTemplate(Items.LINGERING_POTION, waterPotionPatch);
    ItemStackTemplate ARROW_WATER = new ItemStackTemplate(Items.TIPPED_ARROW, waterPotionPatch);

    @SuppressWarnings({"RedundantCast", "unchecked"}) WeightedList.Builder<RandomCountItemStackTemplate> builder =
        (WeightedList.Builder<RandomCountItemStackTemplate>)(WeightedList.Builder<?>)WeightedList.builder();
    return builder
//        .add(new RandomCountItemStackTemplate(Blocks.CUT_COPPER_STAIRS.waxed().exposed().asItem(), ConstantInt.of(1)), 10)
//        .add(new RandomCountItemStackTemplate(Items.ENDER_PEARL, UniformInt.of(2,4)), 10)
//        .add(new RandomCountItemStackTemplate(WATER_BOTTLE, 1), 10)
//        .add(new RandomCountItemStackTemplate(Items.CRYING_OBSIDIAN, UniformInt.of(1,3)), 20)
//        .add(new RandomCountItemStackTemplate(Items.QUARTZ, UniformInt.of(2,8)), 20)
//        .add(new RandomCountItemStackTemplate(Items.GOLD_NUGGET, UniformInt.of(1,5)), 30)
//        .add(new RandomCountItemStackTemplate(Items.BEETROOT_SEEDS, UniformInt.of(1,3)), 30)
//        .add(new RandomCountItemStackTemplate(Items.POTATO, UniformInt.of(2,4)), 30)
//        .add(new RandomCountItemStackTemplate(Items.CHISELED_TUFF_BRICKS, UniformInt.of(6,12)), 40)
//        .add(new RandomCountItemStackTemplate(Items.LEATHER, UniformInt.of(2,8)), 40)
//        .add(new RandomCountItemStackTemplate(Items.NETHER_BRICK, UniformInt.of(2,16)), 40)
//        .add(new RandomCountItemStackTemplate(Items.GRAVEL, UniformInt.of(4,16)), 40)
        .add(new RandomCountItemStackTemplate(Items.BLUE_EGG, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.BROWN_EGG, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.EGG, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.ENDER_PEARL, 2, 4))
        .add(new RandomCountItemStackTemplate(Items.FIRE_CHARGE, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.BEETROOT_SEEDS, 2, 4))
        .add(new RandomCountItemStackTemplate(Items.PITCHER_POD, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.TORCHFLOWER_SEEDS, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.POTATO, 2, 8))
        .add(new RandomCountItemStackTemplate(Items.STRING, 2, 8))
        .add(new RandomCountItemStackTemplate(Items.MELON_SEEDS, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.PUMPKIN_SEEDS, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.ARROW, 2, 16))
        .add(new RandomCountItemStackTemplate(Items.BONE, 2, 4))
        .add(new RandomCountItemStackTemplate(Items.BONE_MEAL, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.BOOK, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.BOWL, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.CHARCOAL, 1, 4))
        .add(new RandomCountItemStackTemplate(Items.COAL, 1, 4))
        .add(new RandomCountItemStackTemplate(Items.COOKED_PORKCHOP, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.COPPER_AXE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.COPPER_HOE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.COPPER_PICKAXE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.COPPER_SHOVEL, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.COPPER_SPEAR, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.COPPER_SWORD, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.GLASS_BOTTLE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.HONEYCOMB, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.HONEY_BOTTLE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.MUSIC_DISC_PIGSTEP, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.NAME_TAG, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.OMINOUS_BOTTLE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.POISONOUS_POTATO, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.PORKCHOP, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.ROTTEN_FLESH, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.SADDLE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.SPECTRAL_ARROW, 2, 8))
        .add(new RandomCountItemStackTemplate(Items.SUGAR, 2, 4))
        .add(new RandomCountItemStackTemplate(ARROW_WATER, 1, 1))
        .add(new RandomCountItemStackTemplate(WATER_BOTTLE, 1, 1))
        .add(new RandomCountItemStackTemplate(WATER_BOTTLE_SPLASH, 1, 1))
        .add(new RandomCountItemStackTemplate(WATER_BOTTLE_LINGERING, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.WARPED_FUNGUS_ON_A_STICK, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.BURN_POTTERY_SHERD, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.FLOW_POTTERY_SHERD, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.FRIEND_POTTERY_SHERD, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.PLENTY_POTTERY_SHERD, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.PRIZE_POTTERY_SHERD, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.CLAY_BALL, 2, 4))
        .add(new RandomCountItemStackTemplate(Items.COPPER_NUGGET, 1, 8))
        .add(new RandomCountItemStackTemplate(Items.FEATHER, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.FLINT, 2, 4))
        .add(new RandomCountItemStackTemplate(Items.GHAST_TEAR, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.GLOWSTONE_DUST, 1, 4))
        .add(new RandomCountItemStackTemplate(Items.GUNPOWDER, 2, 4))
        .add(new RandomCountItemStackTemplate(Items.IRON_NUGGET, 1, 8))
        .add(new RandomCountItemStackTemplate(Items.LEATHER, 2, 4))
        .add(new RandomCountItemStackTemplate(Items.MAGMA_CREAM, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.NETHER_BRICK, 2, 8))
        .add(new RandomCountItemStackTemplate(Items.QUARTZ, 2, 4))
        .add(new RandomCountItemStackTemplate(Items.NETHERITE_SCRAP, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.PAPER, 1, 3))
        .add(new RandomCountItemStackTemplate(Items.SNOUT_ARMOR_TRIM_SMITHING_TEMPLATE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.PIGLIN_BANNER_PATTERN, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.STICK, 2, 16))
        .add(new RandomCountItemStackTemplate(Items.NETHER_WART, 2, 4))
        .add(new RandomCountItemStackTemplate(Items.BLACKSTONE, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.BLACKSTONE_SLAB, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.BLACKSTONE_STAIRS, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.POLISHED_BLACKSTONE, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.POLISHED_BLACKSTONE_SLAB, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.POLISHED_BLACKSTONE_STAIRS, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.POLISHED_BLACKSTONE_BRICKS, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.POLISHED_BLACKSTONE_BRICK_SLAB, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.POLISHED_BLACKSTONE_BRICK_STAIRS, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.CHISELED_POLISHED_BLACKSTONE, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.CRACKED_POLISHED_BLACKSTONE_BRICKS, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.GILDED_BLACKSTONE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.GRAVEL, 2, 16))
        .add(new RandomCountItemStackTemplate(Items.SOUL_SAND, 1, 8))
        .add(new RandomCountItemStackTemplate(Items.SOUL_SOIL, 1, 8))
        .add(new RandomCountItemStackTemplate(Items.NETHERRACK, 2, 16))
        .add(new RandomCountItemStackTemplate(Items.LODESTONE, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.OBSIDIAN, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.CRYING_OBSIDIAN, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.NETHER_BRICKS, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.NETHER_BRICK_STAIRS, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.NETHER_BRICK_FENCE, 1, 2))
        .add(new RandomCountItemStackTemplate(Items.NETHER_WART_BLOCK, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.CAULDRON, 1, 1))
        .add(new RandomCountItemStackTemplate(Items.CHEST, 1, 1))
        .build();
  }

  @Inject(method = "getBarterResponseItems", at = @At("HEAD"), cancellable = true)
  private static void replaceBarterResponseItems(Piglin body, CallbackInfoReturnable<List<ItemStack>> cir) {
    if (Config.CHANGE_PIGLIN_BARTER_LOOT.get()) {
      cir.setReturnValue(
          (rb$itemList == null ? (rb$itemList = rb$generateNewItemList()) : rb$itemList)
              .getRandom(body.getRandom())
              .map(template -> template.create(body.getRandom()))
              .map(Collections::singletonList)
              .orElseGet(Collections::emptyList)
      );
      cir.cancel();
    }
  }

}
