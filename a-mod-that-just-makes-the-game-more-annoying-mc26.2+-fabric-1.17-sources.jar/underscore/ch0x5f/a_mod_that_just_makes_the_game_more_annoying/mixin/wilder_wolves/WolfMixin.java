package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.wilder_wolves;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Wolf.class)
public abstract class WolfMixin {

  @Unique
  private static boolean rb$isDogFood(ItemStack itemStack) {
    return itemStack.is(ItemTags.MEAT) || itemStack.is(Items.BONE);
  }

  @Unique
  private static boolean rb$hasFood(ServerPlayer serverPlayer) {
    return rb$isDogFood(serverPlayer.getMainHandItem()) || rb$isDogFood(serverPlayer.getOffhandItem());
  }

  @ModifyArgs(method = "registerGoals", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/goal/target/NearestAttackableTargetGoal;<init>(Lnet/minecraft/world/entity/Mob;Ljava/lang/Class;IZZLnet/minecraft/world/entity/ai/targeting/TargetingConditions$Selector;)V"))
  private void modifyNearestAttackableTargetGoal(Args args) {
    if (Config.WILDER_WOLVES.get() && args.get(1) == Player.class) {
      TargetingConditions.Selector selector = args.get(5);
      args.set(5, (TargetingConditions.Selector)((entity, level) -> selector.test(entity, level) || entity instanceof ServerPlayer serverPlayer && !rb$hasFood(serverPlayer)));
    }
  }

}
