package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.worse_ores_and_ingots;

import net.minecraft.core.NonNullList;
import net.minecraft.world.item.ItemInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.OresAndIngots;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  @ModifyArgs(method = "serverTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/entity/AbstractFurnaceBlockEntity;burn(Lnet/minecraft/core/NonNullList;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)V"))
  private static void modifyBurnArgs(Args args) {
    if (Config.WORSE_ORES_AND_INGOTS.get()) {
      ItemStack inputItemStack = args.get(1);
      //noinspection unchecked
      if (
          ((NonNullList<ItemStack>)args.get(0)).get(2).isEmpty() &&
          (inputItemStack.is(OresAndIngots.TAG_ORES) || inputItemStack.is(OresAndIngots.TAG_RAW_MATERIALS)) &&
          ((ItemInstance)args.get(2)).is(OresAndIngots.TAG_INGOTS) &&
          Math.random() < 0.25d
      ) {
        ItemStack copied = inputItemStack.copy();
        copied.setCount(1);
        args.set(2, copied);
      }
    }
  }

}
