package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.worse_ores_and_ingots;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.component.PatchedDataComponentMap;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.OresAndIngots;


@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

  @Inject(method = "<init>(Lnet/minecraft/core/Holder;ILnet/minecraft/core/component/PatchedDataComponentMap;)V", at = @At("TAIL"))
  private void postInit(Holder<Item> item, int count, PatchedDataComponentMap components, CallbackInfo ci) {
    if (Config.WORSE_ORES_AND_INGOTS.get() && item.is(OresAndIngots.TAG_INGOTS)) {
      components.applyPatch(DataComponentPatch.builder().set(DataComponents.MAX_STACK_SIZE, 1).build());
    }
  }

}
