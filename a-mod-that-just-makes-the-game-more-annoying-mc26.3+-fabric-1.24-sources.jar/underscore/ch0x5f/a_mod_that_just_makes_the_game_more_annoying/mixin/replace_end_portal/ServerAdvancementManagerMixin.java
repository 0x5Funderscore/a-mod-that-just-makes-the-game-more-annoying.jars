package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_portal;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.advancements.*;
import net.minecraft.advancements.triggers.Criterion;
import net.minecraft.advancements.triggers.ImpossibleTrigger;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.ServerAdvancementManager;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.component.BlockItemStateProperties;
import net.minecraft.world.level.block.Blocks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;


@Mixin(ServerAdvancementManager.class)
public abstract class ServerAdvancementManagerMixin {

  @ModifyExpressionValue(
      method = "<init>",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/core/HolderLookup$RegistryLookup;listElements()Ljava/util/stream/Stream;")
  )
  private Stream<Holder.Reference<Advancement>> addAdvancements(
      Stream<Holder.Reference<Advancement>> original,
      @Local(name = "registries", argsOnly = true) HolderLookup.Provider registries
  ) {
    if (!Config.REPLACE_END_PORTAL.get()) return original;
    Holder.Reference<Advancement> holder = Holder.Reference.createStandAlone(registries.lookupOrThrow(Registries.ADVANCEMENT), ResourceKey.create(Registries.ADVANCEMENT, AMTJMTGMA.FOUND_PORTAL_ROOM_ADVANCEMENT));
    holder.bindValue(new Advancement(
        Optional.of(Identifier.withDefaultNamespace("story/follow_ender_eye")),
        Optional.of(new DisplayInfo(
            new ItemStackTemplate(
                Blocks.TEST_BLOCK.asItem(),
                DataComponentPatch.builder()
                    .set(DataComponents.BLOCK_STATE, new BlockItemStateProperties(Map.of("mode", "fail")))
                    .build()
            ),
            Component.literal("What Portal?"),
            Component.literal("First you have to find The Pickaxe That Can Mine End Portal Frames, in one specific chest in one specific room in a mansion somewhere, and then you have to find 12 portal frames, which spawn occasionally at the bottom of the world under trees"),
            Optional.empty(),
            AdvancementType.TASK,
            true, false, true
        )),
        AdvancementRewards.EMPTY,
        Map.of("complete", new Criterion<>(new ImpossibleTrigger(), new ImpossibleTrigger.TriggerInstance())),
        new AdvancementRequirements(List.of(List.of("complete"))),
        false
    ));
    return Stream.concat(original, Stream.of(holder));
  }
}
