package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.fast_bubble_columns;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Entity.class)
public class EntityMixin {

  @WrapOperation(
      method = {"handleOnInsideBubbleColumn", "handleOnAboveBubbleColumn"},
      at = {
          @At(
              value = "INVOKE",
              target = "Ljava/lang/Math;max(DD)D"
          ),
          @At(
              value = "INVOKE",
              target = "Ljava/lang/Math;min(DD)D"
          )
      }
  )
  private static double wrapMinMax(double a, double b, Operation<Double> original) {
    if (Config.FAST_BUBBLE_COLUMNS.get()) {
      return original.call(a * 4.0, b);
    }
    return original.call(a, b);
  }

}
