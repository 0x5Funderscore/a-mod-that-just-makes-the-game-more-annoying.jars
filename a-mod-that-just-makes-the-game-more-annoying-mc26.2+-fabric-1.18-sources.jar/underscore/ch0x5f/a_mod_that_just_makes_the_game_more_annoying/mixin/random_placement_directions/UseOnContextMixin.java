package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.random_placement_directions;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.IUseOnContextDirectionExtension;


@Mixin(UseOnContext.class)
@Implements(@Interface(iface = IUseOnContextDirectionExtension.class, prefix = "dirExt$"))
public abstract class UseOnContextMixin implements IUseOnContextDirectionExtension {

  @Shadow
  @Final
  private Level level;

  public @NotNull Direction[] dirExt$getRandomNearestLookingDirections() {
    if (rb$nearestLookingDirections == null) this.rb$makeDirections();
    return rb$nearestLookingDirections;
  }

  public @NotNull Direction dirExt$getRandomNearestDirection() {
    if (rb$nearestDirection == null) this.rb$makeDirections();
    return rb$nearestDirection;
  }

  public @NotNull Direction dirExt$getRandomNearestHorizontalDirection() {
    if (rb$nearestHorizontalDirection == null) this.rb$makeDirections();
    return rb$nearestHorizontalDirection;
  }

  public @NotNull Direction dirExt$getRandomNearestVerticalDirection() {
    if (rb$nearestVerticalDirection == null) this.rb$makeDirections();
    return rb$nearestVerticalDirection;
  }

  private @Unique Direction[] rb$nearestLookingDirections = null;
  private @Unique Direction rb$nearestDirection = null;
  private @Unique Direction rb$nearestHorizontalDirection = null;
  private @Unique Direction rb$nearestVerticalDirection = null;

  @Unique
  private void rb$makeDirections() {
    Direction[] directions = Direction.values();
    Direction[] nearestDirectionList = new Direction[directions.length];

    rb$nearestDirection = null;
    rb$nearestHorizontalDirection = null;
    rb$nearestVerticalDirection = null;

    for (int i = 0; i < nearestDirectionList.length; i++) {
      int bound = directions.length - i;
      int picked = (int)(Math.random() * bound);
      Direction pickedDirection = directions[picked];
      nearestDirectionList[i] = pickedDirection;
      directions[picked] = directions[bound - 1];
      if (i == 0) rb$nearestDirection = nearestDirectionList[i];
      if (pickedDirection.getAxis() == Direction.Axis.Y) {
        if (rb$nearestVerticalDirection == null) rb$nearestVerticalDirection = pickedDirection;
      } else {
        if (rb$nearestHorizontalDirection == null) rb$nearestHorizontalDirection = pickedDirection;
      }
    }
    rb$nearestLookingDirections = nearestDirectionList;
  }

  @ModifyReturnValue(method = "getHorizontalDirection", at = @At("TAIL"))
  private Direction replaceHorizontalDirection(Direction original) {
    if (Config.RANDOM_PLACEMENT_DIRECTIONS.get() && !this.level.isClientSide()) {
      return this.getRandomNearestHorizontalDirection();
    }
    return original;
  }
}
