package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.popup_ads;

import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.Nullable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;

import java.util.List;
import java.util.function.ToDoubleFunction;


public class AdSense {

  private static final List<SmartAd> adPool = List.of(
      new SmartAd(
          PopupAd.template(
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/sleep_bottom.png"),
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/sleep_top.png"),
              160, 120
          ),
          adSense -> adSense.player.level().isDarkOutside() ? 2.0 : 0.2
      ),
      new SmartAd(
          PopupAd.template(
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/mine_bottom.png"),
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/mine_top.png"),
              150, 100
          ),
          adSense -> {
            ResourceKey<Level> dimension = adSense.player.level().dimension();
            if (dimension.identifier().equals(Level.OVERWORLD.identifier())) {
              return adSense.player.getY() <= 63.0 ? 2.0 : 1.0;
            } else if (dimension.identifier().equals(Level.END.identifier())) {
              return 0.25;
            }
            return 1.0;
          }
      ),
      new SmartAd(
          PopupAd.template(
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/moviesfree_bottom.png"),
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/moviesfree_top.png"),
              200, 64
          ),
          adSense -> 1.0
      ),
      new SmartAd(
          PopupAd.template(
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/horse_bottom.png"),
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/horse_top.png"),
              166, 141
          ),
          adSense -> adSense.player.level().getEntitiesOfClass(AbstractHorse.class, AABB.ofSize(adSense.player.getEyePosition(), 16.0, 16.0, 16.0)).isEmpty() ? 0.5 : 2.0
      ),
      new SmartAd(
          PopupAd.template(
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/call_bottom.png"),
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/call_top.png"),
              128, 128
          ),
          adSense -> 1.0
      ),
      new SmartAd(
          PopupAd.template(
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/inven_bottom.png"),
              Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/inven_top.png"),
              240, 80
          ),
          adSense -> {
            if (adSense.player.isDeadOrDying()) adSense.recentlyDied = true;
            else if (adSense.recentlyDied) {
              if (adSense.player.tickCount > 200) adSense.recentlyDied = false;
              else return 500.0;
            }
            return 0.0;
          }
      )
  );

  private Player player;
  public boolean recentlyDied = false;

  public AdSense(Player player) {
    this.player = player;
  }

  public void setPlayer(Player player) {
    this.player = player;
  }

  public boolean checkPlayer(Player player) {
    if (player == this.player) return true;
    this.player = player;
    return false;
  }

  public @Nullable PopupAd pickAd(double nothingWeight) {

    if (this.player == null) return null;

    double totalWeight = 0.0;
    double[] weights = new double[adPool.size()];

    for (int i = 0, adPoolSize = adPool.size(); i < adPoolSize; i++) {
      SmartAd ad = adPool.get(i);

      double weight = ad.weightFunction.applyAsDouble(this);
      totalWeight += weight;
      weights[i] = weight;
    }

    if (totalWeight <= 0.0) return null;
    totalWeight += nothingWeight;

    double weightRandom = Math.random() * totalWeight;
    for (int i = 0; i < weights.length; i++) {
      weightRandom -= weights[i];
      if (weightRandom <= 0.0) return adPool.get(i).ad;
    }
    return null;
  }

  public record SmartAd(PopupAd ad, ToDoubleFunction<AdSense> weightFunction) {
  }

}
