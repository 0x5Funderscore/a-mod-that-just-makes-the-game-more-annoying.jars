package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.popup_ads;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;

import java.util.Objects;


public final class PopupAd {
  public final Identifier texture;
  public final float cx;
  public final float cy;
  public final int width;
  public final int height;
  public float destroyProgress;

  public PopupAd(
      Identifier texture,
      float cx,
      float cy,
      int width,
      int height,
      float destroyProgress
  ) {
    this.texture = texture;
    this.cx = cx;
    this.cy = cy;
    this.width = width;
    this.height = height;
    this.destroyProgress = destroyProgress;
  }

  public static PopupAd template(Identifier texture, int width, int height) {
    return new PopupAd(texture, 0f, 0f, width, height, 0f);
  }

  public PopupAd randomize() {
    return new PopupAd(
        this.texture,
        (float)Math.random(),
        (float)Math.random(),
        this.width,
        this.height,
        0f
    );
  }

  public void render(GuiGraphicsExtractor graphics) {
    int scx = (int)(graphics.guiWidth() * this.cx);
    int scy = (int)(graphics.guiHeight() * this.cy);
    int x0 = scx - this.width / 2;
    int y0 = scy - this.height / 2;
    graphics.blit(RenderPipelines.GUI_TEXTURED, this.texture, x0, y0, 0, 0, this.width, this.height, this.width, this.height);

    int destroyTexture = (int)(this.destroyProgress * 11f) - 1;
    if (destroyTexture >= 0) {
      graphics.blit(RenderPipelines.GUI_TEXTURED, Identifier.withDefaultNamespace("textures/block/destroy_stage_" + destroyTexture + ".png"), x0, y0, -x0, -y0, this.width, this.height, 16, 16);
//      graphics.blit(RenderPipelines.GUI_TEXTURED, Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/break/destroy_stage_" + destroyTexture + ".png"), x0, y0, -x0, -y0, this.width, this.height, 16, 16);
    }
  }

}
