package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.popup_ads;

import it.unimi.dsi.fastutil.ints.IntList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Blocks;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.popup_ads.PopupAd;

import java.util.ArrayList;
import java.util.List;


@Mixin(Hud.class)
@Environment(EnvType.CLIENT)
public class HudMixin {

  /*
  @Shadow
  @Final
  private Minecraft minecraft;

  @Unique
  private final List<PopupAd> rb$ads = new ArrayList<>();

  @Unique
  private static final List<PopupAd> rb$adPool = List.of(
      PopupAd.template(Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "textures/ad/1.png"), 128, 96)
  );

  @Unique
  private float rb$timer = 0.0f;

  @Inject(method = "extractRenderState", at = @At("TAIL"))
  private void postExtractRenderState(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker, CallbackInfo ci) {
    if (Config.POPUP_ADS.get() && this.minecraft.gameMode != null) {

      float dt = deltaTracker.getRealtimeDeltaTicks();

      if (!this.minecraft.isPaused()) {
        this.rb$timer += dt;
        if (this.rb$timer > 5f) {
          this.rb$timer %= 5f;
          if (Math.random() < (this.rb$ads.isEmpty() ? 0.0005 : 0.125)) {
            this.rb$ads.add(rb$adPool.get((int)(Math.random() * rb$adPool.size())).randomize());
            if (this.rb$ads.size() >= 5) {
              this.rb$timer -= 100f;
            }
          }
        }
      }

      MultiPlayerGameMode gameMode = this.minecraft.gameMode;
      boolean destroying = gameMode == null || gameMode.isDestroying();
      float destroySpeed = minecraft.player == null ? 1.0f : minecraft.player.getDestroySpeed(Blocks.AIR.defaultBlockState());

      for (int i = 0; i < this.rb$ads.size(); i++) {
        PopupAd ad = this.rb$ads.get(i);
        if (destroying) ad.destroyProgress += dt / 100f * destroySpeed;
        if (ad.destroyProgress >= 1.0f) {
          this.rb$ads.remove(i--);
        } else {
          ad.render(graphics);
        }
      }
    } else {
      this.rb$ads.clear();
    }
  }
  */

}
