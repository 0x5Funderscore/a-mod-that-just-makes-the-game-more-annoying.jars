package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.you_block_origin;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Item.class)
public class ItemMixin {

  @Inject(
      method = "use",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/item/ItemStack;get(Lnet/minecraft/core/component/DataComponentType;)Ljava/lang/Object;",
          ordinal = 0
      )
  )
  private void injectUse(
      Level level, Player player, InteractionHand hand,
      CallbackInfoReturnable<InteractionResult> cir,
      @Local(name = "stack") ItemStack stack
  ) {
    if (Config.YOU_BLOCK_ORIGIN.get()) {
      CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
      if (customData != null) {
        if (customData.copyTag().getBooleanOr("you_block_origin", false)) {
          if (player instanceof ServerPlayer serverPlayer) {
            serverPlayer.connection.disconnect(Component.translatable("multiplayer.disconnect.banned"));
          }
        }
      }
    }
  }

}
