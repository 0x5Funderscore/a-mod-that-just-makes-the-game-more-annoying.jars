package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.twitch_integration;

import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchIntegration;

import java.util.function.BooleanSupplier;


@Mixin(MinecraftServer.class)
public class MinecraftServerMixin {

  @Unique
  private boolean rb$initTwitchIntegration = false;

  @Inject(method = "close", at = @At("HEAD"))
  private void preClose(CallbackInfo ci) {
    if (Config.TWITCH_INTEGRATION__EXPERIMENTAL.get()) {
      TwitchIntegration.INSTANCE.stop((MinecraftServer)(Object)this);
    }
  }

  @Inject(method = "tickServer", at = @At("HEAD"))
  private void preTick(BooleanSupplier haveTime, CallbackInfo ci) {
    if (Config.TWITCH_INTEGRATION__EXPERIMENTAL.get()) {
      if (!rb$initTwitchIntegration) {
        TwitchIntegration.INSTANCE.start((MinecraftServer)(Object)this);
        rb$initTwitchIntegration = true;
      }
      TwitchIntegration.INSTANCE.tick((MinecraftServer)(Object)this);
    }
  }

}
