package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin._global;

import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.screens.TwitchIntegrationScreen;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.screens.ConfigOptionsScreen;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.twitch_integration.TwitchIntegrationClient;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.ConnectionStatus;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchIntegrationConnector;


@Mixin(TitleScreen.class)
@Environment(EnvType.CLIENT)
public abstract class TitleScreenMixin extends Screen {

  @Unique
  private SpriteIconButton rb$twitchButton;

  protected TitleScreenMixin(Component title) {
    super(title);
  }

  @Inject(method = "init", at = @At("TAIL"))
  private void initExtraButtons(
      CallbackInfo ci,
      @Local(name = "topPos") int topPos
  ) {
    SpriteIconButton optionsButton = SpriteIconButton.builder(
        Component.literal("Ragebait Options..."),
        button -> this.minecraft.setScreenAndShow(new ConfigOptionsScreen()),
        true
    )
        .size(20, 20)
        .sprite(Identifier.withDefaultNamespace("toast/tree"), 20, 20)
        .build();
    optionsButton.setTooltip(Tooltip.create(Component.literal("Ragebait Options")));
    this.addRenderableWidget(optionsButton).setPosition(this.width / 2 + 104, topPos);

    if (Config.TWITCH_INTEGRATION__EXPERIMENTAL.get()) {
      this.rb$twitchButton = SpriteIconButton.builder(
          Component.literal("Twitch integration"),
          button -> this.minecraft.setScreenAndShow(new TwitchIntegrationScreen()),
          true
      )
          .size(20, 20)
          .sprite(Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "twitch"), 12, 12)
          .build();
      rb$twitchButton.setTooltip(Tooltip.create(Component.literal("Twitch Integration")));
      this.addRenderableWidget(rb$twitchButton).setPosition(this.width / 2 + 128, topPos);
    }
  }

  @Inject(method = "extractRenderState", at = @At("TAIL"))
  private void afterExtractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a, CallbackInfo ci) {
    if (this.rb$twitchButton != null && TwitchIntegrationConnector.INSTANCE.getStatus() == ConnectionStatus.CONNECTED) {
      graphics.blitSprite(
          RenderPipelines.GUI_TEXTURED,
          TwitchIntegrationClient.CONNECTED_OUTLINE_SPRITE,
          this.rb$twitchButton.getX(),
          this.rb$twitchButton.getY(),
          this.rb$twitchButton.getWidth(),
          this.rb$twitchButton.getHeight(),
          this.rb$twitchButton.getAlpha()
      );
    }
  }

}
