package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.mixin.bedrock_title_screen;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.gui.screens.RealmsNotificationsScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.CreditsAndAttributionScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.friends.FriendsOverlayScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.SafetyScreen;
import net.minecraft.client.gui.screens.options.OnlineOptionsScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.entity.player.PlayerSkin;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.bedrock_menu.BedrockButton;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.screens.ConfigOptionsScreen;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.screens.TwitchIntegrationScreen;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.twitch_integration.TwitchIntegrationClient;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.ConnectionStatus;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.twitch_integration.TwitchIntegrationConnector;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;


@Mixin(TitleScreen.class)
@Environment(EnvType.CLIENT)
public abstract class TitleScreenMixin extends Screen {

  @Shadow
  private @Nullable RealmsNotificationsScreen realmsNotificationsScreen;

  protected TitleScreenMixin(Component title) {
    super(title);
  }

  @Shadow
  protected abstract boolean realmsNotificationsEnabled();

  @Shadow
  private @Nullable SplashRenderer splash;

  @Shadow
  @Nullable
  protected abstract Component getMultiplayerDisabledReason();

  @Unique
  private int rb$paperDollX;
  @Unique
  private int rb$paperDollY;

  @Inject(method = "init", at = @At("HEAD"), cancellable = true, order = 0)
  private void preInit(CallbackInfo ci) {
    if (Config.BEDROCK_TITLE_SCREEN.get() && !this.minecraft.isDemo()) {
      LogUtils.getLogger().warn("bedrock_menu is enabled. If the game crashes while rendering the title screen, try disabling it.");

      if (this.splash == null) {
        this.splash = this.minecraft.gui.splashManager().getSplash();
      }

      int resetX = 5;
      int resetY = 5;
      int resetWidth = 78;
      int resetHeight = 24;
      this.addRenderableWidget(new BedrockButton(
          resetX, resetY,
          resetWidth, resetHeight,
          Component.translatable("controls.reset"),
          (button) -> {
            Config.BEDROCK_TITLE_SCREEN.set(false);
            Config.saveConfig();
            this.minecraft.gui.setScreen(new TitleScreen(true));
          },
          Button.DEFAULT_NARRATION,
          false
      )).setTooltip(Tooltip.create(Component.literal("Disable bedrock_title_screen and load the vanilla menu")));

      int numButtons = 5;

      int buttonWidth = 148;
      int buttonX = this.width / 2 - buttonWidth / 2;

      int buttonHeight = 30;
      int buttonFullHeight = 32;
      int buttonsCenterY = (72 + this.height) / 2;
      int buttonY = buttonsCenterY - numButtons * 16;

      this.addRenderableWidget(new BedrockButton(
          buttonX, buttonY, buttonWidth, buttonHeight,
          Component.translatable("menu.singleplayer"),
          (button) -> this.minecraft.gui.setScreen(new SelectWorldScreen(this)),
          Button.DEFAULT_NARRATION,
          false
      ));

      buttonY += buttonFullHeight;

      Component multiplayerDisabledReason = this.getMultiplayerDisabledReason();
      boolean multiplayerAllowed = multiplayerDisabledReason == null;

      if (multiplayerAllowed) {
        this.addRenderableWidget(new BedrockButton(
            buttonX, buttonY, buttonWidth, buttonHeight,
            Component.translatable("menu.multiplayer"),
            (button) -> {
              Screen screen = (Screen)(this.minecraft.options.skipMultiplayerWarning ? new JoinMultiplayerScreen(this) : new SafetyScreen(this));
              this.minecraft.gui.setScreen(screen);
            },
            Button.DEFAULT_NARRATION,
            false
        ));
      }
      buttonY += buttonFullHeight;

      this.addRenderableWidget(new BedrockButton(
          buttonX, buttonY, buttonWidth, buttonHeight,
          Component.translatable("options.title"),
          (button) -> this.minecraft.gui.setScreen(new OptionsScreen(this, this.minecraft.options)),
          Button.DEFAULT_NARRATION,
          false
      ));

      buttonY += buttonFullHeight;

      if (multiplayerAllowed) {
        this.addRenderableWidget(new BedrockButton(
            buttonX, buttonY, buttonWidth, buttonHeight,
            Component.translatable("menu.online"),
            (button) -> this.minecraft.gui.setScreen(new RealmsMainScreen(this)),
            Button.DEFAULT_NARRATION,
            true
        ));
      }

      buttonY += buttonFullHeight;

      this.addRenderableWidget(new BedrockButton(
          buttonX, buttonY, buttonWidth, buttonHeight,
          Component.translatable("menu.quit"),
          (button) -> this.minecraft.stop(),
          Button.DEFAULT_NARRATION,
          false
      ));

      this.rb$initExtraButtons(buttonX + buttonWidth + 4, buttonY + buttonHeight / 2 - 10);

      rb$paperDollX = (buttonX + buttonWidth + this.width) / 2;
      rb$paperDollY = buttonsCenterY;

      int socialX = this.width - 83;
      int socialY = 5;
      int socialWidth = 78;
      int socialHeight = 24;
      this.addRenderableWidget(new BedrockButton(
          socialX, socialY,
          socialWidth, socialHeight,
          Component.translatable("gui.friends.open"),
          (button) -> OnlineOptionsScreen.confirmFriendsListEnabled(this.minecraft, () -> this.minecraft.gui.setScreen(new FriendsOverlayScreen(this)), this),
          Button.DEFAULT_NARRATION,
          false
      ));

      int copyrightWidth = this.font.width(TitleScreen.COPYRIGHT_TEXT);
      int copyrightX = this.width - copyrightWidth - 2;
      this.addRenderableWidget(new PlainTextButton(copyrightX, this.height - 10, copyrightWidth, 10, TitleScreen.COPYRIGHT_TEXT, (var1) -> this.minecraft.gui.setScreen(new CreditsAndAttributionScreen(this)), this.font));

      if (this.realmsNotificationsScreen == null) {
        this.realmsNotificationsScreen = new RealmsNotificationsScreen();
      }

      if (this.realmsNotificationsEnabled()) {
        this.realmsNotificationsScreen.init(this.width, this.height);
      }

      ci.cancel();
    }
  }

  @Unique
  private SpriteIconButton rb$twitchButtonBedrock;

  @Unique
  private void rb$initExtraButtons(int x, int topPos) {

    SpriteIconButton optionsButton = SpriteIconButton.builder(
            Component.literal("Ragebait Options..."),
            button -> this.minecraft.setScreenAndShow(new ConfigOptionsScreen()),
            true
        )
        .size(20, 20)
        .sprite(Identifier.withDefaultNamespace("toast/tree"), 20, 20)
        .build();
    optionsButton.setTooltip(Tooltip.create(Component.literal("Ragebait Options")));
    this.addRenderableWidget(optionsButton).setPosition(x, topPos);

    if (Config.TWITCH_INTEGRATION__EXPERIMENTAL.get()) {
      this.rb$twitchButtonBedrock = SpriteIconButton.builder(
              Component.literal("Twitch integration"),
              button -> this.minecraft.setScreenAndShow(new TwitchIntegrationScreen()),
              true
          )
          .size(20, 20)
          .sprite(Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "twitch"), 12, 12)
          .build();
      rb$twitchButtonBedrock.setTooltip(Tooltip.create(Component.literal("Twitch Integration")));
      this.addRenderableWidget(rb$twitchButtonBedrock).setPosition(x + 24, topPos);
    }

  }

  @WrapOperation(method = "extractRenderState", at = @At(value = "INVOKE", target = "Lcom/mojang/realmsclient/gui/screens/RealmsNotificationsScreen;extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIF)V"))
  private void wrapRealmsExtractRenderState(RealmsNotificationsScreen instance, GuiGraphicsExtractor graphics, int xm, int ym, float a, Operation<Void> original) {
    if (Config.BEDROCK_TITLE_SCREEN.get()) return;
    original.call(instance, graphics, xm, ym, a);
  }

  @Inject(method = "extractRenderState", at = @At("TAIL"))
  private void afterExtractRenderState(
      GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a, CallbackInfo ci,
      @Local(name = "widgetFade") float widgetFade
  ) {
    if (Config.BEDROCK_TITLE_SCREEN.get() && !this.minecraft.isDemo()) {

      if (this.rb$twitchButtonBedrock != null && TwitchIntegrationConnector.INSTANCE.getStatus() == ConnectionStatus.CONNECTED) {
        graphics.blitSprite(
            RenderPipelines.GUI_TEXTURED,
            TwitchIntegrationClient.CONNECTED_OUTLINE_SPRITE,
            this.rb$twitchButtonBedrock.getX(),
            this.rb$twitchButtonBedrock.getY(),
            this.rb$twitchButtonBedrock.getWidth(),
            this.rb$twitchButtonBedrock.getHeight(),
            this.rb$twitchButtonBedrock.getAlpha()
        );
      }

      this.rb$extractPaperDoll(graphics, mouseX, mouseY, a, widgetFade);

    }
  }

  @Unique
  private AvatarRenderState rb$paperDollRenderState;

  @Unique
  private static CompletableFuture<Optional<PlayerSkin>> rb$playerSkinLookup = null;

  @Unique
  private static PlayerSkin rb$playerSkin = null;

  @Unique
  private static boolean rb$paperDollReady = false;

  @Unique
  private static double rb$easeOutBack(double x) {
    final double c1 = 1.70158;
    final double c3 = c1 + 1.0;
    return 1.0 + c3 * Math.pow(x - 1.0, 3.0) + c1 * Math.pow(x - 1.0, 2.0);
  }

  @Unique
  private void rb$extractPaperDoll(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a, float alpha) {

    if (rb$playerSkinLookup == null) {
      rb$playerSkinLookup = new CompletableFuture<>();
      new Thread(() -> rb$playerSkinLookup.complete(this.minecraft.getSkinManager().get(this.minecraft.getGameProfile()).join())).start();
    } else if (rb$playerSkinLookup.isDone()) {
      try {
        Optional<PlayerSkin> result = rb$playerSkinLookup.get();
        if (result.isPresent()) {
          rb$playerSkin = result.get();
          rb$paperDollReady = true;
        }
      } catch (InterruptedException | ExecutionException e) {
        rb$paperDollReady = false;
      }
    }

    if (rb$paperDollReady) {

      if (rb$playerSkin == null) {
        rb$playerSkin = DefaultPlayerSkin.get(this.minecraft.getGameProfile());
      }

      if (this.rb$paperDollRenderState == null) {
        this.rb$paperDollRenderState = new AvatarRenderState();
        this.rb$paperDollRenderState.entityType = EntityTypes.PLAYER;
        this.rb$paperDollRenderState.bodyRot = 0f;
        this.rb$paperDollRenderState.skin = rb$playerSkin;
      }
      this.rb$paperDollRenderState.ageInTicks += a;

      this.rb$paperDollRenderState.xRot = Math.clamp((float)Math.toDegrees(Math.atan((double)(mouseY - this.rb$paperDollY) / 500f)), -60f, 60f);
      this.rb$paperDollRenderState.yRot = Math.clamp((float)Math.toDegrees(Math.atan((double)(this.rb$paperDollX - mouseX) / 500f)), -60f, 60f);

      this.rb$paperDollRenderState.showHat = this.minecraft.options.isModelPartEnabled(PlayerModelPart.HAT);
      this.rb$paperDollRenderState.showJacket = this.minecraft.options.isModelPartEnabled(PlayerModelPart.JACKET);
      this.rb$paperDollRenderState.showLeftPants = this.minecraft.options.isModelPartEnabled(PlayerModelPart.LEFT_PANTS_LEG);
      this.rb$paperDollRenderState.showRightPants = this.minecraft.options.isModelPartEnabled(PlayerModelPart.RIGHT_PANTS_LEG);
      this.rb$paperDollRenderState.showLeftSleeve = this.minecraft.options.isModelPartEnabled(PlayerModelPart.LEFT_SLEEVE);
      this.rb$paperDollRenderState.showRightSleeve = this.minecraft.options.isModelPartEnabled(PlayerModelPart.RIGHT_SLEEVE);
      this.rb$paperDollRenderState.showCape = this.minecraft.options.isModelPartEnabled(PlayerModelPart.CAPE);

      float scale = 1f;
      if (alpha <= 0.5f) scale = 0f;
      else if (alpha < 1f) scale = (float)rb$easeOutBack(alpha * 2f - 1f);

      if (scale > 0f) {
        graphics.entity(
            rb$paperDollRenderState,
            50f * scale,
            new Vector3f(0f, 2f - scale, 0f),
            new Quaternionf().rotationXYZ(0.174532925f, (float)Math.PI, (float)Math.PI),
            null,
            this.rb$paperDollX - 64,
            this.rb$paperDollY - 64,
            this.rb$paperDollX + 64,
            this.rb$paperDollY + 64
        );
      }

    }
  }

}
