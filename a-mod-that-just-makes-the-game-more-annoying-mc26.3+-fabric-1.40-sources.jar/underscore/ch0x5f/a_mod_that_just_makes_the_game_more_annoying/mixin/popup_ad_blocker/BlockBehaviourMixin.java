package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.mixin.popup_ad_blocker;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.ByteTag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.AMTJMTGMA;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.stream.Stream;


@Mixin(BlockBehaviour.class)
public abstract class BlockBehaviourMixin {

  @Inject(method = "useItemOn", at = @At("HEAD"), cancellable = true)
  private void preUseItemOn(ItemStack itemStack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult, CallbackInfoReturnable<InteractionResult> cir) {
    if (Config.POPUP_AD_BLOCKER.get()) {

      if (itemStack.is(Items.REDSTONE) && state.is(Blocks.BUDDING_AMETHYST)) {

        if (!player.hasInfiniteMaterials()) {
          itemStack.shrink(1);
        }

        ItemStack adBlockerItemStack = new ItemStack(Items.GLOBE_BANNER_PATTERN);
        adBlockerItemStack.remove(DataComponents.PROVIDES_BANNER_PATTERNS);

        CompoundTag customDataTag = new CompoundTag();
        customDataTag.putBoolean("blocks_ads", true);

        adBlockerItemStack.applyComponents(DataComponentPatch.builder()
                .set(DataComponents.CUSTOM_DATA, CustomData.of(customDataTag))
                .set(DataComponents.ITEM_MODEL, Identifier.fromNamespaceAndPath(AMTJMTGMA.MOD_ID, "noad"))
                .set(DataComponents.ITEM_NAME, Component.literal("No Ad™"))
            .build()
        );

        Block.popResource(level, pos, adBlockerItemStack);

        level.destroyBlock(pos, false);

        cir.setReturnValue(InteractionResult.SUCCESS);
        cir.cancel();
      }

    }
  }

}
