package underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.client.options_screen;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.AbstractGameRulesScreen;
import net.minecraft.network.chat.*;
import net.minecraft.util.FormattedCharSequence;
import org.jspecify.annotations.Nullable;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.ch0x5f.a_mod_that_just_makes_the_game_more_annoying.ConfigProperty;

import java.util.*;


public class ConfigOptionsScreen extends Screen {

  private static final Component TITLE = Component.translatable("ragebait_options.title");
  private static final Component WARNING = Component.translatable("ragebait_options.warning").withStyle(ChatFormatting.GOLD);
  private static final Component INFO = Component.translatable("ragebait_options.info").withStyle(ChatFormatting.GOLD);
  private static final Component SEARCH_HINT = Component.translatable("gui.game_rule.search").withStyle(EditBox.SEARCH_HINT_STYLE);
  private static final int SEARCH_BOX_HEIGHT = 15;

  private final HeaderAndFooterLayout layout;
  private ConfigList configList;
  private EditBox searchBox;

  public ConfigOptionsScreen() {
    super(TITLE);
    this.layout = new HeaderAndFooterLayout(this, 12 + 9 + SEARCH_BOX_HEIGHT, 33);
  }

  protected void createAndConfigureSearchBox(final LinearLayout headerLayout) {
    this.searchBox = headerLayout.addChild(new EditBox(this.font, 200, 15, Component.empty()));
    this.searchBox.setHint(SEARCH_HINT);
    this.searchBox.setResponder(this::filterOptions);
  }

  @Override
  protected void init() {
    LinearLayout header = this.layout.addToHeader(LinearLayout.vertical().spacing(4));
    header.defaultCellSetting().alignHorizontallyCenter();
    header.addChild(new StringWidget(TITLE, this.font));
    this.createAndConfigureSearchBox(header);
    this.initContent();
    LinearLayout footer = this.layout.addToFooter(LinearLayout.horizontal().spacing(8));
    footer.addChild(Button.builder(Component.translatable("controls.reset"), (button) -> Config.forEach(configProperty -> configProperty.set(configProperty.getDefault()))).build());
    footer.addChild(Button.builder(CommonComponents.GUI_DONE, (button) -> this.done()).build());
    this.layout.visitWidgets(this::addRenderableWidget);
    this.repositionElements();
  }

  protected void initContent() {
    this.configList = this.layout.addToContents(new ConfigList());
  }

  protected void done() {
    super.onClose();
  }

  @Override
  protected void repositionElements() {
    this.layout.arrangeElements();
    if (this.configList != null) {
      this.configList.updateSize(this.width, this.layout);
    }
  }

  private void filterOptions(String filter) {
    if (this.configList != null) {
      this.configList.populateChildren(filter);
      this.configList.setScrollAmount(0f);
      this.repositionElements();
    }
  }

  @Override
  public void tick() {
    super.tick();
  }

  public abstract static class ConfigAnyEntry extends ContainerObjectSelectionList.Entry<ConfigAnyEntry> {
    private final @Nullable List<FormattedCharSequence> tooltip;

    public ConfigAnyEntry(final @Nullable List<FormattedCharSequence> tooltip) {
      this.tooltip = tooltip;
    }
  }

  public class CategoryEntry extends ConfigAnyEntry {
    private final FocusableTextWidget widget;

    public CategoryEntry(final Component label) {
      super(null);
      this.widget = FocusableTextWidget.builder(label, ConfigOptionsScreen.this.minecraft.font).alwaysShowBorder(false).backgroundFill(FocusableTextWidget.BackgroundFill.ON_FOCUS).maxWidth(224).build();
    }

    public void extractContent(final GuiGraphicsExtractor graphics, final int mouseX, final int mouseY, final boolean hovered, final float a) {
      this.widget.setPosition(this.getContentXMiddle() - this.widget.getWidth() / 2, this.getContentYMiddle() - this.widget.getHeight() / 2);
      this.widget.extractRenderState(graphics, mouseX, mouseY, a);
    }

    public List<? extends GuiEventListener> children() {
      return List.of(this.widget);
    }

    public List<? extends NarratableEntry> narratables() {
      return List.of(this.widget);
    }
  }

  public class OptionEntry extends ConfigAnyEntry {
    private final ConfigProperty configProperty;

    private final List<FormattedCharSequence> label;
    protected final List<AbstractWidget> children;
    private final CycleButton<Boolean> checkbox;

    public OptionEntry(ConfigProperty configProperty, final List<FormattedCharSequence> tooltip, final Component label) {
      super(tooltip);
      this.configProperty = configProperty;
      this.children = Lists.newArrayList();
      this.label = ConfigOptionsScreen.this.minecraft.font.split(label, 170);
      this.checkbox = CycleButton.onOffBuilder(configProperty.get()).displayOnlyValue().withCustomNarration((button) -> button.createDefaultNarrationMessage().append("\n").append(configProperty.getDescription())).create(10, 5, 44, 20, Component.literal(configProperty.getName()), (button, newValue) -> configProperty.set(newValue));
      this.children.add(this.checkbox);
    }

    public List<? extends GuiEventListener> children() {
      return this.children;
    }

    public List<? extends NarratableEntry> narratables() {
      return this.children;
    }

    protected void extractLabel(final GuiGraphicsExtractor graphics, final int rowTop, final int rowLeft) {
      if (this.label.size() == 1) {
        graphics.text(ConfigOptionsScreen.this.minecraft.font, this.label.get(0), rowLeft, rowTop + 5, -1);
      } else if (this.label.size() >= 2) {
        graphics.text(ConfigOptionsScreen.this.minecraft.font, this.label.get(0), rowLeft, rowTop, -1);
        graphics.text(ConfigOptionsScreen.this.minecraft.font, this.label.get(1), rowLeft, rowTop + 10, -1);
      }

    }

    public void extractContent(final GuiGraphicsExtractor graphics, final int mouseX, final int mouseY, final boolean hovered, final float a) {
      this.extractLabel(graphics, this.getContentY(), this.getContentX());
      this.checkbox.setX(this.getContentRight() - 45);
      this.checkbox.setY(this.getContentY());
      this.checkbox.extractRenderState(graphics, mouseX, mouseY, a);
    }
  }

  public class ConfigList extends ContainerObjectSelectionList<ConfigAnyEntry> {
    public ConfigList() {
      super(Minecraft.getInstance(), ConfigOptionsScreen.this.width, ConfigOptionsScreen.this.layout.getContentHeight(), ConfigOptionsScreen.this.layout.getHeaderHeight(), 24);
      this.populateChildren("");
    }

    private void populateChildren(final String filter) {
      this.clearEntries();
      final String lowerCaseFilter = filter.toLowerCase(Locale.ROOT);

      Map<String,Map<ConfigProperty,OptionEntry>> entries = new HashMap<>();

      Config.forEach(configProperty -> {

        if (configProperty.getName().toLowerCase(Locale.ROOT).contains(lowerCaseFilter) || configProperty.getDescription().toLowerCase(Locale.ROOT).contains(lowerCaseFilter)) {

          Component name = Component.literal(configProperty.getName());
          Component description = Component.literal(configProperty.getDescription());

          Component defaultValue = Component.translatable("editGamerule.default", Component.literal(configProperty.get() ? "ON" : "OFF")).withStyle(ChatFormatting.GRAY);

          List<FormattedCharSequence> descriptionLines = ConfigOptionsScreen.this.font.split(description, 150);

          List<FormattedCharSequence> tooltip = ImmutableList.<FormattedCharSequence>builder()
              .add(Component.literal(configProperty.getName()).withStyle(ChatFormatting.YELLOW).getVisualOrderText())
              .add(defaultValue.getVisualOrderText())
              .addAll(descriptionLines)
              .build();

          entries
              .computeIfAbsent(configProperty.getSide(), key -> new HashMap<>())
              .put(configProperty, new OptionEntry(configProperty, tooltip, name));
        }
      });

      this.addEntry(new CategoryEntry(WARNING));
      this.addEntry(new CategoryEntry(INFO));

      entries.entrySet()
          .stream()
          .sorted(Map.Entry.comparingByKey())
          .forEach((entry) -> {
            this.addEntry(
                new CategoryEntry(
                    Component.literal(entry.getKey())
                        .withStyle(ChatFormatting.BOLD, ChatFormatting.YELLOW)
                )
            );
            entry.getValue().entrySet()
                .stream()
                .sorted(Comparator.comparing(e -> e.getKey().getName()))
                .forEach(e -> this.addEntry(e.getValue()));
          });
    }

    @Override
    public void extractWidgetRenderState(final GuiGraphicsExtractor graphics, final int mouseX, final int mouseY, final float a) {
      super.extractWidgetRenderState(graphics, mouseX, mouseY, a);
      ConfigAnyEntry hovered = this.getHovered();
      if (hovered != null && hovered.tooltip != null) {
        graphics.setTooltipForNextFrame(hovered.tooltip, mouseX, mouseY);
      }
    }
  }
}
